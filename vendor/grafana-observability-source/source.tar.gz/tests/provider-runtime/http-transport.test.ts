import assert from "node:assert/strict";
import { execFileSync, spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { createServer as createHttpsServer } from "node:https";
import type { AddressInfo } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test, { type TestContext } from "node:test";

import type { TrustedEndpoint } from "../../packages/contracts/src/index.ts";
import {
  NodeTrustedHttpClient,
  RuntimeTransportError,
  classifyNetworkAddress,
  type RuntimeDnsResolver,
} from "../../packages/provider-runtime/src/index.ts";

test("network address classification distinguishes loopback, private, public, and forbidden ranges", () => {
  assert.equal(classifyNetworkAddress("127.0.0.1"), "loopback");
  assert.equal(classifyNetworkAddress("::1"), "loopback");
  assert.equal(classifyNetworkAddress("10.20.30.40"), "private");
  assert.equal(classifyNetworkAddress("fd00::1"), "private");
  assert.equal(classifyNetworkAddress("8.8.8.8"), "public");
  assert.equal(classifyNetworkAddress("169.254.169.254"), "forbidden");
  assert.equal(classifyNetworkAddress("192.0.2.10"), "forbidden");
  assert.equal(classifyNetworkAddress("64:ff9b::7f00:1"), "forbidden");
  assert.equal(classifyNetworkAddress("64:ff9b:1::a9fe:a9fe"), "forbidden");
  assert.equal(classifyNetworkAddress("2002:7f00:1::1"), "forbidden");
  assert.equal(classifyNetworkAddress("2001:0000:4136:e378:8000:63bf:3fff:fdd2"), "forbidden");
});

const resolver: RuntimeDnsResolver = {
  async lookup() {
    return [{ address: "127.0.0.1", family: 4 }];
  },
};

function endpoint(port: number, overrides: Partial<TrustedEndpoint> = {}): TrustedEndpoint {
  return {
    endpointId: "provider-main",
    adapterId: "adapter.prometheus.v1",
    baseUrl: `http://localhost:${port}/trusted/`,
    authentication: { mode: "BEARER", tokenRef: { kind: "env", key: "PM_TEST_TOKEN" } },
    tls: { minimumVersion: "TLSv1.2" },
    tenantBinding: { headerName: "X-Scope-OrgID", valueRef: "metadata:tenant" },
    network: {
      followRedirects: false,
      allowLoopbackHttp: true,
      allowedHosts: ["localhost"],
      networkClass: "loopback",
      routeMode: "direct",
    },
    ...overrides,
  };
}

async function listeningServer(handler: (request: IncomingMessage, response: ServerResponse) => void) {
  const server = createServer(handler);
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  return server;
}

function tlsFixture(t: TestContext): {
  ca: string;
  serverCertificate: string;
  serverKey: string;
  clientCertificate: string;
  clientKey: string;
} | undefined {
  if (spawnSync("openssl", ["version"], { stdio: "ignore" }).status !== 0) {
    t.skip("openssl is unavailable");
    return undefined;
  }
  const root = mkdtempSync(join(tmpdir(), "pm-transport-tls-"));
  t.after(() => rmSync(root, { recursive: true, force: true }));
  const path = (name: string) => join(root, name);
  const run = (args: readonly string[]) => execFileSync("openssl", args, { stdio: "ignore" });
  run([
    "req", "-x509", "-newkey", "rsa:2048", "-nodes",
    "-keyout", path("ca-key.pem"), "-out", path("ca.pem"),
    "-subj", "/CN=Production Monitoring Test CA", "-days", "1",
  ]);
  run([
    "req", "-newkey", "rsa:2048", "-nodes",
    "-keyout", path("server-key.pem"), "-out", path("server.csr"),
    "-subj", "/CN=provider.test",
  ]);
  writeFileSync(path("server.ext"), "subjectAltName=DNS:provider.test\nextendedKeyUsage=serverAuth\n", { mode: 0o600 });
  run([
    "x509", "-req", "-in", path("server.csr"),
    "-CA", path("ca.pem"), "-CAkey", path("ca-key.pem"), "-CAcreateserial",
    "-out", path("server.pem"), "-days", "1", "-extfile", path("server.ext"),
  ]);
  run([
    "req", "-newkey", "rsa:2048", "-nodes",
    "-keyout", path("client-key.pem"), "-out", path("client.csr"),
    "-subj", "/CN=monitoring-reader",
  ]);
  writeFileSync(path("client.ext"), "extendedKeyUsage=clientAuth\n", { mode: 0o600 });
  run([
    "x509", "-req", "-in", path("client.csr"),
    "-CA", path("ca.pem"), "-CAkey", path("ca-key.pem"), "-CAcreateserial",
    "-out", path("client.pem"), "-days", "1", "-extfile", path("client.ext"),
  ]);
  return {
    ca: readFileSync(path("ca.pem"), "utf8"),
    serverCertificate: readFileSync(path("server.pem"), "utf8"),
    serverKey: readFileSync(path("server-key.pem"), "utf8"),
    clientCertificate: readFileSync(path("client.pem"), "utf8"),
    clientKey: readFileSync(path("client-key.pem"), "utf8"),
  };
}

test("GET transport pins DNS, joins under the trusted base, binds secret and tenant headers, and does not follow redirects", async (t) => {
  const requests: Array<{ url?: string; authorization?: string; tenant?: string }> = [];
  const server = await listeningServer((request, response) => {
    requests.push({
      ...(request.url === undefined ? {} : { url: request.url }),
      ...(request.headers.authorization === undefined ? {} : { authorization: request.headers.authorization }),
      ...(request.headers["x-scope-orgid"] === undefined ? {} : { tenant: String(request.headers["x-scope-orgid"]) }),
    });
    if (request.url?.includes("redirect")) {
      response.writeHead(302, { Location: "/outside" });
      response.end();
      return;
    }
    response.setHeader("content-type", "application/json");
    response.end('{"ok":true}');
  });
  t.after(() => server.close());
  const port = (server.address() as AddressInfo).port;
  const client = new NodeTrustedHttpClient({
    endpoint: endpoint(port),
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 2_000,
    maxResponseBytes: 1_024,
    resolver,
  });
  const response = await client.get("/api/read", { q: "fixed" }, AbortSignal.timeout(2_000), 1_024);
  assert.equal(response.status, 200);
  assert.equal(Buffer.from(response.body).toString("utf8"), '{"ok":true}');
  assert.deepEqual(requests[0], {
    url: "/trusted/api/read?q=fixed",
    authorization: "Bearer secret-value",
    tenant: "tenant-a",
  });
  const redirect = await client.get("/redirect", {}, AbortSignal.timeout(2_000), 1_024);
  assert.equal(redirect.status, 302);
  assert.equal(requests.length, 2, "redirect must not trigger a second request");
  assert.doesNotMatch(JSON.stringify(response), /secret-value/u);
});

test("POST JSON transport canonicalizes and bounds the body while preserving endpoint and header policy", async (t) => {
  const received: Array<{
    method?: string;
    url?: string;
    contentType?: string;
    contentLength?: string;
    authorization?: string;
    tenant?: string;
    body: string;
  }> = [];
  const server = await listeningServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (chunk: Buffer | string) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
    request.on("end", () => {
      received.push({
        ...(request.method === undefined ? {} : { method: request.method }),
        ...(request.url === undefined ? {} : { url: request.url }),
        ...(request.headers["content-type"] === undefined ? {} : { contentType: String(request.headers["content-type"]) }),
        ...(request.headers["content-length"] === undefined ? {} : { contentLength: String(request.headers["content-length"]) }),
        ...(request.headers.authorization === undefined ? {} : { authorization: request.headers.authorization }),
        ...(request.headers["x-scope-orgid"] === undefined ? {} : { tenant: String(request.headers["x-scope-orgid"]) }),
        body: Buffer.concat(chunks).toString("utf8"),
      });
      response.setHeader("content-type", "application/json");
      response.end('{"results":{}}');
    });
  });
  t.after(() => server.close());
  const port = (server.address() as AddressInfo).port;
  const client = new NodeTrustedHttpClient({
    endpoint: endpoint(port),
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 2_000,
    maxResponseBytes: 1_024,
    resolver,
  });
  const body = { to: "2", queries: [{ refId: "A", expr: "fixed" }], from: "1" };
  const response = await client.postJson("/api/ds/query", body, AbortSignal.timeout(2_000), 1_024);
  assert.equal(response.status, 200);
  const expectedBody = '{"from":"1","queries":[{"expr":"fixed","refId":"A"}],"to":"2"}';
  assert.deepEqual(received, [{
    method: "POST",
    url: "/trusted/api/ds/query",
    contentType: "application/json",
    contentLength: String(Buffer.byteLength(expectedBody)),
    authorization: "Bearer secret-value",
    tenant: "tenant-a",
    body: expectedBody,
  }]);
  assert.doesNotMatch(JSON.stringify(response), /secret-value/u);

  await assert.rejects(
    client.postJson("/../escape", {}, AbortSignal.timeout(2_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "PATH_TRAVERSAL",
  );
  await assert.rejects(
    client.postJson("/api/ds/query", { invalid: BigInt(1) } as never, AbortSignal.timeout(2_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "INVALID_JSON_BODY",
  );
  await assert.rejects(
    client.postJson("/api/ds/query", { value: "x".repeat(262_144) }, AbortSignal.timeout(2_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "REQUEST_TOO_LARGE",
  );
  assert.equal(received.length, 1, "invalid POSTs must fail before network I/O");
});

test("transport applies NONE, BEARER, and BASIC authentication only from exact credential references", async (t) => {
  const authorization: Array<string | undefined> = [];
  const server = await listeningServer((request, response) => {
    authorization.push(request.headers.authorization);
    response.end("{}");
  });
  t.after(() => server.close());
  const port = (server.address() as AddressInfo).port;
  const common = {
    metadata: {},
    timeoutMs: 2_000,
    maxResponseBytes: 1_024,
    resolver,
  };
  const none = new NodeTrustedHttpClient({
    ...common,
    endpoint: endpoint(port, { authentication: { mode: "NONE" }, tenantBinding: undefined }),
    environment: {},
  });
  await none.get("/none", {}, AbortSignal.timeout(2_000), 1_024);

  const bearer = new NodeTrustedHttpClient({
    ...common,
    endpoint: endpoint(port, { tenantBinding: undefined }),
    environment: { PM_TEST_TOKEN: "bearer-secret" },
  });
  await bearer.get("/bearer", {}, AbortSignal.timeout(2_000), 1_024);

  const basic = new NodeTrustedHttpClient({
    ...common,
    endpoint: endpoint(port, {
      authentication: {
        mode: "BASIC",
        usernameRef: { kind: "env", key: "PM_TEST_USERNAME" },
        passwordRef: { kind: "env", key: "PM_TEST_PASSWORD" },
      },
      tenantBinding: undefined,
    }),
    environment: { PM_TEST_USERNAME: "reader", PM_TEST_PASSWORD: "password-secret" },
  });
  await basic.get("/basic", {}, AbortSignal.timeout(2_000), 1_024);

  assert.deepEqual(authorization, [
    undefined,
    "Bearer bearer-secret",
    `Basic ${Buffer.from("reader:password-secret", "utf8").toString("base64")}`,
  ]);
});

test("real HTTPS transport enforces mTLS, custom CA, SNI, and minimum TLS version", async (t) => {
  const material = tlsFixture(t);
  if (material === undefined) return;
  const server = createHttpsServer({
    key: material.serverKey,
    cert: material.serverCertificate,
    ca: material.ca,
    requestCert: true,
    rejectUnauthorized: true,
    minVersion: "TLSv1.2",
    maxVersion: "TLSv1.2",
  }, (_request, response) => response.end('{"ok":true}'));
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  t.after(() => server.close());
  const port = (server.address() as AddressInfo).port;
  const mtlsEndpoint = endpoint(port, {
    baseUrl: `https://127.0.0.1:${port}/trusted/`,
    authentication: {
      mode: "MTLS",
      certificateRef: { kind: "env", key: "PM_TEST_CLIENT_CERT" },
      privateKeyRef: { kind: "env", key: "PM_TEST_CLIENT_KEY" },
    },
    tls: {
      minimumVersion: "TLSv1.2",
      caRef: { kind: "env", key: "PM_TEST_CA" },
      serverName: "provider.test",
    },
    tenantBinding: undefined,
    network: {
      followRedirects: false,
      allowLoopbackHttp: false,
      allowedHosts: ["127.0.0.1"],
      networkClass: "loopback",
      routeMode: "direct",
    },
  });
  const environment = {
    PM_TEST_CA: material.ca,
    PM_TEST_CLIENT_CERT: material.clientCertificate,
    PM_TEST_CLIENT_KEY: material.clientKey,
  };
  const create = (
    overrides: Partial<TrustedEndpoint> = {},
    environmentOverrides: Readonly<NodeJS.ProcessEnv> = environment,
  ) =>
    new NodeTrustedHttpClient({
      endpoint: { ...mtlsEndpoint, ...overrides },
      metadata: {},
      environment: environmentOverrides,
      timeoutMs: 2_000,
      maxResponseBytes: 1_024,
      resolver,
    });

  const response = await create().get("/health", {}, AbortSignal.timeout(2_000), 1_024);
  assert.equal(response.status, 200);

  await assert.rejects(
    create({}, { ...environment, PM_TEST_CA: "not-a-certificate" })
      .get("/health", {}, AbortSignal.timeout(2_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "NETWORK_UNAVAILABLE",
  );
  await assert.rejects(
    create({ tls: { ...mtlsEndpoint.tls, serverName: "wrong.test" } })
      .get("/health", {}, AbortSignal.timeout(2_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "NETWORK_UNAVAILABLE",
  );
  await assert.rejects(
    create({ tls: { ...mtlsEndpoint.tls, minimumVersion: "TLSv1.3" } })
      .get("/health", {}, AbortSignal.timeout(2_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "NETWORK_UNAVAILABLE",
  );
  assert.throws(
    () => create({}, { PM_TEST_CA: material.ca, PM_TEST_CLIENT_CERT: material.clientCertificate }),
    (error) => error instanceof RuntimeTransportError && error.code === "CREDENTIAL_UNAVAILABLE",
  );
});

test("workload and broker references require an explicit resolver and never fall back to environment lookup", () => {
  const workloadEndpoint = endpoint(12345, {
    authentication: {
      mode: "BEARER",
      tokenRef: { kind: "workload_identity", key: "prometheus-reader" },
    },
    tenantBinding: undefined,
  });
  assert.throws(() => new NodeTrustedHttpClient({
    endpoint: workloadEndpoint,
    metadata: {},
    environment: { "prometheus-reader": "must-not-be-used" },
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
  }), (error) => error instanceof RuntimeTransportError && error.code === "CREDENTIAL_RESOLVER_NOT_CONFIGURED");

  const resolved = new NodeTrustedHttpClient({
    endpoint: workloadEndpoint,
    metadata: {},
    environment: {},
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
    credentialResolver: {
      resolve(reference) {
        return reference.kind === "workload_identity" && reference.key === "prometheus-reader"
          ? "resolved-workload-token"
          : undefined;
      },
    },
  });
  assert.ok(resolved instanceof NodeTrustedHttpClient);

  const brokerEndpoint = endpoint(12345, {
    authentication: { mode: "BEARER", tokenRef: { kind: "broker", key: "monitoring-read" } },
    tenantBinding: undefined,
  });
  assert.throws(() => new NodeTrustedHttpClient({
    endpoint: brokerEndpoint,
    metadata: {},
    environment: {},
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
  }), (error) => error instanceof RuntimeTransportError && error.code === "CREDENTIAL_RESOLVER_NOT_CONFIGURED");
});

test("transport enforces endpoint containment, response bytes, deadlines, and cancellation", async (t) => {
  const server = await listeningServer((request, response) => {
    if (request.url?.includes("large")) {
      response.end("x".repeat(256));
      return;
    }
    setTimeout(() => response.end("late"), 250);
  });
  t.after(() => server.close());
  const port = (server.address() as AddressInfo).port;
  const client = new NodeTrustedHttpClient({
    endpoint: endpoint(port),
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 50,
    maxResponseBytes: 128,
    resolver,
  });
  await assert.rejects(
    client.get("/large", {}, AbortSignal.timeout(2_000), 64),
    (error) => error instanceof RuntimeTransportError && error.code === "RESPONSE_TOO_LARGE",
  );
  await assert.rejects(
    client.get("/slow", {}, AbortSignal.timeout(2_000), 64),
    (error) => error instanceof RuntimeTransportError && error.kind === "TIMEOUT",
  );
  const controller = new AbortController();
  const pending = client.get("/cancel", {}, controller.signal, 64);
  controller.abort(new Error("cancelled"));
  await assert.rejects(pending, /cancelled/u);
  await assert.rejects(
    client.getAbsolute(`http://localhost:${port}/outside`, AbortSignal.timeout(2_000), 64),
    (error) => error instanceof RuntimeTransportError && error.code === "ENDPOINT_ESCAPE",
  );
});

test("transport fails closed before I/O for an unavailable secret or disallowed host", () => {
  const base = endpoint(12345);
  assert.throws(() => new NodeTrustedHttpClient({
    endpoint: base,
    metadata: { tenant: "tenant-a" },
    environment: {},
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
  }), (error) => error instanceof RuntimeTransportError && error.code === "CREDENTIAL_UNAVAILABLE");
  assert.throws(() => new NodeTrustedHttpClient({
    endpoint: { ...base, network: { ...base.network, allowedHosts: ["other.invalid"] } },
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
  }), (error) => error instanceof RuntimeTransportError && error.code === "HOST_NOT_ALLOWED");
  assert.throws(() => new NodeTrustedHttpClient({
    endpoint: endpoint(12345, {
      authentication: {
        mode: "BASIC",
        usernameRef: { kind: "env", key: "PM_TEST_USERNAME" },
        passwordRef: { kind: "env", key: "PM_TEST_PASSWORD" },
      },
      tenantBinding: undefined,
    }),
    metadata: {},
    environment: { PM_TEST_USERNAME: "reader" },
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
  }), (error) => error instanceof RuntimeTransportError && error.code === "CREDENTIAL_UNAVAILABLE");
  assert.throws(() => new NodeTrustedHttpClient({
    endpoint: endpoint(12345, {
      network: { ...base.network, routeMode: "application_proxy" },
    }),
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
  }), (error) => error instanceof RuntimeTransportError && error.code === "APPLICATION_PROXY_NOT_IMPLEMENTED");
});

test("host_vpn is a private-network direct-socket route and never an ambient proxy", () => {
  const client = new NodeTrustedHttpClient({
    endpoint: endpoint(443, {
      baseUrl: "https://monitoring.internal/",
      authentication: { mode: "NONE" },
      tenantBinding: undefined,
      network: {
        followRedirects: false,
        allowLoopbackHttp: false,
        allowedHosts: ["monitoring.internal"],
        networkClass: "private",
        routeMode: "host_vpn",
      },
    }),
    metadata: {},
    environment: { HTTPS_PROXY: "http://untrusted-proxy.invalid" },
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
  });
  assert.ok(client instanceof NodeTrustedHttpClient);
});

test("DNS is deadline-bounded and an approved loopback HTTP name must still resolve to loopback", async () => {
  const base = endpoint(12345);
  const delayed = new NodeTrustedHttpClient({
    endpoint: base,
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 20,
    maxResponseBytes: 1_024,
    resolver: { async lookup() { return new Promise(() => undefined); } },
  });
  await assert.rejects(
    delayed.get("/read", {}, AbortSignal.timeout(1_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.kind === "TIMEOUT",
  );
  const rebound = new NodeTrustedHttpClient({
    endpoint: base,
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
    resolver: { async lookup() { return [{ address: "192.0.2.10", family: 4 }]; } },
  });
  await assert.rejects(
    rebound.get("/read", {}, AbortSignal.timeout(1_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "DNS_NETWORK_CLASS_MISMATCH",
  );
});

test("all DNS answers and the connected peer must remain in the declared network class", async () => {
  const base = endpoint(12345);
  const mixedAnswers = new NodeTrustedHttpClient({
    endpoint: base,
    metadata: { tenant: "tenant-a" },
    environment: { PM_TEST_TOKEN: "secret-value" },
    timeoutMs: 1_000,
    maxResponseBytes: 1_024,
    resolver: {
      async lookup() {
        return [
          { address: "127.0.0.1", family: 4 },
          { address: "10.0.0.10", family: 4 },
        ];
      },
    },
  });
  await assert.rejects(
    mixedAnswers.get("/read", {}, AbortSignal.timeout(1_000), 1_024),
    (error) => error instanceof RuntimeTransportError && error.code === "DNS_NETWORK_CLASS_MISMATCH",
  );
});
