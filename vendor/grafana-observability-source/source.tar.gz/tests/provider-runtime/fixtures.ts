import { createHash, generateKeyPairSync, sign, type KeyObject } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, realpathSync } from "node:fs";
import { join } from "node:path";

import { build } from "esbuild";

import { writeGeneratedNodeSource } from "../../scripts/plugin-build-lib.mjs";

import { alertmanagerAdapterPackage } from "../../adapters/alertmanager/src/index.ts";
import { gitAdapterPackage } from "../../adapters/git/src/index.ts";
import { grafanaAdapterPackage } from "../../adapters/grafana/src/index.ts";
import { kubernetesAdapterPackage } from "../../adapters/kubernetes/src/index.ts";
import { lokiAdapterPackage } from "../../adapters/loki/src/index.ts";
import { prometheusAdapterPackage } from "../../adapters/prometheus/src/index.ts";
import { tempoAdapterPackage } from "../../adapters/tempo/src/index.ts";
import { fixtureAdapterPackage } from "../../adapters/fixture/src/index.ts";
import { adapterAdmissionPayload } from "../../packages/adapter-sdk/src/index.ts";
import { computeTrustedProfileConfigHash } from "../../packages/config/src/index.ts";
import {
  canonicalJson,
  computeIntegrity,
  sha256Canonical,
  type EvidenceOrigin,
  type AdapterPackage,
  type Sha256,
  type TrustBundle,
  type TrustedEndpoint,
  type TrustedProfile,
} from "../../packages/contracts/src/index.ts";

const FIXED_TIME = "2026-08-11T12:00:00.000Z";
export const TEST_SIGNING_KEY_ID = "provider-test-ed25519";
export const TEST_SIGNING_KEY_PATH = "provider-test-ed25519.pub.pem";
export const TEST_PACKAGE_ARTIFACT_PATH = "workers/provider-worker.mjs";

export interface SignedProviderWorkerMaterial {
  artifactPath: string;
  artifactSha256: Sha256;
  publicKey: KeyObject;
  publicKeyPem: string;
  signPackage(
    adapterPackage: AdapterPackage,
    overrides?: { artifactPath?: string; artifactSha256?: Sha256; signingKeyId?: string },
  ): AdapterPackage;
}

export async function buildSignedProviderWorker(parent: string): Promise<SignedProviderWorkerMaterial> {
  const artifactPath = join(parent, "workers", "provider-worker.mjs");
  mkdirSync(join(parent, "workers"), { recursive: true });
  const result = await build({
    entryPoints: [join(process.cwd(), "packages/provider-runtime/src/worker-entrypoint.ts")],
    bundle: true,
    platform: "node",
    target: "node22",
    format: "cjs",
    legalComments: "none",
    logLevel: "silent",
    write: false,
  });
  const source = result.outputFiles?.[0]?.contents;
  if (source === undefined) throw new Error("esbuild omitted the signed provider worker fixture source");
  writeGeneratedNodeSource(artifactPath, source);
  const canonicalArtifactPath = realpathSync(artifactPath);
  const artifactSha256 = createHash("sha256").update(readFileSync(canonicalArtifactPath)).digest("hex") as Sha256;
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const signPackage = (
    adapterPackage: AdapterPackage,
    overrides: { artifactPath?: string; artifactSha256?: Sha256; signingKeyId?: string } = {},
  ): AdapterPackage => {
    const unsigned: AdapterPackage = {
      ...adapterPackage,
      entrypoint: {
        kind: "SIGNED_WORKER",
        protocol: "PM_ADAPTER_STDIO_V1",
        artifactPath: overrides.artifactPath ?? TEST_PACKAGE_ARTIFACT_PATH,
        artifactSha256: overrides.artifactSha256 ?? artifactSha256,
        signature: "",
        signingKeyId: overrides.signingKeyId ?? TEST_SIGNING_KEY_ID,
      },
    };
    const signature = sign(
      null,
      Buffer.from(canonicalJson(adapterAdmissionPayload(unsigned)), "utf8"),
      privateKey,
    ).toString("base64");
    if (unsigned.entrypoint.kind !== "SIGNED_WORKER") throw new Error("Expected a worker package");
    return { ...unsigned, entrypoint: { ...unsigned.entrypoint, signature } };
  };
  return {
    artifactPath: canonicalArtifactPath,
    artifactSha256,
    publicKey,
    publicKeyPem: publicKey.export({ type: "spki", format: "pem" }).toString(),
    signPackage,
  };
}

export function liveBundle(port: number, adapters: AdapterPackage[]): TrustBundle {
  const endpoints: TrustedEndpoint[] = [
    ["prometheus-main", prometheusAdapterPackage.packageId],
    ["grafana-main", grafanaAdapterPackage.packageId],
    ["alertmanager-main", alertmanagerAdapterPackage.packageId],
    ["loki-main", lokiAdapterPackage.packageId],
    ["tempo-main", tempoAdapterPackage.packageId],
    ["kubernetes-main", kubernetesAdapterPackage.packageId],
  ].map(([endpointId, adapterId]) => ({
    endpointId: endpointId as string,
    adapterId: adapterId!,
    baseUrl: `http://127.0.0.1:${port}/`,
    authentication: endpointId === "prometheus-main"
      ? { mode: "BEARER" as const, tokenRef: { kind: "env" as const, key: "PM_TEST_TOKEN" } }
      : { mode: "NONE" as const },
    tls: { minimumVersion: "TLSv1.2" as const },
    network: {
      followRedirects: false,
      allowLoopbackHttp: true,
      allowedHosts: ["127.0.0.1"],
      networkClass: "loopback",
      routeMode: "direct",
    },
    ...(endpointId === "prometheus-main"
      ? {
          tenantBinding: { headerName: "X-Scope-OrgID", valueRef: "metadata:tenant" },
        }
      : {}),
  }));
  const profileDraft: TrustedProfile = {
    schemaVersion: "1.0.0",
    profileAlias: "live-test",
    capabilityProfile: "investigate",
    allowedOrigins: ["LIVE"] satisfies EvidenceOrigin[],
    compiledAt: FIXED_TIME,
    configSha256: "0".repeat(64) as Sha256,
    endpointRegistrySha256: sha256Canonical(endpoints),
    catalogSha256: sha256Canonical([]),
    scopes: { checkout: { environment: "production", service: "checkout" } },
    endpointIds: endpoints.map((endpoint) => endpoint.endpointId),
    operationIds: [],
    policy: {
      defaultLookback: { mode: "FIXED", durationSeconds: 900 },
      maxEvidenceAge: { mode: "FIXED", durationSeconds: 60 },
      rawEvidenceRetention: { mode: "NONE" },
      auditRequired: true,
      limits: {
        timeoutMs: 5_000,
        maxAgeMs: 60_000,
        maxBytes: 65_536,
        maxRows: 100,
        maxSeries: 25,
        maxPoints: 500,
      },
    },
  };
  const profile: TrustedProfile = {
    ...profileDraft,
    configSha256: computeTrustedProfileConfigHash(profileDraft),
  };
  const unsealed: TrustBundle = {
    schemaVersion: "1.0.0",
    createdAt: FIXED_TIME,
    profile,
    endpoints,
    operations: [],
    adapters,
    integrity: {
      hashContractVersion: "sha256-jcs-v1",
      algorithm: "sha256",
      canonicalization: "RFC8785",
      contentSha256: "0".repeat(64) as Sha256,
    },
  };
  return { ...unsealed, integrity: computeIntegrity(unsealed) };
}

export function liveRuntimeConfiguration(workspaceParent: string) {
  const workspace = join(workspaceParent, "git-workspace");
  mkdirSync(workspace, { recursive: true });
  execFileSync("/usr/bin/git", ["init", "--quiet", workspace], {
    env: { PATH: "/usr/bin:/bin" },
    stdio: "ignore",
  });
  const transport = () => ({ timeoutMs: 2_000, maxResponseBytes: 65_536 });
  const access = (kind: string) => ({
    approvalId: `${kind}-scope-review`,
    reviewedAt: FIXED_TIME,
    effectiveProviderScopes: [] as string[],
  });
  return {
    schemaVersion: "1.0.0",
    metadata: { tenant: "tenant-a" },
    workerAdmission: {
      trustedSigningKeys: [{ keyId: TEST_SIGNING_KEY_ID, manifestPath: TEST_SIGNING_KEY_PATH }],
      revocations: { packageIds: [], artifactSha256s: [], artifactPaths: [], signingKeyIds: [] },
    },
    adapters: [
      {
        kind: "prometheus",
        packageId: "adapter.prometheus.v1",
        credentialEnv: ["PM_TEST_TOKEN"],
        access: access("prometheus"),
        bootstrap: { endpointId: "prometheus-main", transport: transport(), catalog: { entries: [{ id: "health", sourceIdentitySha256: "d".repeat(64), route: "instant", outputName: "health", expression: "up", valueKind: "FLOAT", allowedLabels: ["service"], scope: { environment: "production", service: "checkout" } }] } },
      },
      {
        kind: "grafana",
        packageId: "adapter.grafana.v1",
        credentialEnv: [],
        access: access("grafana"),
        bootstrap: { endpointId: "grafana-main", transport: transport(), catalog: { entries: [{ id: "health", route: "health", outputName: "health" }] } },
      },
      {
        kind: "alertmanager",
        packageId: "adapter.alertmanager.v1",
        credentialEnv: [],
        access: access("alertmanager"),
        bootstrap: { endpointIds: ["alertmanager-main"], transport: transport(), catalog: [{ bindingId: "status", endpointId: "alertmanager-main", operation: "alertmanager.status", maxBytes: 65_536, maxItems: 100 }] },
      },
      {
        kind: "loki",
        packageId: "adapter.loki.v1",
        credentialEnv: [],
        access: access("loki"),
        bootstrap: { endpointId: "loki-main", transport: transport(), catalog: { entries: [{ id: "errors", sourceIdentitySha256: "d".repeat(64), expression: "{service=\"checkout\"}", outputName: "errors", allowedLabels: ["service"], direction: "backward", scope: { environment: "production", service: "checkout" } }] } },
      },
      {
        kind: "tempo",
        packageId: "adapter.tempo.v1",
        credentialEnv: [],
        access: access("tempo"),
        bootstrap: { endpointId: "tempo-main", transport: transport(), catalog: { entries: [{ id: "traces", sourceIdentitySha256: "d".repeat(64), route: "search", query: "{ resource.service.name = `checkout` }", outputName: "traces", allowedAttributes: ["service.name"], scope: { environment: "production", service: "checkout" } }] } },
      },
      {
        kind: "kubernetes",
        packageId: "adapter.kubernetes.v1",
        credentialEnv: [],
        access: access("kubernetes"),
        bootstrap: { endpointId: "kubernetes-main", transport: transport(), catalog: { entries: [{ id: "pods", outputName: "pods", mode: "LIST", resource: "pods", namespaceByEnvironment: { production: "prod" }, selector: { key: "app", valueSource: "service" } }] } },
      },
      {
        kind: "git",
        packageId: "adapter.git.v1",
        credentialEnv: [],
        access: access("git"),
        bootstrap: { gitExecutable: "/usr/bin/git", workspaces: [{ workspaceId: "repository", root: workspace }], catalog: [{ bindingId: "status", workspaceId: "repository", operation: "git.status", allowedPaths: ["."], maxBytes: 65_536, maxFiles: 100, maxHunks: 100, maxLines: 1_000 }] },
      },
    ],
  };
}

export const firstPartyAdapterPackages = [
  prometheusAdapterPackage,
  grafanaAdapterPackage,
  alertmanagerAdapterPackage,
  lokiAdapterPackage,
  tempoAdapterPackage,
  kubernetesAdapterPackage,
  gitAdapterPackage,
] as const;

export { fixtureAdapterPackage };
