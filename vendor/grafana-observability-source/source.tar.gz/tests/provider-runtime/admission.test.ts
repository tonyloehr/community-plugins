import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import {
  appendFileSync,
  chmodSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  realpathSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import {
  createFixtureOperationSnapshot,
  fixtureAdapterPackage,
} from "../../adapters/fixture/src/index.ts";
import {
  AdapterExecutionError,
  createBudgetController,
} from "../../packages/adapter-sdk/src/index.ts";
import { loadTrustedRoot } from "../../packages/config/src/index.ts";
import { computeIntegrity, type AdapterPackage, type Sha256, type TrustBundle } from "../../packages/contracts/src/index.ts";
import { createFixtureRuntimeDefinition } from "../../packages/evidence-server/src/fixture-runtime.ts";
import { createProviderRuntime } from "../../packages/provider-runtime/src/index.ts";
import { writeTrustRoot } from "../config/fixtures.ts";
import {
  buildSignedProviderWorker,
  TEST_PACKAGE_ARTIFACT_PATH,
  TEST_SIGNING_KEY_ID,
  TEST_SIGNING_KEY_PATH,
  type SignedProviderWorkerMaterial,
} from "./fixtures.ts";

type Revocations = {
  packageIds: readonly string[];
  artifactSha256s: readonly string[];
  artifactPaths: readonly string[];
  signingKeyIds: readonly string[];
};

const emptyRevocations = (): Revocations => ({
  packageIds: [],
  artifactSha256s: [],
  artifactPaths: [],
  signingKeyIds: [],
});

function fixtureBundle(adapterPackage: AdapterPackage): TrustBundle {
  const definition = createFixtureRuntimeDefinition();
  const unsealed: TrustBundle = { ...definition.bundle, adapters: [adapterPackage] };
  return { ...unsealed, integrity: computeIntegrity(unsealed) };
}

function runtimeConfiguration(revocations: Revocations = emptyRevocations()) {
  return {
    schemaVersion: "1.0.0",
    metadata: {},
    workerAdmission: {
      trustedSigningKeys: [{ keyId: TEST_SIGNING_KEY_ID, manifestPath: TEST_SIGNING_KEY_PATH }],
      revocations,
    },
    adapters: [{
      kind: "fixture",
      packageId: fixtureAdapterPackage.packageId,
      credentialEnv: [],
      access: {
        approvalId: "fixture-scope-review",
        reviewedAt: "2026-08-11T12:00:00.000Z",
        effectiveProviderScopes: ["environment", "service", "tenantSha256"],
      },
      bootstrap: {},
    }],
  };
}

function writeFixtureRoot(
  parent: string,
  worker: SignedProviderWorkerMaterial,
  adapterPackage: AdapterPackage,
  revocations = emptyRevocations(),
  publicKeyPem = worker.publicKeyPem,
): string {
  return writeTrustRoot(
    parent,
    fixtureBundle(adapterPackage),
    runtimeConfiguration(revocations),
    [{ path: TEST_SIGNING_KEY_PATH, publicKeyPem }],
  );
}

function releaseArtifact(worker: SignedProviderWorkerMaterial, artifactPath = worker.artifactPath, digest = worker.artifactSha256) {
  return [{ packageArtifactPath: TEST_PACKAGE_ARTIFACT_PATH, artifactPath, artifactSha256: digest }];
}

function countingRuntime(parent: string): { runtimePath: string; launchCount: () => number } {
  const runtimePath = join(parent, "counting-node-runtime.sh");
  const launchLog = join(parent, "worker-launches.log");
  writeFileSync(
    runtimePath,
    `#!/bin/sh\nprintf 'launch\\n' >> '${launchLog}'\nexec /usr/bin/env -i '${process.execPath}' "$@"\n`,
    { mode: 0o700 },
  );
  chmodSync(runtimePath, 0o700);
  return {
    runtimePath,
    launchCount: () => existsSync(launchLog)
      ? readFileSync(launchLog, "utf8").trim().split("\n").filter(Boolean).length
      : 0,
  };
}

function assertClosedWorkerError(error: unknown): boolean {
  assert.ok(error instanceof AdapterExecutionError);
  assert.equal(error.sanitized.code, "ADAPTER_WORKER_CLOSED");
  assert.equal(error.sanitized.retryable, false);
  return true;
}

test("signed provider admission rejects signature, digest, path, key, package, and artifact revocations", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "pm-worker-admission-"));
  try {
    const worker = await buildSignedProviderWorker(parent);
    const signed = worker.signPackage(fixtureAdapterPackage);

    await t.test("signature tampering", () => {
      const caseRoot = join(parent, "signature-case");
      mkdirSync(caseRoot);
      const tampered: AdapterPackage = { ...signed, version: "9.9.9" };
      const loaded = loadTrustedRoot({ rootPath: writeFixtureRoot(caseRoot, worker, tampered) });
      const result = createProviderRuntime(loaded, { environment: {}, releaseArtifacts: releaseArtifact(worker) });
      assert.deepEqual(result.registrations, []);
      assert.ok(result.issues.some((issue) => issue.code === "SIGNED_WORKER_ADMISSION_FAILED"));
    });

    await t.test("release digest mapping mismatch", () => {
      const caseRoot = join(parent, "digest-map-case");
      mkdirSync(caseRoot);
      const loaded = loadTrustedRoot({ rootPath: writeFixtureRoot(caseRoot, worker, signed) });
      const result = createProviderRuntime(loaded, {
        environment: {},
        releaseArtifacts: releaseArtifact(worker, worker.artifactPath, "0".repeat(64) as Sha256),
      });
      assert.deepEqual(result.registrations, []);
      assert.ok(result.issues.some((issue) => issue.code === "SIGNED_WORKER_ADMISSION_FAILED"));
    });

    await t.test("signed portable path is fixed by release code", () => {
      const caseRoot = join(parent, "path-case");
      mkdirSync(caseRoot);
      const otherPath = worker.signPackage(fixtureAdapterPackage, { artifactPath: "workers/other-worker.mjs" });
      assert.throws(
        () => loadTrustedRoot({ rootPath: writeFixtureRoot(caseRoot, worker, otherPath) }),
        /fixed provider worker artifact/u,
      );
    });

    for (const [name, revocations] of [
      ["signing key revocation", { ...emptyRevocations(), signingKeyIds: [TEST_SIGNING_KEY_ID] }],
      ["package revocation", { ...emptyRevocations(), packageIds: [fixtureAdapterPackage.packageId] }],
      ["artifact digest revocation", { ...emptyRevocations(), artifactSha256s: [worker.artifactSha256] }],
      ["artifact path revocation", { ...emptyRevocations(), artifactPaths: [TEST_PACKAGE_ARTIFACT_PATH] }],
    ] as const) {
      await t.test(name, () => {
        const caseRoot = join(parent, name.replaceAll(" ", "-"));
        mkdirSync(caseRoot);
        const loaded = loadTrustedRoot({ rootPath: writeFixtureRoot(caseRoot, worker, signed, revocations) });
        const result = createProviderRuntime(loaded, { environment: {}, releaseArtifacts: releaseArtifact(worker) });
        assert.deepEqual(result.registrations, []);
        assert.ok(result.issues.some((issue) => issue.code === "SIGNED_WORKER_ADMISSION_FAILED"));
      });
    }

    await t.test("untrusted signing key", () => {
      const caseRoot = join(parent, "wrong-key-case");
      mkdirSync(caseRoot);
      const wrong = generateKeyPairSync("ed25519").publicKey.export({ type: "spki", format: "pem" }).toString();
      const loaded = loadTrustedRoot({ rootPath: writeFixtureRoot(caseRoot, worker, signed, emptyRevocations(), wrong) });
      const result = createProviderRuntime(loaded, { environment: {}, releaseArtifacts: releaseArtifact(worker) });
      assert.deepEqual(result.registrations, []);
      assert.ok(result.issues.some((issue) => issue.code === "SIGNED_WORKER_ADMISSION_FAILED"));
    });

    await t.test("artifact bytes drift after signing", async () => {
      const caseRoot = join(parent, "artifact-drift-case");
      mkdirSync(caseRoot);
      const driftDirectory = join(parent, "drift", "workers");
      mkdirSync(driftDirectory, { recursive: true });
      const driftPath = join(driftDirectory, "provider-worker.mjs");
      copyFileSync(worker.artifactPath, driftPath);
      appendFileSync(driftPath, "\n// post-signing drift\n");
      const loaded = loadTrustedRoot({ rootPath: writeFixtureRoot(caseRoot, worker, signed) });
      const result = createProviderRuntime(loaded, {
        environment: {},
        releaseArtifacts: releaseArtifact(worker, realpathSync(driftPath)),
      });
      assert.equal(result.registrations.length, 1);
      const doctor = await result.registrations[0]!.adapter.doctor({ signal: AbortSignal.timeout(2_000), clock: { now: () => new Date() } });
      assert.equal(doctor.status, "BLOCKED");
      await result.close();
    });
  } finally {
    rmSync(parent, { recursive: true, force: true });
  }
});

test("worker independently reloads exact manifest and runtime digests before accepting protocol requests", async () => {
  const parent = mkdtempSync(join(tmpdir(), "pm-worker-reload-"));
  let close = async () => {};
  try {
    const worker = await buildSignedProviderWorker(parent);
    const signed = worker.signPackage(fixtureAdapterPackage);
    const rootPath = writeFixtureRoot(parent, worker, signed);
    const loaded = loadTrustedRoot({ rootPath });
    const result = createProviderRuntime(loaded, { environment: {}, releaseArtifacts: releaseArtifact(worker), shutdownGraceMs: 50 });
    close = result.close;
    assert.equal(result.registrations.length, 1);
    const runtimePath = join(rootPath, "provider-runtime.yaml");
    writeFileSync(runtimePath, `${readFileSync(runtimePath, "utf8")}\n# changed after parent admission\n`);
    chmodSync(runtimePath, 0o600);
    const doctor = await result.registrations[0]!.adapter.doctor({
      signal: AbortSignal.timeout(2_000),
      clock: { now: () => new Date() },
    });
    assert.equal(doctor.status, "BLOCKED");
    await assert.rejects(
      result.registrations[0]!.adapter.compile(createFixtureOperationSnapshot("healthy"), {
        adapterPackage: signed,
        maxDefinitionBytes: 64_000,
      }),
      /bootstrap validation failed|terminated unexpectedly|protocol/u,
    );
  } finally {
    await close();
    rmSync(parent, { recursive: true, force: true });
  }
});

test("provider runtime close is terminal, concurrent-safe, and never reopens a child worker", async (t) => {
  if (process.platform === "win32") return t.skip("counting runtime fixture uses a POSIX exec wrapper");
  const parent = mkdtempSync(join(tmpdir(), "pm-worker-terminal-close-"));
  const runtimeParent = mkdtempSync(join(tmpdir(), "pm-worker-counting-runtime-"));
  try {
    const worker = await buildSignedProviderWorker(parent);
    const signed = worker.signPackage(fixtureAdapterPackage);
    const loaded = loadTrustedRoot({ rootPath: writeFixtureRoot(parent, worker, signed) });
    const counter = countingRuntime(runtimeParent);
    const result = createProviderRuntime(loaded, {
      environment: {},
      releaseArtifacts: releaseArtifact(worker),
      runtimePath: counter.runtimePath,
      shutdownGraceMs: 50,
    });
    const registration = result.registrations[0]!;
    const operation = createFixtureOperationSnapshot("healthy");
    const compiled = await registration.adapter.compile(operation, {
      adapterPackage: signed,
      maxDefinitionBytes: 64_000,
    });
    const launchesBeforeClose = counter.launchCount();
    assert.ok(launchesBeforeClose >= 2, "validation and worker processes should be observable");

    const firstClose = result.close();
    const concurrentClose = result.close();
    assert.equal(concurrentClose, firstClose);
    await Promise.all([firstClose, concurrentClose]);
    assert.equal(result.close(), firstClose);

    for (let attempt = 0; attempt < 2; attempt += 1) {
      const doctor = await registration.adapter.doctor({
        signal: AbortSignal.timeout(2_000),
        clock: { now: () => new Date() },
      });
      assert.equal(doctor.status, "BLOCKED");
      assert.match(doctor.checks[0]?.message ?? "", /worker runtime is closed/u);
      await assert.rejects(
        registration.adapter.compile(operation, {
          adapterPackage: signed,
          maxDefinitionBytes: 64_000,
        }),
        assertClosedWorkerError,
      );
    }

    const signal = new AbortController();
    await assert.rejects(
      registration.adapter.execute({
        origin: "SIMULATED",
        scope: { environment: "simulation", service: "checkout" },
        window: {
          start: "2026-08-11T11:45:00.000Z",
          end: "2026-08-11T12:00:00.000Z",
        },
        clock: { now: () => new Date("2026-08-11T12:00:00.000Z") },
        budget: createBudgetController(operation.definition.limits, signal.signal),
        signal: signal.signal,
      }, compiled),
      assertClosedWorkerError,
    );
    assert.equal(counter.launchCount(), launchesBeforeClose);

    const closedBeforeOpen = createProviderRuntime(loaded, {
      environment: {},
      releaseArtifacts: releaseArtifact(worker),
      runtimePath: counter.runtimePath,
      shutdownGraceMs: 50,
    });
    const unopenedRegistration = closedBeforeOpen.registrations[0]!;
    const launchesBeforeUnopenedClose = counter.launchCount();
    const unopenedClose = closedBeforeOpen.close();
    assert.equal(closedBeforeOpen.close(), unopenedClose);
    await unopenedClose;
    const unopenedDoctor = await unopenedRegistration.adapter.doctor({
      signal: AbortSignal.timeout(2_000),
      clock: { now: () => new Date() },
    });
    assert.equal(unopenedDoctor.status, "BLOCKED");
    await assert.rejects(
      unopenedRegistration.adapter.compile(operation, {
        adapterPackage: signed,
        maxDefinitionBytes: 64_000,
      }),
      assertClosedWorkerError,
    );
    assert.equal(counter.launchCount(), launchesBeforeUnopenedClose);
  } finally {
    rmSync(parent, { recursive: true, force: true });
    rmSync(runtimeParent, { recursive: true, force: true });
  }
});
