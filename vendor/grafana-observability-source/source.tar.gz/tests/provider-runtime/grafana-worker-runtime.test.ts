import assert from "node:assert/strict";
import { createServer } from "node:http";
import type { AddressInfo } from "node:net";
import test from "node:test";

import {
  GRAFANA_ADAPTER_PACKAGE_ID,
  canonicalGrafanaDatasourceType,
  grafanaAdapterPackage,
  grafanaCatalogEntryHash,
  type GrafanaDatasourceQueryCatalogEntry,
} from "../../adapters/grafana/src/index.ts";
import { createBudgetController, type AdapterExecutionContext } from "../../packages/adapter-sdk/src/index.ts";
import type { LoadedTrustRoot, ProviderRuntimeBinding } from "../../packages/config/src/index.ts";
import {
  computeOperationDefinitionHash,
  type JsonObject,
  type OperationDefinition,
  type OperationId,
  type OperationSnapshot,
  type Sha256,
} from "../../packages/contracts/src/index.ts";
import { instantiateProviderAdapter } from "../../packages/provider-runtime/src/index.ts";

function queryEntry(): GrafanaDatasourceQueryCatalogEntry {
  return {
    id: "runtime-query",
    route: "datasource-query",
    outputName: "request_rate",
    datasourceUid: "prometheus-main",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    target: {
      datasourceType: "prometheus",
      expression: "sum(rate(http_requests_total{environment=\"test\",service=\"checkout\"}[5m]))",
      mode: "range",
      format: "time_series",
    },
    frame: {
      resultKind: "TIMESERIES",
      fields: [
        { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
        { sourceName: "Value", outputName: "request_rate", type: "number", role: "VALUE" },
      ],
      allowedLabels: ["environment", "service"],
    },
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  };
}

function operation(entry: GrafanaDatasourceQueryCatalogEntry): OperationSnapshot {
  const definition: OperationDefinition = {
    domain: "METRICS",
    sourceAlias: "grafana-main",
    adapterPackageId: GRAFANA_ADAPTER_PACKAGE_ID,
    adapterOperation: "grafana.datasource.query.read",
    authority: "CORROBORATING",
    expectedSourceLineage: {
      accessPath: "GRAFANA",
      datasourceType: canonicalGrafanaDatasourceType(entry.target.datasourceType),
      sourceIdentitySha256: entry.datasourceIdentitySha256,
    },
    sanitizedProviderDefinition: {
      catalogEntryId: entry.id,
      catalogEntrySha256: grafanaCatalogEntryHash(entry),
    },
    scopeMapping: { environment: "environment", service: "service" },
    allowedDimensions: ["environment", "service"],
    requiredProviderScopes: ["environment", "service"],
    sensitivity: "INTERNAL",
    limits: {
      timeoutMs: 2_000,
      maxAgeMs: 60_000,
      maxBytes: 64_000,
      maxRows: 20,
      maxSeries: 10,
      maxPoints: 100,
    },
    normalization: { resultKind: "TIMESERIES", dimensionMappings: {} },
  };
  const semantic = { operationId: "op.grafana.runtime-query" as OperationId, revision: 1, definition };
  return {
    schemaVersion: "1.0.0",
    ...semantic,
    capturedAt: "2026-01-01T00:00:00.000Z",
    definitionSha256: computeOperationDefinitionHash(semantic),
  };
}

function executionContext(snapshot: OperationSnapshot): AdapterExecutionContext {
  const controller = new AbortController();
  return {
    origin: "REPLAY",
    scope: { environment: "test", service: "checkout" },
    window: { start: "2026-01-01T00:00:00.000Z", end: "2026-01-01T00:05:00.000Z" },
    clock: { now: () => new Date("2026-01-01T00:05:00.000Z") },
    budget: createBudgetController(snapshot.definition.limits, controller.signal),
    signal: controller.signal,
  };
}

test("provider worker runtime dispatches Grafana datasource queries through constrained POST JSON", async (t) => {
  const requests: Array<{ method?: string; url?: string; body: string }> = [];
  const server = createServer((request, response) => {
    const chunks: Buffer[] = [];
    request.on("data", (chunk: Buffer | string) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
    request.on("end", () => {
      requests.push({
        ...(request.method === undefined ? {} : { method: request.method }),
        ...(request.url === undefined ? {} : { url: request.url }),
        body: Buffer.concat(chunks).toString("utf8"),
      });
      response.setHeader("content-type", "application/json");
      response.end(JSON.stringify(request.url === "/api/health"
        ? { database: "ok", version: "13.1.0" }
        : {
        results: {
          A: {
            frames: [{
              schema: {
                refId: "A",
                fields: [
                  { name: "Time", type: "time" },
                  { name: "Value", type: "number", labels: { environment: "test", service: "checkout" } },
                ],
              },
              data: { values: [[1767225600000], [5]] },
            }],
          },
        },
      }));
    });
  });
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  t.after(() => server.close());
  const port = (server.address() as AddressInfo).port;
  const entry = queryEntry();
  const binding = {
    kind: "grafana",
    packageId: GRAFANA_ADAPTER_PACKAGE_ID,
    credentialEnv: [],
    access: {
      approvalId: "reviewed-grafana-read",
      reviewedAt: "2026-01-01T00:00:00.000Z",
      effectiveProviderScopes: ["environment", "service"],
    },
    bootstrap: {
      endpointId: "grafana-main",
      catalog: { entries: [entry] } as unknown as JsonObject,
      transport: { timeoutMs: 2_000, maxResponseBytes: 64_000 },
    },
  } satisfies ProviderRuntimeBinding;
  const root = {
    bundle: {
      endpoints: [{
        endpointId: "grafana-main",
        adapterId: GRAFANA_ADAPTER_PACKAGE_ID,
        baseUrl: `http://localhost:${port}/`,
        authentication: { mode: "NONE" },
        tls: { minimumVersion: "TLSv1.2" },
        network: {
          followRedirects: false,
          allowLoopbackHttp: true,
          allowedHosts: ["localhost"],
          networkClass: "loopback",
          routeMode: "direct",
        },
      }],
    },
    providerRuntime: { configuration: { metadata: {} } },
  } as unknown as LoadedTrustRoot;
  const adapter = instantiateProviderAdapter(root, binding, {
    environment: {},
    resolver: { async lookup() { return [{ address: "127.0.0.1", family: 4 }]; } },
  });
  const snapshot = operation(entry);
  const compiled = await adapter.compile(snapshot, {
    adapterPackage: grafanaAdapterPackage,
    maxDefinitionBytes: 64_000,
  });
  const result = await adapter.execute(executionContext(snapshot), compiled);
  assert.equal(result.collectionState, "COMPLETE");
  assert.equal(result.records[0]?.kind, "TIMESERIES");
  assert.equal(requests.length, 2);
  assert.equal(requests[0]?.method, "GET");
  assert.equal(requests[0]?.url, "/api/health");
  assert.equal(requests[1]?.method, "POST");
  assert.equal(requests[1]?.url, "/api/ds/query");
  const sent = JSON.parse(requests[1]!.body) as { queries?: unknown[] };
  assert.equal(sent.queries?.length, 1);
  assert.equal((sent.queries?.[0] as { refId?: unknown }).refId, "A");
});
