import assert from "node:assert/strict";
import { existsSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import { createServer } from "node:http";
import type { AddressInfo } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import {
  computeTrustedProfileConfigHash,
  loadTrustedRoot,
} from "../../packages/config/src/index.ts";
import { computeIntegrity, sha256Canonical } from "../../packages/contracts/src/index.ts";
import { createProviderRuntime } from "../../packages/provider-runtime/src/index.ts";
import { writeTrustRoot } from "../config/fixtures.ts";
import {
  buildSignedProviderWorker,
  firstPartyAdapterPackages,
  liveBundle,
  liveRuntimeConfiguration,
  TEST_PACKAGE_ARTIFACT_PATH,
  TEST_SIGNING_KEY_PATH,
} from "./fixtures.ts";

test("manifest-hashed configuration constructs all seven providers exclusively as signed child workers", async () => {
  const parent = mkdtempSync(join(tmpdir(), "pm-live-runtime-"));
  const server = createServer((request, response) => {
    if (request.url?.startsWith("/api/v1/status/runtimeinfo")) {
      response.setHeader("content-type", "application/json");
      response.end('{"status":"success","data":{}}');
    } else if (request.url?.startsWith("/api/health")) {
      response.setHeader("content-type", "application/json");
      response.end('{"database":"ok","version":"11.0.0"}');
    } else if (request.url?.startsWith("/version")) {
      response.setHeader("content-type", "application/json");
      response.end('{"major":"1","minor":"30"}');
    } else {
      response.setHeader("content-type", "text/plain");
      response.end("ready");
    }
  });
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  let close = async () => {};
  try {
    const worker = await buildSignedProviderWorker(parent);
    assert.equal(existsSync(join(parent, "schemas")), false);
    assert.doesNotMatch(readFileSync(worker.artifactPath, "utf8"), /\.\.\/schemas\//u);
    const adapters = firstPartyAdapterPackages.map((adapterPackage) => worker.signPackage(adapterPackage));
    const configuration = liveRuntimeConfiguration(parent);
    const trustRoot = writeTrustRoot(
      parent,
      liveBundle((server.address() as AddressInfo).port, adapters),
      configuration,
      [{ path: TEST_SIGNING_KEY_PATH, publicKeyPem: worker.publicKeyPem }],
    );
    const loaded = loadTrustedRoot({ rootPath: trustRoot });
    const result = createProviderRuntime(loaded, {
      environment: { PM_TEST_TOKEN: "not-returned" },
      releaseArtifacts: [{
        packageArtifactPath: TEST_PACKAGE_ARTIFACT_PATH,
        artifactPath: worker.artifactPath,
        artifactSha256: worker.artifactSha256,
      }],
      shutdownGraceMs: 100,
    });
    close = result.close;
    assert.equal(result.registrations.length, 7);
    assert.deepEqual(result.issues, []);
    assert.match(result.runtimeConfigurationSha256 ?? "", /^[a-f0-9]{64}$/u);
    assert.doesNotMatch(JSON.stringify(result), /not-returned/u);
    assert.ok(result.registrations.every((registration) => registration.adapterPackage.entrypoint.kind === "SIGNED_WORKER"));
    assert.ok(result.registrations.every((registration) => registration.adapter.constructor.name === "CodeOwnedChildWorkerAdapter"));
    const packageIds = result.registrations.map((registration) => registration.adapterPackage.packageId).sort();
    assert.deepEqual(packageIds, configuration.adapters.map((binding) => binding.packageId).sort());
    for (const registration of result.registrations) {
      const doctor = await registration.adapter.doctor({ signal: AbortSignal.timeout(5_000), clock: { now: () => new Date() } });
      const isGit = registration.adapterPackage.packageId === "adapter.git.v1";
      assert.equal(doctor.status, isGit ? "READY" : "WARN");
      assert.match(doctor.checks[0]?.message ?? "", /release-code-owned signed child worker/iu);
      assert.match(doctor.checks[0]?.message ?? "", /not an OS sandbox/u);
      assert.ok(doctor.checks.some((check) =>
        check.name.startsWith("provider-scope-admission:") && check.status === "PASS"
      ));
      if (!isGit) {
        assert.ok(doctor.checks.some((check) =>
          check.name.startsWith("provider-connectivity:") && check.status === "PASS"
        ));
        assert.ok(doctor.checks.some((check) =>
          check.name.startsWith("provider-clock:") && check.status === "PASS"
        ));
        assert.ok(doctor.checks.some((check) =>
          check.name.startsWith("provider-read-authorization:") && check.status === "WARN"
        ));
      }
    }
  } finally {
    await close();
    await new Promise<void>((resolve) => server.close(() => resolve()));
    rmSync(parent, { recursive: true, force: true });
  }
});

test("runtime defense rejects a third-party package in a programmatically forged loaded root", async () => {
  const parent = mkdtempSync(join(tmpdir(), "pm-third-party-runtime-"));
  try {
    const worker = await buildSignedProviderWorker(parent);
    const adapters = firstPartyAdapterPackages.map((adapterPackage) => worker.signPackage(adapterPackage));
    const configuration = liveRuntimeConfiguration(parent);
    const trustRoot = writeTrustRoot(
      parent,
      liveBundle(1, adapters),
      configuration,
      [{ path: TEST_SIGNING_KEY_PATH, publicKeyPem: worker.publicKeyPem }],
    );
    const loaded = loadTrustedRoot({ rootPath: trustRoot });
    const thirdPartyId = "adapter.third-party.v1" as typeof adapters[number]["packageId"];
    const thirdPartyPackage = worker.signPackage({
      ...firstPartyAdapterPackages[0],
      packageId: thirdPartyId,
    });
    const forgedBinding = {
      ...loaded.providerRuntime!.configuration.adapters[0]!,
      packageId: thirdPartyId,
    };
    const forgedRoot = {
      ...loaded,
      bundle: {
        ...loaded.bundle,
        adapters: [thirdPartyPackage, ...loaded.bundle.adapters.slice(1)],
      },
      providerRuntime: {
        ...loaded.providerRuntime!,
        configuration: {
          ...loaded.providerRuntime!.configuration,
          adapters: [forgedBinding, ...loaded.providerRuntime!.configuration.adapters.slice(1)],
        },
      },
    } as unknown as typeof loaded;
    const result = createProviderRuntime(forgedRoot, {
      environment: { PM_TEST_TOKEN: "not-returned" },
      releaseArtifacts: [{
        packageArtifactPath: TEST_PACKAGE_ARTIFACT_PATH,
        artifactPath: worker.artifactPath,
        artifactSha256: worker.artifactSha256,
      }],
    });
    assert.equal(result.registrations.length, 6);
    assert.ok(result.issues.some((issue) =>
      issue.packageId === thirdPartyId && issue.code === "THIRD_PARTY_ADAPTER_NOT_SUPPORTED"
    ));
    assert.doesNotMatch(JSON.stringify(result), /not-returned/u);
    await result.close();
  } finally {
    rmSync(parent, { recursive: true, force: true });
  }
});

test("missing credential fails closed before a worker registration exists", async () => {
  const parent = mkdtempSync(join(tmpdir(), "pm-live-runtime-"));
  try {
    const worker = await buildSignedProviderWorker(parent);
    const adapters = firstPartyAdapterPackages.map((adapterPackage) => worker.signPackage(adapterPackage));
    const configuration = liveRuntimeConfiguration(parent);
    const trustRoot = writeTrustRoot(
      parent,
      liveBundle(1, adapters),
      configuration,
      [{ path: TEST_SIGNING_KEY_PATH, publicKeyPem: worker.publicKeyPem }],
    );
    const result = createProviderRuntime(loadTrustedRoot({ rootPath: trustRoot }), {
      environment: {},
      releaseArtifacts: [{
        packageArtifactPath: TEST_PACKAGE_ARTIFACT_PATH,
        artifactPath: worker.artifactPath,
        artifactSha256: worker.artifactSha256,
      }],
    });
    assert.equal(result.registrations.length, 6);
    assert.ok(result.issues.some((issue) => issue.packageId === "adapter.prometheus.v1" && issue.code === "CREDENTIAL_UNAVAILABLE"));
    assert.doesNotMatch(JSON.stringify(result), /Bearer|token=/iu);
    await result.close();
  } finally {
    rmSync(parent, { recursive: true, force: true });
  }
});

test("production worker admission rejects workload and broker references without a launcher resolver", async () => {
  const parent = mkdtempSync(join(tmpdir(), "pm-live-runtime-"));
  try {
    const worker = await buildSignedProviderWorker(parent);
    const adapters = firstPartyAdapterPackages.map((adapterPackage) => worker.signPackage(adapterPackage));
    const base = liveBundle(1, adapters);
    const endpoints = base.endpoints.map((endpoint) => endpoint.endpointId === "prometheus-main"
      ? {
          ...endpoint,
          authentication: {
            mode: "BEARER" as const,
            tokenRef: { kind: "workload_identity" as const, key: "prometheus-reader" },
          },
        }
      : endpoint);
    const profileDraft = {
      ...base.profile,
      endpointRegistrySha256: sha256Canonical(endpoints),
    };
    const profile = {
      ...profileDraft,
      configSha256: computeTrustedProfileConfigHash(profileDraft),
    };
    const unsealed = { ...base, profile, endpoints };
    const bundle = { ...unsealed, integrity: computeIntegrity(unsealed) };
    const configuration = liveRuntimeConfiguration(parent);
    configuration.adapters[0]!.credentialEnv = [];
    const trustRoot = writeTrustRoot(
      parent,
      bundle,
      configuration,
      [{ path: TEST_SIGNING_KEY_PATH, publicKeyPem: worker.publicKeyPem }],
    );
    const result = createProviderRuntime(loadTrustedRoot({ rootPath: trustRoot }), {
      environment: { "prometheus-reader": "must-not-be-treated-as-an-environment-reference" },
      releaseArtifacts: [{
        packageArtifactPath: TEST_PACKAGE_ARTIFACT_PATH,
        artifactPath: worker.artifactPath,
        artifactSha256: worker.artifactSha256,
      }],
    });
    assert.equal(result.registrations.length, 6);
    assert.ok(result.issues.some((issue) =>
      issue.packageId === "adapter.prometheus.v1" && issue.code === "CREDENTIAL_RESOLVER_NOT_CONFIGURED"
    ));
    assert.doesNotMatch(JSON.stringify(result), /must-not-be-treated/u);
    await result.close();
  } finally {
    rmSync(parent, { recursive: true, force: true });
  }
});

test("missing runtime file cannot silently downgrade to built-in or empty ready registrations", async () => {
  const parent = mkdtempSync(join(tmpdir(), "pm-live-runtime-"));
  try {
    const worker = await buildSignedProviderWorker(parent);
    const adapters = firstPartyAdapterPackages.map((adapterPackage) => worker.signPackage(adapterPackage));
    const trustRoot = writeTrustRoot(parent, liveBundle(1, adapters));
    const result = createProviderRuntime(loadTrustedRoot({ rootPath: trustRoot }));
    assert.deepEqual(result.registrations, []);
    assert.ok(result.issues.some((issue) => issue.code === "PROVIDER_RUNTIME_NOT_CONFIGURED"));
    await result.close();
  } finally {
    rmSync(parent, { recursive: true, force: true });
  }
});
