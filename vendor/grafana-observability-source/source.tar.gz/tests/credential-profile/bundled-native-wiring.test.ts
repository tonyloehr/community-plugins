import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, realpathSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import test from "node:test";

import {
  BUNDLED_MCP_MACOS_KEYCHAIN_ASSETS,
  createBundledMcpMacOsKeychainLoader,
  createGrafanaObservabilityRuntimeFromEnvironment,
} from "../../packages/grafana-mcp-server/src/runtime.ts";
import {
  BUNDLED_MACOS_KEYCHAIN_ASSETS,
  createBundledMacOsKeychainLoader,
} from "../../packages/observability-cli/src/entrypoint.ts";
import {
  BUNDLED_PRODUCTION_MACOS_KEYCHAIN_ASSETS,
  createBundledProductionMacOsKeychainLoader,
  createProductionMonitoringRuntimeFromEnvironment,
} from "../../packages/mcp-server/src/entrypoint.ts";
import {
  grafanaObservabilityPluginDescriptor,
  pluginNativeAssetForTarget,
  productionMonitoringPluginDescriptor,
} from "../../scripts/plugin-descriptors.mjs";

test("CLI, MCP, and release descriptors share the literal pinned macOS assets", () => {
  for (const architecture of ["arm64", "x64"] as const) {
    const asset = pluginNativeAssetForTarget(
      grafanaObservabilityPluginDescriptor,
      "darwin",
      architecture,
    );
    assert.ok(asset !== undefined);
    assert.deepEqual(BUNDLED_MACOS_KEYCHAIN_ASSETS[architecture], {
      bytes: asset.bytes,
      sha256: asset.sha256,
    });
    assert.deepEqual(BUNDLED_MCP_MACOS_KEYCHAIN_ASSETS[architecture], {
      bytes: asset.bytes,
      sha256: asset.sha256,
    });
    assert.deepEqual(BUNDLED_PRODUCTION_MACOS_KEYCHAIN_ASSETS[architecture], {
      bytes: asset.bytes,
      sha256: asset.sha256,
    });
    const productionAsset = pluginNativeAssetForTarget(
      productionMonitoringPluginDescriptor,
      "darwin",
      architecture,
    );
    assert.deepEqual(productionAsset, asset);
    assert.doesNotThrow(() => createBundledMacOsKeychainLoader({
      platform: "darwin",
      architecture,
    }));
    assert.doesNotThrow(() => createBundledMcpMacOsKeychainLoader({
      platform: "darwin",
      architecture,
    }));
    assert.doesNotThrow(() => createBundledProductionMacOsKeychainLoader({
      platform: "darwin",
      architecture,
    }));
  }
});

test("bundled loaders fail closed on Linux, Windows, and unsupported architectures", () => {
  for (const platform of ["linux", "win32"] as const) {
    assert.throws(
      () => createBundledMacOsKeychainLoader({ platform, architecture: "arm64" }),
      /native OS keyring backend is unavailable/u,
    );
    assert.throws(
      () => createBundledMcpMacOsKeychainLoader({ platform, architecture: "x64" }),
      /native OS keyring backend is unavailable/u,
    );
    assert.throws(
      () => createBundledProductionMacOsKeychainLoader({ platform, architecture: "arm64" }),
      /native OS keyring backend is unavailable/u,
    );
  }
  assert.throws(
    () => createBundledMacOsKeychainLoader({ platform: "darwin", architecture: "ia32" }),
    /native OS keyring backend is unavailable/u,
  );
});

test("release runtime wiring uses only bundle-relative URLs and supports explicit backend injection", async () => {
  const cliSource = readFileSync(resolve("packages/observability-cli/src/entrypoint.ts"), "utf8");
  const mcpSource = readFileSync(resolve("packages/grafana-mcp-server/src/runtime.ts"), "utf8");
  const productionSource = readFileSync(resolve("packages/mcp-server/src/entrypoint.ts"), "utf8");
  for (const source of [cliSource, mcpSource, productionSource]) {
    assert.match(source, /new URL\("\.\.\/native\/keyring\.darwin-arm64\.node", import\.meta\.url\)/u);
    assert.match(source, /new URL\("\.\.\/native\/keyring\.darwin-x64\.node", import\.meta\.url\)/u);
    assert.doesNotMatch(source, /@napi-rs\/keyring(?:"|'|\/index\.js)/u);
    assert.doesNotMatch(source, /KEYRING_(?:PATH|MODULE|BINARY)|execFile|spawn|process\.dlopen/u);
  }

  const backend = {
    async getSecret() { return undefined; },
    async setSecret() {},
    async deleteSecret() { return false; },
  };
  const testRoot = mkdtempSync(resolve(
    realpathSync.native(tmpdir()),
    "production-monitoring-native-wiring-",
  ));
  try {
    const runtime = createGrafanaObservabilityRuntimeFromEnvironment({
      PRODUCTION_MONITORING_MODE: "fixture",
      PRODUCTION_MONITORING_ARTIFACT_ROOT: resolve(testRoot, "grafana-artifacts"),
      PRODUCTION_MONITORING_STATE_ROOT: resolve(testRoot, "grafana-state"),
    }, {
      grafanaKeyringBackend: backend,
      platform: "linux",
      architecture: "x64",
    });
    await runtime.close();
    const productionRuntime = createProductionMonitoringRuntimeFromEnvironment({
      PRODUCTION_MONITORING_MODE: "fixture",
      PRODUCTION_MONITORING_ARTIFACT_ROOT: resolve(testRoot, "production-artifacts"),
      PRODUCTION_MONITORING_STATE_ROOT: resolve(testRoot, "production-state"),
    }, {
      grafanaKeyringBackend: backend,
      platform: "linux",
      architecture: "x64",
    });
    await productionRuntime.close();
  } finally {
    rmSync(testRoot, { recursive: true, force: true });
  }
});
