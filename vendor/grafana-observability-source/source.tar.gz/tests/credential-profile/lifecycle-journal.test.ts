import assert from "node:assert/strict";
import test from "node:test";

import {
  committedGrafanaCredentialLifecycleJournal,
  grafanaCredentialReference,
  legacyGrafanaCredentialReference,
  parseGrafanaCredentialLifecycleJournal,
  type GrafanaCredentialLifecycleJournalV1,
} from "../../packages/grafana-credential-profile/src/index.ts";

const PROFILE_ID = "9d78d956-6379-4bc6-9164-ecb862cf41a6";

function rotationJournal(): GrafanaCredentialLifecycleJournalV1 {
  return {
    schemaVersion: "1.0.0",
    operation: "ROTATE",
    phase: "PREPARED",
    profileId: PROFILE_ID,
    previousRevision: 1,
    previousCredentialRef: grafanaCredentialReference(PROFILE_ID, 1),
    nextRevision: 2,
    nextCredentialRef: grafanaCredentialReference(PROFILE_ID, 2),
  };
}

test("credential lifecycle journals are exact, nonsecret, and phase monotonic", () => {
  const prepared = rotationJournal();
  assert.deepEqual(parseGrafanaCredentialLifecycleJournal(prepared), prepared);
  const committed = committedGrafanaCredentialLifecycleJournal(prepared);
  assert.equal(committed.phase, "COMMITTED");
  assert.doesNotMatch(JSON.stringify(committed), /Bearer |password|secret-canary/iu);
  assert.throws(() => parseGrafanaCredentialLifecycleJournal({
    ...prepared,
    secret: "must-not-be-accepted",
  }));
  assert.throws(() => parseGrafanaCredentialLifecycleJournal({
    ...prepared,
    nextCredentialRef: prepared.previousCredentialRef,
  }));
  assert.throws(() => parseGrafanaCredentialLifecycleJournal({
    ...prepared,
    nextRevision: 3,
  }));
  assert.throws(() => parseGrafanaCredentialLifecycleJournal({
    ...prepared,
    previousRevision: 2,
    nextRevision: 3,
  }));
});

test("connect and delete journals enforce their nullable authority endpoints", () => {
  const connect = parseGrafanaCredentialLifecycleJournal({
    schemaVersion: "1.0.0",
    operation: "CONNECT",
    phase: "PREPARED",
    profileId: PROFILE_ID,
    previousRevision: null,
    previousCredentialRef: null,
    nextRevision: 1,
    nextCredentialRef: grafanaCredentialReference(PROFILE_ID, 1),
  });
  assert.equal(connect.operation, "CONNECT");
  const deletion = parseGrafanaCredentialLifecycleJournal({
    schemaVersion: "1.0.0",
    operation: "DELETE",
    phase: "COMMITTED",
    profileId: PROFILE_ID,
    previousRevision: 2,
    previousCredentialRef: grafanaCredentialReference(PROFILE_ID, 2),
    nextRevision: null,
    nextCredentialRef: null,
  });
  assert.equal(deletion.operation, "DELETE");
  assert.throws(() => parseGrafanaCredentialLifecycleJournal({
    ...connect,
    previousRevision: 1,
  }));
  assert.throws(() => parseGrafanaCredentialLifecycleJournal({
    ...deletion,
    nextRevision: 3,
  }));
  assert.equal(parseGrafanaCredentialLifecycleJournal({
    ...rotationJournal(),
    previousRevision: 4,
    previousCredentialRef: legacyGrafanaCredentialReference(PROFILE_ID),
    nextRevision: 5,
    nextCredentialRef: grafanaCredentialReference(PROFILE_ID, 5),
  }).previousCredentialRef?.key, legacyGrafanaCredentialReference(PROFILE_ID).key);
  assert.throws(() => parseGrafanaCredentialLifecycleJournal({
    ...rotationJournal(),
    nextCredentialRef: legacyGrafanaCredentialReference(PROFILE_ID),
  }));
});
