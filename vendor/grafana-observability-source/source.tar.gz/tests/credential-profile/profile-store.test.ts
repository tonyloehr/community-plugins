import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, linkSync, lstatSync, mkdirSync, mkdtempSync, rmSync, symlinkSync, unlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import {
  addSharedGrafanaProfile,
  committedGrafanaCredentialLifecycleJournal,
  createSharedGrafanaProfile,
  grafanaCredentialReference,
  SharedGrafanaProfileStore,
  sharedGrafanaProfileStateRoot,
} from "../../packages/grafana-credential-profile/src/index.ts";

const PROFILE_ID = "9d78d956-6379-4bc6-9164-ecb862cf41a6";
const LIFECYCLE_LOCK = "grafana-profile-lifecycle-v1.lock";
const JOURNAL = "grafana-credential-lifecycle-journal-v1.json";

test("profile registry is owner-only, atomic, and contains no credential value", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-profile-store-"));
  const root = join(parent, "state");
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const store = new SharedGrafanaProfileStore({ rootPath: root, platform: process.platform === "linux" ? "linux" : "darwin" });
  const profile = createSharedGrafanaProfile({
    profileId: PROFILE_ID,
    profileName: "Operations",
    grafanaOrigin: "https://grafana.example.com",
  });
  await store.update((registry) => addSharedGrafanaProfile(registry, profile));
  assert.deepEqual((await store.read()).profiles, [profile]);
  assert.equal(lstatSync(root).mode & 0o077, 0);
  const registryPath = join(root, "grafana-profiles-v1.json");
  assert.equal(lstatSync(registryPath).mode & 0o077, 0);
  assert.equal(lstatSync(registryPath).nlink, 1);
  assert.doesNotMatch(String(await import("node:fs/promises").then(({ readFile }) => readFile(registryPath, "utf8"))), /Bearer |token|password|secret/iu);
});

test("profile registry refuses symlink, hardlink, and malformed lifecycle-lock state", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-profile-store-adversarial-"));
  const root = join(parent, "state");
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const store = new SharedGrafanaProfileStore({ rootPath: root, platform: process.platform === "linux" ? "linux" : "darwin" });
  await store.read();
  const registryPath = join(root, "grafana-profiles-v1.json");
  const target = join(parent, "target.json");
  writeFileSync(target, "{}", { mode: 0o600 });
  symlinkSync(target, registryPath);
  await assert.rejects(store.read(), /state is unavailable/u);
  rmSync(registryPath);

  linkSync(target, registryPath);
  await assert.rejects(store.read(), /state is unavailable/u);
  rmSync(registryPath);

  mkdirSync(join(root, LIFECYCLE_LOCK), { mode: 0o700 });
  await assert.rejects(store.update((registry) => ({ ...registry })), /state is unavailable/u);
});

test("profile lifecycle lock preserves an active owner and recovers after SIGKILL", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-profile-store-lifecycle-"));
  const root = join(parent, "state");
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const platform = process.platform === "linux" ? "linux" : "darwin";
  const store = new SharedGrafanaProfileStore({ rootPath: root, platform });
  await store.read();
  const lockPath = join(root, LIFECYCLE_LOCK);

  writeFileSync(lockPath, JSON.stringify({
    schemaVersion: "1.0.0",
    pid: process.pid,
    createdAtMs: Date.now(),
    nonce: "11111111-1111-4111-8111-111111111111",
  }), { mode: 0o600 });
  await assert.rejects(
    store.update((registry) => ({ ...registry })),
    /state is unavailable/u,
  );
  assert.equal(existsSync(lockPath), true);
  unlinkSync(lockPath);

  const child = spawnSync(process.execPath, [
    "--import",
    "tsx",
    "--input-type=module",
    "--eval",
    `
      import { writeFileSync } from "node:fs";
      import { SharedGrafanaProfileStore } from "./packages/grafana-credential-profile/src/index.ts";
      const store = new SharedGrafanaProfileStore({ rootPath: ${JSON.stringify(root)}, platform: ${JSON.stringify(platform)} });
      await store.withExclusiveLifecycle(async () => {
        writeFileSync(${JSON.stringify(join(root, ".grafana-profiles-v1.json.tmp"))}, "abandoned-nonsecret-temp", { mode: 0o600 });
        process.kill(process.pid, "SIGKILL");
        await new Promise(() => undefined);
      });
    `,
  ], { cwd: process.cwd(), encoding: "utf8" });
  assert.equal(child.signal, "SIGKILL", child.stderr);
  assert.equal(existsSync(lockPath), true);
  assert.equal(existsSync(join(root, ".grafana-profiles-v1.json.tmp")), true);

  await store.update((registry) => ({ ...registry }));
  assert.equal(existsSync(lockPath), false);
  assert.equal(existsSync(join(root, ".grafana-profiles-v1.json.tmp")), false);
});

test("profile lifecycle journal rejects an active writer and malformed durable bytes", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-profile-store-journal-"));
  const root = join(parent, "state");
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const store = new SharedGrafanaProfileStore({
    rootPath: root,
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  await store.read();
  const journalLock = join(root, `${JOURNAL}.lock`);
  writeFileSync(journalLock, JSON.stringify({
    schemaVersion: "1.0.0",
    pid: process.pid,
    createdAtMs: Date.now(),
    nonce: "22222222-2222-4222-8222-222222222222",
  }), { mode: 0o600 });
  await assert.rejects(
    store.withExclusiveLifecycle(async () => undefined),
    /state is unavailable/u,
  );
  assert.equal(existsSync(journalLock), true);
  unlinkSync(journalLock);

  writeFileSync(join(root, JOURNAL), "{\"malformed\":true}\n", { mode: 0o600 });
  await assert.rejects(
    store.withExclusiveLifecycle(async () => undefined),
    /state is unavailable/u,
  );
});

test("profile lifecycle journal permits only one PREPARED to matching COMMITTED transition", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-profile-store-journal-transition-"));
  const root = join(parent, "state");
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const store = new SharedGrafanaProfileStore({
    rootPath: root,
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const prepared = {
    schemaVersion: "1.0.0" as const,
    operation: "ROTATE" as const,
    phase: "PREPARED" as const,
    profileId: PROFILE_ID,
    previousRevision: 1,
    previousCredentialRef: grafanaCredentialReference(PROFILE_ID, 1),
    nextRevision: 2,
    nextCredentialRef: grafanaCredentialReference(PROFILE_ID, 2),
  };
  await store.withExclusiveLifecycle(async (transaction) => {
    await transaction.writeCredentialLifecycleJournal(prepared);
    await assert.rejects(
      transaction.writeCredentialLifecycleJournal({ ...prepared }),
      /state is unavailable/u,
    );
    await assert.rejects(
      transaction.writeCredentialLifecycleJournal({
        ...prepared,
        operation: "DELETE",
        previousRevision: 1,
        previousCredentialRef: grafanaCredentialReference(PROFILE_ID, 1),
        nextRevision: null,
        nextCredentialRef: null,
      }),
      /state is unavailable/u,
    );
    await transaction.writeCredentialLifecycleJournal(
      committedGrafanaCredentialLifecycleJournal(prepared),
    );
    await assert.rejects(
      transaction.writeCredentialLifecycleJournal(prepared),
      /state is unavailable/u,
    );
    assert.equal(transaction.readCredentialLifecycleJournal()?.phase, "COMMITTED");
    await transaction.clearCredentialLifecycleJournal();
  });
  await store.withExclusiveLifecycle(async (transaction) => {
    await assert.rejects(
      transaction.writeCredentialLifecycleJournal(
        committedGrafanaCredentialLifecycleJournal(prepared),
      ),
      /state is unavailable/u,
    );
  });
});

test("registry update rereads authority after a post-rename directory sync failure", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-profile-store-sync-uncertainty-"));
  const root = join(parent, "state");
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const platform = process.platform === "linux" ? "linux" : "darwin";
  const store = new SharedGrafanaProfileStore({ rootPath: root, platform });
  await store.read();
  const child = spawnSync(process.execPath, [
    "--import",
    "tsx",
    "--input-type=module",
    "--eval",
    `
      import assert from "node:assert/strict";
      import { constants } from "node:fs";
      import { open } from "node:fs/promises";
      import {
        addSharedGrafanaProfile,
        createSharedGrafanaProfile,
        SharedGrafanaProfileStore,
      } from "./packages/grafana-credential-profile/src/index.ts";
      const root = ${JSON.stringify(root)};
      const probe = await open(root, constants.O_RDONLY | constants.O_DIRECTORY);
      const fileHandlePrototype = Object.getPrototypeOf(probe);
      await probe.close();
      const originalSync = fileHandlePrototype.sync;
      let injected = false;
      fileHandlePrototype.sync = async function () {
        const metadata = await this.stat();
        if (!injected && metadata.isDirectory()) {
          injected = true;
          throw new Error("injected directory sync uncertainty");
        }
        return originalSync.call(this);
      };
      const store = new SharedGrafanaProfileStore({ rootPath: root, platform: ${JSON.stringify(platform)} });
      const profile = createSharedGrafanaProfile({
        profileId: ${JSON.stringify(PROFILE_ID)},
        profileName: "Operations",
        grafanaOrigin: "https://grafana.example.com",
      });
      await store.withExclusiveLifecycle(async (transaction) => {
        await assert.rejects(
          transaction.update((registry) => addSharedGrafanaProfile(registry, profile)),
          /state is unavailable/u,
        );
        assert.deepEqual(transaction.read().profiles, [profile]);
      });
      assert.equal(injected, true);
    `,
  ], { cwd: process.cwd(), encoding: "utf8", timeout: 5_000 });
  assert.equal(child.status, 0, child.stderr);
  assert.equal(child.stdout, "");
  assert.deepEqual((await store.read()).profiles.map((profile) => profile.profileId), [PROFILE_ID]);
});

test("profile state roots support only macOS and Linux and reject relative XDG state", () => {
  assert.match(sharedGrafanaProfileStateRoot({ platform: "darwin", homeDirectory: "/Users/test" }), /Codex Observability$/u);
  assert.equal(
    sharedGrafanaProfileStateRoot({ platform: "linux", homeDirectory: "/home/test", environment: { XDG_STATE_HOME: "/state" } }),
    "/state/openai/codex-observability",
  );
  assert.throws(
    () => sharedGrafanaProfileStateRoot({ platform: "linux", homeDirectory: "/home/test", environment: { XDG_STATE_HOME: "relative" } }),
    /state is unavailable/u,
  );
  assert.throws(
    () => sharedGrafanaProfileStateRoot({ platform: "win32", homeDirectory: "C:\\Users\\test" }),
    /state is unavailable/u,
  );
});
