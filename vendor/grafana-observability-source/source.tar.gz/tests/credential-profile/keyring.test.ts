import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import test from "node:test";

import {
  addSharedGrafanaProfile,
  committedGrafanaCredentialLifecycleJournal,
  createSharedGrafanaProfile,
  GRAFANA_KEYRING_SERVICE,
  GrafanaCredentialKeyring,
  HashPinnedMacOsKeychainLoader,
  legacyGrafanaCredentialReference,
  NativeGrafanaKeyringBackend,
  removeSharedGrafanaProfile,
  replaceSharedGrafanaProfile,
  SharedGrafanaProfileCredentialSource,
  SharedGrafanaProfileStore,
  grafanaCredentialReference,
  type GrafanaKeyringBackend,
  type NativeKeyringModule,
} from "../../packages/grafana-credential-profile/src/index.ts";

const PROFILE_ID = "9d78d956-6379-4bc6-9164-ecb862cf41a6";

class FakeKeyringBackend implements GrafanaKeyringBackend {
  readonly values = new Map<string, Uint8Array>();
  failReads = false;

  async getSecret(service: string, account: string): Promise<Uint8Array | undefined> {
    if (this.failReads) throw new Error("backend-sensitive-error");
    const value = this.values.get(`${service}\0${account}`);
    return value === undefined ? undefined : Uint8Array.from(value);
  }

  async setSecret(service: string, account: string, secret: Uint8Array): Promise<void> {
    this.values.set(`${service}\0${account}`, Uint8Array.from(secret));
  }

  async deleteSecret(service: string, account: string): Promise<boolean> {
    return this.values.delete(`${service}\0${account}`);
  }
}

test("Grafana keyring resolves only one derived broker entry and zeroes leases", async () => {
  const backend = new FakeKeyringBackend();
  const keyring = new GrafanaCredentialKeyring(backend);
  const reference = grafanaCredentialReference(PROFILE_ID);
  const source = Buffer.from("canary-grafana-bearer", "ascii");
  await keyring.set(reference, source);
  assert.equal(source.toString("ascii"), "canary-grafana-bearer");
  assert.equal(backend.values.size, 1);
  assert.ok([...backend.values.keys()][0]?.startsWith(`${GRAFANA_KEYRING_SERVICE}\0profile/${PROFILE_ID}/`));
  assert.equal(await keyring.status(reference), "AVAILABLE");
  const lease = await keyring.acquire(reference);
  assert.ok(lease !== undefined);
  assert.equal(Buffer.from(lease.bytes).toString("ascii"), "canary-grafana-bearer");
  lease.dispose();
  assert.ok(lease.bytes.every((byte) => byte === 0));
  assert.equal(await keyring.acquire({ kind: "broker", key: "another-provider:key" }), undefined);
  assert.equal(await keyring.delete(reference), true);
  assert.equal(await keyring.status(reference), "MISSING_OR_UNAVAILABLE");
});

test("status collapses backend errors without exposing detail", async () => {
  const backend = new FakeKeyringBackend();
  backend.failReads = true;
  const keyring = new GrafanaCredentialKeyring(backend);
  assert.equal(await keyring.status(grafanaCredentialReference(PROFILE_ID)), "MISSING_OR_UNAVAILABLE");
});

test("shared profile credential source follows an atomic slot rotation from a stable reviewed reference", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-resolving-keyring-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeKeyringBackend();
  const keyring = new GrafanaCredentialKeyring(backend);
  const credentialSource = new SharedGrafanaProfileCredentialSource(keyring, profileStore);
  const stableReviewedReference = legacyGrafanaCredentialReference(PROFILE_ID);
  const profile = createSharedGrafanaProfile({
    profileId: PROFILE_ID,
    profileName: "Operations",
    grafanaOrigin: "https://grafana.example.com",
  });

  await keyring.set(profile.credentialRef, Buffer.from("first-slot-canary", "ascii"));
  await profileStore.update((registry) => addSharedGrafanaProfile(registry, profile));
  const firstLease = await credentialSource.acquire(stableReviewedReference);
  assert.equal(Buffer.from(firstLease?.bytes ?? []).toString("ascii"), "first-slot-canary");
  firstLease?.dispose();

  const rotated = {
    ...profile,
    credentialRef: grafanaCredentialReference(PROFILE_ID, 2),
    revision: 2,
  };
  await keyring.set(rotated.credentialRef, Buffer.from("second-slot-canary", "ascii"));
  await profileStore.update((registry) => replaceSharedGrafanaProfile(registry, rotated));
  await keyring.delete(profile.credentialRef);
  assert.equal(await keyring.status(profile.credentialRef), "MISSING_OR_UNAVAILABLE");
  const restartedProfileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const restartedCredentialSource = new SharedGrafanaProfileCredentialSource(
    new GrafanaCredentialKeyring(backend),
    restartedProfileStore,
  );
  const rotatedLease = await restartedCredentialSource.acquire(stableReviewedReference);
  assert.equal(Buffer.from(rotatedLease?.bytes ?? []).toString("ascii"), "second-slot-canary");
  rotatedLease?.dispose();

  await restartedProfileStore.update((registry) => removeSharedGrafanaProfile(registry, profile.profileId));
  const deletedRestartSource = new SharedGrafanaProfileCredentialSource(
    new GrafanaCredentialKeyring(backend),
    new SharedGrafanaProfileStore({
      rootPath: join(parent, "state"),
      platform: process.platform === "linux" ? "linux" : "darwin",
    }),
  );
  assert.equal(await deletedRestartSource.acquire(stableReviewedReference), undefined);
});

test("shared profile credential source rejects journals that contradict committed registry authority", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-resolving-keyring-authority-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const keyring = new GrafanaCredentialKeyring(new FakeKeyringBackend());
  const credentialSource = new SharedGrafanaProfileCredentialSource(keyring, profileStore);
  const profile = createSharedGrafanaProfile({
    profileId: PROFILE_ID,
    profileName: "Operations",
    grafanaOrigin: "https://grafana.example.com",
  });
  await keyring.set(profile.credentialRef, Buffer.from("authority-secret-canary", "ascii"));
  await profileStore.update((registry) => addSharedGrafanaProfile(registry, profile));
  const preparedRotation = {
    schemaVersion: "1.0.0" as const,
    operation: "ROTATE" as const,
    phase: "PREPARED" as const,
    profileId: PROFILE_ID,
    previousRevision: 1,
    previousCredentialRef: profile.credentialRef,
    nextRevision: 2,
    nextCredentialRef: grafanaCredentialReference(PROFILE_ID, 2),
  };
  await profileStore.withExclusiveLifecycle(async (transaction) => {
    await transaction.writeCredentialLifecycleJournal(preparedRotation);
  });
  const preparedLease = await credentialSource.acquire(profile.credentialRef);
  assert.equal(Buffer.from(preparedLease?.bytes ?? []).toString("ascii"), "authority-secret-canary");
  preparedLease?.dispose();

  await profileStore.withExclusiveLifecycle(async (transaction) => {
    await transaction.writeCredentialLifecycleJournal(
      committedGrafanaCredentialLifecycleJournal(preparedRotation),
    );
  });
  assert.equal(await credentialSource.acquire(profile.credentialRef), undefined);

  await profileStore.withExclusiveLifecycle(async (transaction) => {
    await transaction.clearCredentialLifecycleJournal();
    const preparedDelete = {
      schemaVersion: "1.0.0",
      operation: "DELETE",
      phase: "PREPARED",
      profileId: PROFILE_ID,
      previousRevision: 1,
      previousCredentialRef: profile.credentialRef,
      nextRevision: null,
      nextCredentialRef: null,
    } as const;
    await transaction.writeCredentialLifecycleJournal(preparedDelete);
    await transaction.writeCredentialLifecycleJournal(
      committedGrafanaCredentialLifecycleJournal(preparedDelete),
    );
  });
  assert.equal(await credentialSource.acquire(profile.credentialRef), undefined);
});

test("native boundary rejects keyutils and any unattested platform backend", async () => {
  const unsafeModule = {
    backendKind: "LINUX_KEYUTILS",
    createEntry() {
      throw new Error("must not be called");
    },
  } as unknown as NativeKeyringModule;
  const backend = new NativeGrafanaKeyringBackend({
    platform: "linux",
    loader: { async load() { return unsafeModule; } },
  });
  await assert.rejects(
    backend.getSecret(GRAFANA_KEYRING_SERVICE, `profile/${PROFILE_ID}/bearer/v1`),
    /native OS keyring backend is unavailable/u,
  );
  let claimedSecretServiceLoaded = false;
  const claimedSecretService = new NativeGrafanaKeyringBackend({
    platform: "linux",
    loader: {
      async load() {
        claimedSecretServiceLoaded = true;
        return { ...unsafeModule, backendKind: "LINUX_SECRET_SERVICE" } as NativeKeyringModule;
      },
    },
  });
  await assert.rejects(
    claimedSecretService.getSecret(GRAFANA_KEYRING_SERVICE, `profile/${PROFILE_ID}/bearer/v1`),
    /native OS keyring backend is unavailable/u,
  );
  assert.equal(claimedSecretServiceLoaded, false);
  assert.throws(
    () => new NativeGrafanaKeyringBackend({ platform: "win32", loader: { async load() { return unsafeModule; } } }),
    /native OS keyring backend is unavailable/u,
  );
});

test("macOS loader imports only a private copy of the exact hash-pinned addon", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-native-loader-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const filename = "keyring.darwin-arm64.node";
  const sourcePath = join(parent, filename);
  const source = Buffer.from("test-only-native-addon-canary", "ascii");
  writeFileSync(sourcePath, source, { mode: 0o400 });
  const values = new Map<string, Uint8Array>();
  class AsyncEntry {
    readonly key: string;
    constructor(service: string, account: string) { this.key = `${service}\0${account}`; }
    async getSecret(): Promise<Uint8Array | undefined> {
      const value = values.get(this.key);
      return value === undefined ? undefined : Uint8Array.from(value);
    }
    async setSecret(secret: Uint8Array): Promise<void> { values.set(this.key, Uint8Array.from(secret)); }
    async deleteCredential(): Promise<boolean> { return values.delete(this.key); }
  }
  let importedPath = "";
  const loader = new HashPinnedMacOsKeychainLoader({
    platform: "darwin",
    architecture: "arm64",
    asset: {
      fileUrl: pathToFileURL(sourcePath),
      bytes: source.byteLength,
      sha256: createHash("sha256").update(source).digest("hex"),
    },
    importer(absolutePath) {
      importedPath = absolutePath;
      assert.notEqual(absolutePath, sourcePath);
      assert.deepEqual(readFileSync(absolutePath), source);
      return { AsyncEntry };
    },
  });
  const backend = new NativeGrafanaKeyringBackend({ platform: "darwin", loader });
  const account = `profile/${PROFILE_ID}/bearer/v1`;
  const secret = Uint8Array.from(Buffer.from("native-secret-canary", "ascii"));
  await backend.setSecret(GRAFANA_KEYRING_SERVICE, account, secret);
  assert.equal(Buffer.from(await backend.getSecret(GRAFANA_KEYRING_SERVICE, account) ?? []).toString("ascii"), "native-secret-canary");
  assert.equal(await backend.deleteSecret(GRAFANA_KEYRING_SERVICE, account), true);
  assert.notEqual(importedPath, "");
  assert.equal(existsSync(importedPath), false);
  assert.equal(existsSync(sourcePath), true);
});

test("macOS loader rejects a mismatched asset before native import", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-native-loader-reject-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const sourcePath = join(parent, "keyring.darwin-arm64.node");
  const source = Buffer.from("tampered-native-addon", "ascii");
  writeFileSync(sourcePath, source, { mode: 0o400 });
  let imported = false;
  const loader = new HashPinnedMacOsKeychainLoader({
    platform: "darwin",
    architecture: "arm64",
    asset: {
      fileUrl: pathToFileURL(sourcePath),
      bytes: source.byteLength,
      sha256: "0".repeat(64),
    },
    importer() {
      imported = true;
      return {};
    },
  });
  await assert.rejects(loader.load(), /native OS keyring backend is unavailable/u);
  assert.equal(imported, false);
});
