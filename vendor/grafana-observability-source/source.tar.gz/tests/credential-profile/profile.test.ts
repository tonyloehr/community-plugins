import assert from "node:assert/strict";
import test from "node:test";

import {
  addSharedGrafanaProfile,
  createSharedGrafanaProfile,
  emptySharedGrafanaProfileRegistry,
  grafanaCredentialReference,
  grafanaKeyringAccount,
  legacyGrafanaCredentialReference,
  normalizeGrafanaOrigin,
  parseSharedGrafanaProfile,
  parseSharedGrafanaProfileRegistry,
} from "../../packages/grafana-credential-profile/src/index.ts";

const PROFILE_ID = "9d78d956-6379-4bc6-9164-ecb862cf41a6";

test("SharedGrafanaProfileV1 is exact, nonsecret, and derives one broker account", () => {
  const profile = createSharedGrafanaProfile({
    profileId: PROFILE_ID,
    profileName: "Operations",
    grafanaOrigin: "https://grafana.example.com/",
  });
  assert.deepEqual(profile, {
    schemaVersion: "1.0.0",
    profileId: PROFILE_ID,
    profileName: "Operations",
    grafanaOrigin: "https://grafana.example.com",
    networkClass: "public",
    credentialRef: { kind: "broker", key: `grafana:${PROFILE_ID}:bearer:v1` },
    revision: 1,
  });
  assert.equal(grafanaKeyringAccount(profile.credentialRef), `profile/${PROFILE_ID}/bearer/v1`);
  assert.equal(grafanaKeyringAccount({ kind: "env", key: profile.credentialRef.key }), undefined);
  assert.deepEqual(grafanaCredentialReference(PROFILE_ID), profile.credentialRef);
  assert.deepEqual(grafanaCredentialReference(PROFILE_ID, 2), {
    kind: "broker",
    key: `grafana:${PROFILE_ID}:bearer:v2`,
  });
  assert.equal(
    grafanaKeyringAccount(grafanaCredentialReference(PROFILE_ID, 2)),
    `profile/${PROFILE_ID}/bearer/v2`,
  );
  assert.equal(
    grafanaKeyringAccount(legacyGrafanaCredentialReference(PROFILE_ID)),
    `profile/${PROFILE_ID}/bearer`,
  );
  assert.doesNotMatch(JSON.stringify(profile), /authorization|password|token|secret/iu);

  assert.throws(
    () => parseSharedGrafanaProfile({ ...profile, token: "must-not-be-accepted" }),
    /invalid or unavailable/u,
  );
  assert.throws(
    () => parseSharedGrafanaProfile({
      ...profile,
      credentialRevision: profile.revision,
      createdAt: "2026-08-15T01:02:03.000Z",
      updatedAt: "2026-08-15T01:02:03.000Z",
    }),
    /invalid or unavailable/u,
  );
  assert.throws(
    () => parseSharedGrafanaProfile({
      ...profile,
      credentialRef: { kind: "broker", key: `grafana:${PROFILE_ID}:bearer:v2` },
    }),
    /invalid or unavailable/u,
  );
  assert.deepEqual(parseSharedGrafanaProfile({
    ...profile,
    credentialRef: grafanaCredentialReference(PROFILE_ID, 2),
    revision: 2,
  }).credentialRef, grafanaCredentialReference(PROFILE_ID, 2));
  assert.equal(parseSharedGrafanaProfile({ ...profile, revision: 2 }).credentialRef.key, profile.credentialRef.key);
  assert.deepEqual(parseSharedGrafanaProfile({
    ...profile,
    credentialRef: legacyGrafanaCredentialReference(PROFILE_ID),
    revision: 7,
  }).credentialRef, legacyGrafanaCredentialReference(PROFILE_ID));
});

test("Grafana origins are canonical and insecure non-loopback or embedded material is rejected", () => {
  assert.deepEqual(normalizeGrafanaOrigin("http://127.0.0.1:3000/"), {
    grafanaOrigin: "http://127.0.0.1:3000",
    networkClass: "loopback",
  });
  assert.deepEqual(normalizeGrafanaOrigin("https://10.1.2.3"), {
    grafanaOrigin: "https://10.1.2.3",
    networkClass: "private",
  });
  for (const unsafe of [
    "http://grafana.example.com",
    "https://user:pass@grafana.example.com",
    "https://grafana.example.com/path",
    "https://grafana.example.com/?token=hidden",
    "https://grafana.example.com/#fragment",
    "file:///tmp/grafana",
  ]) {
    assert.throws(() => normalizeGrafanaOrigin(unsafe), /invalid or unavailable/u);
  }
});

test("registry parsing rejects duplicates, dangling active IDs, and unknown fields", () => {
  const profile = createSharedGrafanaProfile({
    profileId: PROFILE_ID,
    profileName: "Operations",
    grafanaOrigin: "https://grafana.example.com",
  });
  const registry = addSharedGrafanaProfile(emptySharedGrafanaProfileRegistry(), profile);
  assert.deepEqual(parseSharedGrafanaProfileRegistry(registry), registry);
  assert.throws(
    () => parseSharedGrafanaProfileRegistry({ ...registry, profiles: [profile, profile] }),
    /invalid or unavailable/u,
  );
  assert.throws(
    () => parseSharedGrafanaProfileRegistry({ ...registry, activeProfileId: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa" }),
    /invalid or unavailable/u,
  );
  assert.throws(
    () => parseSharedGrafanaProfileRegistry({ ...registry, credential: "forbidden" }),
    /invalid or unavailable/u,
  );
});
