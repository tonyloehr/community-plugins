import assert from "node:assert/strict";
import test from "node:test";

import {
  createFixtureOperationSnapshot,
  fixtureAdapter,
  fixtureAdapterPackage,
  FIXTURE_TENANT_SHA256,
} from "../../adapters/fixture/src/index.ts";
import {
  EvidenceHost,
  MemoryAuditSink,
  MemoryEvidenceStore,
  StaticAdapterRegistry,
  builtinRegistration,
  type AdapterHostPolicy,
  type AuthorizedRunContext,
} from "../../packages/adapter-host/src/index.ts";
import {
  defaultRedactionPolicy,
  type EvidenceAdapter,
  type ProviderResult,
} from "../../packages/adapter-sdk/src/index.ts";
import {
  computeOperationDefinitionHash,
  type OperationSnapshot,
  type RunId,
  type Sha256,
} from "../../packages/contracts/src/index.ts";

const CLOCK = { now: () => new Date("2026-04-05T12:00:00.000Z") };
const BASE_POLICY: AdapterHostPolicy = {
  auditRequired: true,
  maxDefinitionBytes: 64_000,
  maxClockSkewMs: 1_000,
};

function runFor(operation: OperationSnapshot): AuthorizedRunContext {
  return {
    runId: "pmrun_security" as RunId,
    trustBundleSha256: "b".repeat(64) as Sha256,
    origin: "REPLAY",
    scope: { environment: "test", service: "checkout" },
    window: { start: "2026-04-05T11:55:00.000Z", end: "2026-04-05T12:00:00.000Z" },
    allowedOperationHashes: { [operation.operationId]: operation.definitionSha256 },
    authorizedOperationLimits: { [operation.operationId]: operation.definition.limits },
    expectedTenantSha256: FIXTURE_TENANT_SHA256,
  };
}

function host(adapter: EvidenceAdapter = fixtureAdapter, policy: AdapterHostPolicy = BASE_POLICY): EvidenceHost {
  return new EvidenceHost({
    registry: new StaticAdapterRegistry([builtinRegistration(fixtureAdapterPackage, adapter)]),
    audit: new MemoryAuditSink(),
    store: new MemoryEvidenceStore(),
    policy,
    clock: CLOCK,
  });
}

async function collect(
  operation: OperationSnapshot,
  adapter: EvidenceAdapter = fixtureAdapter,
  policy: AdapterHostPolicy = BASE_POLICY,
) {
  return host(adapter, policy).collect({
    run: runFor(operation),
    operation,
    effectiveLimits: operation.definition.limits,
    adapterPackage: fixtureAdapterPackage,
  });
}

test("prompt-injection content is rejected before normalized evidence reaches the model boundary", async () => {
  const operation = createFixtureOperationSnapshot("injection");
  const envelope = await collect(operation, fixtureAdapter, {
    ...BASE_POLICY,
    redactionPolicy: {
      ...defaultRedactionPolicy,
      rejectValuePatterns: [
        ...defaultRedactionPolicy.rejectValuePatterns,
        /ignore\s+previous\s+instructions/iu,
      ],
    },
  });
  const serialized = JSON.stringify(envelope);
  assert.equal(envelope.collectionState, "ERROR");
  assert.equal(envelope.error?.code, "SENSITIVE_PROVIDER_PAYLOAD");
  assert.equal(envelope.values.length, 0);
  assert.doesNotMatch(serialized, /ignore previous instructions|system prompt/iu);
  assert.ok(envelope.redactions.some((record) => record.path.startsWith("/warnings/")));
});

test("secret-bearing fields and values never survive the host boundary", async () => {
  const envelope = await collect(createFixtureOperationSnapshot("secret"));
  const serialized = JSON.stringify(envelope);
  assert.equal(envelope.collectionState, "ERROR");
  assert.equal(envelope.error?.code, "SENSITIVE_PROVIDER_PAYLOAD");
  assert.equal(envelope.source.sanitizedReference, undefined);
  assert.doesNotMatch(serialized, /fixture-super-secret-value|Bearer/iu);
});

test("cross-tenant results fail closed without retaining the mismatched payload", async () => {
  const envelope = await collect(createFixtureOperationSnapshot("cross-tenant"));
  const serialized = JSON.stringify(envelope);
  assert.equal(envelope.collectionState, "ERROR");
  assert.equal(envelope.error?.code, "INVALID_PROVIDER_RESPONSE");
  assert.equal(envelope.values.length, 0);
  assert.doesNotMatch(serialized, new RegExp("e".repeat(64), "u"));
  assert.doesNotMatch(serialized, /0\.01|checkout_error_rate/u);
});

test("provider IAM permissions are not interpreted as result-scope claim names", async () => {
  const operation = createFixtureOperationSnapshot("healthy");
  operation.definition.requiredProviderScopes = ["metrics.read"];
  operation.definitionSha256 = computeOperationDefinitionHash(operation);

  const envelope = await collect(operation);

  assert.equal(envelope.collectionState, "COMPLETE");
});

test("authoritative live operations require sealed environment and service mappings", async () => {
  const operation = createFixtureOperationSnapshot("healthy");
  operation.definition.authority = "AUTHORITATIVE";
  operation.definition.scopeMapping = {};
  operation.definitionSha256 = computeOperationDefinitionHash(operation);
  const run = runFor(operation);
  run.origin = "LIVE";

  await assert.rejects(
    host().collect({
      run,
      operation,
      effectiveLimits: operation.definition.limits,
      adapterPackage: fixtureAdapterPackage,
    }),
    /Authoritative live operation lacks a sealed environment scope mapping/u,
  );
});

test("mapped provider claims fail closed without adapter-verified mapping proof", async () => {
  const operation = createFixtureOperationSnapshot("healthy");
  const unproved = timeseriesResult(1, 1);
  if (unproved.providerScope !== undefined) delete unproved.providerScope.mappings;

  const envelope = await collect(operation, resultAdapter(unproved));

  assert.equal(envelope.collectionState, "ERROR");
  assert.equal(envelope.error?.code, "INVALID_PROVIDER_RESPONSE");
  assert.equal(envelope.values.length, 0);
});

test("row and byte oversize results become bounded policy errors", async () => {
  for (const [dimension, limits, expectedCode] of [
    ["rows", { maxRows: 0 }, "BUDGET_ROWS"],
    ["bytes", { maxBytes: 32 }, "BUDGET_BYTES"],
  ] as const) {
    const operation = createFixtureOperationSnapshot("healthy", { limits });
    const envelope = await collect(operation);
    assert.equal(envelope.collectionState, "ERROR", dimension);
    assert.equal(envelope.error?.code, expectedCode, dimension);
    assert.equal(envelope.values.length, 0, dimension);
  }
});

function resultAdapter(result: ProviderResult | Error): EvidenceAdapter {
  return {
    descriptor: fixtureAdapter.descriptor,
    doctor: () => fixtureAdapter.doctor(),
    compile: (operation, context) => fixtureAdapter.compile(operation, context),
    execute: async () => {
      if (result instanceof Error) throw result;
      return result;
    },
  };
}

function timeseriesResult(series: number, points: number): ProviderResult {
  return {
    schemaVersion: "1.0.0",
    collectionState: "COMPLETE",
    evaluatedAt: CLOCK.now().toISOString(),
    nativeResultType: "matrix",
    nativeDimensions: {},
    records: Array.from({ length: series }, (_, seriesIndex) => ({
      kind: "TIMESERIES" as const,
      name: `bounded_series_${seriesIndex}`,
      dimensions: {},
      points: Array.from({ length: points }, (_, pointIndex) => ({
        at: new Date(CLOCK.now().getTime() - pointIndex * 1_000).toISOString(),
        value: pointIndex,
      })),
    })),
    pagination: { complete: true, pages: 1 },
    warnings: [],
    providerScope: {
      environment: "test",
      service: "checkout",
      tenantSha256: FIXTURE_TENANT_SHA256,
      mappings: { environment: "environment", service: "service" },
    },
  };
}

test("series and point cardinality are independently enforced by the host", async () => {
  const cases = [
    {
      operation: createFixtureOperationSnapshot("healthy", { limits: { maxSeries: 1, maxPoints: 100 } }),
      adapter: resultAdapter(timeseriesResult(2, 1)),
      code: "BUDGET_SERIES",
    },
    {
      operation: createFixtureOperationSnapshot("healthy", { limits: { maxSeries: 1, maxPoints: 1 } }),
      adapter: resultAdapter(timeseriesResult(1, 2)),
      code: "BUDGET_POINTS",
    },
  ];
  for (const scenario of cases) {
    const envelope = await collect(scenario.operation, scenario.adapter);
    assert.equal(envelope.collectionState, "ERROR");
    assert.equal(envelope.error?.code, scenario.code);
    assert.equal(envelope.values.length, 0);
  }
});

test("schema drift and unknown adapter exceptions are sanitized without raw diagnostics", async () => {
  const drift = await collect(createFixtureOperationSnapshot("schema-drift"));
  assert.equal(drift.error?.code, "INVALID_PROVIDER_RESPONSE");
  assert.doesNotMatch(JSON.stringify(drift), /2\.0\.0|Unsupported provider result schema/u);

  const operation = createFixtureOperationSnapshot("healthy");
  const failure = await collect(
    operation,
    resultAdapter(new Error("Bearer host-exception-canary from https://private.internal/query")),
  );
  const serialized = JSON.stringify(failure);
  assert.equal(failure.error?.code, "ADAPTER_FAILURE");
  assert.doesNotMatch(serialized, /host-exception-canary|private\.internal|Bearer/iu);
});
