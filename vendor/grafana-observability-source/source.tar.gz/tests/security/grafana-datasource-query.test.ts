import assert from "node:assert/strict";
import test from "node:test";

import {
  CompiledGrafanaCatalog,
  grafanaCatalogEntryHash,
  normalizeGrafanaFrames,
  validateGrafanaPostgresSql,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaDatasourceQueryTarget,
  type GrafanaFrameContract,
} from "../../adapters/grafana/src/index.ts";
import {
  AdapterContractError,
  createBudgetController,
  type AdapterExecutionContext,
} from "../../packages/adapter-sdk/src/index.ts";
import type { Sha256 } from "../../packages/contracts/src/index.ts";

function entry(): GrafanaDatasourceQueryCatalogEntry {
  return {
    id: "security-query",
    route: "datasource-query",
    outputName: "request_rate",
    datasourceUid: "prometheus-main",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    target: {
      datasourceType: "prometheus",
      expression: "sum(rate(http_requests_total{environment=\"test\",service=\"checkout\"}[5m]))",
      mode: "range",
      format: "time_series",
    },
    frame: {
      resultKind: "TIMESERIES",
      fields: [
        { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
        { sourceName: "Value", outputName: "request_rate", type: "number", role: "VALUE" },
      ],
      allowedLabels: ["environment", "service"],
    },
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  };
}

function context(): AdapterExecutionContext {
  const controller = new AbortController();
  const limits = {
    timeoutMs: 1_000,
    maxAgeMs: 60_000,
    maxBytes: 64_000,
    maxRows: 20,
    maxSeries: 10,
    maxPoints: 100,
  };
  return {
    origin: "REPLAY",
    scope: { environment: "test", service: "checkout" },
    window: { start: "2026-01-01T00:00:00.000Z", end: "2026-01-01T00:05:00.000Z" },
    clock: { now: () => new Date("2026-01-01T00:05:00.000Z") },
    budget: createBudgetController(limits, controller.signal),
    signal: controller.signal,
  };
}

test("Grafana frame normalization drops provider metadata, unknown labels, query text, and datasource identity", () => {
  const trusted = entry();
  if (trusted.target.datasourceType !== "prometheus") throw new Error("test fixture drifted");
  const canary = "Bearer grafana-datasource-secret";
  const normalized = normalizeGrafanaFrames({
    results: {
      A: {
        frames: [{
          schema: {
            refId: "A",
            fields: [
              { name: "Time", type: "time" },
              {
                name: "Value",
                type: "number",
                labels: { environment: "test", service: "checkout", customer_id: canary },
                config: { links: [{ url: `https://private.invalid/${canary}` }] },
              },
            ],
          },
          data: { values: [[1767225600000], [4.5]] },
        }],
        meta: {
          executedQueryString: `${trusted.target.expression} ${canary}`,
          datasourceUid: trusted.datasourceUid,
        },
      },
    },
  }, trusted, context());
  const serialized = JSON.stringify(normalized);
  assert.doesNotMatch(serialized, /grafana-datasource-secret|customer_id|private\.invalid|prometheus-main|http_requests_total/u);
  assert.deepEqual(normalized.records[0], {
    kind: "TIMESERIES",
    name: "request_rate",
    dimensions: { environment: "test", service: "checkout" },
    points: [{ at: "2026-01-01T00:00:00.000Z", value: 4.5 }],
  });
});

test("Grafana frame normalization rejects mapped provider scope drift", () => {
  const trusted = entry();
  assert.throws(() => normalizeGrafanaFrames({
    results: {
      A: {
        frames: [{
          schema: {
            refId: "A",
            fields: [
              { name: "Time", type: "time" },
              { name: "Value", type: "number", labels: { environment: "production", service: "checkout" } },
            ],
          },
          data: { values: [[1767225600000], [1]] },
        }],
      },
    },
  }, trusted, context()), AdapterContractError);
});

test("Grafana catalog admission deep-clones targets and rejects query-language escape hatches", () => {
  const trusted = entry();
  const hash = grafanaCatalogEntryHash(trusted);
  const catalog = new CompiledGrafanaCatalog({ entries: [trusted] });
  if (trusted.target.datasourceType !== "prometheus") throw new Error("test fixture drifted");
  trusted.target.expression = "up";
  const resolved = catalog.resolve("security-query", hash);
  assert.equal(
    resolved.route === "datasource-query" &&
      resolved.target.datasourceType === "prometheus" &&
      resolved.target.expression.includes("http_requests_total"),
    true,
  );
  assert.equal(Object.isFrozen(resolved), true);
  assert.equal(resolved.route === "datasource-query" && Object.isFrozen(resolved.target), true);

  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...entry(),
    target: { ...entry().target, expression: "$environment" },
  } as GrafanaDatasourceQueryCatalogEntry] }), /variable/u);
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...entry(),
    target: {
      datasourceType: "postgres",
      rawSql: "SELECT pg_terminate_backend(pid) FROM pg_stat_activity LIMIT 10",
      format: "time_series",
      maxRows: 10,
    },
  }] }), /PostgreSQL/u);
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...entry(),
    target: {
      datasourceType: "mysql",
      rawSql: "SELECT 1 LIMIT 1",
      format: "table",
      maxRows: 1,
    },
  } as never] }), /not certified/u);
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...entry(),
    datasourceIdentitySha256: "0".repeat(63) as Sha256,
  }] }), /identity hash/u);

  const subjectRef = "pmsub_abcdefghijklmnopqrstuvwxyz" as never;
  const subjectBound = {
    ...entry(),
    frame: { ...entry().frame, allowedLabels: ["environment", "service", "instance"] },
    scope: {
      environment: "test",
      service: "checkout",
      subject: { kind: "HOST" as const, ref: subjectRef, providerValue: "node-a.internal" },
    },
    scopeMappings: { environment: "environment", service: "service", "subject.ref": "instance" },
  } satisfies GrafanaDatasourceQueryCatalogEntry;
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [subjectBound] }), /enrolled scope/u);
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...subjectBound,
    scopeMappings: { environment: "environment", service: "service" },
  } as GrafanaDatasourceQueryCatalogEntry] }), /scope mappings/u);
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...entry(),
    target: {
      datasourceType: "prometheus",
      expression: 'http_requests_total{environment="test"}',
      mode: "range",
      format: "time_series",
    },
    scope: { environment: "test", service: "test" },
    scopeMappings: { environment: "environment", service: "environment" },
  }] }), /scope mappings/u);
});

test("Grafana admission requires exact native environment and service scope without stamping", () => {
  const admit = (candidate: GrafanaDatasourceQueryCatalogEntry) =>
    new CompiledGrafanaCatalog({ entries: [candidate] });
  assert.doesNotThrow(() => admit(entry()));
  for (const expression of [
    "sum(rate(http_requests_total[5m]))",
    'sum(rate(http_requests_total{service="checkout"}[5m]))',
    'http_requests_total{environment="test",service="checkout"} + http_errors_total{environment="test"}',
    'label_replace(http_requests_total{environment="test",service="checkout"}, "environment", "test", "service", ".*")',
    'label_replace(http_requests_total{environment="test",service="checkout"}, "service", "checkout", "environment", ".*")',
  ]) {
    assert.throws(() => admit({
      ...entry(),
      target: { ...entry().target, expression },
    } as GrafanaDatasourceQueryCatalogEntry), /scope/u);
  }

  const validLoki: GrafanaDatasourceQueryCatalogEntry = {
    ...entry(),
    target: {
      datasourceType: "loki",
      expression: '{environment="test",service="checkout"} |= "error"',
      queryType: "range",
      direction: "backward",
    },
  };
  assert.doesNotThrow(() => admit(validLoki));
  for (const expression of [
    '{service="checkout"} |= "error"',
    '{environment="test",service="checkout"} | label_format environment="test"',
    '{environment="test",service="checkout"} | label_format service="checkout"',
    'sum(count_over_time({environment="test",service="checkout"}[5m])) + sum(count_over_time({service="checkout"}[5m]))',
  ]) {
    assert.throws(() => admit({
      ...validLoki,
      target: { ...validLoki.target, expression },
    } as GrafanaDatasourceQueryCatalogEntry), /scope/u);
  }

  const tableFrame: GrafanaFrameContract = {
    resultKind: "TABLE",
    fields: [
      { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
      { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      { sourceName: "value", outputName: "value", type: "number", role: "COLUMN" },
    ],
    allowedLabels: [],
  };
  const validTempo: GrafanaDatasourceQueryCatalogEntry = {
    ...entry(),
    target: {
      datasourceType: "tempo",
      expression: '{ resource.deployment.environment = "test" && resource.service.name = "checkout" }',
      queryType: "traceql",
      limit: 20,
      spansPerSpanSet: 20,
      tableType: "traces",
    },
    frame: tableFrame,
  };
  assert.doesNotThrow(() => admit(validTempo));
  for (const expression of [
    '{ resource.service.name = "checkout" }',
    '{ resource.deployment.environment = "test" || resource.service.name = "checkout" }',
    '{ resource.deployment.environment = "test" && resource.service.name = "checkout" } >> { resource.service.name = "checkout" }',
  ]) {
    assert.throws(() => admit({
      ...validTempo,
      target: { ...validTempo.target, expression },
    } as GrafanaDatasourceQueryCatalogEntry), /scope/u);
  }

  const validPostgres: GrafanaDatasourceQueryCatalogEntry = {
    ...entry(),
    target: {
      datasourceType: "postgres",
      rawSql: "SELECT environment, service, value FROM metrics WHERE environment = 'test' AND service = 'checkout' LIMIT 10",
      format: "table",
      maxRows: 10,
    },
    frame: tableFrame,
    postgresReadOnlyIdentity: {
      roleIdentitySha256: "a".repeat(64) as Sha256,
      privilegeModel: "SELECT_ONLY",
    },
  };
  assert.doesNotThrow(() => admit(validPostgres));
  for (const rawSql of [
    "SELECT environment, service, value FROM metrics WHERE environment = 'test' LIMIT 10",
    "SELECT environment, service, value FROM metrics WHERE environment = 'test' AND service = 'checkout' OR true LIMIT 10",
    "SELECT 'test' AS environment, service, value FROM metrics WHERE environment = 'test' AND service = 'checkout' LIMIT 10",
    "SELECT environment, 'checkout' AS service, value FROM metrics WHERE environment = 'test' AND service = 'checkout' LIMIT 10",
  ]) {
    assert.throws(() => admit({
      ...validPostgres,
      target: { ...validPostgres.target, rawSql },
    } as GrafanaDatasourceQueryCatalogEntry), /scope/u);
  }
});

test("Grafana subject admission requires datasource-native exact filters and rejects scope fabrication", () => {
  const subjectRef = "pmsub_abcdefghijklmnopqrstuvwxyz" as never;
  const providerValue = "node-a.internal";
  const metricFrame: GrafanaFrameContract = {
    ...entry().frame,
    allowedLabels: ["environment", "service", "instance"],
  };
  const subjectEntry = (
    target: GrafanaDatasourceQueryTarget,
    frame: GrafanaFrameContract = metricFrame,
    mapping = "instance",
  ): GrafanaDatasourceQueryCatalogEntry => ({
    ...entry(),
    target,
    ...(target.datasourceType === "postgres" || target.datasourceType === "grafana-postgresql-datasource"
      ? {
          postgresReadOnlyIdentity: {
            roleIdentitySha256: "a".repeat(64) as Sha256,
            privilegeModel: "SELECT_ONLY" as const,
          },
        }
      : {}),
    frame,
    scope: {
      environment: "test",
      service: "checkout",
      subject: { kind: "HOST", ref: subjectRef, providerValue },
    },
    scopeMappings: { environment: "environment", service: "service", "subject.ref": mapping },
  });

  const validPrometheus = subjectEntry({
    datasourceType: "prometheus",
    expression: `sum(rate(node_cpu_usage{environment="test",service="checkout",instance="${providerValue}"}[5m]))`,
    mode: "range",
    format: "time_series",
  });
  assert.doesNotThrow(() => new CompiledGrafanaCatalog({ entries: [validPrometheus] }));
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...validPrometheus,
    target: {
      ...validPrometheus.target,
      expression: `label_replace(sum(rate(http_requests_total[5m])), "instance", "${providerValue}", "service", ".*") + node_cpu_usage{instance="${providerValue}"}`,
    },
  } as GrafanaDatasourceQueryCatalogEntry] }), /scope/u);
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...validPrometheus,
    target: {
      ...validPrometheus.target,
      expression: `label_replace(node_cpu_usage{instance=~".*"}, "instance", "${providerValue}", "service", ".*")`,
    },
  } as GrafanaDatasourceQueryCatalogEntry] }), /scope/u);

  const validLoki = subjectEntry({
    datasourceType: "loki",
    expression: `{environment="test",service="checkout",instance="${providerValue}"} |= "error"`,
    queryType: "range",
    direction: "backward",
  });
  assert.doesNotThrow(() => new CompiledGrafanaCatalog({ entries: [validLoki] }));
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...validLoki,
    target: {
      ...validLoki.target,
      expression: `{environment="test",service="checkout"} | label_format instance="${providerValue}"`,
    },
  } as GrafanaDatasourceQueryCatalogEntry] }), /scope/u);

  const tableFrame: GrafanaFrameContract = {
    resultKind: "TABLE",
    fields: [
      { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
      { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      { sourceName: "resource.host.name", outputName: "subject", type: "string", role: "DIMENSION" },
      { sourceName: "value", outputName: "value", type: "number", role: "COLUMN" },
    ],
    allowedLabels: [],
  };
  const validTempo = subjectEntry({
    datasourceType: "tempo",
    expression: `{ resource.deployment.environment = "test" && resource.service.name = "checkout" && resource.host.name = "${providerValue}" }`,
    queryType: "traceql",
    limit: 20,
    spansPerSpanSet: 20,
    tableType: "traces",
  }, tableFrame, "resource.host.name");
  assert.doesNotThrow(() => new CompiledGrafanaCatalog({ entries: [validTempo] }));
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
    ...validTempo,
    target: {
      ...validTempo.target,
      expression: `{ resource.host.name = "${providerValue}" || true }`,
    },
  } as GrafanaDatasourceQueryCatalogEntry] }), /scope/u);

  const postgresFrame: GrafanaFrameContract = {
    ...tableFrame,
    fields: tableFrame.fields.map((field) => field.sourceName === "resource.host.name"
      ? { ...field, sourceName: "instance" }
      : field),
  };
  const validPostgres = subjectEntry({
    datasourceType: "postgres",
    rawSql: `SELECT environment, service, instance, value FROM metrics WHERE $__timeFilter(observed_at) AND environment = 'test' AND service = 'checkout' AND instance = '${providerValue}' LIMIT 10`,
    format: "table",
    maxRows: 10,
  }, postgresFrame);
  assert.doesNotThrow(() => new CompiledGrafanaCatalog({ entries: [validPostgres] }));
  for (const rawSql of [
    `SELECT environment, service, '${providerValue}' AS instance, value FROM metrics WHERE environment = 'test' AND service = 'checkout' AND instance = '${providerValue}' LIMIT 10`,
    `SELECT environment, service, instance, value FROM metrics WHERE environment = 'test' AND service = 'checkout' AND (instance = '${providerValue}' OR true) LIMIT 10`,
    `SELECT * FROM (SELECT environment, service, '${providerValue}' AS instance, value FROM metrics) scoped WHERE environment = 'test' AND service = 'checkout' AND instance = '${providerValue}' LIMIT 10`,
  ]) {
    assert.throws(() => new CompiledGrafanaCatalog({ entries: [{
      ...validPostgres,
      target: { ...validPostgres.target, rawSql },
    } as GrafanaDatasourceQueryCatalogEntry] }), /scope/u);
  }
});

test("Grafana PostgreSQL v1 rejects every function call, including unreviewed user-defined calls", () => {
  for (const rawSql of [
    "SELECT count(*) FROM metrics LIMIT 10",
    "SELECT user_defined_mutator() LIMIT 1",
    "SELECT public.audit_and_delete() LIMIT 1",
  ]) {
    assert.throws(() => validateGrafanaPostgresSql({
      datasourceType: "postgres",
      rawSql,
      format: "table",
      maxRows: 10,
    }), /function call/u);
  }
});

test("Grafana normalization rejects provider-native subject values in every non-mapped output path", () => {
  const subjectRef = "pmsub_abcdefghijklmnopqrstuvwxyz" as never;
  const providerValue = "node-a.internal";
  const scopedEntry = (
    frame: GrafanaFrameContract,
    target: GrafanaDatasourceQueryTarget,
    mapping: string,
  ): GrafanaDatasourceQueryCatalogEntry => ({
    ...entry(),
    target,
    frame,
    scope: {
      environment: "test",
      service: "checkout",
      subject: { kind: "HOST", ref: subjectRef, providerValue },
    },
    scopeMappings: { environment: "environment", service: "service", "subject.ref": mapping },
  });

  const tableFrame: GrafanaFrameContract = {
    resultKind: "TABLE",
    fields: [
      { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
      { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      { sourceName: "instance", outputName: "subject", type: "string", role: "DIMENSION" },
      { sourceName: "note", outputName: "note", type: "string", role: "COLUMN" },
    ],
    allowedLabels: [],
  };
  const tableEntry = scopedEntry(tableFrame, {
    datasourceType: "prometheus",
    expression: `node_info{environment="test",service="checkout",instance="${providerValue}"}`,
    mode: "instant",
    format: "table",
  }, "instance");
  assert.throws(() => normalizeGrafanaFrames({
    results: { A: { frames: [{
      schema: { refId: "A", fields: [
        { name: "environment", type: "string" },
        { name: "service", type: "string" },
        { name: "instance", type: "string" },
        { name: "note", type: "string" },
      ] },
      data: { values: [["test"], ["checkout"], [providerValue], [`failure on ${providerValue}`]] },
    }] } },
  }, tableEntry, context()), /provider-native subject value/u);

  const eventFrame: GrafanaFrameContract = {
    resultKind: "EVENT",
    fields: [
      { sourceName: "Time", outputName: "occurred_at", type: "time", role: "TIME" },
      { sourceName: "Summary", outputName: "summary", type: "string", role: "SUMMARY" },
      { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
      { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      { sourceName: "instance", outputName: "subject", type: "string", role: "DIMENSION" },
    ],
    allowedLabels: [],
  };
  const eventEntry = scopedEntry(eventFrame, {
    datasourceType: "loki",
    expression: `{environment="test",service="checkout",instance="${providerValue}"} |= "error"`,
    queryType: "range",
    direction: "backward",
  }, "instance");
  assert.throws(() => normalizeGrafanaFrames({
    results: { A: { frames: [{
      schema: { refId: "A", fields: [
        { name: "Time", type: "time" },
        { name: "Summary", type: "string" },
        { name: "environment", type: "string" },
        { name: "service", type: "string" },
        { name: "instance", type: "string" },
      ] },
      data: { values: [[1767225600000], [`error from ${providerValue}`], ["test"], ["checkout"], [providerValue]] },
    }] } },
  }, eventEntry, context()), /provider-native subject value/u);

  const fixedSummaryEntry: GrafanaDatasourceQueryCatalogEntry = {
    ...eventEntry,
    frame: {
      ...eventFrame,
      fields: eventFrame.fields.filter((field) => field.role !== "SUMMARY"),
      eventSummary: `fixed incident on ${providerValue}`,
    },
  };
  assert.throws(() => new CompiledGrafanaCatalog({ entries: [fixedSummaryEntry] }), /summary exposes/u);
  assert.throws(() => normalizeGrafanaFrames({
    results: { A: { frames: [{
      schema: { refId: "A", fields: [
        { name: "Time", type: "time" },
        { name: "environment", type: "string" },
        { name: "service", type: "string" },
        { name: "instance", type: "string" },
      ] },
      data: { values: [[1767225600000], ["test"], ["checkout"], [providerValue]] },
    }] } },
  }, fixedSummaryEntry, context()), /provider-native subject value/u);

  const labelFrame: GrafanaFrameContract = {
    ...entry().frame,
    allowedLabels: ["environment", "service", "instance", "alias"],
  };
  const labelEntry = scopedEntry(labelFrame, {
    datasourceType: "prometheus",
    expression: `node_cpu_usage{environment="test",service="checkout",instance="${providerValue}"}`,
    mode: "range",
    format: "time_series",
  }, "instance");
  assert.throws(() => normalizeGrafanaFrames({
    results: { A: { frames: [{
      schema: { refId: "A", fields: [
        { name: "Time", type: "time" },
        { name: "Value", type: "number", labels: {
          environment: "test",
          service: "checkout",
          instance: providerValue,
          alias: `host:${providerValue}`,
        } },
      ] },
      data: { values: [[1767225600000], [1]] },
    }] } },
  }, labelEntry, context()), /provider-native subject value/u);
});
