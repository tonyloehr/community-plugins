import assert from "node:assert/strict";
import test from "node:test";

import {
  createFixtureOperationSnapshot,
  fixtureAdapter,
  fixtureAdapterPackage,
} from "../../adapters/fixture/src/index.ts";
import { computeOperationDefinitionHash, type JsonValue } from "../../packages/contracts/src/index.ts";

const UNSAFE_FIELDS = [
  "url",
  "query",
  "promql",
  "logql",
  "traceql",
  "path",
  "headers",
  "authorization",
  "cookie",
  "shell",
  "command",
  "args",
  "tenant",
  "namespace",
  "selector",
  "method",
] as const;

const UNSAFE_VALUES: readonly JsonValue[] = [
  "https://169.254.169.254/latest/meta-data/",
  "http://127.0.0.1:2375/containers/json",
  "/etc/passwd",
  "../../../../private/key",
  "sum({__name__=~\".*\"})",
  "{tenant=~\".*\"}",
  "$(touch /tmp/owned)",
  "`id`",
  ["--upload-pack=/tmp/owned"],
  { authorization: "Bearer fuzz-secret-canary", host: "attacker.invalid" },
];

test("closed provider definitions reject deterministic URL/query/path/header/shell fuzz cases", async () => {
  let seed = 0x5eed1234;
  const next = (): number => {
    seed = (seed * 1_664_525 + 1_013_904_223) >>> 0;
    return seed;
  };
  for (let iteration = 0; iteration < 96; iteration += 1) {
    const field = UNSAFE_FIELDS[next() % UNSAFE_FIELDS.length]!;
    const value = UNSAFE_VALUES[next() % UNSAFE_VALUES.length]!;
    const operation = createFixtureOperationSnapshot("healthy", {
      operationId: `op.fixture.fuzz-${iteration}` as never,
    });
    operation.definition.sanitizedProviderDefinition = {
      ...operation.definition.sanitizedProviderDefinition,
      [field]: value,
    };
    operation.definitionSha256 = computeOperationDefinitionHash(operation);
    await assert.rejects(
      fixtureAdapter.compile(operation, {
        adapterPackage: fixtureAdapterPackage,
        maxDefinitionBytes: 64_000,
      }),
      /one enumerated scenario/u,
      `${field} iteration ${iteration}`,
    );
  }
});

test("definition-size limits fail before an oversized operation can compile", async () => {
  const operation = createFixtureOperationSnapshot("healthy");
  operation.definition.sanitizedProviderDefinition = {
    scenario: "healthy",
    padding: "x".repeat(4_096),
  };
  operation.definitionSha256 = computeOperationDefinitionHash(operation);
  await assert.rejects(
    fixtureAdapter.compile(operation, {
      adapterPackage: fixtureAdapterPackage,
      maxDefinitionBytes: 256,
    }),
    /exceeds compile budget/u,
  );
});
