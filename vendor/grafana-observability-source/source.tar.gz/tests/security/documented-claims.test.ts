import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

import { alertmanagerAdapterPackage } from "../../adapters/alertmanager/src/index.ts";
import { fixtureAdapterPackage } from "../../adapters/fixture/src/index.ts";
import { gitAdapterPackage } from "../../adapters/git/src/index.ts";
import { grafanaAdapterPackage } from "../../adapters/grafana/src/index.ts";
import { kubernetesAdapterPackage } from "../../adapters/kubernetes/src/index.ts";
import { lokiAdapterPackage } from "../../adapters/loki/src/index.ts";
import { prometheusAdapterPackage } from "../../adapters/prometheus/src/index.ts";
import { tempoAdapterPackage } from "../../adapters/tempo/src/index.ts";

const docs = (name: string): string =>
  readFileSync(new URL(`../../docs/${name}`, import.meta.url), "utf8");

const pluginReference = (name: string): string =>
  readFileSync(new URL(`../../plugins/production-monitoring/references/${name}`, import.meta.url), "utf8");

function connectivityRows(markdown: string): Map<string, string> {
  const rows = new Map<string, string>();
  for (const line of markdown.split("\n")) {
    const match = /^\| `([A-Z_]+)` \| `([A-Z_]+)` \|/u.exec(line);
    if (match !== null) rows.set(match[1]!, match[2]!);
  }
  return rows;
}

test("connectivity claims are explicit per surface and deny implicit private reachability", () => {
  const document = docs("connectivity.md");
  const rows = connectivityRows(document);
  assert.deepEqual(Object.fromEntries(rows), {
    FIXTURE: "IMPLEMENTED",
    LOCAL_STDIO: "IMPLEMENTED",
    CUSTOMER_VPC: "IMPLEMENTED_REFERENCE",
    CUSTOMER_RELAY: "NOT_IMPLEMENTED",
    PUBLISHER_HOSTED: "NOT_IMPLEMENTED",
  });
  assert.match(document, /cannot reach a user's localhost, laptop VPN, or private VPC by default/iu);
  assert.match(document, /one surface never implies reachability on another/iu);
  assert.match(document, /admits only its exact release-code-owned first-party child worker/iu);
  assert.match(document, /not an OS egress\/filesystem\/resource sandbox/iu);
  assert.match(document, /deterministic mTLS test is not a deployed or approved customer route/iu);
  assert.doesNotMatch(
    document,
    /PUBLISHER_HOSTED[^\n]*`IMPLEMENTED(?:_SOURCE)?`/u,
  );
});

test("provider access documentation preserves the hardened endpoint contract", () => {
  const connectivity = docs("connectivity.md");
  const setup = docs("prometheus-grafana-setup.md");
  const bundledConfiguration = pluginReference("config-and-preflight.md");
  const bundledConnectivity = pluginReference("connectivity.md");
  const combined = [connectivity, setup, bundledConfiguration, bundledConnectivity].join("\n");

  for (const authenticationMode of ["NONE", "BEARER", "BASIC", "MTLS"]) {
    assert.ok(combined.includes(`\`${authenticationMode}\``), `missing auth mode ${authenticationMode}`);
  }
  for (const networkClass of ["loopback", "private", "public"]) {
    assert.ok(combined.includes(`\`${networkClass}\``), `missing network class ${networkClass}`);
  }
  assert.match(setup, /minimumVersion: TLSv1\.2/u);
  assert.match(setup, /caRef:[\s\S]*serverName:/u);
  assert.match(combined, /SNI\/certificate verification name/iu);
  assert.match(connectivity, /`direct` and `host_vpn` are both direct-socket routes/iu);
  assert.match(bundledConnectivity, /`direct` and `host_vpn` both mean a direct socket/iu);
  assert.match(combined, /DNS[\s\S]*connected socket peer/iu);
  assert.match(combined, /`application_proxy`[\s\S]*`APPLICATION_PROXY_NOT_IMPLEMENTED`/u);
  assert.doesNotMatch(connectivity, /approved loopback, proxy, or VPN route/iu);
});

test("compatibility claims exactly include each implemented adapter declaration", () => {
  const document = docs("compatibility.md");
  const packages = [
    fixtureAdapterPackage,
    prometheusAdapterPackage,
    grafanaAdapterPackage,
    gitAdapterPackage,
    alertmanagerAdapterPackage,
    lokiAdapterPackage,
    tempoAdapterPackage,
    kubernetesAdapterPackage,
  ];
  for (const adapterPackage of packages) {
    assert.ok(document.includes(`\`${adapterPackage.packageId}\``));
    assert.ok(document.includes(`\`${adapterPackage.version}\``));
    for (const compatibility of adapterPackage.providerCompatibility) {
      assert.ok(
        document.includes(compatibility.versions),
        `${adapterPackage.packageId} omitted provider range ${compatibility.versions}`,
      );
    }
  }
  assert.match(document, /not automatically active/iu);
  assert.match(document, /third-party activation is unsupported/iu);
  assert.match(document, /not an OS sandbox/iu);
});

test("threat model names every adversarial class covered by the security suite", () => {
  const document = docs("security-threat-model.md");
  for (const phrase of [
    "Arbitrary URL",
    "Arbitrary query",
    "Credential or sensitive-data leakage",
    "Prompt injection",
    "Cross-tenant",
    "Cardinality",
    "Provider or schema drift",
    "Adapter replacement or child-process escape",
  ]) {
    assert.ok(document.includes(phrase), `threat model omitted ${phrase}`);
  }
  assert.match(document, /Direct in-process conformance proves the adapter contract, not production[\s\S]*OS isolation/iu);
  assert.match(document, /Third-party\s+packages have no v0\.1 production activation path/iu);
});
