import {
  GrafanaCredentialKeyring,
  SharedGrafanaProfileStore,
} from "../../packages/grafana-credential-profile/src/index.ts";
import {
  runObservabilityCli,
  type GrafanaConnectionPreview,
  type ObservabilityCliIo,
} from "../../packages/observability-cli/src/index.ts";

import {
  crashInjectedProfileStore,
  FileKeyringBackend,
  type CredentialCrashPoint,
} from "./credential-crash-fixture.ts";

const PROFILE_ID = "9d78d956-6379-4bc6-9164-ecb862cf41a6";
const PREVIEW: GrafanaConnectionPreview = {
  schemaVersion: "1.0.0",
  grafanaVersion: "12.2.0",
  permissionState: "READ_ONLY_CONFIRMED",
  datasources: [],
  proposedCapabilityPackIds: [],
  panelCandidates: [],
  warnings: [],
};

const [, , operation, crashPoint, stateRoot, keyringPath] = process.argv;
if (
  (operation !== "connect" && operation !== "rotate" && operation !== "delete")
  || (
    crashPoint !== "AFTER_PREPARED"
    && crashPoint !== "AFTER_STAGED"
    && crashPoint !== "AFTER_REGISTRY_COMMIT"
    && crashPoint !== "AFTER_COMMITTED"
    && crashPoint !== "AFTER_CLEANUP"
    && crashPoint !== "BEFORE_JOURNAL_CLEAR"
  )
  || stateRoot === undefined
  || keyringPath === undefined
) {
  process.exitCode = 2;
} else {
  const output = { isTTY: true as const, write() {} };
  const io: ObservabilityCliIo = {
    stdin: {
      isTTY: true,
      setRawMode() {},
      on() {},
      once() {},
      removeListener() {},
      resume() {},
      pause() {},
    },
    stdout: output,
    stderr: output,
  };
  const platform = process.platform === "linux" ? "linux" : "darwin";
  const baseStore = new SharedGrafanaProfileStore({ rootPath: stateRoot, platform });
  const profileStore = crashInjectedProfileStore(baseStore, crashPoint as CredentialCrashPoint);
  const credentialStore = new GrafanaCredentialKeyring(
    new FileKeyringBackend(keyringPath, crashPoint as CredentialCrashPoint),
  );
  const argv = operation === "connect"
    ? ["grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations"]
    : ["grafana", operation];
  const exitCode = await runObservabilityCli(argv, {
    profileStore,
    credentialStore,
    io,
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from(
      operation === "connect"
        ? "crash-connect-secret-canary"
        : "crash-rotate-secret-canary",
    )),
    connectionDiscovery: { async inspect() { return PREVIEW; } },
    confirmActivation: async () => true,
    confirmDelete: async () => true,
  });
  process.exitCode = exitCode === 0 ? 7 : 8;
}
