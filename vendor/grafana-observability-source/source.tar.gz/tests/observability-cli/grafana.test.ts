import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { EventEmitter } from "node:events";
import { existsSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import {
  addSharedGrafanaProfile,
  createSharedGrafanaProfile,
  grafanaCredentialReference,
  GrafanaCredentialKeyring,
  legacyGrafanaCredentialReference,
  SharedGrafanaProfileCredentialSource,
  SharedGrafanaProfileStore,
  type GrafanaKeyringBackend,
  type SharedGrafanaProfileRegistryStore,
} from "../../packages/grafana-credential-profile/src/index.ts";
import {
  HttpGrafanaConnectionDiscovery,
  GrafanaDiscoveryError,
  readSecretFromTty,
  runObservabilityCli,
  type GrafanaConnectionDiscovery,
  type GrafanaConnectionPreview,
  type ObservabilityCliIo,
  type SecretTtyInput,
  type SecretTtyOutput,
} from "../../packages/observability-cli/src/index.ts";
import { FileKeyringBackend, type CredentialCrashPoint } from "./credential-crash-fixture.ts";

const PROFILE_ID = "9d78d956-6379-4bc6-9164-ecb862cf41a6";
const SECRET = "grafana-cli-secret-canary";
const LIFECYCLE_JOURNAL_FILENAME = "grafana-credential-lifecycle-journal-v1.json";
const LIFECYCLE_LOCK_FILENAME = "grafana-profile-lifecycle-v1.lock";
const PREVIEW: GrafanaConnectionPreview = {
  schemaVersion: "1.0.0",
  grafanaVersion: "12.2.0",
  permissionState: "READ_ONLY_CONFIRMED",
  datasources: [{ name: "Metrics", type: "prometheus" }],
  proposedCapabilityPackIds: ["grafana.infrastructure", "grafana.apm"],
  panelCandidates: [{ dashboardTitle: "Checkout", panelTitle: "Error rate", panelId: 7, datasourceType: "prometheus" }],
  warnings: [],
};
const DISCOVERY: GrafanaConnectionDiscovery = {
  async inspect() { return PREVIEW; },
};

function confirmedDiscovery(): Pick<
  Parameters<typeof runObservabilityCli>[1],
  "connectionDiscovery" | "confirmActivation"
> {
  return { connectionDiscovery: DISCOVERY, confirmActivation: async () => true };
}

function updateFailingProfileStore(
  profileStore: SharedGrafanaProfileRegistryStore,
  shouldFail: () => boolean,
): SharedGrafanaProfileRegistryStore {
  const failIfRequested = (): void => {
    if (shouldFail()) throw new Error(`registry-failure-${SECRET}`);
  };
  return {
    read: () => profileStore.read(),
    update: async (mutation) => {
      failIfRequested();
      return profileStore.update(mutation);
    },
    withExclusiveLifecycle: (operation) => profileStore.withExclusiveLifecycle(
      (transaction) => operation({
        read: () => transaction.read(),
        readCredentialLifecycleJournal: () => transaction.readCredentialLifecycleJournal(),
        writeCredentialLifecycleJournal: (journal) => transaction.writeCredentialLifecycleJournal(journal),
        clearCredentialLifecycleJournal: () => transaction.clearCredentialLifecycleJournal(),
        update: async (mutation) => {
          failIfRequested();
          return transaction.update(mutation);
        },
      }),
    ),
  };
}

function deferred<T>(): {
  promise: Promise<T>;
  resolve: (value: T) => void;
} {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => { resolve = done; });
  return { promise, resolve };
}

function lastJsonLine(value: string): Record<string, unknown> {
  const lines = value.trim().split("\n");
  return JSON.parse(lines.at(-1)!) as Record<string, unknown>;
}

class FakeBackend implements GrafanaKeyringBackend {
  readonly values = new Map<string, Uint8Array>();
  failDelete = false;

  async getSecret(service: string, account: string): Promise<Uint8Array | undefined> {
    const value = this.values.get(`${service}\0${account}`);
    return value === undefined ? undefined : Uint8Array.from(value);
  }

  async setSecret(service: string, account: string, secret: Uint8Array): Promise<void> {
    this.values.set(`${service}\0${account}`, Uint8Array.from(secret));
  }

  async deleteSecret(service: string, account: string): Promise<boolean> {
    if (this.failDelete) throw new Error("backend secret detail");
    return this.values.delete(`${service}\0${account}`);
  }
}

class MemoryOutput implements SecretTtyOutput {
  readonly isTTY = true;
  value = "";

  write(value: string): void {
    this.value += value;
  }
}

function unusedInput(): SecretTtyInput {
  return {
    isTTY: true,
    setRawMode() {},
    on() {},
    once() {},
    removeListener() {},
    resume() {},
    pause() {},
  };
}

function io(): ObservabilityCliIo & { stdout: MemoryOutput; stderr: MemoryOutput } {
  return { stdin: unusedInput(), stdout: new MemoryOutput(), stderr: new MemoryOutput() };
}

function testProfileStore(rootPath: string): SharedGrafanaProfileStore {
  return new SharedGrafanaProfileStore({
    rootPath,
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
}

async function seedCrashProfile(stateRoot: string, keyringPath: string): Promise<void> {
  const exitCode = await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore: testProfileStore(stateRoot),
    credentialStore: new GrafanaCredentialKeyring(new FileKeyringBackend(keyringPath)),
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from("crash-seed-secret-canary")),
    ...confirmedDiscovery(),
  });
  assert.equal(exitCode, 0);
}

function discoveryWithFetch(
  fetchImplementation: typeof fetch,
  options: { timeoutMs?: number } = {},
): HttpGrafanaConnectionDiscovery {
  return new HttpGrafanaConnectionDiscovery({
    ...options,
    transportFactory: ({ grafanaOrigin }) => ({
      async get(pathname, query, signal) {
        const url = new URL(pathname, `${grafanaOrigin}/`);
        for (const [name, value] of Object.entries(query)) url.searchParams.append(name, value);
        const response = await fetchImplementation(url, { method: "GET", signal });
        if (response.body === null) {
          return {
            status: response.status,
            headers: Object.fromEntries([...response.headers.entries()].map(([name, value]) => [name.toLowerCase(), value])),
            body: new Uint8Array(),
          };
        }
        const reader = response.body.getReader();
        let rejectAbort: ((error: Error) => void) | undefined;
        const aborted = new Promise<never>((_resolve, reject) => { rejectAbort = reject; });
        const onAbort = () => {
          void reader.cancel().catch(() => undefined);
          rejectAbort?.(new Error("test transport aborted"));
        };
        signal.addEventListener("abort", onAbort, { once: true });
        if (signal.aborted) onAbort();
        const chunks: Buffer[] = [];
        let bytes = 0;
        try {
          for (;;) {
            const result = await Promise.race([reader.read(), aborted]);
            if (result.done) break;
            const chunk = Buffer.from(result.value);
            chunks.push(chunk);
            bytes += chunk.byteLength;
          }
          return {
            status: response.status,
            headers: Object.fromEntries([...response.headers.entries()].map(([name, value]) => [name.toLowerCase(), value])),
            body: Buffer.concat(chunks, bytes),
          };
        } finally {
          signal.removeEventListener("abort", onAbort);
        }
      },
    }),
  });
}

async function listeningGrafanaServer(
  handler: (request: IncomingMessage, response: ServerResponse) => void,
  host = "127.0.0.1",
) {
  const server = createServer(handler);
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, host, resolve);
  });
  return server;
}

function jsonResponse(response: ServerResponse, body: unknown, status = 200): void {
  response.writeHead(status, { "Content-Type": "application/json" });
  response.end(JSON.stringify(body));
}

test("connect, status, rotate, and delete share one nonsecret profile", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeBackend();
  const credentialStore = new GrafanaCredentialKeyring(backend);
  const connectIo = io();
  const entered = Uint8Array.from(Buffer.from(SECRET, "ascii"));
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations", "--json",
  ], {
    profileStore,
    credentialStore,
    io: connectIo,
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => entered,
    ...confirmedDiscovery(),
  }), 0);
  assert.ok(entered.every((byte) => byte === 0));
  assert.doesNotMatch(connectIo.stdout.value + connectIo.stderr.value, new RegExp(SECRET, "u"));
  const preview = JSON.parse(connectIo.stdout.value.trim().split("\n")[0]!) as Record<string, unknown>;
  assert.equal(preview.event, "GRAFANA_DISCOVERY_PREVIEW");
  const connected = lastJsonLine(connectIo.stdout.value);
  assert.equal(connected.credentialReference, `grafana:${PROFILE_ID}:bearer:v1`);
  assert.equal((await profileStore.read()).profiles.length, 1);

  const statusIo = io();
  assert.equal(await runObservabilityCli(["grafana", "status", "--json"], {
    profileStore,
    credentialStore,
    io: statusIo,
  }), 0);
  assert.equal((JSON.parse(statusIo.stdout.value) as { credentialStatus: string }).credentialStatus, "AVAILABLE");
  assert.doesNotMatch(statusIo.stdout.value, new RegExp(SECRET, "u"));

  const rotateIo = io();
  const rotated = Uint8Array.from(Buffer.from("rotated-cli-secret-canary", "ascii"));
  assert.equal(await runObservabilityCli(["grafana", "rotate", "--json"], {
    profileStore,
    credentialStore,
    io: rotateIo,
    promptSecret: async () => rotated,
    ...confirmedDiscovery(),
  }), 0);
  assert.ok(rotated.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles[0]?.revision, 2);
  assert.doesNotMatch(rotateIo.stdout.value + rotateIo.stderr.value, /rotated-cli-secret-canary/u);

  const deleteIo = io();
  assert.equal(await runObservabilityCli(["grafana", "delete", "--json"], {
    profileStore,
    credentialStore,
    io: deleteIo,
    confirmDelete: async () => true,
  }), 0);
  assert.equal((await profileStore.read()).profiles.length, 0);
  assert.equal(backend.values.size, 0);
});

test("connect rejects a colliding profile identity before prompting or overwriting its slot", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-profile-id-collision-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = testProfileStore(join(parent, "state"));
  const credentialStore = new GrafanaCredentialKeyring(new FakeBackend());
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore,
    credentialStore,
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from("original-profile-secret", "ascii")),
    ...confirmedDiscovery(),
  }), 0);

  let prompted = false;
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://secondary.example.com", "--profile", "Secondary",
  ], {
    profileStore,
    credentialStore,
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => {
      prompted = true;
      return Uint8Array.from(Buffer.from("must-not-overwrite", "ascii"));
    },
    ...confirmedDiscovery(),
  }), 1);
  assert.equal(prompted, false);
  const lease = await credentialStore.acquire(grafanaCredentialReference(PROFILE_ID));
  assert.equal(Buffer.from(lease?.bytes ?? []).toString("ascii"), "original-profile-secret");
  lease?.dispose();
  assert.equal((await profileStore.read()).profiles.length, 1);
});

test("rotate migrates a legacy unversioned profile and static trust reference to a new slot", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-legacy-profile-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const stateRoot = join(parent, "state");
  const profileStore = testProfileStore(stateRoot);
  const backend = new FakeBackend();
  const credentialStore = new GrafanaCredentialKeyring(backend);
  const legacyReference = legacyGrafanaCredentialReference(PROFILE_ID);
  const legacyProfile = {
    ...createSharedGrafanaProfile({
      profileId: PROFILE_ID,
      profileName: "Operations",
      grafanaOrigin: "https://grafana.example.com",
    }),
    credentialRef: legacyReference,
    revision: 2,
  };
  await credentialStore.set(legacyReference, Buffer.from("legacy-profile-secret", "ascii"));
  await profileStore.update((registry) => addSharedGrafanaProfile(registry, legacyProfile));

  assert.equal(await runObservabilityCli(["grafana", "rotate"], {
    profileStore,
    credentialStore,
    io: io(),
    promptSecret: async () => Uint8Array.from(Buffer.from("migrated-profile-secret", "ascii")),
    ...confirmedDiscovery(),
  }), 0);
  const migrated = (await profileStore.read()).profiles[0];
  assert.equal(migrated?.revision, 3);
  assert.deepEqual(migrated?.credentialRef, grafanaCredentialReference(PROFILE_ID, 3));
  assert.equal(await credentialStore.status(legacyReference), "MISSING_OR_UNAVAILABLE");

  const restartedSource = new SharedGrafanaProfileCredentialSource(
    new GrafanaCredentialKeyring(backend),
    testProfileStore(stateRoot),
  );
  const lease = await restartedSource.acquire(legacyReference);
  assert.equal(Buffer.from(lease?.bytes ?? []).toString("ascii"), "migrated-profile-secret");
  lease?.dispose();
});

test("secret arguments and noninteractive secret entry fail without disclosure", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-reject-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const commandIo = io();
  let prompted = false;
  const exitCode = await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations", "--token", SECRET,
  ], {
    profileStore: new SharedGrafanaProfileStore({
      rootPath: join(parent, "state"),
      platform: process.platform === "linux" ? "linux" : "darwin",
    }),
    credentialStore: new GrafanaCredentialKeyring(new FakeBackend()),
    io: commandIo,
    promptSecret: async () => {
      prompted = true;
      return Uint8Array.from(Buffer.from(SECRET));
    },
  });
  assert.equal(exitCode, 2);
  assert.equal(prompted, false);
  assert.doesNotMatch(commandIo.stdout.value + commandIo.stderr.value, new RegExp(SECRET, "u"));

  await assert.rejects(
    readSecretFromTty({ ...unusedInput(), isTTY: false }, new MemoryOutput()),
    /Interactive secret entry failed/u,
  );
});

test("TTY secret prompt disables echo, restores raw mode, and returns bytes only", async () => {
  class FakeInput extends EventEmitter implements SecretTtyInput {
    readonly isTTY = true;
    readonly rawModes: boolean[] = [];
    setRawMode(mode: boolean): void { this.rawModes.push(mode); }
    resume(): void {}
    pause(): void {}
    override on(event: "data", listener: (chunk: Buffer) => void): this { return super.on(event, listener); }
    override once(event: "error" | "end", listener: (error?: Error) => void): this { return super.once(event, listener); }
    override removeListener(event: "data" | "error" | "end", listener: (...args: unknown[]) => void): this {
      return super.removeListener(event, listener);
    }
  }
  const input = new FakeInput();
  const output = new MemoryOutput();
  const reading = readSecretFromTty(input, output);
  input.emit("data", Buffer.from(`${SECRET}\r`, "ascii"));
  const secret = await reading;
  assert.equal(Buffer.from(secret).toString("ascii"), SECRET);
  assert.deepEqual(input.rawModes, [true, false]);
  assert.doesNotMatch(output.value, new RegExp(SECRET, "u"));
  secret.fill(0);
});

test("delete commits its tombstone and retains pending cleanup when keyring deletion fails", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-delete-fail-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeBackend();
  const credentialStore = new GrafanaCredentialKeyring(backend);
  await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore,
    credentialStore,
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from(SECRET)),
    ...confirmedDiscovery(),
  });
  backend.failDelete = true;
  const deleteIo = io();
  assert.equal(await runObservabilityCli(["grafana", "delete"], {
    profileStore,
    credentialStore,
    io: deleteIo,
    confirmDelete: async () => true,
  }), 1);
  assert.equal((await profileStore.read()).profiles.length, 0);
  await profileStore.withExclusiveLifecycle(async (transaction) => {
    const journal = transaction.readCredentialLifecycleJournal();
    assert.equal(journal?.operation, "DELETE");
    assert.equal(journal?.phase, "COMMITTED");
  });
  assert.equal(backend.values.size, 1);
  assert.doesNotMatch(deleteIo.stderr.value, /backend|secret detail|grafana-cli-secret/iu);

  backend.failDelete = false;
  assert.equal(await runObservabilityCli(["grafana", "status"], {
    profileStore,
    credentialStore,
    io: io(),
  }), 1);
  assert.equal(backend.values.size, 0);
  await profileStore.withExclusiveLifecycle(async (transaction) => {
    assert.equal(transaction.readCredentialLifecycleJournal(), undefined);
  });
});

test("connect discovery proposes only certified packs and saved one-target panels", async () => {
  const requests: string[] = [];
  const discovery = discoveryWithFetch(
    async (input, init) => {
      const url = new URL(String(input));
      requests.push(`${init?.method ?? "GET"} ${url.pathname}${url.search}`);
      const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
        status,
        headers: { "content-type": "application/json" },
      });
      if (url.pathname === "/api/health") return json({ database: "ok", version: "13.1.0" });
      if (url.pathname === "/api/datasources") return json([
        { uid: "metrics-uid", name: "Metrics", type: "prometheus" },
        { uid: "logs-uid", name: "Logs", type: "loki" },
        { uid: "postgres-modern", name: "Business KPIs", type: "grafana-postgresql-datasource" },
        { uid: "postgres-legacy", name: "Legacy KPIs", type: "postgres" },
        { uid: "unsafe-uid", name: "Unsupported", type: "elasticsearch" },
      ]);
      if (url.pathname === "/api/access-control/user/permissions") {
        return json({ "datasources:read": ["uid:metrics-uid"], "datasources:query": ["uid:metrics-uid"] });
      }
      if (url.pathname === "/api/search") return json([{ uid: "checkout", title: "Checkout" }]);
      if (url.pathname === "/api/dashboards/uid/checkout") return json({
        dashboard: {
          uid: "checkout",
          version: 1,
          title: "Checkout",
          templating: { list: [] },
          panels: [
            {
              id: 7,
              title: "Error rate",
              datasource: { type: "prometheus", uid: "metrics-uid" },
              targets: [{ refId: "A", datasource: { type: "prometheus", uid: "metrics-uid" }, expr: "sum(rate(errors_total[5m]))" }],
            },
            {
              id: 8,
              title: "Revenue",
              datasource: { type: "grafana-postgresql-datasource", uid: "postgres-modern" },
              targets: [{
                refId: "A",
                datasource: { type: "grafana-postgresql-datasource", uid: "postgres-modern" },
                rawSql: "SELECT revenue FROM business_kpis LIMIT 1",
              }],
            },
          ],
        },
      });
      return json({}, 404);
    },
  );
  const preview = await discovery.inspect({
    grafanaOrigin: "https://grafana.example.com",
    bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
  });
  assert.deepEqual(preview.datasources.map((item) => item.type), [
    "grafana-postgresql-datasource",
    "loki",
    "postgres",
    "prometheus",
  ]);
  assert.deepEqual(preview.proposedCapabilityPackIds, [
    "grafana.infrastructure",
    "grafana.apm",
    "grafana.logs",
    "grafana.iot-edge",
    "grafana.business-kpis",
  ]);
  assert.deepEqual(preview.panelCandidates, [
    {
      dashboardTitle: "Checkout",
      panelTitle: "Error rate",
      panelId: 7,
      datasourceType: "prometheus",
    },
    {
      dashboardTitle: "Checkout",
      panelTitle: "Revenue",
      panelId: 8,
      datasourceType: "grafana-postgresql-datasource",
    },
  ]);
  assert.match(preview.warnings[0] ?? "", /Grafana 13/u);
  assert.match(preview.warnings[1] ?? "", /PostgreSQL/u);
  assert.deepEqual(requests, [
    "GET /api/health",
    "GET /api/datasources",
    "GET /api/access-control/user/permissions",
    "GET /api/search?type=dash-db&limit=20",
    "GET /api/dashboards/uid/checkout",
  ]);
  assert.doesNotMatch(JSON.stringify(preview), new RegExp(SECRET, "u"));
});

test("credentialed discovery pins the resolved peer and keeps the bearer out of ambient environment state", async (t) => {
  const requests: string[] = [];
  const authorizations: boolean[] = [];
  const localAddresses: string[] = [];
  const server = await listeningGrafanaServer((request, response) => {
    requests.push(request.url ?? "");
    authorizations.push(request.headers.authorization === `Bearer ${SECRET}`);
    localAddresses.push(request.socket.localAddress ?? "");
    if (request.url === "/api/health") {
      jsonResponse(response, { database: "ok", version: "12.2.0" });
      return;
    }
    if (request.url === "/api/datasources") {
      jsonResponse(response, []);
      return;
    }
    if (request.url === "/api/access-control/user/permissions") {
      jsonResponse(response, {
        "datasources:read": ["datasources:*"],
        "datasources:query": ["datasources:*"],
      });
      return;
    }
    jsonResponse(response, {}, 404);
  });
  t.after(() => new Promise<void>((resolve, reject) => {
    server.close((error) => { if (error === undefined) resolve(); else reject(error); });
  }));
  const port = (server.address() as AddressInfo).port;
  let lookups = 0;
  const discovery = new HttpGrafanaConnectionDiscovery({
    resolver: {
      async lookup(hostname) {
        lookups += 1;
        assert.equal(hostname, "localhost");
        return [{ address: "127.0.0.1", family: 4 }];
      },
    },
    timeoutMs: 2_000,
  });
  const preview = await discovery.inspect({
    grafanaOrigin: `http://localhost:${String(port)}`,
    bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
  });
  assert.equal(preview.permissionState, "READ_ONLY_CONFIRMED");
  assert.deepEqual(requests, [
    "/api/health",
    "/api/datasources",
    "/api/access-control/user/permissions",
    "/api/search?type=dash-db&limit=20",
  ]);
  assert.equal(lookups, requests.length);
  assert.ok(authorizations.every(Boolean));
  assert.ok(localAddresses.every((address) => address === "127.0.0.1"));
  assert.doesNotMatch(JSON.stringify(preview), new RegExp(SECRET, "u"));
});

test("credentialed discovery rejects DNS rebinding between requests before exposing the bearer to the new address class", async (t) => {
  let serverRequests = 0;
  let authorizationAccepted = false;
  const server = await listeningGrafanaServer((request, response) => {
    serverRequests += 1;
    authorizationAccepted = request.headers.authorization === `Bearer ${SECRET}`;
    jsonResponse(response, { database: "ok", version: "12.2.0" });
  });
  t.after(() => new Promise<void>((resolve, reject) => {
    server.close((error) => { if (error === undefined) resolve(); else reject(error); });
  }));
  const port = (server.address() as AddressInfo).port;
  let lookups = 0;
  const discovery = new HttpGrafanaConnectionDiscovery({
    resolver: {
      async lookup() {
        lookups += 1;
        return lookups === 1
          ? [{ address: "127.0.0.1", family: 4 }]
          : [{ address: "10.20.30.40", family: 4 }];
      },
    },
    timeoutMs: 2_000,
  });
  await assert.rejects(
    discovery.inspect({
      grafanaOrigin: `http://localhost:${String(port)}`,
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    }),
    (error: unknown) => error instanceof GrafanaDiscoveryError
      && error.code === "UNAVAILABLE"
      && !JSON.stringify(error).includes(SECRET),
  );
  assert.equal(lookups, 2);
  assert.equal(serverRequests, 1);
  assert.equal(authorizationAccepted, true);
});

test("credentialed discovery rejects mixed DNS answers and forbidden, private, or public class drift", async () => {
  const mixed = new HttpGrafanaConnectionDiscovery({
    resolver: {
      async lookup() {
        return [
          { address: "127.0.0.1", family: 4 },
          { address: "10.20.30.40", family: 4 },
        ];
      },
    },
    timeoutMs: 200,
  });
  await assert.rejects(
    mixed.inspect({
      grafanaOrigin: "http://localhost:3000",
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    }),
    (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "UNAVAILABLE",
  );

  const mismatches = [
    {
      grafanaOrigin: "http://localhost:3000",
      address: "169.254.169.254",
      family: 4 as const,
    },
    {
      grafanaOrigin: "https://10.20.30.40",
      address: "8.8.8.8",
      family: 4 as const,
    },
    {
      grafanaOrigin: "https://grafana.example.com",
      address: "10.20.30.40",
      family: 4 as const,
    },
  ];
  for (const mismatch of mismatches) {
    const discovery = new HttpGrafanaConnectionDiscovery({
      resolver: { async lookup() { return [{ address: mismatch.address, family: mismatch.family }]; } },
      timeoutMs: 200,
    });
    await assert.rejects(
      discovery.inspect({
        grafanaOrigin: mismatch.grafanaOrigin,
        bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
      }),
      (error: unknown) => error instanceof GrafanaDiscoveryError
        && error.code === "UNAVAILABLE"
        && !JSON.stringify(error).includes(SECRET),
    );
  }
});

test("credentialed discovery returns redirect failure without following a special-address Location", async (t) => {
  let requests = 0;
  const server = await listeningGrafanaServer((_request, response) => {
    requests += 1;
    response.writeHead(302, { Location: "http://169.254.169.254/latest/meta-data/" });
    response.end();
  });
  t.after(() => new Promise<void>((resolve, reject) => {
    server.close((error) => { if (error === undefined) resolve(); else reject(error); });
  }));
  const port = (server.address() as AddressInfo).port;
  const discovery = new HttpGrafanaConnectionDiscovery({
    resolver: { async lookup() { return [{ address: "127.0.0.1", family: 4 }]; } },
    timeoutMs: 2_000,
  });
  await assert.rejects(
    discovery.inspect({
      grafanaOrigin: `http://localhost:${String(port)}`,
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    }),
    (error: unknown) => error instanceof GrafanaDiscoveryError
      && error.code === "UNAVAILABLE"
      && !JSON.stringify(error).includes(SECRET),
  );
  assert.equal(requests, 1);
});

test("discovery rejects unsupported versions and known write authority", async () => {
  const inspect = async (healthVersion: string, permissions: Record<string, unknown>) => {
    const discovery = discoveryWithFetch(
      async (input) => {
        const path = new URL(String(input)).pathname;
        const body = path === "/api/health"
          ? { database: "ok", version: healthVersion }
          : path === "/api/datasources"
            ? []
            : permissions;
        return new Response(JSON.stringify(body), { status: 200 });
      },
    );
    return discovery.inspect({
      grafanaOrigin: "https://grafana.example.com",
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    });
  };
  await assert.rejects(inspect("14.0.0", {}), /failed safely/u);
  await assert.rejects(inspect("12.0.0", { "datasources:write": ["*"] }), /failed safely/u);
});

test("connect cancellation zeroes the proposed credential and stores nothing", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-cancel-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeBackend();
  const secret = Uint8Array.from(Buffer.from(SECRET, "ascii"));
  const commandIo = io();
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore,
    credentialStore: new GrafanaCredentialKeyring(backend),
    io: commandIo,
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => secret,
    connectionDiscovery: DISCOVERY,
    confirmActivation: async () => false,
  }), 0);
  assert.ok(secret.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles.length, 0);
  assert.equal(backend.values.size, 0);
  assert.match(commandIo.stdout.value, /activation cancelled/u);
  assert.doesNotMatch(commandIo.stdout.value + commandIo.stderr.value, new RegExp(SECRET, "u"));
});

test("rotate cancellation zeroes the proposal and retains the prior credential", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-rotate-cancel-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeBackend();
  const credentialStore = new GrafanaCredentialKeyring(backend);
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore,
    credentialStore,
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from(SECRET)),
    ...confirmedDiscovery(),
  }), 0);
  const proposalText = "cancelled-rotation-secret-canary";
  const proposal = Uint8Array.from(Buffer.from(proposalText));
  const commandIo = io();
  assert.equal(await runObservabilityCli(["grafana", "rotate"], {
    profileStore,
    credentialStore,
    io: commandIo,
    promptSecret: async () => proposal,
    connectionDiscovery: DISCOVERY,
    confirmActivation: async () => false,
  }), 0);
  assert.ok(proposal.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles[0]?.revision, 1);
  assert.equal(Buffer.from([...backend.values.values()][0] ?? []).toString("ascii"), SECRET);
  assert.doesNotMatch(commandIo.stdout.value + commandIo.stderr.value, new RegExp(proposalText, "u"));
});

test("concurrent rotate operations cannot roll stale bytes over the serialized winner", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-concurrent-rotate-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeBackend();
  const credentialStore = new GrafanaCredentialKeyring(backend);
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore,
    credentialStore,
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from(SECRET)),
    ...confirmedDiscovery(),
  }), 0);

  const promptEntered = deferred<void>();
  const releasePrompt = deferred<void>();
  t.after(() => releasePrompt.resolve(undefined));
  const winnerText = "serialized-rotate-winner-canary";
  const winnerSecret = Uint8Array.from(Buffer.from(winnerText));
  const winnerIo = io();
  const winner = runObservabilityCli(["grafana", "rotate"], {
    profileStore,
    credentialStore,
    io: winnerIo,
    promptSecret: async () => {
      promptEntered.resolve(undefined);
      await releasePrompt.promise;
      return winnerSecret;
    },
    ...confirmedDiscovery(),
  });
  await promptEntered.promise;

  const loserText = "serialized-rotate-loser-canary";
  const loserSecret = Uint8Array.from(Buffer.from(loserText));
  let loserPrompted = false;
  const loserIo = io();
  assert.equal(await runObservabilityCli(["grafana", "rotate"], {
    profileStore,
    credentialStore,
    io: loserIo,
    promptSecret: async () => {
      loserPrompted = true;
      return loserSecret;
    },
    ...confirmedDiscovery(),
  }), 1);
  assert.equal(loserPrompted, false);
  assert.match(loserIo.stderr.value, /credential store is unavailable/u);

  releasePrompt.resolve(undefined);
  assert.equal(await winner, 0);
  assert.ok(winnerSecret.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles[0]?.revision, 2);
  assert.equal(Buffer.from([...backend.values.values()][0] ?? []).toString("ascii"), winnerText);
  assert.doesNotMatch(
    winnerIo.stdout.value + winnerIo.stderr.value + loserIo.stdout.value + loserIo.stderr.value,
    new RegExp(`${winnerText}|${loserText}|${SECRET}`, "u"),
  );
  loserSecret.fill(0);
});

test("concurrent rotate and delete cannot leave an orphan or restored stale credential", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-concurrent-delete-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeBackend();
  const credentialStore = new GrafanaCredentialKeyring(backend);
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore,
    credentialStore,
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from(SECRET)),
    ...confirmedDiscovery(),
  }), 0);

  const promptEntered = deferred<void>();
  const releasePrompt = deferred<void>();
  t.after(() => releasePrompt.resolve(undefined));
  const winnerText = "serialized-rotate-delete-winner-canary";
  const winnerSecret = Uint8Array.from(Buffer.from(winnerText));
  const winnerIo = io();
  const winner = runObservabilityCli(["grafana", "rotate"], {
    profileStore,
    credentialStore,
    io: winnerIo,
    promptSecret: async () => {
      promptEntered.resolve(undefined);
      await releasePrompt.promise;
      return winnerSecret;
    },
    ...confirmedDiscovery(),
  });
  await promptEntered.promise;

  let deletionConfirmed = false;
  const deleteIo = io();
  assert.equal(await runObservabilityCli(["grafana", "delete"], {
    profileStore,
    credentialStore,
    io: deleteIo,
    confirmDelete: async () => {
      deletionConfirmed = true;
      return true;
    },
  }), 1);
  assert.equal(deletionConfirmed, false);
  assert.match(deleteIo.stderr.value, /credential store is unavailable/u);

  releasePrompt.resolve(undefined);
  assert.equal(await winner, 0);
  assert.ok(winnerSecret.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles[0]?.revision, 2);
  assert.equal(Buffer.from([...backend.values.values()][0] ?? []).toString("ascii"), winnerText);
  assert.doesNotMatch(
    winnerIo.stdout.value + winnerIo.stderr.value + deleteIo.stdout.value + deleteIo.stderr.value,
    new RegExp(`${winnerText}|${SECRET}`, "u"),
  );
});

test("SIGKILL recovery resolves every credential lifecycle phase from registry authority", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-crash-phases-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const scenarios: readonly {
    operation: "connect" | "rotate" | "delete";
    crashPoint: CredentialCrashPoint;
    authority: "PREVIOUS" | "NEXT";
  }[] = [
    { operation: "connect", crashPoint: "AFTER_PREPARED", authority: "PREVIOUS" },
    { operation: "connect", crashPoint: "AFTER_STAGED", authority: "PREVIOUS" },
    { operation: "connect", crashPoint: "AFTER_REGISTRY_COMMIT", authority: "NEXT" },
    { operation: "connect", crashPoint: "AFTER_COMMITTED", authority: "NEXT" },
    { operation: "connect", crashPoint: "BEFORE_JOURNAL_CLEAR", authority: "NEXT" },
    { operation: "rotate", crashPoint: "AFTER_PREPARED", authority: "PREVIOUS" },
    { operation: "rotate", crashPoint: "AFTER_STAGED", authority: "PREVIOUS" },
    { operation: "rotate", crashPoint: "AFTER_REGISTRY_COMMIT", authority: "NEXT" },
    { operation: "rotate", crashPoint: "AFTER_COMMITTED", authority: "NEXT" },
    { operation: "rotate", crashPoint: "AFTER_CLEANUP", authority: "NEXT" },
    { operation: "rotate", crashPoint: "BEFORE_JOURNAL_CLEAR", authority: "NEXT" },
    { operation: "delete", crashPoint: "AFTER_PREPARED", authority: "PREVIOUS" },
    { operation: "delete", crashPoint: "AFTER_REGISTRY_COMMIT", authority: "NEXT" },
    { operation: "delete", crashPoint: "AFTER_COMMITTED", authority: "NEXT" },
    { operation: "delete", crashPoint: "AFTER_CLEANUP", authority: "NEXT" },
    { operation: "delete", crashPoint: "BEFORE_JOURNAL_CLEAR", authority: "NEXT" },
  ];
  const secretCanaries = [
    "crash-seed-secret-canary",
    "crash-connect-secret-canary",
    "crash-rotate-secret-canary",
  ];
  const worker = join(process.cwd(), "tests", "observability-cli", "credential-crash-worker.ts");

  for (const [index, scenario] of scenarios.entries()) {
    const scenarioRoot = join(parent, `${String(index).padStart(2, "0")}-${scenario.operation}-${scenario.crashPoint.toLowerCase()}`);
    const stateRoot = join(scenarioRoot, "state");
    const keyringPath = join(scenarioRoot, "keyring.json");
    if (scenario.operation !== "connect") await seedCrashProfile(stateRoot, keyringPath);
    const child = spawnSync(process.execPath, [
      "--import",
      "tsx",
      worker,
      scenario.operation,
      scenario.crashPoint,
      stateRoot,
      keyringPath,
    ], { cwd: process.cwd(), encoding: "utf8", timeout: 5_000 });
    assert.equal(child.signal, "SIGKILL", `${scenario.operation}/${scenario.crashPoint}: ${child.stderr}`);
    assert.equal(child.stdout, "");
    assert.equal(child.stderr, "");

    const journalPath = join(stateRoot, LIFECYCLE_JOURNAL_FILENAME);
    assert.equal(existsSync(journalPath), true);
    const journalBytes = readFileSync(journalPath);
    for (const canary of secretCanaries) {
      assert.equal(journalBytes.includes(Buffer.from(canary)), false);
      assert.equal(journalBytes.includes(Buffer.from(Buffer.from(canary).toString("base64"))), false);
    }
    assert.equal(existsSync(join(stateRoot, LIFECYCLE_LOCK_FILENAME)), true);

    const profileStore = testProfileStore(stateRoot);
    const credentialStore = new GrafanaCredentialKeyring(new FileKeyringBackend(keyringPath));
    const statusIo = io();
    const expectedProfile = scenario.operation === "connect"
      ? scenario.authority === "NEXT"
      : scenario.operation === "rotate"
        ? true
        : scenario.authority === "PREVIOUS";
    assert.equal(await runObservabilityCli(["grafana", "status"], {
      profileStore,
      credentialStore,
      io: statusIo,
    }), expectedProfile ? 0 : 1);
    assert.doesNotMatch(statusIo.stdout.value + statusIo.stderr.value, /crash-(?:seed|connect|rotate)-secret-canary/u);

    const registry = await profileStore.read();
    const profile = registry.profiles[0];
    if (!expectedProfile) {
      assert.equal(profile, undefined);
    } else if (scenario.operation === "rotate" && scenario.authority === "NEXT") {
      assert.equal(profile?.revision, 2);
      assert.equal(profile?.credentialRef.key, grafanaCredentialReference(PROFILE_ID, 2).key);
    } else {
      assert.equal(profile?.revision, 1);
      assert.equal(profile?.credentialRef.key, grafanaCredentialReference(PROFILE_ID, 1).key);
    }

    const slotOne = await credentialStore.status(grafanaCredentialReference(PROFILE_ID, 1));
    const slotTwo = await credentialStore.status(grafanaCredentialReference(PROFILE_ID, 2));
    if (scenario.operation === "connect") {
      assert.equal(slotOne, scenario.authority === "NEXT" ? "AVAILABLE" : "MISSING_OR_UNAVAILABLE");
      assert.equal(slotTwo, "MISSING_OR_UNAVAILABLE");
    } else if (scenario.operation === "rotate") {
      assert.equal(slotOne, scenario.authority === "PREVIOUS" ? "AVAILABLE" : "MISSING_OR_UNAVAILABLE");
      assert.equal(slotTwo, scenario.authority === "NEXT" ? "AVAILABLE" : "MISSING_OR_UNAVAILABLE");
    } else {
      assert.equal(slotOne, scenario.authority === "PREVIOUS" ? "AVAILABLE" : "MISSING_OR_UNAVAILABLE");
      assert.equal(slotTwo, "MISSING_OR_UNAVAILABLE");
    }
    await profileStore.withExclusiveLifecycle(async (transaction) => {
      assert.equal(transaction.readCredentialLifecycleJournal(), undefined);
    });
    assert.equal(existsSync(join(stateRoot, LIFECYCLE_LOCK_FILENAME)), false);
  }
});

test("connect rejects a reflected credential before preview or persistence", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-reflection-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const backend = new FakeBackend();
  const secret = Uint8Array.from(Buffer.from(SECRET, "ascii"));
  const commandIo = io();
  let confirmationAttempted = false;
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore,
    credentialStore: new GrafanaCredentialKeyring(backend),
    io: commandIo,
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => secret,
    connectionDiscovery: {
      async inspect() {
        return { ...PREVIEW, datasources: [{ name: SECRET, type: "prometheus" }] };
      },
    },
    confirmActivation: async () => {
      confirmationAttempted = true;
      return true;
    },
  }), 1);
  assert.equal(confirmationAttempted, false);
  assert.ok(secret.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles.length, 0);
  assert.equal(backend.values.size, 0);
  assert.doesNotMatch(commandIo.stdout.value + commandIo.stderr.value, new RegExp(SECRET, "u"));
});

test("discovery timeout covers stalled response-body consumption", async () => {
  let bodyCancelled = false;
  const discovery = discoveryWithFetch(
    async () => new Response(new ReadableStream<Uint8Array>({
      cancel() { bodyCancelled = true; },
    }), { status: 200, headers: { "content-type": "application/json" } }),
    { timeoutMs: 25 },
  );
  const startedAt = Date.now();
  await assert.rejects(
    discovery.inspect({
      grafanaOrigin: "https://grafana.example.com",
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    }),
    (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "UNAVAILABLE",
  );
  assert.ok(Date.now() - startedAt < 1_000);
  assert.equal(bodyCancelled, true);
});

test("discovery rejects incrementally oversized bodies and reflected canaries", async () => {
  const oversized = discoveryWithFetch(
    async () => new Response(new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new Uint8Array(1_048_577));
        controller.close();
      },
    }), { status: 200 }),
  );
  await assert.rejects(
    oversized.inspect({
      grafanaOrigin: "https://grafana.example.com",
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    }),
    (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "INVALID_RESPONSE",
  );

  const reflected = discoveryWithFetch(
    async (input) => {
      const path = new URL(String(input)).pathname;
      const body = path === "/api/health"
        ? { database: "ok", version: "12.2.0" }
        : path === "/api/datasources"
          ? [{ name: SECRET, type: "prometheus" }]
          : { "datasources:read": ["datasources:*"], "datasources:query": ["datasources:*"] };
      return new Response(JSON.stringify(body), { status: 200 });
    },
  );
  await assert.rejects(
    reflected.inspect({
      grafanaOrigin: "https://grafana.example.com",
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    }),
    (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "INVALID_RESPONSE",
  );
});

test("tagged Grafana 10-13 Viewer permission payloads are accepted without admitting broader access", async () => {
  // Golden non-`:read` grants come from the tagged built-in Viewer role sources named in
  // grafana-discovery.ts. Each scope is kept exact so a Grafana role expansion fails closed.
  const viewerPermissions = (major: number): Record<string, string[]> => ({
    "datasources:read": ["datasources:*"],
    "datasources:query": ["datasources:*"],
    "dashboards:read": ["dashboards:*"],
    "plugins.app:access": ["plugins:*"],
    "alert.notifications.receivers:list": [""],
    ...(major === 13
      ? { "notifications.alerting.grafana.app/configs:get": ["configs:*"] }
      : {}),
  });
  const inspect = async (version: string): Promise<GrafanaConnectionPreview> => {
    const discovery = discoveryWithFetch(
      async (input) => {
        const path = new URL(String(input)).pathname;
        if (path === "/api/health") {
          return new Response(JSON.stringify({ database: "ok", version }), { status: 200 });
        }
        if (path === "/api/datasources") return new Response("[]", { status: 200 });
        if (path === "/api/access-control/user/permissions") {
          return new Response(JSON.stringify(viewerPermissions(Number(version.split(".", 1)[0]))), { status: 200 });
        }
        return new Response("{}", { status: 404 });
      },
    );
    return discovery.inspect({
      grafanaOrigin: "https://grafana.example.com",
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    }) as Promise<GrafanaConnectionPreview>;
  };
  for (const version of ["10.4.19", "11.6.11", "12.4.0", "13.2.0"]) {
    const preview = await inspect(version);
    assert.equal(preview.grafanaVersion, version);
    assert.equal(preview.permissionState, "READ_ONLY_CONFIRMED");
  }
  assert.match((await inspect("13.0.0")).warnings.join(" "), /deprecated/u);
  for (const version of ["9.5.0", "14.0.0", "12-not-semver", "12.01.0"]) {
    await assert.rejects(
      inspect(version),
      (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "UNSUPPORTED_VERSION",
    );
  }
});

test("permission discovery fails closed when proof is unavailable, insufficient, or writable", async () => {
  const inspect = async (permissionStatus: number, permissions: unknown): Promise<unknown> => {
    const discovery = discoveryWithFetch(
      async (input) => {
        const path = new URL(String(input)).pathname;
        if (path === "/api/health") {
          return new Response(JSON.stringify({ database: "ok", version: "12.2.0" }), { status: 200 });
        }
        if (path === "/api/datasources") return new Response("[]", { status: 200 });
        if (path === "/api/access-control/user/permissions") {
          return new Response(JSON.stringify(permissions), { status: permissionStatus });
        }
        return new Response("{}", { status: 404 });
      },
    );
    return discovery.inspect({
      grafanaOrigin: "https://grafana.example.com",
      bearerSecret: Uint8Array.from(Buffer.from(SECRET)),
    });
  };
  for (const status of [403, 404, 405]) {
    await assert.rejects(
      inspect(status, {}),
      (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "PERMISSION_REJECTED",
    );
  }
  await assert.rejects(
    inspect(200, { "datasources:read": ["datasources:*"] }),
    (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "PERMISSION_REJECTED",
  );
  await assert.rejects(
    inspect(200, {
      "datasources:read": ["datasources:*"],
      "datasources:query": ["datasources:*"],
      "annotations:write": ["annotations:*"],
    }),
    (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "OVER_PRIVILEGED",
  );
  for (const permissions of [
    {
      "datasources:read": ["datasources:*"],
      "datasources:query": ["datasources:*"],
      "plugins.app:access": ["plugins:id:unreviewed"],
    },
    {
      "datasources:read": ["datasources:*"],
      "datasources:query": ["datasources:*"],
      "alert.notifications.receivers:list": ["receivers:*"],
    },
  ]) {
    await assert.rejects(
      inspect(200, permissions),
      (error: unknown) => error instanceof GrafanaDiscoveryError && error.code === "OVER_PRIVILEGED",
    );
  }
});

test("rotate and delete restore the old keyring value when registry commit fails", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-rollback-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  let failUpdates = false;
  const wrappedStore = updateFailingProfileStore(profileStore, () => failUpdates);
  const backend = new FakeBackend();
  const credentialStore = new GrafanaCredentialKeyring(backend);
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore: wrappedStore,
    credentialStore,
    io: io(),
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => Uint8Array.from(Buffer.from(SECRET)),
    ...confirmedDiscovery(),
  }), 0);
  failUpdates = true;
  const rotatedSecretText = "rotated-rollback-secret-canary";
  const rotatedSecret = Uint8Array.from(Buffer.from(rotatedSecretText));
  const rotateIo = io();
  assert.equal(await runObservabilityCli(["grafana", "rotate"], {
    profileStore: wrappedStore,
    credentialStore,
    io: rotateIo,
    promptSecret: async () => rotatedSecret,
    ...confirmedDiscovery(),
  }), 1);
  assert.ok(rotatedSecret.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles[0]?.revision, 1);
  assert.equal(Buffer.from([...backend.values.values()][0] ?? []).toString("ascii"), SECRET);
  assert.doesNotMatch(rotateIo.stdout.value + rotateIo.stderr.value, /registry-failure|grafana-cli-secret|rotated-rollback/iu);

  const deleteIo = io();
  assert.equal(await runObservabilityCli(["grafana", "delete"], {
    profileStore: wrappedStore,
    credentialStore,
    io: deleteIo,
    confirmDelete: async () => true,
  }), 1);
  assert.equal((await profileStore.read()).profiles.length, 1);
  assert.equal(Buffer.from([...backend.values.values()][0] ?? []).toString("ascii"), SECRET);
  assert.doesNotMatch(deleteIo.stdout.value + deleteIo.stderr.value, /registry-failure|grafana-cli-secret/iu);
});

test("connect deletes the newly written credential when registry commit fails", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "observability-cli-connect-rollback-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const profileStore = new SharedGrafanaProfileStore({
    rootPath: join(parent, "state"),
    platform: process.platform === "linux" ? "linux" : "darwin",
  });
  const wrappedStore = updateFailingProfileStore(profileStore, () => true);
  const backend = new FakeBackend();
  const secret = Uint8Array.from(Buffer.from(SECRET));
  const commandIo = io();
  assert.equal(await runObservabilityCli([
    "grafana", "connect", "--url", "https://grafana.example.com", "--profile", "Operations",
  ], {
    profileStore: wrappedStore,
    credentialStore: new GrafanaCredentialKeyring(backend),
    io: commandIo,
    createProfileId: () => PROFILE_ID,
    promptSecret: async () => secret,
    ...confirmedDiscovery(),
  }), 1);
  assert.ok(secret.every((byte) => byte === 0));
  assert.equal((await profileStore.read()).profiles.length, 0);
  assert.equal(backend.values.size, 0);
  assert.doesNotMatch(commandIo.stdout.value + commandIo.stderr.value, /registry-failure|grafana-cli-secret/iu);
});
