import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";

import type {
  GrafanaCredentialLifecycleJournalV1,
  GrafanaKeyringBackend,
  SharedGrafanaProfileRegistryStore,
} from "../../packages/grafana-credential-profile/src/index.ts";

export type CredentialCrashPoint =
  | "AFTER_PREPARED"
  | "AFTER_STAGED"
  | "AFTER_REGISTRY_COMMIT"
  | "AFTER_COMMITTED"
  | "AFTER_CLEANUP"
  | "BEFORE_JOURNAL_CLEAR";

function crashNow(): never {
  process.kill(process.pid, "SIGKILL");
  throw new Error("SIGKILL did not terminate the credential crash fixture");
}

export class FileKeyringBackend implements GrafanaKeyringBackend {
  readonly #path: string;
  readonly #crashPoint: CredentialCrashPoint | undefined;

  constructor(path: string, crashPoint?: CredentialCrashPoint) {
    this.#path = path;
    this.#crashPoint = crashPoint;
  }

  #read(): Record<string, string> {
    return existsSync(this.#path)
      ? JSON.parse(readFileSync(this.#path, "utf8")) as Record<string, string>
      : {};
  }

  #write(values: Readonly<Record<string, string>>): void {
    mkdirSync(dirname(this.#path), { recursive: true, mode: 0o700 });
    writeFileSync(this.#path, `${JSON.stringify(values)}\n`, { mode: 0o600 });
  }

  async getSecret(service: string, account: string): Promise<Uint8Array | undefined> {
    const encoded = this.#read()[`${service}\0${account}`];
    return encoded === undefined ? undefined : Uint8Array.from(Buffer.from(encoded, "base64"));
  }

  async setSecret(service: string, account: string, secret: Uint8Array): Promise<void> {
    this.#write({
      ...this.#read(),
      [`${service}\0${account}`]: Buffer.from(secret).toString("base64"),
    });
    if (this.#crashPoint === "AFTER_STAGED") crashNow();
  }

  async deleteSecret(service: string, account: string): Promise<boolean> {
    const values = this.#read();
    const key = `${service}\0${account}`;
    const existed = Object.hasOwn(values, key);
    delete values[key];
    this.#write(values);
    if (this.#crashPoint === "AFTER_CLEANUP") crashNow();
    return existed;
  }
}

export function crashInjectedProfileStore(
  profileStore: SharedGrafanaProfileRegistryStore,
  crashPoint: CredentialCrashPoint,
): SharedGrafanaProfileRegistryStore {
  return {
    read: () => profileStore.read(),
    update: (mutation) => profileStore.update(mutation),
    withExclusiveLifecycle: (operation) => profileStore.withExclusiveLifecycle(
      (transaction) => operation({
        read: () => transaction.read(),
        readCredentialLifecycleJournal: () => transaction.readCredentialLifecycleJournal(),
        writeCredentialLifecycleJournal: async (
          journal: Readonly<GrafanaCredentialLifecycleJournalV1>,
        ) => {
          await transaction.writeCredentialLifecycleJournal(journal);
          if (
            (crashPoint === "AFTER_PREPARED" && journal.phase === "PREPARED")
            || (crashPoint === "AFTER_COMMITTED" && journal.phase === "COMMITTED")
          ) {
            crashNow();
          }
        },
        clearCredentialLifecycleJournal: async () => {
          if (crashPoint === "BEFORE_JOURNAL_CLEAR") crashNow();
          await transaction.clearCredentialLifecycleJournal();
        },
        update: async (mutation) => {
          const updated = await transaction.update(mutation);
          if (crashPoint === "AFTER_REGISTRY_COMMIT") crashNow();
          return updated;
        },
      }),
    ),
  };
}
