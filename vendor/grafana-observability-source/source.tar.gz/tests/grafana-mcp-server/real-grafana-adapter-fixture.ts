import {
  GRAFANA_ADAPTER_PACKAGE_ID,
  GrafanaAdapter,
  canonicalGrafanaDatasourceType,
  grafanaAdapterPackage,
  grafanaCatalogEntryHash,
  isGrafanaPostgresDatasourceType,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaDatasourceQueryScopeMappings,
  type GrafanaDatasourceQueryTarget,
  type GrafanaDatasourceType,
  type GrafanaFrameContract,
  type GrafanaFrameFieldContract,
  type GrafanaHttpRequest,
  type GrafanaHttpResponse,
  type GrafanaTransport,
} from "../../adapters/grafana/src/index.ts";
import { builtinRegistration, type AdapterRegistration } from "../../packages/adapter-host/src/index.ts";
import { computeTrustedProfileConfigHash } from "../../packages/config/src/index.ts";
import {
  GRAFANA_CAPABILITY_PACKS,
  computeIntegrity,
  computeOperationDefinitionHash,
  sha256Canonical,
  type EvidenceDomain,
  type OperationDefinition,
  type OperationId,
  type OperationLimits,
  type OperationSnapshot,
  type ProviderCapabilityPackV1,
  type Scope,
  type Sha256,
  type SubjectRef,
  type TrustBundle,
  type TrustedEndpoint,
  type TrustedProfile,
} from "../../packages/contracts/src/index.ts";

export const REAL_GRAFANA_FIXTURE_NOW = "2026-08-15T02:00:00.000Z";
export const REAL_GRAFANA_FIXTURE_WINDOW = {
  start: "2026-08-15T01:00:00.000Z",
  end: REAL_GRAFANA_FIXTURE_NOW,
};
export const REAL_GRAFANA_FIXTURE_PROFILE = "actual-grafana";

const LIMITS: OperationLimits = {
  timeoutMs: 1_000,
  maxAgeMs: 60_000,
  maxBytes: 64_000,
  maxRows: 100,
  maxSeries: 10,
  maxPoints: 100,
};

const SUBJECTS = {
  infrastructure: {
    kind: "HOST" as const,
    ref: "pmsub_actualinfrahost000000000" as SubjectRef,
    providerValue: "native-host-alpha-secret",
  },
  logs: {
    kind: "HOST" as const,
    ref: "pmsub_actualloghost0000000000" as SubjectRef,
    providerValue: "native-log-host-secret",
  },
  iot: {
    kind: "DEVICE" as const,
    ref: "pmsub_actualdevice000000000000" as SubjectRef,
    providerValue: "native-device-alpha-secret",
  },
  business: {
    kind: "BUSINESS_UNIT" as const,
    ref: "pmsub_actualbusiness0000000000" as SubjectRef,
    providerValue: "native-business-unit-secret",
  },
};

export const REAL_GRAFANA_FIXTURE_SCOPES = {
  infrastructure: {
    environment: "simulation",
    service: "checkout",
    subject: { kind: SUBJECTS.infrastructure.kind, ref: SUBJECTS.infrastructure.ref },
  },
  apm: { environment: "simulation", service: "checkout" },
  logs: {
    environment: "simulation",
    service: "checkout",
    subject: { kind: SUBJECTS.logs.kind, ref: SUBJECTS.logs.ref },
  },
  iot: {
    environment: "simulation",
    subject: { kind: SUBJECTS.iot.kind, ref: SUBJECTS.iot.ref },
  },
  business: {
    environment: "simulation",
    subject: { kind: SUBJECTS.business.kind, ref: SUBJECTS.business.ref },
  },
} satisfies Record<string, Scope>;

type CertifiedDatasourceType = GrafanaDatasourceType;

interface NumericFixtureSpec {
  operationId: string;
  packId: string;
  scopeAlias: keyof typeof REAL_GRAFANA_FIXTURE_SCOPES;
  datasourceType: Exclude<CertifiedDatasourceType, "tempo">;
  value: number;
}

interface EventFixtureSpec {
  operationId: string;
  packId: "grafana.apm";
  scopeAlias: "apm";
  datasourceType: "loki" | "tempo";
  summary: string;
  attribute: {
    sourceName: string;
    outputName: string;
    value: number;
  };
}

type FixtureSpec = NumericFixtureSpec | EventFixtureSpec;

const FIXTURE_SPECS: readonly FixtureSpec[] = [
  { operationId: "grafana.infrastructure.cpu.usage", packId: "grafana.infrastructure", scopeAlias: "infrastructure", datasourceType: "prometheus", value: 97 },
  { operationId: "grafana.infrastructure.memory.load", packId: "grafana.infrastructure", scopeAlias: "infrastructure", datasourceType: "prometheus", value: 82 },
  { operationId: "grafana.infrastructure.disk.free", packId: "grafana.infrastructure", scopeAlias: "infrastructure", datasourceType: "prometheus", value: 8 },
  { operationId: "grafana.infrastructure.system.load", packId: "grafana.infrastructure", scopeAlias: "infrastructure", datasourceType: "prometheus", value: 2.1 },
  { operationId: "grafana.apm.request.rate", packId: "grafana.apm", scopeAlias: "apm", datasourceType: "prometheus", value: 120 },
  {
    operationId: "grafana.apm.error.codes",
    packId: "grafana.apm",
    scopeAlias: "apm",
    datasourceType: "loki",
    summary: "HTTP 503 response observed for checkout",
    attribute: { sourceName: "Status code", outputName: "status_code", value: 503 },
  },
  { operationId: "grafana.apm.error.rate", packId: "grafana.apm", scopeAlias: "apm", datasourceType: "prometheus", value: 6 },
  { operationId: "grafana.apm.latency.p95", packId: "grafana.apm", scopeAlias: "apm", datasourceType: "prometheus", value: 1_250 },
  {
    operationId: "grafana.apm.traces.slow",
    packId: "grafana.apm",
    scopeAlias: "apm",
    datasourceType: "tempo",
    summary: "Slow checkout trace exceeded 1000 ms",
    attribute: { sourceName: "Duration", outputName: "duration_ms", value: 1_250 },
  },
  { operationId: "grafana.logs.events", packId: "grafana.logs", scopeAlias: "logs", datasourceType: "loki", value: 42 },
  { operationId: "grafana.logs.error.rate", packId: "grafana.logs", scopeAlias: "logs", datasourceType: "loki", value: 1.5 },
  { operationId: "grafana.logs.security.markers", packId: "grafana.logs", scopeAlias: "logs", datasourceType: "loki", value: 1 },
  { operationId: "grafana.iot.telemetry", packId: "grafana.iot-edge", scopeAlias: "iot", datasourceType: "prometheus", value: 17.4 },
  { operationId: "grafana.iot.device.freshness", packId: "grafana.iot-edge", scopeAlias: "iot", datasourceType: "prometheus", value: 420 },
  { operationId: "grafana.business.revenue", packId: "grafana.business-kpis", scopeAlias: "business", datasourceType: "grafana-postgresql-datasource", value: 95_000 },
  { operationId: "grafana.business.conversion", packId: "grafana.business-kpis", scopeAlias: "business", datasourceType: "grafana-postgresql-datasource", value: 3.2 },
  { operationId: "grafana.business.operational.kpi", packId: "grafana.business-kpis", scopeAlias: "business", datasourceType: "grafana-postgresql-datasource", value: 88 },
] as const;

interface CompiledFixtureSpec {
  spec: FixtureSpec;
  entry: GrafanaDatasourceQueryCatalogEntry;
  responseValues: unknown[][];
}

export interface CapturedGrafanaQuery {
  operationId: string;
  datasourceType: CertifiedDatasourceType;
  datasourceUid: string;
  targetCount: number;
  method: "GET" | "POST";
  path: "/api/ds/query" | `/api/datasources/proxy/uid/${string}/api/search`;
}

function isEventSpec(spec: FixtureSpec): spec is EventFixtureSpec {
  return "summary" in spec;
}

function packFor(spec: FixtureSpec): Readonly<ProviderCapabilityPackV1> {
  const pack = GRAFANA_CAPABILITY_PACKS.find((candidate) => candidate.packId === spec.packId);
  if (pack === undefined) throw new TypeError(`Missing fixture capability pack: ${spec.packId}`);
  return pack;
}

function scopeMappings(pack: Readonly<ProviderCapabilityPackV1>): GrafanaDatasourceQueryScopeMappings {
  const environment = pack.scopeMappings.find((mapping) => mapping.scopeField === "environment")?.providerField;
  const service = pack.scopeMappings.find((mapping) => mapping.scopeField === "service")?.providerField;
  const subject = pack.scopeMappings.find((mapping) => mapping.scopeField === "subject.ref")?.providerField;
  if (environment === undefined) throw new TypeError(`Capability pack ${pack.packId} lacks environment scope`);
  return {
    environment,
    ...(service === undefined ? {} : { service }),
    ...(subject === undefined ? {} : { "subject.ref": subject }),
  };
}

function subjectForAlias(alias: FixtureSpec["scopeAlias"]): (typeof SUBJECTS)[keyof typeof SUBJECTS] | undefined {
  if (alias === "infrastructure") return SUBJECTS.infrastructure;
  if (alias === "logs") return SUBJECTS.logs;
  if (alias === "iot") return SUBJECTS.iot;
  if (alias === "business") return SUBJECTS.business;
  return undefined;
}

function slug(value: string): string {
  return value.replaceAll(/[^A-Za-z0-9_]/gu, "_");
}

function targetFor(
  spec: FixtureSpec,
  scope: Scope,
  mappings: GrafanaDatasourceQueryScopeMappings,
  subjectProviderValue: string | undefined,
  resultName: string,
): { target: GrafanaDatasourceQueryTarget; queryCanary: string } {
  const selectorParts = [
    `${mappings.environment}="${scope.environment}"`,
    ...(scope.service === undefined ? [] : [`${mappings.service!}="${scope.service}"`]),
    ...(subjectProviderValue === undefined ? [] : [`${mappings["subject.ref"]!}="${subjectProviderValue}"`]),
  ];
  const operationSlug = slug(spec.operationId);
  if (spec.datasourceType === "prometheus") {
    const queryCanary = `private_metric_${operationSlug}`;
    return {
      target: {
        datasourceType: "prometheus",
        expression: `${queryCanary}{${selectorParts.join(",")}}`,
        mode: "instant",
        format: "time_series",
      },
      queryCanary,
    };
  }
  if (spec.datasourceType === "loki") {
    const queryCanary = `private_loki_selector_${operationSlug}`;
    return {
      target: {
        datasourceType: "loki",
        expression: `{${selectorParts.join(",")}} |= "${queryCanary}"`,
        queryType: "range",
        direction: "backward",
      },
      queryCanary,
    };
  }
  if (spec.datasourceType === "tempo") {
    const queryCanary = `private_trace_selector_${operationSlug}`;
    return {
      target: {
        datasourceType: "tempo",
        expression: `{ resource.deployment.environment = "${scope.environment}" && resource.service.name = "${scope.service!}" && name = "${queryCanary}" }`,
        queryType: "traceql",
        limit: 20,
        spansPerSpanSet: 20,
        tableType: "traces",
      },
      queryCanary,
    };
  }
  const queryCanary = "private_business_kpi";
  return {
    target: {
      datasourceType: spec.datasourceType,
      rawSql: `SELECT ${resultName} AS value, ${mappings.environment}, ${mappings["subject.ref"]!} FROM ${queryCanary} WHERE ${mappings.environment} = '${scope.environment}' AND ${mappings["subject.ref"]!} = '${subjectProviderValue!}' LIMIT 1`,
      format: "table",
      maxRows: 1,
    },
    queryCanary,
  };
}

function dimensionFields(
  scope: Scope,
  mappings: GrafanaDatasourceQueryScopeMappings,
): GrafanaFrameFieldContract[] {
  return [
    { sourceName: mappings.environment, outputName: "environment", type: "string", role: "DIMENSION" },
    ...(scope.service === undefined
      ? []
      : [{ sourceName: mappings.service!, outputName: "service", type: "string" as const, role: "DIMENSION" as const }]),
    ...(scope.subject === undefined
      ? []
      : [{ sourceName: mappings["subject.ref"]!, outputName: "subject_ref", type: "string" as const, role: "DIMENSION" as const }]),
  ];
}

function scopeValues(
  scope: Scope,
  subjectProviderValue: string | undefined,
  rows: number,
): unknown[][] {
  return [
    Array.from({ length: rows }, () => scope.environment),
    ...(scope.service === undefined ? [] : [Array.from({ length: rows }, () => scope.service!)]),
    ...(scope.subject === undefined ? [] : [Array.from({ length: rows }, () => subjectProviderValue!)]),
  ];
}

function compileSpec(spec: FixtureSpec): {
  compiled: CompiledFixtureSpec;
  leakageTokens: string[];
} {
  const pack = packFor(spec);
  const scope: Scope = REAL_GRAFANA_FIXTURE_SCOPES[spec.scopeAlias];
  const mappings = scopeMappings(pack);
  const subject = subjectForAlias(spec.scopeAlias);
  const signal = pack.signals.find((candidate) => candidate.operationId === spec.operationId);
  const resultName = signal?.resultName ?? (spec.datasourceType === "tempo" ? "slow_traces" : "error_codes");
  const { target, queryCanary } = targetFor(spec, scope, mappings, subject?.providerValue, resultName);
  const dimensions = dimensionFields(scope, mappings);
  let frame: GrafanaFrameContract;
  let responseValues: unknown[][];
  if (isEventSpec(spec)) {
    frame = {
      resultKind: "EVENT",
      fields: [
        { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
        { sourceName: "Summary", outputName: "summary", type: "string", role: "SUMMARY" },
        { sourceName: spec.attribute.sourceName, outputName: spec.attribute.outputName, type: "number", role: "ATTRIBUTE" },
        ...dimensions,
      ],
      allowedLabels: [],
    };
    responseValues = [
      [Date.parse(REAL_GRAFANA_FIXTURE_NOW) - 120_000],
      [spec.summary],
      [spec.attribute.value],
      ...scopeValues(scope, subject?.providerValue, 1),
    ];
  } else if (spec.datasourceType === "loki") {
    frame = {
      resultKind: "TIMESERIES",
      fields: [
        { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
        { sourceName: "Value", outputName: resultName, type: "number", role: "VALUE" },
        ...dimensions,
      ],
      allowedLabels: [],
      ...(signal?.unit === undefined ? {} : { unit: signal.unit }),
    };
    responseValues = [
      [Date.parse(REAL_GRAFANA_FIXTURE_NOW) - 120_000, Date.parse(REAL_GRAFANA_FIXTURE_NOW) - 60_000],
      [spec.value * 0.8, spec.value],
      ...scopeValues(scope, subject?.providerValue, 2),
    ];
  } else {
    frame = {
      resultKind: "SCALAR",
      fields: [
        { sourceName: "Value", outputName: resultName, type: "number", role: "VALUE" },
        ...dimensions,
      ],
      allowedLabels: [],
      ...(signal?.unit === undefined ? {} : { unit: signal.unit }),
    };
    responseValues = [[spec.value], ...scopeValues(scope, subject?.providerValue, 1)];
  }
  const datasourceUid = `private-${spec.datasourceType}-${slug(spec.operationId)}`;
  const entry: GrafanaDatasourceQueryCatalogEntry = {
    id: `catalog.${spec.operationId}`,
    route: "datasource-query",
    outputName: resultName,
    datasourceUid,
    datasourceIdentitySha256: {
      prometheus: "1".repeat(64),
      loki: "2".repeat(64),
      tempo: "3".repeat(64),
      postgres: "4".repeat(64),
    }[canonicalGrafanaDatasourceType(spec.datasourceType)] as Sha256,
    target,
    ...(isGrafanaPostgresDatasourceType(spec.datasourceType)
      ? {
          postgresReadOnlyIdentity: {
            roleIdentitySha256: "5".repeat(64) as Sha256,
            privilegeModel: "SELECT_ONLY" as const,
          },
        }
      : {}),
    frame,
    minIntervalMs: 1_000,
    scope: {
      environment: scope.environment,
      ...(scope.service === undefined ? {} : { service: scope.service }),
      ...(scope.subject === undefined || subject === undefined
        ? {}
        : { subject: { kind: scope.subject.kind, ref: scope.subject.ref, providerValue: subject.providerValue } }),
    },
    scopeMappings: mappings,
  };
  return {
    compiled: { spec, entry, responseValues },
    leakageTokens: [datasourceUid, queryCanary, ...(subject === undefined ? [] : [subject.providerValue])],
  };
}

function domainFor(datasourceType: CertifiedDatasourceType): EvidenceDomain {
  if (datasourceType === "loki") return "LOGS";
  if (datasourceType === "tempo") return "TRACES";
  return "METRICS";
}

function operationFor(compiled: CompiledFixtureSpec): OperationSnapshot {
  const { spec, entry } = compiled;
  const definition: OperationDefinition = {
    domain: domainFor(spec.datasourceType),
    sourceAlias: "grafana-fixture-endpoint",
    adapterPackageId: GRAFANA_ADAPTER_PACKAGE_ID,
    adapterOperation: "grafana.datasource.query.read",
    authority: "CORROBORATING",
    sanitizedProviderDefinition: {
      catalogEntryId: entry.id,
      catalogEntrySha256: grafanaCatalogEntryHash(entry),
    },
    expectedSourceLineage: {
      accessPath: "GRAFANA",
      datasourceType: canonicalGrafanaDatasourceType(spec.datasourceType),
      sourceIdentitySha256: entry.datasourceIdentitySha256,
    },
    scopeMapping: { ...entry.scopeMappings },
    allowedDimensions: entry.frame.fields
      .filter((field) => field.role === "DIMENSION")
      .map((field) => field.outputName),
    requiredProviderScopes: Object.keys(entry.scopeMappings),
    sensitivity: "INTERNAL",
    limits: LIMITS,
    normalization: {
      resultKind: entry.frame.resultKind,
      ...(entry.frame.unit === undefined ? {} : { targetUnit: entry.frame.unit }),
      dimensionMappings: {},
    },
  };
  const semantic = { operationId: spec.operationId as OperationId, revision: 1, definition };
  return {
    schemaVersion: "1.0.0",
    ...semantic,
    capturedAt: REAL_GRAFANA_FIXTURE_NOW,
    definitionSha256: computeOperationDefinitionHash(semantic),
  };
}

async function* chunks(value: unknown): AsyncGenerator<Uint8Array> {
  yield Buffer.from(JSON.stringify(value));
}

function responseFor(compiled: CompiledFixtureSpec): GrafanaHttpResponse {
  if (compiled.spec.datasourceType === "tempo" && isEventSpec(compiled.spec)) {
    const startTimeUnixNano = String(BigInt(Date.parse(REAL_GRAFANA_FIXTURE_NOW) - 120_000) * 1_000_000n);
    const durationMs = compiled.spec.attribute.value;
    return {
      status: 200,
      body: chunks({ traces: [{
        traceID: "1".repeat(32),
        rootServiceName: compiled.entry.scope.service,
        rootTraceName: compiled.spec.summary,
        startTimeUnixNano,
        durationMs,
        spanSets: [{ spans: [{
          spanID: "2".repeat(16),
          startTimeUnixNano,
          durationNanos: String(durationMs * 1_000_000),
          attributes: [
            { key: "deployment.environment", value: { stringValue: compiled.entry.scope.environment } },
            { key: "service.name", value: { stringValue: compiled.entry.scope.service } },
          ],
        }] }],
      }] }),
    };
  }
  return {
    status: 200,
    body: chunks({
      results: {
        A: {
          frames: [{
            schema: {
              refId: "A",
              fields: compiled.entry.frame.fields.map((field) => ({
                name: field.sourceName,
                type: field.type,
              })),
            },
            data: { values: compiled.responseValues },
          }],
        },
      },
    }),
  };
}

export class DeterministicGrafanaTransport implements GrafanaTransport {
  readonly requests: CapturedGrafanaQuery[] = [];
  readonly #byUid: ReadonlyMap<string, CompiledFixtureSpec>;

  constructor(compiled: readonly CompiledFixtureSpec[]) {
    this.#byUid = new Map(compiled.map((item) => [item.entry.datasourceUid, item]));
  }

  async request(request: Readonly<GrafanaHttpRequest>): Promise<GrafanaHttpResponse> {
    if (request.method === "GET" && request.path === "/api/health") {
      return { status: 200, body: chunks({ database: "ok", version: "13.1.0" }) };
    }
    if (request.method === "GET") {
      const compiled = [...this.#byUid.values()].find((candidate) =>
        candidate.entry.target.datasourceType === "tempo" &&
        request.path === `/api/datasources/proxy/uid/${candidate.entry.datasourceUid}/api/search`);
      if (compiled === undefined || compiled.entry.target.datasourceType !== "tempo") {
        throw new TypeError("The deterministic Grafana fixture received an unknown Tempo route");
      }
      const expectedQuery = {
        q: compiled.entry.target.expression,
        start: String(Date.parse(REAL_GRAFANA_FIXTURE_WINDOW.start) / 1_000),
        end: String(Date.parse(REAL_GRAFANA_FIXTURE_WINDOW.end) / 1_000),
        limit: String(Math.min(compiled.entry.target.limit, LIMITS.maxRows)),
        spss: String(Math.min(compiled.entry.target.spansPerSpanSet, LIMITS.maxRows)),
      };
      if (sha256Canonical(request.query) !== sha256Canonical(expectedQuery) || "body" in request) {
        throw new TypeError("The deterministic Grafana fixture received a modified Tempo query");
      }
      this.requests.push({
        operationId: compiled.spec.operationId,
        datasourceType: compiled.spec.datasourceType,
        datasourceUid: compiled.entry.datasourceUid,
        targetCount: 1,
        method: "GET",
        path: `/api/datasources/proxy/uid/${compiled.entry.datasourceUid}/api/search`,
      });
      return responseFor(compiled);
    }
    if (request.method !== "POST" || request.path !== "/api/ds/query") {
      throw new TypeError("The deterministic Grafana fixture accepts only reviewed datasource read routes");
    }
    const queries = request.body.queries;
    if (!Array.isArray(queries) || queries.length !== 1) {
      throw new TypeError("The deterministic Grafana fixture requires exactly one target");
    }
    const target = queries[0];
    if (target === null || typeof target !== "object" || Array.isArray(target)) {
      throw new TypeError("The deterministic Grafana fixture target is invalid");
    }
    const datasource = (target as { datasource?: unknown }).datasource;
    if (datasource === null || typeof datasource !== "object" || Array.isArray(datasource)) {
      throw new TypeError("The deterministic Grafana fixture datasource is invalid");
    }
    const uid = (datasource as { uid?: unknown }).uid;
    const datasourceType = (datasource as { type?: unknown }).type;
    if (typeof uid !== "string" || typeof datasourceType !== "string") {
      throw new TypeError("The deterministic Grafana fixture datasource binding is invalid");
    }
    const compiled = this.#byUid.get(uid);
    if (compiled === undefined || compiled.spec.datasourceType !== datasourceType || datasourceType === "tempo") {
      throw new TypeError("The deterministic Grafana fixture received an unknown datasource binding");
    }
    this.requests.push({
      operationId: compiled.spec.operationId,
      datasourceType: compiled.spec.datasourceType,
      datasourceUid: uid,
      targetCount: queries.length,
      method: "POST",
      path: "/api/ds/query",
    });
    return responseFor(compiled);
  }
}

export interface RealGrafanaAdapterRuntimeFixture {
  bundle: TrustBundle;
  registrations: AdapterRegistration[];
  transport: DeterministicGrafanaTransport;
  expectedDatasourceTypes: ReadonlyMap<string, CertifiedDatasourceType>;
  leakageTokens: readonly string[];
}

export function createRealGrafanaAdapterRuntimeFixture(): RealGrafanaAdapterRuntimeFixture {
  const requiredOperationIds = GRAFANA_CAPABILITY_PACKS.flatMap((pack) => pack.requiredOperationIds);
  const fixtureOperationIds = FIXTURE_SPECS.map((spec) => spec.operationId);
  if (
    new Set(requiredOperationIds).size !== requiredOperationIds.length ||
    new Set(fixtureOperationIds).size !== fixtureOperationIds.length ||
    requiredOperationIds.length !== fixtureOperationIds.length ||
    requiredOperationIds.some((operationId) => !fixtureOperationIds.includes(operationId))
  ) {
    throw new TypeError("The real Grafana adapter fixture must bind every required capability-pack operation exactly once");
  }
  const compiledWithLeakage = FIXTURE_SPECS.map(compileSpec);
  const compiled = compiledWithLeakage.map((item) => item.compiled);
  const catalog = { entries: compiled.map((item) => item.entry) };
  const transport = new DeterministicGrafanaTransport(compiled);
  const adapter = new GrafanaAdapter({ catalog, transport });
  const operations = compiled.map(operationFor);
  const endpoint: TrustedEndpoint = {
    endpointId: "grafana-fixture-endpoint",
    adapterId: GRAFANA_ADAPTER_PACKAGE_ID,
    baseUrl: "http://127.0.0.1:3000/",
    authentication: { mode: "NONE" },
    tls: { minimumVersion: "TLSv1.2" },
    network: {
      followRedirects: false,
      allowLoopbackHttp: true,
      allowedHosts: ["127.0.0.1"],
      networkClass: "loopback",
      routeMode: "direct",
    },
  };
  const profileDraft: TrustedProfile = {
    schemaVersion: "1.0.0",
    profileAlias: REAL_GRAFANA_FIXTURE_PROFILE,
    capabilityProfile: "investigate",
    allowedOrigins: ["SIMULATED"],
    compiledAt: REAL_GRAFANA_FIXTURE_NOW,
    configSha256: "0".repeat(64) as Sha256,
    endpointRegistrySha256: sha256Canonical([endpoint]),
    catalogSha256: sha256Canonical(operations),
    capabilityPackCatalogSha256: sha256Canonical(GRAFANA_CAPABILITY_PACKS),
    scopes: structuredClone(REAL_GRAFANA_FIXTURE_SCOPES),
    endpointIds: [endpoint.endpointId],
    operationIds: operations.map((operation) => operation.operationId),
    capabilityPackIds: GRAFANA_CAPABILITY_PACKS.map((pack) => pack.packId),
    policy: {
      defaultLookback: { mode: "FIXED", durationSeconds: 3_600 },
      maxEvidenceAge: { mode: "FIXED", durationSeconds: 60 },
      rawEvidenceRetention: { mode: "NONE" },
      auditRequired: true,
      limits: LIMITS,
    },
  };
  const profile = { ...profileDraft, configSha256: computeTrustedProfileConfigHash(profileDraft) };
  const capabilityPacks: ProviderCapabilityPackV1[] = GRAFANA_CAPABILITY_PACKS.map(
    (pack) => structuredClone(pack) as ProviderCapabilityPackV1,
  );
  const draft = {
    schemaVersion: "1.0.0" as const,
    createdAt: REAL_GRAFANA_FIXTURE_NOW,
    profile,
    endpoints: [endpoint],
    operations,
    adapters: [grafanaAdapterPackage],
    capabilityPacks,
  };
  return {
    bundle: { ...draft, integrity: computeIntegrity(draft) },
    registrations: [builtinRegistration(grafanaAdapterPackage, adapter)],
    transport,
    expectedDatasourceTypes: new Map(compiled.map((item) => [item.spec.operationId, item.spec.datasourceType])),
    leakageTokens: [...new Set([
      ...compiledWithLeakage.flatMap((item) => item.leakageTokens),
      ...Object.values(SUBJECTS).map((subject) => subject.providerValue),
    ])],
  };
}
