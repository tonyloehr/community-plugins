import assert from "node:assert/strict";
import test, { type TestContext } from "node:test";

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";

import {
  GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS,
  GRAFANA_OBSERVABILITY_TOOL_NAMES,
  createGrafanaObservabilityMcpServer,
} from "../../packages/grafana-mcp-server/src/server.ts";
import type {
  GrafanaEvidenceDetailResult,
  GrafanaEvidenceRef,
  GrafanaLinkRef,
  GrafanaObservabilityRuntime,
  GrafanaReportRef,
  GrafanaRunPackInput,
} from "../../packages/grafana-mcp-server/src/types.ts";

const REPORT_REF = `gfrpt_${"a".repeat(64)}` as GrafanaReportRef;
const EVIDENCE_REF = `gfev_${"b".repeat(64)}` as GrafanaEvidenceRef;
const LINK_REF = `gflnk_${"c".repeat(64)}` as GrafanaLinkRef;
const WINDOW = { start: "2026-08-15T01:00:00.000Z", end: "2026-08-15T02:00:00.000Z" };
const RUN_PACK_DESCRIPTION = "Collect one activated provider-read-only Grafana pack and write only plugin-owned local run, audit, checkpoint, and sealed evidence artifact state.";
const EXPECTED_TOOL_ANNOTATIONS = {
  grafana_profile_status: {
    readOnlyHint: true,
    openWorldHint: true,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_list_packs: {
    readOnlyHint: true,
    openWorldHint: false,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_run_pack: {
    readOnlyHint: false,
    openWorldHint: true,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_get_evidence: {
    readOnlyHint: true,
    openWorldHint: false,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_resolve_link: {
    readOnlyHint: true,
    openWorldHint: false,
    destructiveHint: false,
    idempotentHint: true,
  },
} as const;

function resultPayload<T>(result: unknown): T {
  assert.ok(result !== null && typeof result === "object" && "structuredContent" in result);
  const structured = (result as { structuredContent?: Record<string, unknown> }).structuredContent;
  assert.ok(structured);
  return structured as T;
}

function fixtureRuntime(overrides: Partial<GrafanaObservabilityRuntime> = {}): GrafanaObservabilityRuntime {
  const evidence: GrafanaEvidenceDetailResult = {
    schemaVersion: "1.0.0",
    status: "COMPLETE",
    reportRef: REPORT_REF,
    evidenceRef: EVIDENCE_REF,
    title: "grafana.infrastructure.cpu.usage",
    domain: "METRICS",
    origin: "SIMULATED",
    authority: "AUTHORITATIVE",
    provider: "grafana",
    evaluatedAt: WINDOW.end,
    collectedAt: WINDOW.end,
    window: WINDOW,
    summary: "CPU usage is 42 percent.",
    values: [{ kind: "METRIC", label: "cpu_usage", value: 42, unit: "percent", points: [] }],
    limitationCount: 0,
    linkRefs: [LINK_REF],
  };
  return {
    profileStatus: async (profileAlias) => ({
      schemaVersion: "1.0.0",
      status: "COMPLETE",
      profileAlias,
      readiness: "READY",
      originModes: ["SIMULATED"],
      checks: [{ name: "trust-bundle", status: "PASS" }],
      limitations: [],
    }),
    listPacks: (profileAlias) => ({
      schemaVersion: "1.0.0",
      status: "COMPLETE",
      profileAlias,
      packs: [{
        packId: "grafana.infrastructure",
        revision: 1,
        useCase: "INFRASTRUCTURE",
        requiredOperationCount: 4,
        optionalOperationCount: 0,
      }],
      limitations: [],
    }),
    runPack: async (input) => ({
      schemaVersion: "1.0.0",
      status: "COMPLETE",
      reportRef: REPORT_REF,
      profileAlias: input.profileAlias,
      pack: {
        packId: input.packId,
        revision: 1,
        useCase: "INFRASTRUCTURE",
        requiredOperationCount: 1,
        optionalOperationCount: 0,
      },
      scopeAlias: input.scopeAlias,
      origin: input.origin,
      window: input.window,
      evidenceSummary: { COMPLETE: 1, EMPTY: 0, STALE: 0, CONTRADICTORY: 0, ERROR: 0 },
      collectionFailures: 0,
      evidence: [],
      signals: [],
      issues: [],
      limitations: [],
    }),
    getEvidence: () => evidence,
    resolveLink: () => ({
      schemaVersion: "1.0.0",
      status: "COMPLETE",
      reportRef: REPORT_REF,
      linkRef: LINK_REF,
      mode: "OPEN_EXTERNAL",
      label: "Open Grafana evidence",
      url: "https://grafana.example.test/d/reviewed",
    }),
    close: async () => undefined,
    ...overrides,
  };
}

async function connected(t: TestContext, runtime: GrafanaObservabilityRuntime = fixtureRuntime()) {
  const server = createGrafanaObservabilityMcpServer(runtime);
  const client = new Client({ name: "grafana-observability-test", version: "1.0.0" });
  const [clientTransport, serverTransport] = InMemoryTransport.createLinkedPair();
  await server.connect(serverTransport);
  await client.connect(clientTransport);
  t.after(async () => {
    await client.close();
    await server.close();
    await runtime.close();
  });
  return client;
}

test("standalone server exposes four read-only tools, one additive local-write tool, and no UI resources", async (t) => {
  const client = await connected(t);
  assert.deepEqual(client.getServerVersion(), { name: "grafana-observability", version: "0.1.0" });
  const listed = await client.listTools();
  assert.deepEqual(listed.tools.map((tool) => tool.name).sort(), [...GRAFANA_OBSERVABILITY_TOOL_NAMES].sort());
  assert.deepEqual(GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS, EXPECTED_TOOL_ANNOTATIONS);
  for (const tool of listed.tools) {
    assert.deepEqual(
      tool.annotations,
      EXPECTED_TOOL_ANNOTATIONS[
        tool.name as keyof typeof GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS
      ],
    );
    assert.equal(tool.annotations?.destructiveHint, false);
    assert.equal(tool._meta?.["ui/resourceUri"], undefined);
    const schema = JSON.stringify(tool.inputSchema);
    for (const forbidden of [
      "url",
      "query",
      "headers",
      "datasourceId",
      "datasourceUid",
      "sql",
      "promql",
      "logql",
      "traceql",
      "variables",
      "panelJson",
    ]) {
      assert.doesNotMatch(schema, new RegExp(`"${forbidden}"`, "iu"));
    }
  }
  assert.equal(
    listed.tools.find((tool) => tool.name === "grafana_run_pack")?.description,
    RUN_PACK_DESCRIPTION,
  );
  assert.match(
    listed.tools.find((tool) => tool.name === "grafana_profile_status")?.description ?? "",
    /without returning its origin URL/u,
  );
  await assert.rejects(client.listResources());
});

test("tool routing preserves only bounded aliases, opaque refs, and windows", async (t) => {
  let received: GrafanaRunPackInput | undefined;
  const client = await connected(t, fixtureRuntime({
    runPack: async (input) => {
      received = structuredClone(input);
      return fixtureRuntime().runPack(input);
    },
  }));
  const run = await client.callTool({
    name: "grafana_run_pack",
    arguments: {
      idempotencyKey: "infra-hourly-1",
      profileAlias: "local-grafana",
      packId: "grafana.infrastructure",
      scopeAlias: "fleet-west",
      origin: "LIVE",
      window: WINDOW,
      baselineWindow: { start: "2026-08-14T23:00:00.000Z", end: "2026-08-15T00:00:00.000Z" },
    },
  });
  assert.equal(resultPayload<{ status: string }>(run).status, "COMPLETE");
  assert.deepEqual(received, {
    idempotencyKey: "infra-hourly-1",
    profileAlias: "local-grafana",
    packId: "grafana.infrastructure",
    scopeAlias: "fleet-west",
    origin: "LIVE",
    window: WINDOW,
    baselineWindow: { start: "2026-08-14T23:00:00.000Z", end: "2026-08-15T00:00:00.000Z" },
  });

  assert.equal(resultPayload<{ status: string }>(await client.callTool({
    name: "grafana_profile_status",
    arguments: { profileAlias: "local-grafana" },
  })).status, "COMPLETE");
  assert.equal(resultPayload<{ status: string }>(await client.callTool({
    name: "grafana_list_packs",
    arguments: { profileAlias: "local-grafana" },
  })).status, "COMPLETE");
  assert.equal(resultPayload<{ evidenceRef: string }>(await client.callTool({
    name: "grafana_get_evidence",
    arguments: { reportRef: REPORT_REF, evidenceRef: EVIDENCE_REF },
  })).evidenceRef, EVIDENCE_REF);
  assert.equal(resultPayload<{ linkRef: string }>(await client.callTool({
    name: "grafana_resolve_link",
    arguments: { reportRef: REPORT_REF, linkRef: LINK_REF },
  })).linkRef, LINK_REF);
});

test("schema rejects arbitrary provider material and unsafe windows before runtime entry", async (t) => {
  let calls = 0;
  const client = await connected(t, fixtureRuntime({
    runPack: async (input, signal) => {
      calls += 1;
      return fixtureRuntime().runPack(input, signal);
    },
  }));
  const base = {
    idempotencyKey: "invalid-input",
    profileAlias: "local-grafana",
    packId: "grafana.infrastructure",
    scopeAlias: "fleet-west",
    origin: "LIVE",
    window: WINDOW,
  };
  for (const argumentsValue of [
    { ...base, query: "up" },
    { ...base, datasourceUid: "secret-uid" },
    { ...base, packId: "grafana.unreviewed" },
    { ...base, window: { start: WINDOW.end, end: WINDOW.start } },
    { ...base, window: { start: "2026-08-01T00:00:00.000Z", end: "2026-08-15T00:00:00.000Z" } },
    {
      ...base,
      baselineWindow: { start: "2026-08-15T01:30:00.000Z", end: "2026-08-15T01:45:00.000Z" },
    },
    {
      ...base,
      baselineWindow: { start: "2026-08-14T23:00:00.000Z", end: "2026-08-14T23:30:00.000Z" },
    },
  ]) {
    const rejected = await client.callTool({ name: "grafana_run_pack", arguments: argumentsValue });
    assert.equal(rejected.isError, true);
  }
  assert.equal(calls, 0);
});

test("runtime failures return the ERROR state without leaking provider or credential text", async (t) => {
  const canary = "grafana-token-canary-DO-NOT-LEAK";
  const client = await connected(t, fixtureRuntime({
    profileStatus: async () => {
      const error = new Error(`Bearer ${canary} failed at https://grafana.internal/api/ds/query`);
      Object.assign(error, { code: "AUTHENTICATION_FAILED" });
      throw error;
    },
  }));
  const result = await client.callTool({
    name: "grafana_profile_status",
    arguments: { profileAlias: "local-grafana" },
  });
  assert.equal(result.isError, true);
  const payload = resultPayload<{ status: string; error: { code: string; message: string } }>(result);
  assert.equal(payload.status, "ERROR");
  assert.equal(payload.error.code, "AUTHENTICATION_FAILED");
  const serialized = JSON.stringify(result);
  assert.doesNotMatch(serialized, new RegExp(canary, "u"));
  assert.doesNotMatch(serialized, /grafana\.internal|\/api\/ds\/query|Bearer/iu);
});
