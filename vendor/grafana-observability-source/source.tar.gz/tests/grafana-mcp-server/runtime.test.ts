import assert from "node:assert/strict";
import test from "node:test";

import {
  GRAFANA_CAPABILITY_PACKS,
  type OperationId,
  type MonitoringWorkspaceSnapshot,
  type WorkbenchEvidenceDetail,
  type WorkbenchEvidenceRef,
  type WorkbenchLinkRef,
} from "../../packages/contracts/src/index.ts";
import {
  GrafanaObservabilityError,
  MonitoringGrafanaObservabilityRuntime,
  deriveGrafanaReportStatus,
} from "../../packages/grafana-mcp-server/src/runtime.ts";
import {
  GRAFANA_OBSERVABILITY_PACK_IDS,
  type GrafanaEvidenceRef,
  type GrafanaLinkRef,
  type GrafanaReportRef,
  type GrafanaRunPackInput,
  type MonitoringRuntimePort,
} from "../../packages/grafana-mcp-server/src/types.ts";

const RAW_EVIDENCE = `pmwsev_${"e".repeat(64)}` as WorkbenchEvidenceRef;
const RAW_LINK = `pmwslnk_${"l".repeat(64)}` as WorkbenchLinkRef;
const WORKSPACE_ID = `pmws_${"w".repeat(64)}`;
const RUN_HANDLE = `pmh_${"h".repeat(43)}`;
const WINDOW = { start: "2026-08-15T01:00:00.000Z", end: "2026-08-15T02:00:00.000Z" };
const CANARY = "datasource-uid-and-token-canary";
const operationId = (value: string): OperationId => value as OperationId;

function snapshot(state: "COMPLETE" | "EMPTY" | "STALE" | "CONTRADICTORY" | "ERROR" = "COMPLETE") {
  return {
    schemaVersion: "1.1.0",
    workspaceId: WORKSPACE_ID,
    stateVersion: 100,
    asOf: WINDOW.end,
    lifecycle: "SEALED",
    phase: "FINALIZING",
    origin: "LIVE",
    scope: { environment: "production", service: "checkout", window: WINDOW },
    status: {
      service: "UNKNOWN",
      collection: state === "ERROR" ? "ERROR" : "COMPLETE",
      causality: "NOT_ASSESSED",
      recovery: "NOT_ASSESSED",
      audit: "HEALTHY",
    },
    progress: { completedOperations: state === "COMPLETE" ? 1 : 0, requiredOperations: 1, sourceStates: { [state]: 1 } },
    signals: [{
      signalRef: "cpu_usage",
      title: "CPU usage",
      displayValue: "42",
      unit: "percent",
      severity: "GOOD",
      direction: "FLAT",
      points: [42],
      evidenceRefs: [RAW_EVIDENCE],
    }],
    hypotheses: [],
    issues: [{
      issueRef: `pmwsiss_${"i".repeat(64)}`,
      kind: "ALERT",
      severity: "WARNING",
      status: "OPEN",
      classification: "SIGNED_RULE",
      title: "CPU threshold",
      summary: "A reviewed threshold was crossed.",
      evidenceRefs: [RAW_EVIDENCE],
      hypothesisRefs: [],
      patch: {
        schemaVersion: "1.0.0",
        state: "NOT_ELIGIBLE",
        eligible: false,
        updatedAt: WINDOW.end,
        evidenceRefs: [],
        limitations: [],
      },
    }],
    evidence: [{
      evidenceRef: RAW_EVIDENCE,
      title: "grafana.infrastructure.cpu.usage",
      domain: "METRICS",
      state,
      authority: "AUTHORITATIVE",
      sourceLabel: `grafana · ${CANARY}`,
      summary: `CPU is 42; raw link https://grafana.internal/${CANARY} omitted`,
      observedAt: WINDOW.end,
      linkRefs: [RAW_LINK],
    }],
    activity: [],
    patch: {
      schemaVersion: "1.0.0",
      state: "NOT_ELIGIBLE",
      eligible: false,
      updatedAt: WINDOW.end,
      evidenceRefs: [],
      limitations: [],
    },
    nextAction: { action: "NONE", enabled: false, label: "No action" },
    limitations: [],
  } as unknown as MonitoringWorkspaceSnapshot;
}

function detail(state: "COMPLETE" | "EMPTY" | "STALE" | "CONTRADICTORY" | "ERROR" = "COMPLETE") {
  return {
    schemaVersion: "1.0.0",
    workspaceId: WORKSPACE_ID,
    evidenceRef: RAW_EVIDENCE,
    title: "grafana.infrastructure.cpu.usage",
    domain: "METRICS",
    origin: "LIVE",
    authority: "AUTHORITATIVE",
    state,
    source: { provider: "grafana", sourceAlias: CANARY },
    evaluatedAt: WINDOW.end,
    collectedAt: WINDOW.end,
    window: WINDOW,
    summary: `CPU signal from https://grafana.internal/${CANARY}`,
    values: [
      { kind: "METRIC", label: "cpu_usage", value: 42, unit: "percent", points: [{ at: WINDOW.end, value: 42 }] },
      { kind: "EVENT", at: WINDOW.end, summary: `See https://grafana.internal/${CANARY}` },
      { kind: "FACT", label: "note", value: `See http://localhost:3000/${CANARY}` },
    ],
    limitations: [`Credential ${CANARY} was unavailable`],
    linkRefs: [RAW_LINK],
  } as unknown as WorkbenchEvidenceDetail;
}

class FakeMonitoringRuntime implements MonitoringRuntimePort {
  readonly profileAlias = "local-grafana";
  beginCalls = 0;
  collectCalls: string[] = [];
  cancelCalls: Array<{ revision: number; reason: "INTERRUPTED" | "PROVIDER_UNAVAILABLE" }> = [];
  openedRunIds: string[] = [];
  currentSnapshot = snapshot();
  currentDetail = detail();
  targetUrl = "https://grafana.example.test/d/reviewed";
  closed = 0;

  async doctor(profileAlias: string) {
    return {
      status: "READY" as const,
      profileAlias,
      surface: "local-stdio",
      originModes: ["LIVE"],
      checks: [{ name: "grafana-health", status: "PASS" as const, message: `secret ${CANARY}` }],
    };
  }

  listCapabilities(profileAlias: string): ReturnType<MonitoringRuntimePort["listCapabilities"]> {
    return {
      profileAlias,
      surface: "local-stdio",
      route: "operator-host",
      privateNetworkReachability: "HOST_DEPENDENT",
      capabilities: [{
        provider: "grafana",
        packageId: "adapter.grafana.v1",
        domains: ["METRICS"],
        operations: ["grafana.infrastructure.cpu.usage"],
        status: "AVAILABLE",
      }],
      capabilityPacks: [
        {
          packId: "grafana.infrastructure",
          revision: 1,
          useCase: "INFRASTRUCTURE",
          requiredOperationIds: ["grafana.infrastructure.cpu.usage"],
          optionalOperationIds: [],
          signals: [{
            signalId: "cpu_usage",
            operationId: operationId("grafana.infrastructure.cpu.usage"),
            resultName: "cpu_usage",
            order: 1,
            unit: "percent",
            polarity: "HIGH_IS_BAD" as const,
            thresholds: { comparator: "GTE" as const, warning: 80, critical: 95 },
          }],
          definitionSha256: "d".repeat(64),
        },
        {
          packId: "grafana.unreviewed",
          revision: 1,
          useCase: "UNREVIEWED",
          requiredOperationIds: [],
          optionalOperationIds: [],
          signals: [],
          definitionSha256: "f".repeat(64),
        },
      ],
      limitations: [],
    };
  }

  beginRun() {
    this.beginCalls += 1;
    return {
      runId: `pmrun_${"r".repeat(64)}`,
      runHandle: RUN_HANDLE,
      revision: 1,
      replayed: false,
      requestSha256: "a".repeat(64),
      trustBundleSha256: "b".repeat(64),
      operationSnapshotSha256: "c".repeat(64),
      origin: "LIVE",
    } as ReturnType<MonitoringRuntimePort["beginRun"]>;
  }

  async collect(
    _runHandle: Parameters<MonitoringRuntimePort["collect"]>[0],
    expectedRevision: number,
    _operationIds: readonly string[],
    window: "CURRENT" | "BASELINE",
  ) {
    this.collectCalls.push(window);
    return {
      runId: `pmrun_${"r".repeat(64)}`,
      revision: expectedRevision + 1,
      evidence: [],
      budget: {},
    } as unknown as Awaited<ReturnType<MonitoringRuntimePort["collect"]>>;
  }

  finalizeRun(_runHandle: Parameters<MonitoringRuntimePort["finalizeRun"]>[0], expectedRevision: number) {
    return {
      runId: `pmrun_${"r".repeat(64)}`,
      revision: expectedRevision + 1,
      state: "SEALED",
      status: "PARTIAL",
      bundleId: `pmbundle_${"b".repeat(64)}`,
      manifestSha256: "m".repeat(64),
      artifactRelativePath: "bundles/test",
      recoveryState: "NONE",
      evidenceSummary: { COMPLETE: 1, EMPTY: 0, STALE: 0, CONTRADICTORY: 0, ERROR: 0 },
      presentation: {},
    } as unknown as ReturnType<MonitoringRuntimePort["finalizeRun"]>;
  }

  cancelRun(
    _runHandle: Parameters<MonitoringRuntimePort["cancelRun"]>[0],
    expectedRevision: number,
    reason: Parameters<MonitoringRuntimePort["cancelRun"]>[2],
  ) {
    this.cancelCalls.push({ revision: expectedRevision, reason });
    return {
      runId: `pmrun_${"r".repeat(64)}`,
      revision: expectedRevision + 1,
      state: "ABORTED",
      retainedEvidenceIds: [],
    } as unknown as ReturnType<MonitoringRuntimePort["cancelRun"]>;
  }

  openWorkbenchForRun(runId: Parameters<MonitoringRuntimePort["openWorkbenchForRun"]>[0]) {
    this.openedRunIds.push(runId);
    return this.currentSnapshot;
  }

  workspaceEvidence() {
    return this.currentDetail;
  }

  resolveWorkspaceLink() {
    return {
      schemaVersion: "1.0.0",
      workspaceId: WORKSPACE_ID,
      linkRef: RAW_LINK,
      mode: "OPEN_EXTERNAL",
      label: "Open Grafana evidence",
      url: this.targetUrl,
    } as ReturnType<MonitoringRuntimePort["resolveWorkspaceLink"]>;
  }

  async close() {
    this.closed += 1;
  }
}

function input(overrides: Partial<GrafanaRunPackInput> = {}): GrafanaRunPackInput {
  return {
    idempotencyKey: "infra-hourly-1",
    profileAlias: "local-grafana",
    packId: "grafana.infrastructure",
    scopeAlias: "fleet-west",
    origin: "LIVE",
    window: WINDOW,
    ...overrides,
  };
}

test("standalone pack IDs exactly match the five code-owned Grafana capability packs", () => {
  assert.deepEqual(
    [...GRAFANA_OBSERVABILITY_PACK_IDS].sort(),
    GRAFANA_CAPABILITY_PACKS.map((pack) => pack.packId).sort(),
  );
});

test("six-state report derivation is deterministic", () => {
  const status = (states: Parameters<typeof deriveGrafanaReportStatus>[0]["states"], expectedEvidenceCount = states.length, collectionFailures = 0) =>
    deriveGrafanaReportStatus({ states, expectedEvidenceCount, collectionFailures });
  assert.equal(status(["COMPLETE"]), "COMPLETE");
  assert.equal(status(["EMPTY"]), "EMPTY");
  assert.equal(status(["STALE"]), "STALE");
  assert.equal(status(["CONTRADICTORY"]), "CONTRADICTORY");
  assert.equal(status(["ERROR"]), "ERROR");
  assert.equal(status(["COMPLETE", "EMPTY"]), "PARTIAL");
  assert.equal(status(["COMPLETE"], 2), "PARTIAL");
  assert.equal(status([], 1, 1), "ERROR");
  assert.equal(status([], 0, 0), "EMPTY");
});

test("monitoring wrapper runs one activated pack and exposes only remapped sanitized evidence", async () => {
  const source = new FakeMonitoringRuntime();
  const runtime = new MonitoringGrafanaObservabilityRuntime(source);
  const status = await runtime.profileStatus("local-grafana");
  assert.equal(status.status, "COMPLETE");
  assert.doesNotMatch(JSON.stringify(status), new RegExp(CANARY, "u"));

  const packs = runtime.listPacks("local-grafana");
  assert.deepEqual(packs.packs, [{
    packId: "grafana.infrastructure",
    revision: 1,
    useCase: "INFRASTRUCTURE",
    requiredOperationCount: 1,
    optionalOperationCount: 0,
  }]);
  assert.doesNotMatch(JSON.stringify(packs), /definitionSha256|requiredOperationIds|[d]{64}/u);

  const report = await runtime.runPack(input());
  assert.equal(report.status, "COMPLETE");
  assert.match(report.reportRef, /^gfrpt_[a-f0-9]{64}$/u);
  assert.match(report.evidence[0]!.evidenceRef, /^gfev_[a-f0-9]{64}$/u);
  assert.match(report.evidence[0]!.linkRefs[0]!, /^gflnk_[a-f0-9]{64}$/u);
  assert.deepEqual(source.collectCalls, ["CURRENT"]);
  assert.deepEqual(source.openedRunIds, [`pmrun_${"r".repeat(64)}`]);
  assert.deepEqual(source.cancelCalls, []);
  assert.doesNotMatch(JSON.stringify(report), new RegExp(CANARY, "u"));
  assert.doesNotMatch(JSON.stringify(report), /https?:\/\//iu);

  const evidence = runtime.getEvidence(report.reportRef, report.evidence[0]!.evidenceRef);
  assert.equal(evidence.provider, "grafana");
  assert.equal(evidence.limitationCount, 1);
  assert.match((evidence.values[1] as { summary: string }).summary, /\[link omitted\]/u);
  assert.match(String((evidence.values[2] as { value: string }).value), /\[link omitted\]/u);
  const serializedEvidence = JSON.stringify(evidence);
  assert.doesNotMatch(serializedEvidence, new RegExp(CANARY, "u"));
  assert.doesNotMatch(serializedEvidence, /https?:\/\//iu);

  const resolved = runtime.resolveLink(report.reportRef, report.evidence[0]!.linkRefs[0]!);
  assert.equal(resolved.url, "https://grafana.example.test/d/reviewed");
  await runtime.close();
  assert.equal(source.closed, 1);
});

test("standalone runtime filters and rejects Grafana-prefixed packs outside the exact product set", async () => {
  const source = new FakeMonitoringRuntime();
  const runtime = new MonitoringGrafanaObservabilityRuntime(source);
  assert.deepEqual(runtime.listPacks("local-grafana").packs.map((pack) => pack.packId), [
    "grafana.infrastructure",
  ]);
  await assert.rejects(
    runtime.runPack({ ...input(), packId: "grafana.unreviewed" } as unknown as GrafanaRunPackInput),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "INVALID_INPUT",
  );
  assert.equal(source.beginCalls, 0);
});

test("standalone runtime rejects a pack with a non-Grafana optional route before collection", async () => {
  const source = new FakeMonitoringRuntime();
  const originalListCapabilities = source.listCapabilities.bind(source);
  source.listCapabilities = (profileAlias: string) => {
    const listed = originalListCapabilities(profileAlias);
    return {
      ...listed,
      capabilities: [
        ...listed.capabilities,
        {
          provider: "prometheus",
          packageId: "adapter.prometheus.v1",
          domains: ["METRICS"],
          operations: ["prometheus.infrastructure.cpu.usage"],
          status: "AVAILABLE" as const,
        },
      ],
      capabilityPacks: listed.capabilityPacks.map((pack) => pack.packId === "grafana.infrastructure"
        ? {
            ...pack,
            optionalOperationIds: ["prometheus.infrastructure.cpu.usage"],
          }
        : pack),
    };
  };

  const runtime = new MonitoringGrafanaObservabilityRuntime(source);
  assert.deepEqual(runtime.listPacks("local-grafana").packs, []);
  await assert.rejects(
    runtime.runPack(input()),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "PACK_NOT_ACTIVE",
  );
  assert.equal(source.beginCalls, 0);
  assert.deepEqual(source.collectCalls, []);
  assert.deepEqual(source.cancelCalls, []);
});

test("standalone runtime requires each pack operation to have exactly one trusted route", async () => {
  const source = new FakeMonitoringRuntime();
  const originalListCapabilities = source.listCapabilities.bind(source);
  source.listCapabilities = (profileAlias: string) => {
    const listed = originalListCapabilities(profileAlias);
    return {
      ...listed,
      capabilities: [...listed.capabilities, structuredClone(listed.capabilities[0]!)],
    };
  };

  const runtime = new MonitoringGrafanaObservabilityRuntime(source);
  assert.deepEqual(runtime.listPacks("local-grafana").packs, []);
  await assert.rejects(
    runtime.runPack(input()),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "PACK_NOT_ACTIVE",
  );
  assert.equal(source.beginCalls, 0);
  assert.deepEqual(source.collectCalls, []);
  assert.deepEqual(source.openedRunIds, []);
});

test("a verified evidence-only PARTIAL workbench remains a usable pack report", async () => {
  const source = new FakeMonitoringRuntime();
  source.currentSnapshot = { ...source.currentSnapshot, lifecycle: "PARTIAL" };
  const report = await new MonitoringGrafanaObservabilityRuntime(source).runPack(input());
  assert.equal(report.status, "COMPLETE");
  assert.equal(report.evidence.length, 1);
});

test("standalone signal severity follows the hash-bound threshold and unit contract", async () => {
  const severityFor = async (value: number, unit = "percent") => {
    const source = new FakeMonitoringRuntime();
    source.currentDetail = {
      ...source.currentDetail,
      values: [{
        kind: "METRIC",
        label: "cpu_usage",
        value,
        unit,
        points: [{ at: WINDOW.end, value }],
      }],
    };
    const report = await new MonitoringGrafanaObservabilityRuntime(source).runPack(input());
    return report.signals[0]!.severity;
  };
  assert.equal(await severityFor(42), "GOOD");
  assert.equal(await severityFor(85), "WARNING");
  assert.equal(await severityFor(96), "CRITICAL");
  assert.equal(await severityFor(96, "ratio"), "WARNING", "unit drift cannot trigger a signed threshold");
});

test("baseline runs are collected through the same frozen operation set", async () => {
  const source = new FakeMonitoringRuntime();
  source.currentSnapshot = {
    ...source.currentSnapshot,
    evidence: [
      ...source.currentSnapshot.evidence,
      {
        ...source.currentSnapshot.evidence[0]!,
        evidenceRef: `pmwsev_${"q".repeat(64)}` as WorkbenchEvidenceRef,
        linkRefs: [],
      },
    ],
  };
  const originalDetail = source.currentDetail;
  source.workspaceEvidence = (_workspaceId?: unknown, evidenceRef?: unknown) => ({
    ...originalDetail,
    evidenceRef: evidenceRef as WorkbenchEvidenceRef,
    linkRefs: evidenceRef === RAW_EVIDENCE ? [RAW_LINK] : [],
  });
  const runtime = new MonitoringGrafanaObservabilityRuntime(source);
  const report = await runtime.runPack(input({
    baselineWindow: { start: "2026-08-14T23:00:00.000Z", end: "2026-08-15T00:00:00.000Z" },
  }));
  assert.deepEqual(source.collectCalls, ["CURRENT", "BASELINE"]);
  assert.equal(report.status, "COMPLETE");
  assert.equal(report.evidence.length, 2);
});

test("standalone reports preserve the full required-operation signal order beyond the UI card cap", async () => {
  const source = new FakeMonitoringRuntime();
  const operationIds = [
    "grafana.infrastructure.cpu.usage",
    "grafana.infrastructure.memory.load",
    "grafana.infrastructure.disk.free",
    "grafana.infrastructure.system.load",
  ];
  const rawRefs = ["e", "m", "d", "s"].map((letter) =>
    `pmwsev_${letter.repeat(64)}` as WorkbenchEvidenceRef);
  source.listCapabilities = (profileAlias: string) => ({
    profileAlias,
    surface: "local-stdio",
    route: "operator-host",
    privateNetworkReachability: "HOST_DEPENDENT",
    capabilities: [{
      provider: "grafana",
      packageId: "adapter.grafana.v1",
      domains: ["METRICS"],
      operations: operationIds,
      status: "AVAILABLE",
    }],
    capabilityPacks: [{
      packId: "grafana.infrastructure",
      revision: 1,
      useCase: "INFRASTRUCTURE",
      requiredOperationIds: operationIds,
      optionalOperationIds: [],
      signals: [
        { signalId: "cpu_usage", operationId: operationId(operationIds[0]!), resultName: "cpu_usage", order: 1, unit: "ratio", polarity: "HIGH_IS_BAD" as const },
        { signalId: "memory_load", operationId: operationId(operationIds[1]!), resultName: "memory_load", order: 2, unit: "ratio", polarity: "HIGH_IS_BAD" as const },
        { signalId: "disk_free", operationId: operationId(operationIds[2]!), resultName: "disk_free", order: 3, unit: "percent", polarity: "LOW_IS_BAD" as const },
        { signalId: "system_load", operationId: operationId(operationIds[3]!), resultName: "system_load", order: 4, unit: "ratio", polarity: "HIGH_IS_BAD" as const },
      ],
      definitionSha256: "d".repeat(64),
    }],
    limitations: [],
  });
  source.currentSnapshot = {
    ...source.currentSnapshot,
    signals: [],
    evidence: operationIds.map((title, index) => ({
      ...source.currentSnapshot.evidence[0]!,
      evidenceRef: rawRefs[index]!,
      title,
      linkRefs: [],
    })),
  };
  source.workspaceEvidence = (_workspaceId?: unknown, evidenceRef?: unknown) => {
    const index = rawRefs.indexOf(evidenceRef as WorkbenchEvidenceRef);
    return {
      ...source.currentDetail,
      evidenceRef: rawRefs[index]!,
      title: operationIds[index]!,
      values: [{
        kind: "METRIC",
        label: operationIds[index]!.split(".").slice(-2).join("_"),
        value: index + 1,
        unit: index === 2 ? "percent" : "ratio",
        points: [{ at: WINDOW.end, value: index + 1 }],
      }],
      linkRefs: [],
    } as WorkbenchEvidenceDetail;
  };

  const report = await new MonitoringGrafanaObservabilityRuntime(source).runPack(input());
  assert.equal(report.status, "COMPLETE");
  assert.equal(report.signals.length, 4);
  assert.deepEqual(report.signals.map((signal) => signal.title), [
    "cpu_usage",
    "memory_load",
    "disk_free",
    "system_load",
  ]);
});

test("idempotency is replay-safe and opaque references are report-owned", async () => {
  const source = new FakeMonitoringRuntime();
  const runtime = new MonitoringGrafanaObservabilityRuntime(source);
  const first = await runtime.runPack(input());
  const replay = await runtime.runPack(input());
  assert.deepEqual(replay, first);
  assert.equal(source.beginCalls, 1);

  await assert.rejects(
    runtime.runPack(input({ window: { start: "2026-08-15T03:00:00.000Z", end: "2026-08-15T04:00:00.000Z" } })),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "IDEMPOTENCY_CONFLICT",
  );
  await assert.rejects(
    Promise.resolve().then(() => runtime.getEvidence(
      first.reportRef,
      `gfev_${"x".repeat(64)}` as GrafanaEvidenceRef,
    )),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "EVIDENCE_NOT_FOUND",
  );
  await assert.rejects(
    Promise.resolve().then(() => runtime.resolveLink(
      `gfrpt_${"x".repeat(64)}` as GrafanaReportRef,
      first.evidence[0]!.linkRefs[0]!,
    )),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "REPORT_NOT_FOUND",
  );
});

test("non-Grafana evidence and unsafe resolved links fail closed", async () => {
  const wrongProvider = new FakeMonitoringRuntime();
  wrongProvider.currentDetail = {
    ...wrongProvider.currentDetail,
    source: { provider: "prometheus", sourceAlias: "direct" },
  };
  await assert.rejects(
    new MonitoringGrafanaObservabilityRuntime(wrongProvider).runPack(input()),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "NON_GRAFANA_EVIDENCE",
  );

  const unsafeLink = new FakeMonitoringRuntime();
  unsafeLink.targetUrl = "http://grafana.example.test/d/reviewed";
  const runtime = new MonitoringGrafanaObservabilityRuntime(unsafeLink);
  const report = await runtime.runPack(input());
  await assert.rejects(
    Promise.resolve().then(() => runtime.resolveLink(report.reportRef, report.evidence[0]!.linkRefs[0] as GrafanaLinkRef)),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "UNSAFE_LINK",
  );
});

test("failed and interrupted collections cancel the exact open run without masking the cause", async (t) => {
  await t.test("provider failure", async () => {
    const source = new FakeMonitoringRuntime();
    const cause = new Error("provider failed");
    source.collect = async () => { throw cause; };
    await assert.rejects(
      new MonitoringGrafanaObservabilityRuntime(source).runPack(input()),
      (error: unknown) => error === cause,
    );
    assert.deepEqual(source.cancelCalls, [{ revision: 1, reason: "PROVIDER_UNAVAILABLE" }]);
    assert.deepEqual(source.openedRunIds, []);
  });

  await t.test("abort", async () => {
    const source = new FakeMonitoringRuntime();
    const controller = new AbortController();
    controller.abort();
    source.collect = async () => { throw new DOMException("aborted", "AbortError"); };
    await assert.rejects(
      new MonitoringGrafanaObservabilityRuntime(source).runPack(input(), controller.signal),
      (error: unknown) => error instanceof DOMException && error.name === "AbortError",
    );
    assert.deepEqual(source.cancelCalls, [{ revision: 1, reason: "INTERRUPTED" }]);
    assert.deepEqual(source.openedRunIds, []);
  });
});
