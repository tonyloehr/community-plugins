import assert from "node:assert/strict";
import { existsSync, mkdtempSync, realpathSync, rmSync, rmdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import test from "node:test";

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

import { deleteOwnedArtifactRoot } from "../../packages/artifacts/src/index.ts";
import {
  GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS,
  GRAFANA_OBSERVABILITY_TOOL_NAMES,
} from "../../packages/grafana-mcp-server/src/index.ts";

const repositoryRoot = resolve(import.meta.dirname, "../..");
const pluginRoot = resolve(repositoryRoot, "plugins/grafana-observability");
const serverBundle = resolve(pluginRoot, "mcp/server.mjs");

test("compiled Grafana plugin serves the exact provider-read-only/local-write tool contract over real stdio", async () => {
  assert.equal(existsSync(serverBundle), true, "run npm run build before the release test");
  const parent = realpathSync.native(mkdtempSync(join(tmpdir(), "grafana-bundle-stdio-")));
  const artifactRoot = join(parent, "artifacts");
  const stateRoot = join(parent, "state");
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: ["./mcp/server.mjs", "--stdio"],
    cwd: pluginRoot,
    env: {
      PRODUCTION_MONITORING_MODE: "fixture",
      PRODUCTION_MONITORING_ARTIFACT_ROOT: artifactRoot,
      PRODUCTION_MONITORING_STATE_ROOT: stateRoot,
      PRODUCTION_MONITORING_PRINCIPAL_SESSION: "grafana-bundle-stdio-test",
    },
    stderr: "pipe",
  });
  let stderr = "";
  transport.stderr?.on("data", (chunk: Buffer) => {
    stderr += chunk.toString("utf8");
  });
  const client = new Client({ name: "compiled-grafana-bundle-test", version: "1.0.0" });
  try {
    await client.connect(transport);
    const tools = await client.listTools();
    assert.deepEqual(
      tools.tools.map((tool) => tool.name).sort(),
      [...GRAFANA_OBSERVABILITY_TOOL_NAMES].sort(),
    );
    for (const tool of tools.tools) {
      assert.deepEqual(
        tool.annotations,
        GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS[
          tool.name as keyof typeof GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS
        ],
      );
    }
    assert.equal(
      tools.tools.find((tool) => tool.name === "grafana_run_pack")?.description,
      "Collect one activated provider-read-only Grafana pack and write only plugin-owned local run, audit, checkpoint, and sealed evidence artifact state.",
    );

    const status = await client.callTool({
      name: "grafana_profile_status",
      arguments: { profileAlias: "fixture" },
    });
    assert.equal(status.isError, undefined);
    assert.match(JSON.stringify(status.structuredContent), /"status":"COMPLETE"/u);
  } finally {
    await client.close();
    if (existsSync(artifactRoot)) deleteOwnedArtifactRoot(artifactRoot);
    rmSync(stateRoot, { force: true, recursive: true });
    rmdirSync(parent);
  }
  assert.equal(stderr, "");
});
