import assert from "node:assert/strict";
import test from "node:test";

import {
  connectGrafanaStdio,
  createGrafanaStdioShutdown,
} from "../../packages/grafana-mcp-server/src/entrypoint.ts";

test("stdio shutdown is idempotent and always relinquishes runtime authority", async () => {
  let serverCloses = 0;
  let runtimeCloses = 0;
  const shutdown = createGrafanaStdioShutdown(
    { close: async () => { serverCloses += 1; } },
    { close: async () => { runtimeCloses += 1; } },
  );
  await Promise.all([shutdown(), shutdown(), shutdown()]);
  assert.equal(serverCloses, 1);
  assert.equal(runtimeCloses, 1);
});

test("stdio connect failure uses the same terminal cleanup path", async () => {
  let closes = 0;
  await assert.rejects(connectGrafanaStdio(
    async () => { throw new Error("connect failed"); },
    async () => { closes += 1; },
  ), /connect failed/u);
  assert.equal(closes, 1);
});

test("runtime cleanup still occurs if server close fails", async () => {
  let runtimeCloses = 0;
  const shutdown = createGrafanaStdioShutdown(
    { close: async () => { throw new Error("server close failed"); } },
    { close: async () => { runtimeCloses += 1; } },
  );
  await assert.rejects(shutdown(), /server close failed/u);
  assert.equal(runtimeCloses, 1);
});
