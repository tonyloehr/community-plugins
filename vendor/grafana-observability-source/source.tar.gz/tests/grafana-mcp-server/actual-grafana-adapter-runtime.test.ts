import assert from "node:assert/strict";
import { existsSync, mkdtempSync, realpathSync, rmSync, rmdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import { deleteOwnedArtifactRoot } from "../../packages/artifacts/src/index.ts";
import {
  canonicalGrafanaDatasourceType,
} from "../../adapters/grafana/src/index.ts";
import {
  GRAFANA_CAPABILITY_PACKS,
  type EvidenceEnvelope,
  type Scope,
} from "../../packages/contracts/src/index.ts";
import {
  MonitoringRuntime,
  type CollectOutput,
} from "../../packages/evidence-server/src/index.ts";
import { MonitoringGrafanaObservabilityRuntime } from "../../packages/grafana-mcp-server/src/runtime.ts";
import type {
  GrafanaEvidenceDetailResult,
  GrafanaRunPackResult,
  MonitoringRuntimePort,
} from "../../packages/grafana-mcp-server/src/types.ts";

import {
  REAL_GRAFANA_FIXTURE_NOW,
  REAL_GRAFANA_FIXTURE_PROFILE,
  REAL_GRAFANA_FIXTURE_SCOPES,
  REAL_GRAFANA_FIXTURE_WINDOW,
  createRealGrafanaAdapterRuntimeFixture,
} from "./real-grafana-adapter-fixture.ts";

test("all five packs use the actual Grafana adapter, frozen targets, and frame normalization", async (t) => {
  const fixture = createRealGrafanaAdapterRuntimeFixture();
  const parent = realpathSync.native(mkdtempSync(join(tmpdir(), "pm-real-grafana-adapter-")));
  const artifactRoot = join(parent, "artifacts");
  const stateRoot = join(parent, "state");
  const runtime = new MonitoringRuntime({
    bundle: fixture.bundle,
    registrations: fixture.registrations,
    artifactRoot,
    stateRoot,
    surface: "fixture",
    clock: { now: () => new Date(REAL_GRAFANA_FIXTURE_NOW) },
    principal: {
      issuerAlias: "real-grafana-adapter-test",
      subject: "developer",
      tenant: "fixture-tenant",
      session: "fixture-session",
    },
  });
  const collectedEvidence: EvidenceEnvelope[] = [];
  const port: MonitoringRuntimePort = {
    get profileAlias() { return runtime.profileAlias; },
    doctor: runtime.doctor.bind(runtime),
    listCapabilities: runtime.listCapabilities.bind(runtime),
    beginRun: runtime.beginRun.bind(runtime),
    collect: async (...args): Promise<CollectOutput> => {
      const output = await runtime.collect(...args);
      collectedEvidence.push(...output.evidence);
      return output;
    },
    finalizeRun: runtime.finalizeRun.bind(runtime),
    cancelRun: runtime.cancelRun.bind(runtime),
    openWorkbenchForRun: runtime.openWorkbenchForRun.bind(runtime),
    workspaceEvidence: runtime.workspaceEvidence.bind(runtime),
    resolveWorkspaceLink: runtime.resolveWorkspaceLink.bind(runtime),
    close: runtime.close.bind(runtime),
  };
  const standalone = new MonitoringGrafanaObservabilityRuntime(port);
  t.after(async () => {
    await standalone.close();
    if (existsSync(artifactRoot)) deleteOwnedArtifactRoot(artifactRoot);
    rmSync(stateRoot, { recursive: true, force: true });
    rmdirSync(parent);
  });

  const cases = [
    ["grafana.infrastructure", "infrastructure"],
    ["grafana.apm", "apm"],
    ["grafana.logs", "logs"],
    ["grafana.iot-edge", "iot"],
    ["grafana.business-kpis", "business"],
  ] as const;
  const reports = new Map<string, GrafanaRunPackResult>();
  const details = new Map<string, GrafanaEvidenceDetailResult>();
  for (const [packId, scopeAlias] of cases) {
    const pack = GRAFANA_CAPABILITY_PACKS.find((candidate) => candidate.packId === packId)!;
    const report = await standalone.runPack({
      idempotencyKey: `actual-adapter-${scopeAlias}`,
      profileAlias: REAL_GRAFANA_FIXTURE_PROFILE,
      packId,
      scopeAlias,
      origin: "SIMULATED",
      window: REAL_GRAFANA_FIXTURE_WINDOW,
    });
    reports.set(packId, report);
    assert.equal(report.status, "COMPLETE", packId);
    assert.equal(report.collectionFailures, 0, packId);
    assert.equal(report.evidence.length, pack.requiredOperationIds.length, packId);
    assert.ok(report.evidence.every((item) => item.status === "COMPLETE"), packId);
    assert.deepEqual(
      report.signals.map((signal) => signal.title),
      [...pack.signals].sort((left, right) => left.order - right.order).map((signal) => signal.signalId),
      packId,
    );
    for (const card of report.evidence) {
      const detail = standalone.getEvidence(report.reportRef, card.evidenceRef);
      details.set(detail.title, detail);
      assert.equal(detail.status, "COMPLETE", detail.title);
      assert.equal(detail.provider, "grafana", detail.title);
    }
  }

  assert.equal(fixture.transport.requests.length, fixture.expectedDatasourceTypes.size);
  assert.equal(collectedEvidence.length, fixture.expectedDatasourceTypes.size);
  for (const [operationId, datasourceType] of fixture.expectedDatasourceTypes) {
    const requests = fixture.transport.requests.filter((request) => request.operationId === operationId);
    assert.equal(requests.length, 1, operationId);
    assert.equal(requests[0]!.targetCount, 1, operationId);
    assert.equal(requests[0]!.method, datasourceType === "tempo" ? "GET" : "POST", operationId);
    assert.equal(requests[0]!.path, datasourceType === "tempo"
      ? `/api/datasources/proxy/uid/${requests[0]!.datasourceUid}/api/search`
      : "/api/ds/query", operationId);
    assert.equal(requests[0]!.datasourceType, datasourceType, operationId);
    const evidence = collectedEvidence.find((item) => item.operationId === operationId);
    assert.ok(evidence !== undefined, operationId);
    assert.equal(evidence.source.lineage?.accessPath, "GRAFANA", operationId);
    assert.equal(
      evidence.source.lineage?.datasourceType,
      canonicalGrafanaDatasourceType(datasourceType),
      operationId,
    );
  }

  for (const [scopeAlias, rawScope] of Object.entries(REAL_GRAFANA_FIXTURE_SCOPES)) {
    const scope: Scope = rawScope;
    if (scope.subject === undefined) continue;
    const scoped = collectedEvidence.filter((envelope) => envelope.scope.subject?.ref === scope.subject?.ref);
    assert.ok(scoped.length > 0, scopeAlias);
    assert.ok(scoped.every((envelope) => JSON.stringify(envelope.values).includes(scope.subject!.ref)), scopeAlias);
  }

  const errorCodes = details.get("grafana.apm.error.codes");
  assert.ok(errorCodes !== undefined);
  assert.equal(errorCodes.domain, "LOGS");
  assert.ok(errorCodes.values.some((value) => value.kind === "EVENT" && /HTTP 503/u.test(value.summary)));
  const slowTrace = details.get("grafana.apm.traces.slow");
  assert.ok(slowTrace !== undefined);
  assert.equal(slowTrace.domain, "TRACES");
  assert.ok(slowTrace.values.some((value) => value.kind === "EVENT" && /Slow checkout trace/u.test(value.summary)));

  const rawEvidenceJson = JSON.stringify(collectedEvidence);
  const standaloneJson = JSON.stringify({ reports: [...reports.values()], details: [...details.values()] });
  for (const token of fixture.leakageTokens) {
    assert.equal(rawEvidenceJson.includes(token), false, "provider-native fixture material leaked into evidence");
    assert.equal(standaloneJson.includes(token), false, "provider-native fixture material leaked into standalone output");
  }
  assert.doesNotMatch(
    standaloneJson,
    /datasourceUid|sourceIdentitySha256|providerValue|rawSql|executedQueryString|private_(?:metric|loki|trace|business)/u,
  );
});
