import assert from "node:assert/strict";
import { existsSync, mkdtempSync, realpathSync, rmSync, rmdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import { fixtureAdapter, fixtureAdapterPackage, createFixtureOperationSnapshot } from "../../adapters/fixture/src/index.ts";
import type { EvidenceAdapter } from "../../packages/adapter-sdk/src/index.ts";
import { ArtifactStore, deleteOwnedArtifactRoot } from "../../packages/artifacts/src/index.ts";
import { computeTrustedProfileConfigHash } from "../../packages/config/src/index.ts";
import {
  GRAFANA_CAPABILITY_PACKS,
  computeIntegrity,
  computeOperationDefinitionHash,
  sha256Canonical,
  type OperationId,
  type Sha256,
  type SubjectRef,
  type TrustBundle,
  type TrustedProfile,
} from "../../packages/contracts/src/index.ts";
import {
  MonitoringRuntime,
  createFixtureRuntimeDefinition,
} from "../../packages/evidence-server/src/index.ts";
import {
  MonitoringGrafanaObservabilityRuntime,
  GrafanaObservabilityError,
} from "../../packages/grafana-mcp-server/src/runtime.ts";
import type { MonitoringRuntimePort } from "../../packages/grafana-mcp-server/src/types.ts";
import {
  REAL_GRAFANA_FIXTURE_PROFILE,
  createRealGrafanaAdapterRuntimeFixture,
} from "./real-grafana-adapter-fixture.ts";

const NOW = "2026-08-15T02:00:00.000Z";
const WINDOW = { start: "2026-08-15T01:00:00.000Z", end: NOW };

function misassembledNonGrafanaPackDefinition(): {
  bundle: TrustBundle;
  registrations: ConstructorParameters<typeof MonitoringRuntime>[0]["registrations"];
  providerExecutions: { count: number };
} {
  const base = createFixtureRuntimeDefinition();
  const packs = GRAFANA_CAPABILITY_PACKS;
  const admittedOperationIds = [...new Set(packs.flatMap((pack) => pack.requiredOperationIds))];
  const signalByOperation = new Map(
    packs.flatMap((pack) => pack.signals).map((signal) => [signal.operationId, signal]),
  );
  const subjectProviderField = new Map<OperationId, string>();
  const packScopeMappingByOperation = new Map<OperationId, Record<string, string>>();
  for (const pack of packs) {
    const subjectMapping = pack.scopeMappings.find((mapping) => mapping.scopeField === "subject.ref");
    for (const operationId of pack.requiredOperationIds) {
      packScopeMappingByOperation.set(operationId, Object.fromEntries(
        pack.scopeMappings.map((mapping) => [mapping.scopeField, mapping.providerField]),
      ));
      if (subjectMapping !== undefined) {
        subjectProviderField.set(operationId, subjectMapping.providerField);
      }
    }
  }
  const operations = admittedOperationIds.map((id) => {
    const fixture = createFixtureOperationSnapshot("healthy", { operationId: id as OperationId });
    const signal = signalByOperation.get(id);
    const semantic = {
      schemaVersion: fixture.schemaVersion,
      operationId: fixture.operationId,
      revision: fixture.revision,
      capturedAt: fixture.capturedAt,
      definition: {
        ...fixture.definition,
        expectedSourceLineage: {
          accessPath: "GRAFANA" as const,
          datasourceType: "prometheus" as const,
          sourceIdentitySha256: "9".repeat(64) as Sha256,
        },
        scopeMapping: packScopeMappingByOperation.get(id)!,
        requiredProviderScopes: [
          "tenantSha256",
          ...Object.keys(packScopeMappingByOperation.get(id)!),
        ],
        normalization: {
          ...fixture.definition.normalization,
          targetUnit: signal?.unit ?? "ratio",
        },
      },
    };
    return { ...semantic, definitionSha256: computeOperationDefinitionHash(semantic) };
  });
  const profileDraft: TrustedProfile = {
    ...base.bundle.profile,
    profileAlias: "local-grafana",
    operationIds: operations.map((operation) => operation.operationId),
    capabilityPackIds: packs.map((pack) => pack.packId),
    catalogSha256: sha256Canonical(operations),
    configSha256: "0".repeat(64) as Sha256,
    scopes: {
      ...base.bundle.profile.scopes,
      checkout: {
        ...base.bundle.profile.scopes.checkout!,
        subject: {
          kind: "HOST",
          ref: "pmsub_checkoutfleetwest000000" as SubjectRef,
        },
      },
      apm: { environment: "simulation", service: "checkout" },
      logs: {
        environment: "simulation",
        service: "checkout",
        subject: { kind: "HOST", ref: "pmsub_checkoutloghost00000000" as SubjectRef },
      },
      iot: {
        environment: "simulation",
        subject: { kind: "DEVICE", ref: "pmsub_windturbine00000000000" as SubjectRef },
      },
      business: {
        environment: "simulation",
        subject: { kind: "BUSINESS_UNIT", ref: "pmsub_commerceunit000000000" as SubjectRef },
      },
    },
  };
  const profile = {
    ...profileDraft,
    configSha256: computeTrustedProfileConfigHash(profileDraft),
  };
  const bundleDraft = {
    schemaVersion: base.bundle.schemaVersion,
    createdAt: base.bundle.createdAt,
    profile,
    endpoints: base.bundle.endpoints,
    operations,
    adapters: base.bundle.adapters,
    capabilityPacks: packs,
  };
  const bundle = { ...bundleDraft, integrity: computeIntegrity(bundleDraft) } as TrustBundle;
  const providerExecutions = { count: 0 };
  const grafanaFixture = {
    descriptor: { ...fixtureAdapter.descriptor, provider: "grafana" },
    doctor: fixtureAdapter.doctor.bind(fixtureAdapter),
    compile: fixtureAdapter.compile.bind(fixtureAdapter),
    async execute(
      context: Parameters<EvidenceAdapter["execute"]>[0],
      operation: Parameters<EvidenceAdapter["execute"]>[1],
    ) {
      providerExecutions.count += 1;
      const result = await fixtureAdapter.execute(context, operation as never);
      const signal = signalByOperation.get(operation.operationId);
      const resultName = signal?.resultName;
      const providerField = subjectProviderField.get(operation.operationId);
      return {
        ...result,
        providerScope: {
          ...result.providerScope,
          ...(context.scope.subject === undefined ? {} : { subject: context.scope.subject }),
          mappings: {
            ...result.providerScope?.mappings,
            ...(providerField === undefined ? {} : { "subject.ref": providerField }),
          },
        },
        records: result.records.map((record) =>
          resultName !== undefined && (record.kind === "SCALAR" || record.kind === "TIMESERIES")
            ? { ...record, name: resultName, unit: signal?.unit ?? "ratio" }
            : record),
        sourceLineage: {
          accessPath: "GRAFANA" as const,
          datasourceType: "prometheus" as const,
          sourceIdentitySha256: "9".repeat(64) as Sha256,
        },
      };
    },
  } as EvidenceAdapter;
  return {
    bundle,
    registrations: [{ adapterPackage: fixtureAdapterPackage, adapter: grafanaFixture }],
    providerExecutions,
  };
}

test("all five packs run through a real MonitoringRuntime and stamp the Grafana 0.1 producer", async (t) => {
  const fixture = createRealGrafanaAdapterRuntimeFixture();
  const parent = realpathSync.native(mkdtempSync(join(tmpdir(), "grafana-real-runtime-")));
  const artifactRoot = join(parent, "artifacts");
  const stateRoot = join(parent, "state");
  const runtime = new MonitoringRuntime({
    bundle: fixture.bundle,
    registrations: fixture.registrations,
    artifactRoot,
    stateRoot,
    surface: "fixture",
    clock: { now: () => new Date(NOW) },
    principal: {
      issuerAlias: "grafana-real-runtime-test",
      subject: "developer",
      tenant: "fixture-tenant",
      session: "fixture-session",
    },
    artifactProducer: {
      pluginVersion: "0.1.0",
      contractsVersion: "0.3.0",
      reportProjectionVersion: "1.1.0",
    },
  });
  let finalized: ReturnType<MonitoringRuntime["finalizeRun"]> | undefined;
  const port: MonitoringRuntimePort = {
    get profileAlias() { return runtime.profileAlias; },
    doctor: runtime.doctor.bind(runtime),
    listCapabilities: runtime.listCapabilities.bind(runtime),
    beginRun: runtime.beginRun.bind(runtime),
    collect: runtime.collect.bind(runtime),
    finalizeRun: (...args) => {
      finalized = runtime.finalizeRun(...args);
      return finalized;
    },
    cancelRun: runtime.cancelRun.bind(runtime),
    openWorkbenchForRun: runtime.openWorkbenchForRun.bind(runtime),
    workspaceEvidence: runtime.workspaceEvidence.bind(runtime),
    resolveWorkspaceLink: runtime.resolveWorkspaceLink.bind(runtime),
    close: runtime.close.bind(runtime),
  };
  const standalone = new MonitoringGrafanaObservabilityRuntime(port);
  t.after(async () => {
    await standalone.close();
    if (existsSync(artifactRoot)) deleteOwnedArtifactRoot(artifactRoot);
    rmSync(stateRoot, { recursive: true, force: true });
    rmdirSync(parent);
  });

  const cases = [
    ["grafana.infrastructure", "infrastructure"],
    ["grafana.apm", "apm"],
    ["grafana.logs", "logs"],
    ["grafana.iot-edge", "iot"],
    ["grafana.business-kpis", "business"],
  ] as const;
  for (const [packId, scopeAlias] of cases) {
    const pack = GRAFANA_CAPABILITY_PACKS.find((candidate) => candidate.packId === packId)!;
    const report = await standalone.runPack({
      idempotencyKey: `real-${scopeAlias}-pack`,
      profileAlias: REAL_GRAFANA_FIXTURE_PROFILE,
      packId,
      scopeAlias,
      origin: "SIMULATED",
      window: WINDOW,
    });

    assert.equal(finalized?.status, "PARTIAL", "evidence-only artifacts remain explicitly partial");
    assert.equal(
      report.status,
      "COMPLETE",
      `${packId} derives status from evidence, not fabricated analysis: ${JSON.stringify(
        report.evidence.map((item) => [item.title, item.status, item.summary]),
      )}`,
    );
    assert.equal(report.evidence.length, pack.requiredOperationIds.length, packId);
    assert.deepEqual(
      report.signals.map((signal) => signal.title),
      [...pack.signals].sort((left, right) => left.order - right.order).map((signal) => signal.signalId),
      packId,
    );
  }
  assert.ok(finalized);
  const validated = new ArtifactStore({ root: artifactRoot }).validateBundle(finalized.bundleId);
  const lastPack = GRAFANA_CAPABILITY_PACKS.find((pack) => pack.packId === "grafana.business-kpis")!;
  assert.deepEqual(validated.request.requiredOperations, lastPack.requiredOperationIds);
  assert.deepEqual(validated.manifest.producer, {
    pluginVersion: "0.1.0",
    contractsVersion: "0.3.0",
    reportProjectionVersion: "1.1.0",
  });
});

test("a hash-bound Grafana pack routed to a non-Grafana adapter is rejected before provider execution", async (t) => {
  const fixture = misassembledNonGrafanaPackDefinition();
  const parent = realpathSync.native(mkdtempSync(join(tmpdir(), "grafana-route-gate-")));
  const artifactRoot = join(parent, "artifacts");
  const stateRoot = join(parent, "state");
  const runtime = new MonitoringRuntime({
    bundle: fixture.bundle,
    registrations: fixture.registrations,
    artifactRoot,
    stateRoot,
    surface: "fixture",
    clock: { now: () => new Date(NOW) },
    principal: {
      issuerAlias: "grafana-route-gate-test",
      subject: "developer",
      tenant: "fixture-tenant",
      session: "fixture-session",
    },
  });
  let beginCalls = 0;
  let collectCalls = 0;
  let openCalls = 0;
  const port: MonitoringRuntimePort = {
    get profileAlias() { return runtime.profileAlias; },
    doctor: runtime.doctor.bind(runtime),
    listCapabilities: runtime.listCapabilities.bind(runtime),
    beginRun: (...args) => {
      beginCalls += 1;
      return runtime.beginRun(...args);
    },
    collect: async (...args) => {
      collectCalls += 1;
      return runtime.collect(...args);
    },
    finalizeRun: runtime.finalizeRun.bind(runtime),
    cancelRun: runtime.cancelRun.bind(runtime),
    openWorkbenchForRun: (...args) => {
      openCalls += 1;
      return runtime.openWorkbenchForRun(...args);
    },
    workspaceEvidence: runtime.workspaceEvidence.bind(runtime),
    resolveWorkspaceLink: runtime.resolveWorkspaceLink.bind(runtime),
    close: runtime.close.bind(runtime),
  };
  const standalone = new MonitoringGrafanaObservabilityRuntime(port);
  t.after(async () => {
    await standalone.close();
    if (existsSync(artifactRoot)) deleteOwnedArtifactRoot(artifactRoot);
    rmSync(stateRoot, { recursive: true, force: true });
    rmdirSync(parent);
  });

  await assert.rejects(
    standalone.runPack({
      idempotencyKey: "reject-non-grafana-route",
      profileAlias: "local-grafana",
      packId: "grafana.infrastructure",
      scopeAlias: "checkout",
      origin: "SIMULATED",
      window: WINDOW,
    }),
    (error: unknown) => error instanceof GrafanaObservabilityError && error.code === "PACK_NOT_ACTIVE",
  );
  assert.equal(beginCalls, 0);
  assert.equal(collectCalls, 0);
  assert.equal(openCalls, 0);
  assert.equal(fixture.providerExecutions.count, 0);
});
