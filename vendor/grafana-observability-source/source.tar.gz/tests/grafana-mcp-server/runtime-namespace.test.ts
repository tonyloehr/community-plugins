import assert from "node:assert/strict";
import test from "node:test";

import { defaultRuntimeArtifactRoot } from "../../packages/evidence-server/src/index.ts";
import { GRAFANA_OBSERVABILITY_RUNTIME_NAMESPACE } from "../../packages/grafana-mcp-server/src/index.ts";
import { PRODUCTION_MONITORING_RUNTIME_NAMESPACE } from "../../packages/mcp-server/src/entrypoint.ts";

test("plugins share the credential broker but use separate default runtime state", () => {
  const productionRoot = defaultRuntimeArtifactRoot(PRODUCTION_MONITORING_RUNTIME_NAMESPACE);
  const grafanaRoot = defaultRuntimeArtifactRoot(GRAFANA_OBSERVABILITY_RUNTIME_NAMESPACE);

  assert.notEqual(productionRoot, grafanaRoot);
  assert.match(productionRoot, /codex-production-monitoring-(?:\d+|local)$/u);
  assert.match(grafanaRoot, /codex-grafana-observability-(?:\d+|local)$/u);
});
