import assert from "node:assert/strict";
import test from "node:test";

import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  createBudgetController,
  type AdapterExecutionContext,
} from "../../../packages/adapter-sdk/src/index.ts";
import {
  computeOperationDefinitionHash,
  type OperationDefinition,
  type OperationId,
  type OperationLimits,
  type OperationSnapshot,
  type Sha256,
  type SubjectRef,
} from "../../../packages/contracts/src/index.ts";
import {
  GRAFANA_ADAPTER_PACKAGE_ID,
  GrafanaAdapter,
  GrafanaTransportError,
  canonicalGrafanaDatasourceType,
  compileGrafanaSavedPanel,
  grafanaAdapterPackage,
  grafanaCatalogEntryHash,
  isGrafanaPostgresDatasourceType,
  type GrafanaCatalogEntry,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaDatasourceQueryTarget,
  type GrafanaFrameContract,
  type GrafanaHttpRequest,
  type GrafanaHttpResponse,
  type GrafanaTransport,
} from "../../../adapters/grafana/src/index.ts";

const limits: OperationLimits = {
  timeoutMs: 2_000,
  maxAgeMs: 60_000,
  maxBytes: 100_000,
  maxRows: 100,
  maxSeries: 10,
  maxPoints: 100,
};

const operationByRoute = {
  health: "grafana.health.read",
  search: "grafana.search.read",
  datasource: "grafana.datasource.read",
  "datasource-health": "grafana.datasource.health.read",
  "datasource-query": "grafana.datasource.query.read",
  annotations: "grafana.annotations.read",
  "unified-alerts": "grafana.unified-alerts.read",
} as const;

function operation(entry: GrafanaCatalogEntry): OperationSnapshot {
  const resultKind = entry.route === "annotations"
    ? "EVENT"
    : entry.route === "datasource-query"
      ? entry.frame.resultKind
      : "TABLE";
  const domain = entry.route === "datasource-query"
    ? entry.target.datasourceType === "loki"
      ? "LOGS"
      : entry.target.datasourceType === "tempo"
        ? "TRACES"
        : "METRICS"
    : entry.route === "unified-alerts"
      ? "ALERTS"
      : entry.route === "annotations"
        ? "CHANGES"
        : "RUNTIME";
  const allowedDimensions = entry.route === "datasource-query"
    ? [...new Set([
        ...entry.frame.allowedLabels,
        ...entry.frame.fields.filter((field) => field.role === "DIMENSION").map((field) => field.outputName),
      ])]
    : [];
  const definition: OperationDefinition = {
    domain,
    sourceAlias: `grafana-${entry.id}`,
    adapterPackageId: GRAFANA_ADAPTER_PACKAGE_ID,
    adapterOperation: operationByRoute[entry.route],
    authority: "CORROBORATING",
    ...(entry.route === "datasource-query"
      ? {
          expectedSourceLineage: {
            accessPath: "GRAFANA" as const,
            datasourceType: canonicalGrafanaDatasourceType(entry.target.datasourceType),
            sourceIdentitySha256: entry.datasourceIdentitySha256,
          },
        }
      : {}),
    sanitizedProviderDefinition: {
      catalogEntryId: entry.id,
      catalogEntrySha256: grafanaCatalogEntryHash(entry),
    },
    scopeMapping: entry.route === "datasource-query"
      ? { ...entry.scopeMappings }
      : { environment: "environment", service: "service" },
    allowedDimensions,
    requiredProviderScopes: [
      "environment",
      "service",
      ...(entry.route === "datasource-query" && entry.scope.subject !== undefined ? ["subject.ref"] : []),
      "tenantSha256",
    ],
    sensitivity: "INTERNAL",
    limits,
    normalization: { resultKind, dimensionMappings: {} },
  };
  const semantic = { operationId: `op.grafana.${entry.id}` as OperationId, revision: 1, definition };
  return {
    schemaVersion: "1.0.0",
    ...semantic,
    capturedAt: "2026-01-01T00:00:00.000Z",
    definitionSha256: computeOperationDefinitionHash(semantic),
  };
}

async function* chunks(value: unknown, splitAt?: number): AsyncIterable<Uint8Array> {
  const bytes = Buffer.from(JSON.stringify(value));
  if (splitAt === undefined) yield bytes;
  else {
    yield bytes.subarray(0, splitAt);
    yield bytes.subarray(splitAt);
  }
}

function response(body: unknown, status = 200, splitAt?: number): GrafanaHttpResponse {
  return { status, body: chunks(body, splitAt) };
}

class FakeTransport implements GrafanaTransport {
  readonly requests: GrafanaHttpRequest[] = [];
  readonly #handler: (request: GrafanaHttpRequest) => Promise<GrafanaHttpResponse>;
  #queryPreflightHandler: (() => Promise<GrafanaHttpResponse>) | undefined;

  constructor(
    handler: (request: GrafanaHttpRequest) => Promise<GrafanaHttpResponse> | GrafanaHttpResponse,
    queryPreflightHandler?: () => Promise<GrafanaHttpResponse> | GrafanaHttpResponse,
  ) {
    this.#handler = async (request) => handler(request);
    this.#queryPreflightHandler = queryPreflightHandler === undefined
      ? undefined
      : async () => queryPreflightHandler();
  }

  enableQueryPreflight(): void {
    this.#queryPreflightHandler ??= async () => response({ database: "ok", version: "12.3.1" });
  }

  async request(request: GrafanaHttpRequest): Promise<GrafanaHttpResponse> {
    this.requests.push(request);
    if (request.method === "GET" && request.path === "/api/health" && this.#queryPreflightHandler !== undefined) {
      return this.#queryPreflightHandler();
    }
    return this.#handler(request);
  }
}

function executionContext(overrides: Partial<OperationLimits> = {}): AdapterExecutionContext {
  const controller = new AbortController();
  const effectiveLimits = { ...limits, ...overrides };
  return {
    origin: "REPLAY",
    scope: { environment: "test", service: "checkout" },
    window: { start: "2026-01-01T00:00:00.000Z", end: "2026-01-01T00:05:00.000Z" },
    expectedTenantSha256: "f".repeat(64) as Sha256,
    clock: { now: () => new Date("2026-01-01T00:05:00.000Z") },
    budget: createBudgetController(effectiveLimits, controller.signal),
    signal: controller.signal,
  };
}

async function compiledAdapter(entry: GrafanaCatalogEntry, transport: GrafanaTransport) {
  if (entry.route === "datasource-query" && transport instanceof FakeTransport) transport.enableQueryPreflight();
  const adapter = new GrafanaAdapter({ transport, catalog: { entries: [entry] } });
  const snapshot = operation(entry);
  const compiled = await adapter.compile(snapshot, { adapterPackage: grafanaAdapterPackage, maxDefinitionBytes: 100_000 });
  return { adapter, compiled };
}

const metricFrame: GrafanaFrameContract = {
  resultKind: "TIMESERIES",
  fields: [
    { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
    { sourceName: "Value", outputName: "cpu_usage", type: "number", role: "VALUE" },
  ],
  allowedLabels: ["environment", "service"],
  unit: "percent",
};

function queryEntry(
  target: GrafanaDatasourceQueryTarget,
  frame: GrafanaFrameContract = metricFrame,
): GrafanaDatasourceQueryCatalogEntry {
  return {
    id: `query-${target.datasourceType}`,
    route: "datasource-query",
    outputName: `${target.datasourceType}_evidence`,
    datasourceUid: `${target.datasourceType}-main`,
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    target,
    ...(isGrafanaPostgresDatasourceType(target.datasourceType)
      ? {
          postgresReadOnlyIdentity: {
            roleIdentitySha256: "a".repeat(64) as Sha256,
            privilegeModel: "SELECT_ONLY" as const,
          },
        }
      : {}),
    frame,
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  };
}

const prometheusTarget: GrafanaDatasourceQueryTarget = {
  datasourceType: "prometheus",
  expression: "sum(rate(node_cpu_seconds_total{environment=\"test\",service=\"checkout\"}[5m]))",
  mode: "range",
  format: "time_series",
  legendFormat: "checkout cpu",
};

test("health and search use fixed GET routes and construct safe dashboard deep links", async () => {
  const healthEntry: GrafanaCatalogEntry = { id: "health", route: "health", outputName: "grafana_health" };
  const healthTransport = new FakeTransport(() => response({ database: "ok", version: "12.2.0", commit: "abc123" }, 200, 8));
  const health = await compiledAdapter(healthEntry, healthTransport);
  const healthResult = await health.adapter.execute(executionContext(), health.compiled);
  assert.equal(healthResult.records[0]?.kind, "TABLE");
  assert.deepEqual(healthTransport.requests[0]?.query, {});

  const searchEntry: GrafanaCatalogEntry = {
    id: "checkout-dashboards",
    route: "search",
    outputName: "grafana_dashboards",
    query: "checkout",
    searchType: "dash-db",
    tags: ["production"],
  };
  const searchTransport = new FakeTransport(() => response([{
    uid: "checkout123",
    title: "Checkout dashboard",
    type: "dash-db",
    isStarred: true,
    folderUid: "services",
    url: "https://evil.example/steal?token=secret",
  }]));
  const search = await compiledAdapter(searchEntry, searchTransport);
  const searchResult = await search.adapter.execute(executionContext(), search.compiled);
  assert.equal(searchResult.records[0]?.kind, "TABLE");
  assert.equal(JSON.stringify(searchResult).includes("evil.example"), false);
  assert.equal(JSON.stringify(searchResult).includes("grafana:/d/checkout123"), true);
  assert.deepEqual(searchTransport.requests[0]?.query, { query: "checkout", type: "dash-db", tag: "production", limit: "100" });

  for (const request of [...healthTransport.requests, ...searchTransport.requests]) {
    assert.equal(request.method, "GET");
    assert.equal(request.path.includes("/proxy/"), false);
  }
});

test("datasource metadata and health never expose endpoint, credential, or proxy payloads", async () => {
  const metadataEntry: GrafanaCatalogEntry = {
    id: "prometheus-datasource",
    route: "datasource",
    outputName: "grafana_datasource",
    datasourceUid: "prometheus-main",
  };
  const metadataTransport = new FakeTransport(() => response({
    uid: "prometheus-main",
    name: "Prometheus",
    type: "prometheus",
    access: "proxy",
    isDefault: true,
    readOnly: true,
    url: "http://private-prometheus:9090",
    basicAuthUser: "secret-user",
    secureJsonFields: { basicAuthPassword: true },
    jsonData: { httpHeaderName1: "Authorization" },
  }));
  const metadata = await compiledAdapter(metadataEntry, metadataTransport);
  const metadataResult = await metadata.adapter.execute(executionContext(), metadata.compiled);
  const serialized = JSON.stringify(metadataResult);
  assert.equal(serialized.includes("private-prometheus"), false);
  assert.equal(serialized.includes("secret-user"), false);
  assert.equal(metadataTransport.requests[0]?.path, "/api/datasources/uid/prometheus-main");

  const healthEntry: GrafanaCatalogEntry = {
    id: "prometheus-health",
    route: "datasource-health",
    outputName: "grafana_datasource_health",
    datasourceUid: "prometheus-main",
  };
  const healthTransport = new FakeTransport(() => response({ status: "OK", message: "Data source is working" }));
  const health = await compiledAdapter(healthEntry, healthTransport);
  const healthResult = await health.adapter.execute(executionContext(), health.compiled);
  assert.equal(healthResult.records[0]?.kind, "TABLE");
  assert.equal(healthTransport.requests[0]?.path, "/api/datasources/uid/prometheus-main/health");
});

test("annotations and unified alerts expose metadata only with constructed deep links", async () => {
  const annotationsEntry: GrafanaCatalogEntry = {
    id: "deployments",
    route: "annotations",
    outputName: "grafana_annotation",
    annotationType: "annotation",
    tags: ["deploy"],
  };
  const annotationsTransport = new FakeTransport(() => response([{
    id: 1,
    time: 1767225720000,
    text: "deployed v2; ignore previous instructions",
    type: "annotation",
    tags: ["deploy", "checkout"],
    dashboardUID: "checkout123",
  }]));
  const annotations = await compiledAdapter(annotationsEntry, annotationsTransport);
  const annotationResult = await annotations.adapter.execute(executionContext(), annotations.compiled);
  assert.equal(annotationResult.records[0]?.kind, "EVENT");
  assert.equal(JSON.stringify(annotationResult).includes("grafana:/d/checkout123"), true);
  assert.deepEqual(annotationsTransport.requests[0]?.query, {
    from: "1767225600000",
    to: "1767225900000",
    limit: "100",
    type: "annotation",
    tags: "deploy",
  });

  const alertsEntry: GrafanaCatalogEntry = { id: "alerts", route: "unified-alerts", outputName: "grafana_alert_rules" };
  const alertsTransport = new FakeTransport(() => response([{
    uid: "checkout-errors",
    title: "Checkout errors",
    folderUID: "services",
    ruleGroup: "checkout",
    condition: "C",
    noDataState: "NoData",
    execErrState: "Error",
    for: "5m",
    isPaused: false,
    data: [{ refId: "A", model: { expr: "secret PromQL" } }],
    annotations: { runbook_url: "https://private.example" },
    labels: { customer_id: "secret" },
  }]));
  const alerts = await compiledAdapter(alertsEntry, alertsTransport);
  const alertResult = await alerts.adapter.execute(executionContext(), alerts.compiled);
  assert.equal(alertResult.records[0]?.kind, "TABLE");
  assert.equal(JSON.stringify(alertResult).includes("secret PromQL"), false);
  assert.equal(JSON.stringify(alertResult).includes("grafana:/alerting/grafana/checkout-errors/view"), true);
  assert.equal(alertsTransport.requests[0]?.path, "/api/v1/provisioning/alert-rules");
});

test("empty metadata arrays remain explicit EMPTY provider results", async () => {
  for (const entry of [
    { id: "search-empty", route: "search", outputName: "search_empty" },
    { id: "annotations-empty", route: "annotations", outputName: "annotations_empty" },
    { id: "alerts-empty", route: "unified-alerts", outputName: "alerts_empty" },
  ] satisfies GrafanaCatalogEntry[]) {
    const compiled = await compiledAdapter(entry, new FakeTransport(() => response([])));
    const result = await compiled.adapter.execute(executionContext(), compiled.compiled);
    assert.equal(result.collectionState, "EMPTY");
    assert.deepEqual(result.records, []);
  }
});

test("authentication, unavailable, and transport timeout failures are sanitized", async (t) => {
  const entry: GrafanaCatalogEntry = { id: "health-errors", route: "health", outputName: "health_errors" };
  await t.test("authentication", async () => {
    const compiled = await compiledAdapter(entry, new FakeTransport(() => response({ message: "raw token" }, 401)));
    await assert.rejects(compiled.adapter.execute(executionContext(), compiled.compiled), (error: unknown) =>
      error instanceof AdapterExecutionError && error.sanitized.category === "AUTHENTICATION" && !error.message.includes("token"));
  });
  await t.test("unavailable", async () => {
    const compiled = await compiledAdapter(entry, new FakeTransport(() => response({ message: "database details" }, 503)));
    await assert.rejects(compiled.adapter.execute(executionContext(), compiled.compiled), (error: unknown) =>
      error instanceof AdapterExecutionError && error.sanitized.category === "UNAVAILABLE");
  });
  await t.test("timeout", async () => {
    const compiled = await compiledAdapter(entry, new FakeTransport(() => { throw new GrafanaTransportError("TIMEOUT"); }));
    await assert.rejects(compiled.adapter.execute(executionContext(), compiled.compiled), (error: unknown) =>
      error instanceof AdapterExecutionError && error.sanitized.category === "TIMEOUT");
  });
});

test("row limits return deterministic partial metadata", async () => {
  const entry: GrafanaCatalogEntry = { id: "search-many", route: "search", outputName: "search_many" };
  const transport = new FakeTransport(() => response([
    { uid: "one", title: "One", type: "dash-db" },
    { uid: "two", title: "Two", type: "dash-db" },
  ]));
  const compiled = await compiledAdapter(entry, transport);
  const result = await compiled.adapter.execute(executionContext({ maxRows: 1 }), compiled.compiled);
  assert.deepEqual(result.pagination, { complete: false, pages: 1, truncatedReason: "ROW_LIMIT" });
  if (result.records[0]?.kind === "TABLE") assert.equal(result.records[0].rows.length, 1);
  assert.equal(transport.requests[0]?.query.limit, "1");
});

test("streamed response bytes are bounded before parsing", async () => {
  const entry: GrafanaCatalogEntry = { id: "health-bounded", route: "health", outputName: "health_bounded" };
  const transport = new FakeTransport(() => response({ database: "ok", version: "12", commit: "abc" }, 200, 8));
  const compiled = await compiledAdapter(entry, transport);
  await assert.rejects(compiled.adapter.execute(executionContext({ maxBytes: 10 }), compiled.compiled), (error: unknown) =>
    error instanceof BudgetExceededError && error.dimension === "bytes");
});

test("response schema drift fails closed across metadata routes", async (t) => {
  const cases: Array<[string, GrafanaCatalogEntry, unknown]> = [
    ["health state", { id: "health-drift", route: "health", outputName: "health_drift" }, { database: "maybe", version: "12", commit: "abc" }],
    ["search UID", { id: "search-drift", route: "search", outputName: "search_drift" }, [{ uid: "../../escape", title: "Bad", type: "dash-db" }]],
    ["datasource scope", { id: "ds-drift", route: "datasource", outputName: "ds_drift", datasourceUid: "trusted" }, { uid: "different", name: "x", type: "prometheus", access: "proxy" }],
    ["annotation time", { id: "annotation-drift", route: "annotations", outputName: "annotation_drift" }, [{ time: "yesterday" }]],
    ["alerts envelope", { id: "alerts-drift", route: "unified-alerts", outputName: "alerts_drift" }, { items: [] }],
  ];
  for (const [name, entry, body] of cases) {
    await t.test(name, async () => {
      const compiled = await compiledAdapter(entry, new FakeTransport(() => response(body)));
      await assert.rejects(compiled.adapter.execute(executionContext(), compiled.compiled), AdapterContractError);
    });
  }
});

test("compile and catalog admission reject tool paths, headers, proxy routes, and hash drift", async () => {
  assert.throws(
    () => new GrafanaAdapter({
      transport: new FakeTransport(() => response({})),
      catalog: { entries: [{ id: "proxy", route: "proxy", outputName: "proxy", path: "/api/datasources/proxy/uid/x" } as never] },
    }),
    /not read-only and allowlisted/u,
  );
  assert.throws(
    () => new GrafanaAdapter({
      transport: new FakeTransport(() => response({})),
      catalog: { entries: [{ id: "headers", route: "health", outputName: "headers", headers: { Authorization: "secret" } } as never] },
    }),
    /unsupported field/u,
  );

  const entry: GrafanaCatalogEntry = { id: "trusted", route: "health", outputName: "trusted" };
  const adapter = new GrafanaAdapter({ transport: new FakeTransport(() => response({})), catalog: { entries: [entry] } });
  const snapshot = operation(entry);
  const malicious: OperationSnapshot = {
    ...snapshot,
    definition: {
      ...snapshot.definition,
      sanitizedProviderDefinition: { ...snapshot.definition.sanitizedProviderDefinition, path: "/api/admin/pause-all" },
    },
  };
  malicious.definitionSha256 = computeOperationDefinitionHash(malicious);
  await assert.rejects(
    adapter.compile(malicious, { adapterPackage: grafanaAdapterPackage, maxDefinitionBytes: 100_000 }),
    /only a trusted catalog reference/u,
  );
  const drifted: OperationSnapshot = {
    ...snapshot,
    definition: {
      ...snapshot.definition,
      sanitizedProviderDefinition: { catalogEntryId: entry.id, catalogEntrySha256: "0".repeat(64) },
    },
  };
  drifted.definitionSha256 = computeOperationDefinitionHash(drifted);
  await assert.rejects(
    adapter.compile(drifted, { adapterPackage: grafanaAdapterPackage, maxDefinitionBytes: 100_000 }),
    /hash mismatch/u,
  );

  const datasourceEntry: GrafanaCatalogEntry = {
    id: "binding",
    route: "datasource",
    outputName: "binding",
    datasourceUid: "trusted",
  };
  const datasourceAdapter = new GrafanaAdapter({
    transport: new FakeTransport(() => response({})),
    catalog: { entries: [datasourceEntry] },
  });
  const datasourceOperation = operation(datasourceEntry);
  const compiled = await datasourceAdapter.compile(datasourceOperation, {
    adapterPackage: grafanaAdapterPackage,
    maxDefinitionBytes: 100_000,
  });
  (compiled.binding as { datasourceUid: string }).datasourceUid = "../proxy/uid/escape";
  await assert.rejects(datasourceAdapter.execute(executionContext(), compiled), /no longer matches the trusted catalog/u);
});

test("datasource-query emits exactly one certified target for Prometheus, Loki, Tempo, and PostgreSQL", async (t) => {
  const eventFrame: GrafanaFrameContract = {
    resultKind: "EVENT",
    fields: [
      { sourceName: "Time", outputName: "occurred_at", type: "time", role: "TIME" },
      { sourceName: "Line", outputName: "summary", type: "string", role: "SUMMARY" },
      { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
      { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
    ],
    allowedLabels: [],
  };
  const tableFrame: GrafanaFrameContract = {
    resultKind: "TABLE",
    fields: [
      { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
      { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      { sourceName: "value", outputName: "value", type: "number", role: "COLUMN" },
    ],
    allowedLabels: [],
  };
  const cases: Array<[string, GrafanaDatasourceQueryCatalogEntry]> = [
    ["prometheus", queryEntry(prometheusTarget)],
    ["loki", queryEntry({
      datasourceType: "loki",
      expression: "{environment=\"test\",service=\"checkout\"} |= \"error\"",
      queryType: "range",
      direction: "backward",
    }, eventFrame)],
    ["tempo", queryEntry({
      datasourceType: "tempo",
      expression: "{ resource.deployment.environment = \"test\" && resource.service.name = \"checkout\" }",
      queryType: "traceql",
      limit: 25,
      spansPerSpanSet: 10,
      tableType: "traces",
    }, tableFrame)],
    ["postgres", queryEntry({
      datasourceType: "postgres",
      rawSql: "SELECT environment, service, value FROM business_kpis WHERE $__timeFilter(observed_at) AND environment = 'test' AND service = 'checkout' LIMIT 100",
      format: "table",
      maxRows: 100,
    }, tableFrame)],
    ["grafana-postgresql-datasource", queryEntry({
      datasourceType: "grafana-postgresql-datasource",
      rawSql: "SELECT environment, service, value FROM business_kpis WHERE $__timeFilter(observed_at) AND environment = 'test' AND service = 'checkout' LIMIT 100",
      format: "table",
      maxRows: 100,
    }, tableFrame)],
  ];
  for (const [datasourceType, entry] of cases) {
    await t.test(datasourceType, async () => {
      const transport = new FakeTransport(() => response(entry.target.datasourceType === "tempo"
        ? { traces: [] }
        : { results: { A: { frames: [] } } }));
      const compiled = await compiledAdapter(entry, transport);
      const result = await compiled.adapter.execute(executionContext(), compiled.compiled);
      assert.equal(transport.requests[0]?.method, "GET");
      assert.equal(transport.requests[0]?.path, "/api/health");
      const request = transport.requests[1];
      if (entry.target.datasourceType === "tempo") {
        assert.equal(request?.method, "GET");
        assert.equal(request?.path, `/api/datasources/proxy/uid/${entry.datasourceUid}/api/search`);
        assert.deepEqual(request?.query, {
          q: entry.target.expression,
          start: String(Date.parse(executionContext().window.start) / 1_000),
          end: String(Date.parse(executionContext().window.end) / 1_000),
          limit: "25",
          spss: "10",
        });
        assert.equal("body" in request!, false);
      } else {
        assert.equal(request?.method, "POST");
        assert.equal(request?.path, "/api/ds/query");
      }
      if (request?.method === "POST") {
        assert.deepEqual(request.query, {});
        const queries = request.body.queries;
        assert.ok(Array.isArray(queries));
        assert.equal(queries.length, 1);
        assert.equal((queries[0] as { refId?: unknown }).refId, "A");
        assert.equal((queries[0] as { datasource?: { type?: unknown } }).datasource?.type, datasourceType);
      }
      assert.equal(result.collectionState, "EMPTY");
      assert.equal(result.schemaVersion, "1.0.0");
      assert.equal(result.sourceLineage?.accessPath, "GRAFANA");
      assert.equal(result.sourceLineage?.datasourceType, canonicalGrafanaDatasourceType(entry.target.datasourceType));
      assert.equal(result.sourceLineage?.sourceIdentitySha256, "d".repeat(64));
      assert.equal(JSON.stringify(result).includes(entry.datasourceUid), false);
      assert.equal(JSON.stringify(result).includes("SELECT environment"), false);
      if (isGrafanaPostgresDatasourceType(entry.target.datasourceType)) {
        assert.equal(JSON.stringify(request).includes("a".repeat(64)), false, "role attestation stays outside provider I/O");
        assert.equal(JSON.stringify(result).includes("a".repeat(64)), false, "role attestation stays outside evidence");
      }
    });
  }
});

test("datasource-query preflights a certified Grafana version before every POST and fails closed", async (t) => {
  for (const version of ["10.4.12", "11.6.5", "12.3.1", "13.0.0-rc1"]) {
    await t.test(`supports ${version}`, async () => {
      const transport = new FakeTransport(
        () => response({ results: { A: { frames: [] } } }),
        () => response({ database: "ok", version }),
      );
      const compiled = await compiledAdapter(queryEntry(prometheusTarget), transport);
      const result = await compiled.adapter.execute(executionContext(), compiled.compiled);
      assert.deepEqual(
        transport.requests.map((request) => `${request.method} ${request.path}`),
        ["GET /api/health", "POST /api/ds/query"],
      );
      if (version.startsWith("13.")) {
        assert.deepEqual(result.warnings, [
          "Grafana 13 datasource queries use the certified legacy /api route, which is deprecated",
        ]);
      } else {
        assert.deepEqual(result.warnings, []);
      }
    });
  }

  for (const [name, health, expectedCode] of [
    ["Grafana 14", { database: "ok", version: "14.0.0" }, "GRAFANA_VERSION_UNSUPPORTED"],
    ["unsupported old Grafana", { database: "ok", version: "9.5.21" }, "GRAFANA_VERSION_UNSUPPORTED"],
    ["malformed version", { database: "ok", version: "13" }, "GRAFANA_VERSION_INVALID"],
    ["leading-zero version", { database: "ok", version: "013.1.0" }, "GRAFANA_VERSION_INVALID"],
    ["leading-zero component", { database: "ok", version: "13.000001.0" }, "GRAFANA_VERSION_INVALID"],
    ["oversized numeric component", { database: "ok", version: "13.1234567.0" }, "GRAFANA_VERSION_INVALID"],
    ["oversized suffix", { database: "ok", version: `13.1.0-${"x".repeat(65)}` }, "GRAFANA_VERSION_INVALID"],
    ["malformed health", { database: "fail", version: "13.1.0" }, "GRAFANA_HEALTH_INVALID"],
  ] as const) {
    await t.test(`rejects ${name} before POST`, async () => {
      const transport = new FakeTransport(
        () => response({ results: { A: { frames: [] } } }),
        () => response(health),
      );
      const compiled = await compiledAdapter(queryEntry(prometheusTarget), transport);
      await assert.rejects(compiled.adapter.execute(executionContext(), compiled.compiled), (error: unknown) =>
        error instanceof AdapterExecutionError && error.sanitized.code === expectedCode);
      assert.deepEqual(
        transport.requests.map((request) => `${request.method} ${request.path}`),
        ["GET /api/health"],
      );
    });
  }
});

test("datasource frames normalize metrics without leaking query metadata or unenrolled labels", async () => {
  const entry: GrafanaDatasourceQueryCatalogEntry = {
    ...queryEntry(prometheusTarget),
    sourcePanel: {
      dashboardUid: "checkout-overview",
      dashboardVersion: 7,
      panelId: 12,
      targetRefId: "A",
    },
  };
  const canary = "Bearer datasource-frame-secret";
  const transport = new FakeTransport(() => response({
    results: {
      A: {
        frames: [{
          schema: {
            refId: "A",
            fields: [
              { name: "Time", type: "time" },
              {
                name: "Value",
                type: "number",
                labels: { environment: "test", service: "checkout", customer_id: canary },
                config: { displayName: canary, links: [{ url: "https://private.invalid" }] },
              },
            ],
          },
          data: { values: [[1767225600000, 1767225601000], [12.5, 17.25]] },
        }],
        meta: { executedQueryString: `${prometheusTarget.expression} ${canary}` },
      },
    },
  }));
  const compiled = await compiledAdapter(entry, transport);
  const result = await compiled.adapter.execute(executionContext(), compiled.compiled);
  assert.equal(result.collectionState, "COMPLETE");
  assert.equal(result.nativeResultType, "datasource-query:prometheus");
  assert.equal(result.nativeUnit, "percent");
  assert.equal(result.sanitizedReference, "grafana:/d/checkout-overview?viewPanel=12");
  assert.deepEqual(result.providerScope, {
    environment: "test",
    service: "checkout",
    mappings: { environment: "environment", service: "service" },
  });
  assert.deepEqual(result.records, [{
    kind: "TIMESERIES",
    name: "cpu_usage",
    unit: "percent",
    dimensions: { environment: "test", service: "checkout" },
    points: [
      { at: "2026-01-01T00:00:00.000Z", value: 12.5 },
      { at: "2026-01-01T00:00:01.000Z", value: 17.25 },
    ],
  }]);
  const serialized = JSON.stringify(result);
  assert.equal(serialized.includes(canary), false);
  assert.equal(serialized.includes("customer_id"), false);
  assert.equal(serialized.includes(entry.datasourceUid), false);
  assert.equal(serialized.includes(prometheusTarget.expression), false);
  const request = transport.requests[1];
  if (request?.method === "POST") {
    assert.equal(request.body.from, "1767225600000");
    assert.equal(request.body.to, "1767225900000");
    const queries = request.body.queries;
    assert.ok(Array.isArray(queries));
    assert.equal((queries[0] as { intervalMs?: unknown }).intervalMs, 3_000);
  }
});

test("datasource-query rejects a sealed lineage that does not match the enrolled datasource identity", async () => {
  const entry = queryEntry(prometheusTarget);
  const adapter = new GrafanaAdapter({
    transport: new FakeTransport(() => response({ results: { A: { frames: [] } } })),
    catalog: { entries: [entry] },
  });
  const snapshot = operation(entry);
  snapshot.definition.expectedSourceLineage = {
    accessPath: "GRAFANA",
    datasourceType: "prometheus",
    sourceIdentitySha256: "e".repeat(64) as Sha256,
  };
  snapshot.definitionSha256 = computeOperationDefinitionHash(snapshot);
  await assert.rejects(
    adapter.compile(snapshot, { adapterPackage: grafanaAdapterPackage, maxDefinitionBytes: 100_000 }),
    /source lineage/u,
  );
});

test("datasource-query rejects scope drift before I/O and provider scope drift after I/O", async () => {
  const entry = queryEntry(prometheusTarget);
  const transport = new FakeTransport(() => response({ results: { A: { frames: [] } } }));
  const compiled = await compiledAdapter(entry, transport);
  const wrongScope = { ...executionContext(), scope: { environment: "production", service: "checkout" } };
  await assert.rejects(compiled.adapter.execute(wrongScope, compiled.compiled), /execution scope/u);
  assert.equal(transport.requests.length, 0);

  const driftTransport = new FakeTransport(() => response({
    results: { A: { frames: [{
      schema: {
        refId: "A",
        fields: [
          { name: "Time", type: "time" },
          { name: "Value", type: "number", labels: { environment: "staging", service: "checkout" } },
        ],
      },
      data: { values: [[1767225600000], [1]] },
    }] } },
  }));
  const drift = await compiledAdapter(entry, driftTransport);
  await assert.rejects(drift.adapter.execute(executionContext(), drift.compiled), /environment does not match/u);
});

test("datasource-query binds opaque subjects and rejects cross-subject dimensions and rows", async () => {
  const subjectRef = "pmsub_abcdefghijklmnopqrstuvwxyz" as SubjectRef;
  const providerValue = "node-a.internal";
  const entry: GrafanaDatasourceQueryCatalogEntry = {
    ...queryEntry({
      ...prometheusTarget,
      expression: `node_cpu_usage{environment="test",service="checkout",instance="${providerValue}"}`,
    }),
    frame: { ...metricFrame, allowedLabels: ["environment", "service", "instance"] },
    scope: {
      environment: "test",
      service: "checkout",
      subject: { kind: "HOST", ref: subjectRef, providerValue },
    },
    scopeMappings: { environment: "environment", service: "service", "subject.ref": "instance" },
  };
  const transport = new FakeTransport(() => response({
    results: { A: { frames: [{
      schema: {
        refId: "A",
        fields: [
          { name: "Time", type: "time" },
          { name: "Value", type: "number", labels: { environment: "test", service: "checkout", instance: providerValue } },
        ],
      },
      data: { values: [[1767225600000], [12.5]] },
    }] } },
  }));
  const compiled = await compiledAdapter(entry, transport);
  const scopedContext = {
    ...executionContext(),
    scope: { environment: "test", service: "checkout", subject: { kind: "HOST" as const, ref: subjectRef } },
  };
  const result = await compiled.adapter.execute(scopedContext, compiled.compiled);
  assert.deepEqual(result.providerScope?.subject, { kind: "HOST", ref: subjectRef });
  assert.equal(JSON.stringify(result).includes(providerValue), false);
  assert.equal(JSON.stringify(result).includes(subjectRef), true);

  const wrongSubject = {
    ...scopedContext,
    scope: {
      ...scopedContext.scope,
      subject: { kind: "HOST" as const, ref: "pmsub_zyxwvutsrqponmlkjihgfedcba" as SubjectRef },
    },
  };
  await assert.rejects(compiled.adapter.execute(wrongSubject, compiled.compiled), /execution scope/u);
  assert.equal(transport.requests.length, 2, "wrong opaque subjects fail before another provider request");

  const tableEntry: GrafanaDatasourceQueryCatalogEntry = {
    ...entry,
    id: "query-subject-table",
    target: {
      ...prometheusTarget,
      expression: `node_info{environment="test",service="checkout",instance="${providerValue}"}`,
      format: "table",
    },
    frame: {
      resultKind: "TABLE",
      fields: [
        { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
        { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
        { sourceName: "instance", outputName: "subject", type: "string", role: "DIMENSION" },
        { sourceName: "value", outputName: "value", type: "number", role: "COLUMN" },
      ],
      allowedLabels: [],
    },
  };
  const crossSubject = await compiledAdapter(tableEntry, new FakeTransport(() => response({
    results: { A: { frames: [{
      schema: { refId: "A", fields: [
        { name: "environment", type: "string" },
        { name: "service", type: "string" },
        { name: "instance", type: "string" },
        { name: "value", type: "number" },
      ] },
      data: { values: [
        ["test", "test"],
        ["checkout", "checkout"],
        [providerValue, "node-b.internal"],
        [1, 2],
      ] },
    }] } },
  })));
  await assert.rejects(crossSubject.adapter.execute(scopedContext, crossSubject.compiled), /subject does not match/u);
});

test("datasource-query truncation and schema or API failures remain explicit and sanitized", async () => {
  const entry = queryEntry(prometheusTarget);
  const frame = {
    schema: {
      refId: "A",
      fields: [
        { name: "Time", type: "time" },
        { name: "Value", type: "number", labels: { environment: "test", service: "checkout" } },
      ],
    },
    data: { values: [[1767225600000, 1767225601000], [1, 2]] },
  };
  const bounded = await compiledAdapter(entry, new FakeTransport(() => response({ results: { A: { frames: [frame] } } })));
  const boundedResult = await bounded.adapter.execute(executionContext({ maxPoints: 1 }), bounded.compiled);
  assert.deepEqual(boundedResult.pagination, { complete: false, pages: 1, truncatedReason: "POINT_LIMIT" });
  assert.equal(boundedResult.warnings.length, 1);

  const nullable = await compiledAdapter(entry, new FakeTransport(() => response({
    results: { A: { frames: [{ ...frame, data: { values: [[1767225600000], [null]] } }] } },
  })));
  const nullableResult = await nullable.adapter.execute(executionContext(), nullable.compiled);
  assert.equal(nullableResult.records[0]?.kind === "TIMESERIES" && nullableResult.records[0].points[0]?.value, null);

  const unsafeTime = await compiledAdapter(entry, new FakeTransport(() => response({
    results: { A: { frames: [{ ...frame, data: { values: [[0], [1]] } }] } },
  })));
  await assert.rejects(unsafeTime.adapter.execute(executionContext(), unsafeTime.compiled), /outside the requested window/u);

  const drift = await compiledAdapter(entry, new FakeTransport(() => response({
    results: { A: { frames: [{ ...frame, schema: { ...frame.schema, fields: [{ name: "Time", type: "string" }] } }] } },
  })));
  await assert.rejects(drift.adapter.execute(executionContext(), drift.compiled), AdapterContractError);

  const canary = "SELECT secret FROM credentials";
  const failed = await compiledAdapter(entry, new FakeTransport(() => response({
    results: { A: { status: 400, error: canary, frames: [] } },
  })));
  await assert.rejects(failed.adapter.execute(executionContext(), failed.compiled), (error: unknown) =>
    error instanceof AdapterExecutionError && error.sanitized.code === "GRAFANA_DATASOURCE_QUERY_FAILED" && !error.message.includes(canary));
});

test("datasource validators reject unapproved plugins, Grafana variables, mutable SQL, and target escape fields", () => {
  const transport = new FakeTransport(() => response({}));
  const admit = (entry: GrafanaDatasourceQueryCatalogEntry) => new GrafanaAdapter({ transport, catalog: { entries: [entry] } });
  assert.throws(() => admit(queryEntry({
    datasourceType: "postgres",
    rawSql: "WITH scoped AS (SELECT environment, service, value FROM metrics) SELECT * FROM scoped LIMIT 10",
    format: "time_series",
    maxRows: 10,
  })), /scope/u);
  const postgresEntry = queryEntry({
    datasourceType: "postgres",
    rawSql: "SELECT environment, service, value FROM metrics WHERE environment = 'test' AND service = 'checkout' LIMIT 10",
    format: "time_series",
    maxRows: 10,
  });
  assert.throws(() => admit({ ...postgresEntry, postgresReadOnlyIdentity: undefined }), /SELECT_ONLY database identity attestation/u);
  assert.throws(() => admit({
    ...postgresEntry,
    postgresReadOnlyIdentity: {
      roleIdentitySha256: "0".repeat(63) as Sha256,
      privilegeModel: "SELECT_ONLY",
    },
  }), /identity attestation is invalid/u);
  assert.throws(() => admit({
    ...postgresEntry,
    postgresReadOnlyIdentity: {
      roleIdentitySha256: "a".repeat(64) as Sha256,
      privilegeModel: "READ_ONLY",
    } as never,
  }), /identity attestation is invalid/u);
  assert.throws(() => admit({
    ...postgresEntry,
    postgresReadOnlyIdentity: {
      roleIdentitySha256: "a".repeat(64) as Sha256,
      privilegeModel: "SELECT_ONLY",
      databaseRole: "grafana_reader",
    } as never,
  }), /unsupported field/u);
  assert.throws(() => admit({
    ...queryEntry(prometheusTarget),
    postgresReadOnlyIdentity: {
      roleIdentitySha256: "a".repeat(64) as Sha256,
      privilegeModel: "SELECT_ONLY",
    },
  }), /forbidden for non-PostgreSQL/u);
  assert.notEqual(
    grafanaCatalogEntryHash(postgresEntry),
    grafanaCatalogEntryHash({
      ...postgresEntry,
      postgresReadOnlyIdentity: {
        roleIdentitySha256: "b".repeat(64) as Sha256,
        privilegeModel: "SELECT_ONLY",
      },
    }),
    "the reviewed upstream role identity must be hash-bound into the catalog entry",
  );
  assert.throws(() => admit(queryEntry({
    datasourceType: "mysql",
    rawSql: "SELECT 1 LIMIT 1",
    format: "table",
    maxRows: 1,
  } as never)), /not certified/u);
  assert.throws(() => admit(queryEntry({
    ...prometheusTarget,
    expression: "sum(rate(http_requests_total{$environment=\"test\"}[5m]))",
  })), /variable/u);
  assert.throws(() => admit(queryEntry({
    ...prometheusTarget,
    path: "/api/datasources/proxy/uid/escape",
  } as GrafanaDatasourceQueryTarget)), /unsupported field/u);
  for (const rawSql of [
    "SELECT environment, service, value FROM metrics",
    "WITH changed AS (DELETE FROM metrics RETURNING *) SELECT * FROM changed LIMIT 1",
    "SELECT environment, service, value FROM metrics LIMIT 1; DROP TABLE metrics",
    "SELECT environment, service, value INTO copied_metrics FROM metrics LIMIT 1",
    "SELECT environment, service, value FROM metrics LIMIT 1 FOR UPDATE",
    "SELECT pg_read_file('/etc/passwd') LIMIT 1",
    "SELECT environment, service, value FROM metrics WHERE observed_at > $__interval LIMIT 1",
  ]) {
    assert.throws(() => admit(queryEntry({
      datasourceType: "postgres",
      rawSql,
      format: "time_series",
      maxRows: 10,
    })), /PostgreSQL/u);
  }
});

test("saved-panel compiler produces a reviewable one-target proposal and rejects dynamic panels", () => {
  const dashboard = {
    uid: "checkout-overview",
    version: 7,
    templating: { list: [] },
    panels: [{
      id: 12,
      datasource: { type: "prometheus", uid: "prometheus-main" },
      targets: [{
        refId: "A",
        datasource: { type: "prometheus", uid: "prometheus-main" },
        expr: prometheusTarget.expression,
        instant: false,
        range: true,
        format: "time_series",
      }],
    }],
  };
  const proposal = compileGrafanaSavedPanel({
    dashboard,
    panelId: 12,
    id: "saved-checkout-cpu",
    outputName: "checkout_cpu",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    frame: metricFrame,
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  });
  assert.equal(proposal.target.datasourceType, "prometheus");
  assert.deepEqual(proposal.sourcePanel, {
    dashboardUid: "checkout-overview",
    dashboardVersion: 7,
    panelId: 12,
    targetRefId: "A",
  });
  assert.throws(() => compileGrafanaSavedPanel({
    dashboard: { ...dashboard, templating: { list: [{ name: "environment" }] } },
    panelId: 12,
    id: "dynamic",
    outputName: "dynamic",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    frame: metricFrame,
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  }), /variables/u);
  assert.throws(() => compileGrafanaSavedPanel({
    dashboard: {
      ...dashboard,
      panels: [{ ...dashboard.panels[0], transformations: [{ id: "organize" }] }],
    },
    panelId: 12,
    id: "transformed",
    outputName: "transformed",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    frame: metricFrame,
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  }), /transformations/u);
  assert.throws(() => compileGrafanaSavedPanel({
    dashboard: {
      ...dashboard,
      panels: [{
        ...dashboard.panels[0],
        datasource: { type: "mixed", uid: "-- Mixed --" },
        targets: [{ ...dashboard.panels[0]!.targets[0], datasource: { type: "mixed", uid: "-- Mixed --" } }],
      }],
    },
    panelId: 12,
    id: "mixed",
    outputName: "mixed",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    frame: metricFrame,
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  }), /not certified/u);

  const postgresDashboard = {
    ...dashboard,
    panels: [{
      ...dashboard.panels[0],
      datasource: { type: "grafana-postgresql-datasource", uid: "postgres-main" },
      targets: [{
        refId: "A",
        datasource: { type: "grafana-postgresql-datasource", uid: "postgres-main" },
        rawSql: "SELECT environment, service, value FROM business_kpis WHERE $__timeFilter(observed_at) AND environment = 'test' AND service = 'checkout' LIMIT 10",
        format: "table",
      }],
    }],
  };
  assert.throws(() => compileGrafanaSavedPanel({
    dashboard: postgresDashboard,
    panelId: 12,
    id: "saved-postgres-missing-role",
    outputName: "business_kpis",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    frame: {
      resultKind: "TABLE",
      fields: [
        { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
        { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
        { sourceName: "value", outputName: "value", type: "number", role: "COLUMN" },
      ],
      allowedLabels: [],
    },
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
    postgresMaxRows: 10,
  }), /SELECT_ONLY database identity attestation/u);
  const postgresProposal = compileGrafanaSavedPanel({
    dashboard: postgresDashboard,
    panelId: 12,
    id: "saved-postgres",
    outputName: "business_kpis",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    frame: {
      resultKind: "TABLE",
      fields: [
        { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
        { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
        { sourceName: "value", outputName: "value", type: "number", role: "COLUMN" },
      ],
      allowedLabels: [],
    },
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
    postgresMaxRows: 10,
    postgresReadOnlyIdentity: {
      roleIdentitySha256: "a".repeat(64) as Sha256,
      privilegeModel: "SELECT_ONLY",
    },
  });
  assert.deepEqual(postgresProposal.postgresReadOnlyIdentity, {
    roleIdentitySha256: "a".repeat(64),
    privilegeModel: "SELECT_ONLY",
  });
  assert.equal(postgresProposal.target.datasourceType, "grafana-postgresql-datasource");

  const legacyPostgresProposal = compileGrafanaSavedPanel({
    dashboard: {
      ...postgresDashboard,
      panels: [{
        ...postgresDashboard.panels[0],
        datasource: { type: "postgres", uid: "postgres-main" },
        targets: [{
          ...postgresDashboard.panels[0]!.targets[0],
          datasource: { type: "postgres", uid: "postgres-main" },
        }],
      }],
    },
    panelId: 12,
    id: "saved-postgres-legacy",
    outputName: "business_kpis_legacy",
    datasourceIdentitySha256: "d".repeat(64) as Sha256,
    frame: postgresProposal.frame,
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
    postgresMaxRows: 10,
    postgresReadOnlyIdentity: {
      roleIdentitySha256: "a".repeat(64) as Sha256,
      privilegeModel: "SELECT_ONLY",
    },
  });
  assert.equal(legacyPostgresProposal.target.datasourceType, "postgres");
});
