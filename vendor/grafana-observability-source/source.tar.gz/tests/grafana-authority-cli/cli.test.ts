import assert from "node:assert/strict";
import {
  chmodSync,
  mkdtempSync,
  mkdirSync,
  readFileSync,
  realpathSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import {
  grafanaCatalogEntryHash,
  isGrafanaPostgresDatasourceType,
  type GrafanaDatasourceType,
} from "../../adapters/grafana/src/index.ts";
import type {
  ActivationReceipt,
  ActivationSummary,
  ActivateTrustRootOptions,
} from "../../packages/config/src/index.ts";
import type { Sha256 } from "../../packages/contracts/src/index.ts";
import {
  executeGrafanaAuthorityCli,
  type GrafanaAuthorityCliIo,
} from "../../packages/grafana-authority-cli/src/index.ts";

const HASH_A = "a".repeat(64) as Sha256;
const HASH_B = "b".repeat(64) as Sha256;
const HASH_D = "d".repeat(64) as Sha256;

function tempRoot(t: test.TestContext): string {
  const root = realpathSync(mkdtempSync(join(realpathSync(tmpdir()), "grafana-authority-cli-")));
  chmodSync(root, 0o700);
  t.after(() => rmSync(root, { force: true, recursive: true }));
  return root;
}

function captureIo(): { io: GrafanaAuthorityCliIo; stdout: string[]; stderr: string[] } {
  const stdout: string[] = [];
  const stderr: string[] = [];
  return {
    stdout,
    stderr,
    io: {
      stdout: (text) => stdout.push(text),
      stderr: (text) => stderr.push(text),
    },
  };
}

function activationSummary(root: string): ActivationSummary {
  return {
    schemaVersion: "1.0.0",
    valid: true,
    trustRootPath: root,
    rootManifestSha256: HASH_A,
    trustBundleSha256: HASH_B,
    providerRuntimeSha256: null,
    profileAlias: "grafana-prod",
    adapterPackageIds: ["adapter.grafana.v1"],
    credentialEnvironmentReferences: [],
  };
}

function enrollment(
  datasourceType: Extract<GrafanaDatasourceType, "prometheus" | "postgres" | "grafana-postgresql-datasource"> = "prometheus",
): Record<string, unknown> {
  const isPostgres = isGrafanaPostgresDatasourceType(datasourceType);
  return {
    schemaVersion: "1.0.0",
    kind: "grafana-saved-panel-enrollment-v1",
    dashboard: {
      uid: "checkout-overview",
      version: 7,
      templating: { list: [] },
      links: [{ url: "https://ignored.invalid/dashboard" }],
      panels: [{
        id: 12,
        datasource: { type: datasourceType, uid: isPostgres ? "postgres-main" : "prometheus-main" },
        targets: [{
          refId: "A",
          datasource: { type: datasourceType, uid: isPostgres ? "postgres-main" : "prometheus-main" },
          ...(isPostgres
            ? {
                rawSql: "SELECT environment, service, value FROM business_kpis WHERE $__timeFilter(observed_at) AND environment = 'test' AND service = 'checkout' LIMIT 10",
                format: "table",
              }
            : {
                expr: 'sum(rate(http_requests_total{environment="test",service="checkout"}[5m]))',
                instant: false,
                range: true,
                format: "time_series",
              }),
        }],
      }],
    },
    panelId: 12,
    id: isPostgres ? "saved-business-kpis" : "saved-checkout-rate",
    outputName: isPostgres ? "business_kpis" : "checkout_rate",
    datasourceIdentitySha256: HASH_D,
    frame: isPostgres
      ? {
          resultKind: "TABLE",
          fields: [
            { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
            { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
            { sourceName: "value", outputName: "value", type: "number", role: "COLUMN" },
          ],
          allowedLabels: [],
        }
      : {
          resultKind: "TIMESERIES",
          fields: [
            { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
            { sourceName: "Value", outputName: "value", type: "number", role: "VALUE" },
          ],
          allowedLabels: ["environment", "service"],
        },
    minIntervalMs: 1_000,
    scope: { environment: "test", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
    ...(isPostgres ? { postgresMaxRows: 10 } : {}),
  };
}

test("trust-root validate is standalone and never activates", async () => {
  const root = "/absolute/admin-root";
  const capture = captureIo();
  let validateCalls = 0;
  let activateCalls = 0;
  const exitCode = await executeGrafanaAuthorityCli(
    ["trust-root", "validate", "--root", root],
    {
      io: capture.io,
      validateRoot: (path) => {
        validateCalls += 1;
        assert.equal(path, root);
        return activationSummary(root);
      },
      activateRoot: () => {
        activateCalls += 1;
        throw new Error("must not activate");
      },
    },
  );
  assert.equal(exitCode, 0);
  assert.equal(validateCalls, 1);
  assert.equal(activateCalls, 0);
  assert.equal(capture.stderr.length, 0);
  const result = JSON.parse(capture.stdout.join("")) as Record<string, unknown>;
  assert.equal(result.valid, true);
  assert.equal(result.activationPerformed, false);
  assert.equal(result.rootManifestSha256, HASH_A);
  assert.equal(result.trustBundleSha256, HASH_B);
});

test("trust-root activation requires both reviewed digests and forwards only bounded options", async () => {
  const capture = captureIo();
  const root = "/absolute/admin-root";
  const receipt = "/absolute/private/activation.json";
  let supplied: ActivateTrustRootOptions | undefined;
  const exitCode = await executeGrafanaAuthorityCli([
    "trust-root",
    "activate",
    "--root",
    root,
    "--receipt",
    receipt,
    "--expected-root-manifest-sha256",
    HASH_A,
    "--expected-trust-bundle-sha256",
    HASH_B,
  ], {
    io: capture.io,
    now: () => new Date("2026-08-15T12:00:00.000Z"),
    activateRoot: (options) => {
      supplied = options;
      return {
        schemaVersion: "1.0.0",
        kind: "production-monitoring-activation-v1",
        activatedAt: options.activatedAt!,
        trustRootPath: options.trustRootPath,
        rootManifestSha256: options.expectedRootManifestSha256,
        trustBundleSha256: options.expectedTrustBundleSha256,
        providerRuntimeSha256: null,
        integrity: {
          hashContractVersion: "sha256-jcs-v1",
          algorithm: "sha256",
          canonicalization: "RFC8785",
          contentSha256: HASH_D,
        },
      } satisfies ActivationReceipt;
    },
  });
  assert.equal(exitCode, 0);
  assert.deepEqual(supplied, {
    trustRootPath: root,
    receiptPath: receipt,
    expectedRootManifestSha256: HASH_A,
    expectedTrustBundleSha256: HASH_B,
    activatedAt: "2026-08-15T12:00:00.000Z",
    replace: false,
  });
  const result = JSON.parse(capture.stdout.join("")) as Record<string, unknown>;
  assert.equal(result.activationPerformed, true);

  const rejected = captureIo();
  assert.equal(await executeGrafanaAuthorityCli([
    "trust-root",
    "activate",
    "--root",
    root,
    "--receipt",
    receipt,
    "--expected-root-manifest-sha256",
    HASH_A,
  ], { io: rejected.io }), 2);
  assert.match(rejected.stderr.join(""), /INVALID_ARGUMENTS/u);
});

test("saved-panel enrollment writes one no-clobber hash-pinned entry without URL or header material", async (t) => {
  const root = tempRoot(t);
  const input = join(root, "enrollment.json");
  const output = join(root, "proposal.json");
  writeFileSync(input, JSON.stringify(enrollment()), { encoding: "utf8", mode: 0o600 });
  const capture = captureIo();
  let activateCalls = 0;
  const exitCode = await executeGrafanaAuthorityCli([
    "saved-panel",
    "enroll",
    "--input",
    input,
    "--output",
    output,
  ], {
    io: capture.io,
    activateRoot: () => {
      activateCalls += 1;
      throw new Error("must not activate");
    },
  });
  assert.equal(exitCode, 0);
  assert.equal(activateCalls, 0);
  const proposalSource = readFileSync(output, "utf8");
  assert.doesNotMatch(proposalSource, /ignored\.invalid|headers?/iu);
  const proposal = JSON.parse(proposalSource) as {
    kind: unknown;
    activationPerformed: unknown;
    catalogEntrySha256: Sha256;
    catalogEntry: Parameters<typeof grafanaCatalogEntryHash>[0];
  };
  assert.equal(proposal.kind, "grafana-frozen-catalog-entry-v1");
  assert.equal(proposal.activationPerformed, false);
  assert.equal(proposal.catalogEntrySha256, grafanaCatalogEntryHash(proposal.catalogEntry));
  assert.equal(proposal.catalogEntry.route, "datasource-query");
  assert.deepEqual(proposal.catalogEntry.sourcePanel, {
    dashboardUid: "checkout-overview",
    dashboardVersion: 7,
    panelId: 12,
    targetRefId: "A",
  });
  assert.equal(
    await executeGrafanaAuthorityCli([
      "saved-panel",
      "enroll",
      "--input",
      input,
      "--output",
      output,
    ], { io: captureIo().io }),
    1,
    "proposal output is no-clobber",
  );
});

test("modern PostgreSQL enrollment preserves the provider plugin ID and hash-binds SELECT_ONLY identity", async (t) => {
  const root = tempRoot(t);
  const input = join(root, "postgres-enrollment.json");
  const missingOutput = join(root, "missing.json");
  writeFileSync(input, JSON.stringify(enrollment("grafana-postgresql-datasource")), { encoding: "utf8", mode: 0o600 });
  assert.equal(await executeGrafanaAuthorityCli([
    "saved-panel",
    "enroll",
    "--input",
    input,
    "--output",
    missingOutput,
  ], { io: captureIo().io }), 1);

  const attested = enrollment("grafana-postgresql-datasource");
  attested.postgresReadOnlyIdentity = {
    roleIdentitySha256: HASH_A,
    privilegeModel: "SELECT_ONLY",
  };
  writeFileSync(input, JSON.stringify(attested), { encoding: "utf8", flag: "w", mode: 0o600 });
  const output = join(root, "attested.json");
  assert.equal(await executeGrafanaAuthorityCli([
    "saved-panel",
    "enroll",
    "--input",
    input,
    "--output",
    output,
  ], { io: captureIo().io }), 0);
  const proposal = JSON.parse(readFileSync(output, "utf8")) as {
    catalogEntry: { target?: { datasourceType?: unknown }; postgresReadOnlyIdentity?: unknown };
  };
  assert.equal(proposal.catalogEntry.target?.datasourceType, "grafana-postgresql-datasource");
  assert.deepEqual(proposal.catalogEntry.postgresReadOnlyIdentity, {
    roleIdentitySha256: HASH_A,
    privilegeModel: "SELECT_ONLY",
  });

  const prometheus = enrollment();
  prometheus.postgresReadOnlyIdentity = {
    roleIdentitySha256: HASH_A,
    privilegeModel: "SELECT_ONLY",
  };
  writeFileSync(input, JSON.stringify(prometheus), { encoding: "utf8", flag: "w", mode: 0o600 });
  assert.equal(await executeGrafanaAuthorityCli([
    "saved-panel",
    "enroll",
    "--input",
    input,
    "--output",
    join(root, "forbidden.json"),
  ], { io: captureIo().io }), 1);
});

test("authority CLI accepts neither credential, URL, header, nor non-regular enrollment inputs", async (t) => {
  const root = tempRoot(t);
  const capture = captureIo();
  assert.equal(await executeGrafanaAuthorityCli([
    "saved-panel",
    "enroll",
    "--url",
    "https://grafana.invalid",
    "--output",
    join(root, "proposal.json"),
  ], { io: capture.io }), 2);
  assert.match(capture.stderr.join(""), /INVALID_ARGUMENTS/u);

  const directoryInput = join(root, "input-directory");
  mkdirSync(directoryInput);
  assert.equal(await executeGrafanaAuthorityCli([
    "saved-panel",
    "enroll",
    "--input",
    directoryInput,
    "--output",
    join(root, "directory-proposal.json"),
  ], { io: captureIo().io }), 1);
});

test("authority CLI remains independent of workflow, provider-network, and credential packages", () => {
  const manifest = JSON.parse(
    readFileSync("packages/grafana-authority-cli/package.json", "utf8"),
  ) as { dependencies?: Record<string, string> };
  assert.deepEqual(manifest.dependencies, {
    "@codex-production-monitoring/adapter-grafana": "0.3.0",
    "@codex-production-monitoring/config": "0.3.0",
    "@codex-production-monitoring/contracts": "0.3.0",
  });
  const source = readFileSync("packages/grafana-authority-cli/src/main.ts", "utf8");
  assert.doesNotMatch(source, /@codex-production-monitoring\/(?:cli|headless|evidence-server|provider-runtime)/u);
  assert.doesNotMatch(source, /node:https?|\bfetch\s*\(/u);
  assert.doesNotMatch(source, /process\.env/u);
});
