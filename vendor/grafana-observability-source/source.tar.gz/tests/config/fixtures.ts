import { chmodSync, mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

import {
  computeIntegrity,
  computeOperationDefinitionHash,
  sha256Bytes,
  sha256Canonical,
} from "../../packages/contracts/src/index.ts";
import type {
  AdapterPackage,
  AdapterPackageId,
  EvidenceOrigin,
  OperationId,
  OperationSnapshot,
  Sha256,
  TrustBundle,
  TrustedEndpoint,
  TrustedProfile,
} from "../../packages/contracts/src/index.ts";
import { computeTrustedProfileConfigHash } from "../../packages/config/src/index.ts";
import { stringify } from "yaml";

const FIXED_TIME = "2026-08-10T12:00:00.000Z";

export function makeTrustBundle(): TrustBundle {
  const packageId = "prometheus.metrics" as AdapterPackageId;
  const adapter: AdapterPackage = {
    schemaVersion: "1.0.0",
    packageId,
    name: "Prometheus metrics",
    version: "0.1.0",
    protocolVersion: "1.0",
    publisher: { name: "Test publisher" },
    entrypoint: { kind: "BUILTIN", registryKey: "prometheus" },
    domains: ["METRICS"],
    capabilities: ["service-health"],
    providerCompatibility: [{ provider: "prometheus", versions: ">=3.0.0" }],
    supportedContractVersions: ["1.0.0"],
    conformance: ["CORE_READ", "METRICS"],
  };
  const endpoint: TrustedEndpoint = {
    endpointId: "prometheus-primary",
    adapterId: packageId,
    baseUrl: "https://prometheus.example.com/api/v1/",
    authentication: { mode: "BEARER", tokenRef: { kind: "env", key: "PROMETHEUS_READ_TOKEN" } },
    tls: { minimumVersion: "TLSv1.2" },
    network: {
      followRedirects: false,
      allowLoopbackHttp: false,
      allowedHosts: ["prometheus.example.com"],
      networkClass: "public",
      routeMode: "direct",
    },
    tenantBinding: { headerName: "X-Scope-OrgID", valueRef: "metadata:tenant" },
  };
  const operationWithoutHash = {
    schemaVersion: "1.0.0" as const,
    operationId: "service.health" as OperationId,
    revision: 1,
    capturedAt: FIXED_TIME,
    definition: {
      domain: "METRICS" as const,
      sourceAlias: endpoint.endpointId,
      adapterPackageId: packageId,
      adapterOperation: "service-health",
      authority: "AUTHORITATIVE" as const,
      sanitizedProviderDefinition: { template: "up" },
      scopeMapping: { service: "service" },
      allowedDimensions: ["service"],
      requiredProviderScopes: ["metrics:read"],
      sensitivity: "INTERNAL" as const,
      limits: {
        timeoutMs: 5_000,
        maxAgeMs: 60_000,
        maxBytes: 65_536,
        maxRows: 100,
        maxSeries: 25,
        maxPoints: 500,
      },
      normalization: {
        resultKind: "SCALAR" as const,
        dimensionMappings: { service: "service" },
      },
    },
  };
  const operation: OperationSnapshot = {
    ...operationWithoutHash,
    definitionSha256: computeOperationDefinitionHash(operationWithoutHash),
  };
  const profileWithoutConfigHash = {
    schemaVersion: "1.0.0" as const,
    profileAlias: "checkout-production",
    capabilityProfile: "investigate" as const,
    allowedOrigins: ["LIVE", "REPLAY"] as EvidenceOrigin[],
    compiledAt: FIXED_TIME,
    configSha256: "0".repeat(64) as Sha256,
    endpointRegistrySha256: sha256Canonical([endpoint]),
    catalogSha256: sha256Canonical([operation]),
    scopes: {
      checkout: { environment: "production", service: "checkout" },
      worker: { environment: "production", service: "worker" },
    },
    endpointIds: [endpoint.endpointId],
    operationIds: [operation.operationId],
    policy: {
      defaultLookback: { mode: "FIXED" as const, durationSeconds: 900 },
      maxEvidenceAge: { mode: "FIXED" as const, durationSeconds: 60 },
      rawEvidenceRetention: { mode: "NONE" as const },
      auditRequired: true,
      limits: {
        timeoutMs: 10_000,
        maxAgeMs: 120_000,
        maxBytes: 131_072,
        maxRows: 500,
        maxSeries: 100,
        maxPoints: 2_000,
      },
    },
  };
  const provisional = profileWithoutConfigHash as TrustedProfile;
  const profile: TrustedProfile = {
    ...provisional,
    configSha256: computeTrustedProfileConfigHash(provisional),
  };
  const unsealed: TrustBundle = {
    schemaVersion: "1.0.0",
    createdAt: FIXED_TIME,
    profile,
    endpoints: [endpoint],
    operations: [operation],
    adapters: [adapter],
    integrity: {
      hashContractVersion: "sha256-jcs-v1",
      algorithm: "sha256",
      canonicalization: "RFC8785",
      contentSha256: "0".repeat(64) as Sha256,
    },
  };
  return { ...unsealed, integrity: computeIntegrity(unsealed) };
}

export interface TestSigningKeyFile {
  path: string;
  publicKeyPem: string;
}

export function writeTrustRoot(
  parent: string,
  bundle = makeTrustBundle(),
  providerRuntime?: unknown,
  signingKeys: readonly TestSigningKeyFile[] = [],
): string {
  const root = join(parent, "trust-root");
  mkdirSync(root, { mode: 0o700 });
  chmodSync(root, 0o700);
  const bundleText = stringify(bundle, { lineWidth: 0 });
  const bundleBytes = Buffer.from(bundleText, "utf8");
  const bundlePath = join(root, "trust-bundle.yaml");
  writeFileSync(bundlePath, bundleBytes, { mode: 0o600 });
  chmodSync(bundlePath, 0o600);
  const files = [
    {
      role: "TRUST_BUNDLE",
      path: "trust-bundle.yaml",
      bytes: bundleBytes.byteLength,
      sha256: sha256Bytes(bundleBytes),
    },
  ];
  if (providerRuntime !== undefined) {
    const runtimeText = stringify(providerRuntime, { lineWidth: 0 });
    const runtimeBytes = Buffer.from(runtimeText, "utf8");
    const runtimePath = join(root, "provider-runtime.yaml");
    writeFileSync(runtimePath, runtimeBytes, { mode: 0o600 });
    chmodSync(runtimePath, 0o600);
    files.push({
      role: "PROVIDER_RUNTIME",
      path: "provider-runtime.yaml",
      bytes: runtimeBytes.byteLength,
      sha256: sha256Bytes(runtimeBytes),
    });
  }
  for (const signingKey of signingKeys) {
    if (signingKey.path.includes("/") || signingKey.path.includes("\\")) {
      throw new Error("Test signing key path must be a top-level filename");
    }
    const keyBytes = Buffer.from(signingKey.publicKeyPem, "utf8");
    const keyPath = join(root, signingKey.path);
    writeFileSync(keyPath, keyBytes, { mode: 0o600 });
    chmodSync(keyPath, 0o600);
    files.push({
      role: "SIGNING_KEY",
      path: signingKey.path,
      bytes: keyBytes.byteLength,
      sha256: sha256Bytes(keyBytes),
    });
  }
  const manifest = {
    schemaVersion: "1.0.0",
    rootId: "test-root",
    createdAt: FIXED_TIME,
    files,
  };
  const manifestPath = join(root, "manifest.yaml");
  writeFileSync(manifestPath, stringify(manifest, { lineWidth: 0 }), { mode: 0o600 });
  chmodSync(manifestPath, 0o600);
  return root;
}
