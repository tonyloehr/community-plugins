import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import {
  existsSync,
  fstatSync,
  lstatSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import test from "node:test";

import { HashPinnedMacOsKeychainLoader } from "../../packages/grafana-credential-profile/src/macos-keychain-loader.ts";

class AsyncEntry {
  async getSecret(): Promise<undefined> { return undefined; }
  async setSecret(): Promise<void> { /* test-only addon */ }
  async deleteCredential(): Promise<boolean> { return false; }
}

for (const failImport of [false, true]) {
  test(`native staging remains linked through ${failImport ? "failed" : "successful"} import`, async (t) => {
    const parent = mkdtempSync(join(tmpdir(), "grafana-linked-inode-test-"));
    t.after(() => rmSync(parent, { force: true, recursive: true }));
    const filename = "keyring.darwin-arm64.node";
    const sourcePath = join(parent, filename);
    const source = Buffer.from("synthetic-native-addon-fixture", "ascii");
    writeFileSync(sourcePath, source, { mode: 0o400 });
    let importedPath = "";
    let stagedPath = "";
    let stagedDirectory = "";
    const loader = new HashPinnedMacOsKeychainLoader({
      platform: "darwin",
      architecture: "arm64",
      asset: {
        fileUrl: pathToFileURL(sourcePath),
        bytes: source.byteLength,
        sha256: createHash("sha256").update(source).digest("hex"),
      },
      importer(absolutePath) {
        importedPath = absolutePath;
        assert.match(absolutePath, /^\/dev\/fd\/\d+$/u);
        const held = fstatSync(Number(absolutePath.split("/").at(-1)));
        assert.equal(held.nlink, 1, "macOS code signing requires a linked Mach-O inode");
        assert.equal(held.mode & 0o777, 0o400);
        assert.deepEqual(readFileSync(absolutePath), source);
        for (const entry of readdirSync(tmpdir(), { withFileTypes: true })) {
          if (!entry.isDirectory() || !entry.name.startsWith("codex-observability-keyring-")) continue;
          const candidate = join(tmpdir(), entry.name, filename);
          if (!existsSync(candidate)) continue;
          const metadata = statSync(candidate);
          if (metadata.dev === held.dev && metadata.ino === held.ino) {
            stagedPath = candidate;
            stagedDirectory = join(tmpdir(), entry.name);
            break;
          }
        }
        assert.notEqual(stagedPath, "", "verified staged inode must remain named during import");
        const directory = lstatSync(stagedDirectory);
        assert.equal(directory.isSymbolicLink(), false);
        assert.equal(directory.mode & 0o777, 0o700);
        if (typeof process.getuid === "function") assert.equal(directory.uid, process.getuid());
        if (failImport) throw new Error("synthetic import failure");
        return { AsyncEntry };
      },
    });
    if (failImport) await assert.rejects(loader.load(), /native OS keyring backend is unavailable/u);
    else assert.equal((await loader.load()).backendKind, "MACOS_KEYCHAIN");
    assert.notEqual(importedPath, "");
    assert.equal(existsSync(importedPath), false, "the held descriptor must close");
    assert.equal(existsSync(stagedPath), false, "the staged file must be removed");
    assert.equal(existsSync(stagedDirectory), false, "the private directory must be removed");
    assert.equal(existsSync(sourcePath), true, "the packaged source asset is preserved");
  });
}

test("the pinned native ABI accepts missing values and copies then erases byte arrays", async (t) => {
  const parent = mkdtempSync(join(tmpdir(), "grafana-native-abi-test-"));
  t.after(() => rmSync(parent, { force: true, recursive: true }));
  const source = Buffer.from("synthetic-native-abi-fixture", "ascii");
  const sourcePath = join(parent, "keyring.darwin-arm64.node");
  writeFileSync(sourcePath, source, { mode: 0o400 });
  let raw: unknown;
  class AbiEntry {
    async getSecret(): Promise<unknown> { return raw; }
    async setSecret(): Promise<void> { /* test-only addon */ }
    async deleteCredential(): Promise<boolean> { return false; }
  }
  const module = await new HashPinnedMacOsKeychainLoader({
    platform: "darwin", architecture: "arm64",
    asset: {
      fileUrl: pathToFileURL(sourcePath), bytes: source.byteLength,
      sha256: createHash("sha256").update(source).digest("hex"),
    },
    importer() { return { AsyncEntry: AbiEntry }; },
  }).load();
  const entry = module.createEntry("synthetic-service", "synthetic-account");

  for (const missing of [undefined, null]) {
    raw = missing;
    assert.equal(await entry.getSecret(), undefined);
  }
  for (const value of [[0, 65, 255], Uint8Array.from([0, 65, 255])]) {
    raw = value;
    const copied = await entry.getSecret();
    assert.deepEqual(copied, Uint8Array.from([0, 65, 255]));
    assert.notEqual(copied, value);
    assert.deepEqual(Array.from(value), [0, 0, 0]);
    copied?.fill(0);
  }

  const sparse = [65, 66];
  delete sparse[0];
  let accessorReads = 0;
  const accessor = [65];
  Object.defineProperty(accessor, "0", { get() { accessorReads += 1; return 65; }, configurable: true });
  const extraProperty = Object.assign([65], { extra: true });
  for (const malformed of [[], [256], [-1], [1.5], [Number.NaN], ["65"], sparse, accessor, extraProperty, Array(16_385).fill(65), {}, "not-bytes"]) {
    raw = malformed;
    await assert.rejects(entry.getSecret(), /native OS keyring backend is unavailable/u);
    if (Array.isArray(malformed)) {
      for (const name of Object.getOwnPropertyNames(malformed)) {
        const property = Object.getOwnPropertyDescriptor(malformed, name);
        if (/^(?:0|[1-9][0-9]*)$/u.test(name) && property !== undefined && "value" in property && property.writable === true) {
          assert.equal(property.value, 0, "rejected native array bytes are erased");
        }
      }
    }
  }
  assert.equal(accessorReads, 0, "native ABI validation must not invoke array accessors");
});
