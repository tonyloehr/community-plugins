import assert from "node:assert/strict";
import test from "node:test";

import { runObservabilityCliEntrypoint } from "../../packages/observability-cli/src/entrypoint.ts";
import {
  OBSERVABILITY_CLI_VERSION,
  observabilityCliHelp,
  observabilityCliInformation,
} from "../../packages/observability-cli/src/help.ts";

test("help and version do not construct or read a platform credential backend", async () => {
  for (const platform of ["linux", "win32", "darwin"] as const) {
    for (const argv of [[], ["--help"], ["--version"]]) {
      let stdout = "";
      let stderr = "";
      let loaderReads = 0;
      const status = await runObservabilityCliEntrypoint({
        argv,
        platform,
        get nativeLoader(): never {
          loaderReads += 1;
          throw new Error("informational command touched the credential backend");
        },
        io: {
          stdin: process.stdin,
          stdout: { write(value) { stdout += value; } },
          stderr: { write(value) { stderr += value; } },
        },
      });
      assert.equal(status, 0);
      assert.equal(stdout, argv[0] === "--version" ? `${OBSERVABILITY_CLI_VERSION}\n` : observabilityCliHelp());
      assert.equal(stderr, "");
      assert.equal(loaderReads, 0);
    }
  }
});

test("unsupported platforms still reject credential commands before state or network access", async () => {
  for (const platform of ["linux", "win32"] as const) {
    await assert.rejects(
      runObservabilityCliEntrypoint({ argv: ["grafana", "status"], platform }),
      /native OS keyring backend is unavailable/u,
    );
  }
  assert.equal(observabilityCliInformation(["--help", "--version"]), undefined);
  assert.equal(observabilityCliInformation(["grafana", "--help"]), undefined);
});
