import assert from "node:assert/strict";
import test from "node:test";

import {
  GrafanaAdapter,
  grafanaAdapterPackage,
  grafanaCatalogEntryHash,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaHttpRequest,
} from "../../adapters/grafana/src/index.ts";
import { normalizeGrafanaNativeResponse } from "../../adapters/grafana/src/native-response.ts";
import { normalizeGrafanaFrames } from "../../adapters/grafana/src/frame-normalizer.ts";
import { createBudgetController, type AdapterExecutionContext } from "../../packages/adapter-sdk/src/index.ts";
import { computeOperationDefinitionHash, type OperationSnapshot, type Sha256 } from "../../packages/contracts/src/index.ts";

const NOW = "2026-08-20T12:00:00.000Z";
const TIME = Date.parse(NOW) - 1_000;
const LIMITS = { timeoutMs: 5_000, maxAgeMs: 60_000, maxBytes: 100_000, maxRows: 20, maxSeries: 10, maxPoints: 100 };

function context(limits = LIMITS): AdapterExecutionContext {
  const signal = new AbortController().signal;
  return {
    origin: "SIMULATED",
    scope: { environment: "simulation", service: "checkout" },
    window: { start: "2026-08-20T11:55:00.000Z", end: NOW },
    clock: { now: () => new Date(NOW) },
    budget: createBudgetController(limits, signal),
    signal,
  };
}

function tempoEntry(): GrafanaDatasourceQueryCatalogEntry {
  return {
    id: "native-tempo", route: "datasource-query", outputName: "slow_traces",
    datasourceUid: "reviewed-tempo", datasourceIdentitySha256: "1".repeat(64) as Sha256,
    target: {
      datasourceType: "tempo", expression: '{ resource.deployment.environment = "simulation" && resource.service.name = "checkout" && duration > 1s }',
      queryType: "traceql", limit: 10, spansPerSpanSet: 10, tableType: "traces",
    },
    frame: {
      resultKind: "EVENT",
      fields: [
        { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
        { sourceName: "Summary", outputName: "summary", type: "string", role: "SUMMARY" },
        { sourceName: "Duration", outputName: "duration_ms", type: "number", role: "ATTRIBUTE" },
        { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
        { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      ],
      allowedLabels: [],
    },
    minIntervalMs: 1_000,
    scope: { environment: "simulation", service: "checkout" },
    scopeMappings: { environment: "environment", service: "service" },
  };
}

function tempoResponse() {
  return { traces: [{
    traceID: "1".repeat(32), rootServiceName: "checkout", rootTraceName: "checkout.bank_transfer",
    startTimeUnixNano: String(BigInt(TIME) * 1_000_000n), durationMs: 1_250,
    spanSets: [{ spans: [{
      spanID: "2".repeat(16), startTimeUnixNano: String(BigInt(TIME) * 1_000_000n), durationNanos: "1250000000",
      attributes: [
        { key: "deployment.environment", value: { stringValue: "simulation" } },
        { key: "service.name", value: { stringValue: "checkout" } },
      ],
    }] }],
  }] };
}

function snapshot(entry: GrafanaDatasourceQueryCatalogEntry): OperationSnapshot {
  const semantic = {
    operationId: "grafana.apm.traces.slow" as OperationSnapshot["operationId"], revision: 1,
    definition: {
      domain: "TRACES" as const, sourceAlias: "grafana-test", adapterPackageId: grafanaAdapterPackage.packageId,
      adapterOperation: "grafana.datasource.query.read", authority: "CORROBORATING" as const,
      sanitizedProviderDefinition: { catalogEntryId: entry.id, catalogEntrySha256: grafanaCatalogEntryHash(entry) },
      expectedSourceLineage: { accessPath: "GRAFANA" as const, datasourceType: "tempo" as const, sourceIdentitySha256: entry.datasourceIdentitySha256 },
      scopeMapping: { ...entry.scopeMappings }, allowedDimensions: ["environment", "service"],
      requiredProviderScopes: ["environment", "service"], sensitivity: "INTERNAL" as const, limits: LIMITS,
      normalization: { resultKind: "EVENT" as const, dimensionMappings: {} },
    },
  };
  return { schemaVersion: "1.0.0", ...semantic, capturedAt: NOW, definitionSha256: computeOperationDefinitionHash(semantic) };
}

async function* json(value: unknown) { yield Buffer.from(JSON.stringify(value)); }

test("Tempo uses only the enrolled fixed read proxy and verifies actual matching-span scope", async () => {
  const entry = tempoEntry();
  const requests: GrafanaHttpRequest[] = [];
  const adapter = new GrafanaAdapter({ catalog: { entries: [entry] }, transport: {
    async request(request) {
      requests.push(request);
      return { status: 200, body: json(request.path === "/api/health" ? { database: "ok", version: "12.1.0" } : tempoResponse()) };
    },
  } });
  const compiled = await adapter.compile(snapshot(entry), { adapterPackage: grafanaAdapterPackage, maxDefinitionBytes: 100_000 });
  const result = await adapter.execute(context(), compiled);
  assert.equal(result.collectionState, "COMPLETE");
  assert.equal(result.records[0]?.kind, "EVENT");
  assert.equal(requests.length, 2);
  const request = requests[1]!;
  assert.equal(request.method, "GET");
  assert.equal(request.path, "/api/datasources/proxy/uid/reviewed-tempo/api/search");
  assert.deepEqual(request.query, {
    q: entry.target.datasourceType === "tempo" ? entry.target.expression : "",
    start: String(Date.parse("2026-08-20T11:55:00.000Z") / 1_000), end: String(Date.parse(NOW) / 1_000),
    limit: "10", spss: "10",
  });
  assert.equal("body" in request, false);
  await assert.rejects(adapter.execute(context(), {
    ...compiled, binding: { ...compiled.binding, datasourceUid: "arbitrary-route" } as typeof compiled.binding,
  }));
  assert.equal(requests.length, 2, "a modified binding cannot produce another provider request");
  assert.throws(() => new GrafanaAdapter({
    catalog: { entries: [{ ...entry, datasourceUid: "bad/../../proxy" }] },
    transport: { async request() { throw new Error("must not run"); } },
  }));
});

test("Tempo never substitutes requested scope or rootServiceName for matching-span evidence", () => {
  for (const mode of ["wrong-environment", "missing-service", "duplicate-service", "empty-spans"] as const) {
    const body = tempoResponse();
    const span = body.traces[0]!.spanSets[0]!.spans[0]!;
    if (mode === "wrong-environment") span.attributes[0]!.value.stringValue = "another-environment";
    if (mode === "missing-service") span.attributes.pop();
    if (mode === "duplicate-service") span.attributes.push({ key: "service.name", value: { stringValue: "checkout" } });
    if (mode === "empty-spans") body.traces[0]!.spanSets[0]!.spans = [];
    assert.throws(() => normalizeGrafanaNativeResponse(body, tempoEntry(), context()), /Grafana native response/u, mode);
  }
});

test("Tempo enforces the effective request limits, not only the larger enrolled maxima", () => {
  const traces = tempoResponse();
  traces.traces.push({ ...structuredClone(traces.traces[0]!), traceID: "3".repeat(32) });
  assert.throws(() => normalizeGrafanaNativeResponse(traces, tempoEntry(), context({ ...LIMITS, maxRows: 1 })), /Tempo search envelope/u);
  const spans = tempoResponse();
  const set = spans.traces[0]!.spanSets[0]!;
  set.spans.push({ ...structuredClone(set.spans[0]!), spanID: "4".repeat(16) });
  assert.throws(() => normalizeGrafanaNativeResponse(spans, tempoEntry(), context({ ...LIMITS, maxRows: 1 })), /Tempo span set/u);
});

function lokiEntry(): GrafanaDatasourceQueryCatalogEntry {
  return {
    ...tempoEntry(), id: "native-loki", outputName: "error_codes", datasourceUid: "reviewed-loki",
    target: { datasourceType: "loki", expression: '{environment="simulation",service="checkout"} | json | status_code = 503', queryType: "range", direction: "backward" },
    frame: {
      resultKind: "EVENT",
      fields: [
        { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
        { sourceName: "Line", outputName: "summary", type: "string", role: "SUMMARY" },
        { sourceName: "status_code", outputName: "status_code", type: "number", role: "ATTRIBUTE" },
        { sourceName: "environment", outputName: "environment", type: "string", role: "DIMENSION" },
        { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      ], allowedLabels: [],
    },
  };
}

function lokiResponse(): { results: { A: { frames: Array<{ schema: { refId: string; fields: Array<{ name: string; type: string }> }; data: { values: unknown[][] } }> } } } {
  return { results: { A: { frames: [{
    schema: { refId: "A", fields: [
      { name: "labels", type: "other" }, { name: "Time", type: "time" }, { name: "Line", type: "string" },
      { name: "tsNs", type: "string" }, { name: "labelTypes", type: "other" }, { name: "id", type: "string" },
    ] },
    data: { values: [
      [{ environment: "simulation", service: "checkout", status_code: "503" }], [TIME], ["checkout payment timeout"],
      [String(BigInt(TIME) * 1_000_000n)], [{ environment: "I", service: "I", status_code: "P" }], ["bounded-id"],
    ] },
  }] } } };
}

test("native Loki JSON labels project only enrolled primitive fields and prove each row's scope", () => {
  const entry = lokiEntry();
  const ctx = context();
  const result = normalizeGrafanaFrames(normalizeGrafanaNativeResponse(lokiResponse(), entry, ctx), entry, ctx);
  assert.equal(result.records.length, 1);
  assert.deepEqual(result.records[0], {
    kind: "EVENT", name: "error_codes", occurredAt: new Date(TIME).toISOString(), summary: "checkout payment timeout",
    attributes: { status_code: 503, environment: "simulation", service: "checkout" },
  });
  for (const mode of ["malformed-labels", "wrong-scope", "extra-field", "unequal-columns"] as const) {
    const body = lokiResponse();
    const frame = body.results.A.frames[0]!;
    if (mode === "malformed-labels") frame.data.values[0]![0] = { environment: 7, service: "checkout" };
    if (mode === "wrong-scope") frame.data.values[0]![0] = { environment: "other", service: "checkout", status_code: "503" };
    if (mode === "extra-field") {
      frame.schema.fields.push({ name: "unexpected", type: "string" }); frame.data.values.push(["canary"]);
    }
    if (mode === "unequal-columns") frame.data.values[2]!.push("extra");
    const current = context();
    assert.throws(() => normalizeGrafanaFrames(normalizeGrafanaNativeResponse(body, entry, current), entry, current), /Grafana/u, mode);
  }
});

test("Loki projection aliases cannot overwrite a conflicting native scope label", () => {
  const base = lokiEntry();
  const entry: GrafanaDatasourceQueryCatalogEntry = {
    ...base,
    target: { datasourceType: "loki", expression: '{body="simulation",service="checkout"}', queryType: "range", direction: "backward" },
    scopeMappings: { environment: "body", service: "service" },
    frame: {
      resultKind: "EVENT", allowedLabels: [], eventSummary: "Reviewed log line",
      fields: [
        { sourceName: "Time", outputName: "observed_at", type: "time", role: "TIME" },
        { sourceName: "body", outputName: "environment", type: "string", role: "DIMENSION" },
        { sourceName: "service", outputName: "service", type: "string", role: "DIMENSION" },
      ],
    },
  };
  const body = lokiResponse();
  body.results.A.frames[0]!.data.values[0]![0] = { body: "outside-scope", service: "checkout" };
  body.results.A.frames[0]!.data.values[2]![0] = "simulation";
  assert.throws(() => normalizeGrafanaNativeResponse(body, entry, context()), /Loki log row does not prove/u);
});
