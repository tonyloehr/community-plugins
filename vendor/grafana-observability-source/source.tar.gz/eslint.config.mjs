import eslint from "@eslint/js";
import tseslint from "typescript-eslint";

const nodeGlobals = {
  Buffer: "readonly",
  console: "readonly",
  process: "readonly",
  setTimeout: "readonly",
};

export default tseslint.config(
  {
    ignores: [
      "coverage/**",
      "dist/**",
      "**/dist/**",
      "node_modules/**",
      "plugins/production-monitoring/mcp/**/*.mjs",
      "plugins/production-monitoring/scripts/pmctl.mjs",
      "plugins/production-monitoring/workers/**/*.mjs",
    ],
  },
  eslint.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ["**/*.{js,mjs,cjs,ts,mts,cts}"],
    languageOptions: {
      ecmaVersion: 2022,
      globals: nodeGlobals,
      sourceType: "module",
    },
    rules: {
      "no-console": "off",
    },
  },
);
