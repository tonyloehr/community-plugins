export * from "./alertmanager-adapter.ts";
