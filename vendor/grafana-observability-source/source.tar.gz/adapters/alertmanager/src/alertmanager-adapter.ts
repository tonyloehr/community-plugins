import {
  canonicalJson,
  computeOperationDefinitionHash,
  type AdapterPackage,
  type AdapterPackageId,
  type JsonObject,
  type JsonPrimitive,
  type OperationDefinition,
  type OperationId,
  type OperationLimits,
  type OperationSnapshot,
  type Pagination,
  type SanitizedError,
} from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  type AdapterCompileContext,
  type AdapterDoctorContext,
  type AdapterDoctorResult,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderEvent,
  type ProviderResult,
  type ProviderTable,
  type ProviderValue,
} from "../../../packages/adapter-sdk/src/index.ts";

export const ALERTMANAGER_ADAPTER_PACKAGE_ID = "adapter.alertmanager.v1" as AdapterPackageId;

export const alertmanagerAdapterPackage: AdapterPackage = {
  schemaVersion: "1.0.0",
  packageId: ALERTMANAGER_ADAPTER_PACKAGE_ID,
  name: "Read-only Alertmanager evidence adapter",
  version: "1.0.0",
  protocolVersion: "1.0",
  publisher: { name: "Codex Production Monitoring" },
  entrypoint: { kind: "BUILTIN", registryKey: "alertmanager-readonly-v1" },
  domains: ["ALERTS", "RUNTIME"],
  capabilities: [
    "alertmanager.status.read",
    "alertmanager.alerts.read",
    "alertmanager.silences.read",
  ],
  providerCompatibility: [{ provider: "prometheus-alertmanager", versions: ">=0.25 <1" }],
  supportedContractVersions: ["1.0.0"],
  conformance: ["CORE_READ", "ALERTS", "RUNTIME"],
};

export interface AlertmanagerEndpointBinding {
  endpointId: string;
  baseUrl: string;
}

export interface AlertmanagerAlertFilters {
  active?: boolean;
  silenced?: boolean;
  inhibited?: boolean;
  unprocessed?: boolean;
  filter?: readonly string[];
}

interface AlertmanagerCatalogBindingBase {
  bindingId: string;
  endpointId: string;
  maxBytes: number;
  maxItems: number;
}

export interface AlertmanagerStatusBinding extends AlertmanagerCatalogBindingBase {
  operation: "alertmanager.status";
}

export interface AlertmanagerAlertsBinding extends AlertmanagerCatalogBindingBase {
  operation: "alertmanager.alerts";
  filters?: AlertmanagerAlertFilters;
}

export interface AlertmanagerSilencesBinding extends AlertmanagerCatalogBindingBase {
  operation: "alertmanager.silences.read";
}

export type AlertmanagerCatalogBinding =
  | AlertmanagerStatusBinding
  | AlertmanagerAlertsBinding
  | AlertmanagerSilencesBinding;

export interface AlertmanagerTransportRequest {
  method: "GET";
  endpointId: string;
  url: string;
  headers: Readonly<{ Accept: "application/json" }>;
  maxBytes: number;
  signal: AbortSignal;
}

export interface AlertmanagerTransportResponse {
  status: number;
  headers?: Readonly<Record<string, string>>;
  body: string | Uint8Array;
}

export interface AlertmanagerTransport {
  request(
    request: Readonly<AlertmanagerTransportRequest>,
  ): Promise<AlertmanagerTransportResponse>;
}

export interface AlertmanagerAdapterOptions {
  endpoints: readonly AlertmanagerEndpointBinding[];
  catalog: readonly AlertmanagerCatalogBinding[];
  transport: AlertmanagerTransport;
}

interface TrustedEndpoint {
  endpointId: string;
  baseUrl: string;
}

type AlertmanagerCompiledBinding = JsonObject & {
  bindingId: string;
  endpointId: string;
  operation:
    | "alertmanager.status"
    | "alertmanager.alerts"
    | "alertmanager.silences.read";
  maxBytes: number;
  maxItems: number;
  filters?: JsonObject;
};

const descriptor = {
  packageId: ALERTMANAGER_ADAPTER_PACKAGE_ID,
  name: alertmanagerAdapterPackage.name,
  version: alertmanagerAdapterPackage.version,
  provider: "prometheus-alertmanager",
  domains: ["ALERTS", "RUNTIME"] as const,
  operations: [
    "alertmanager.status",
    "alertmanager.alerts",
    "alertmanager.silences.read",
  ] as const,
  resultSchemaVersions: ["1.0.0"] as const,
};

const SAFE_IDENTIFIER = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u;
const ROUTES = {
  "alertmanager.status": "api/v2/status",
  "alertmanager.alerts": "api/v2/alerts",
  "alertmanager.silences.read": "api/v2/silences",
} as const;
const ALERT_STATES = new Set(["active", "suppressed", "unprocessed"]);
const SILENCE_STATES = new Set(["pending", "active", "expired"]);

function hasAsciiControl(value: string): boolean {
  return [...value].some((character) => {
    const code = character.charCodeAt(0);
    return code <= 0x1f || code === 0x7f;
  });
}

function replaceUnsafeControls(value: string): string {
  return [...value]
    .map((character) => {
      const code = character.charCodeAt(0);
      return code <= 0x08 || code === 0x0b || code === 0x0c || (code >= 0x0e && code <= 0x1f) || code === 0x7f
        ? "�"
        : character;
    })
    .join("");
}

function assertPositiveInteger(value: number, label: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new AdapterContractError(`${label} must be a positive safe integer`);
  }
}

function assertCatalogBounds(binding: AlertmanagerCatalogBinding): void {
  if (binding.maxBytes > 1_073_741_824) {
    throw new AdapterContractError("Alertmanager maxBytes is too large");
  }
  if (binding.maxItems > 1_000_000) {
    throw new AdapterContractError("Alertmanager maxItems is too large");
  }
}

function trustedEndpoint(binding: AlertmanagerEndpointBinding): TrustedEndpoint {
  if (!SAFE_IDENTIFIER.test(binding.endpointId)) {
    throw new AdapterContractError("Alertmanager endpointId is invalid");
  }
  let url: URL;
  try {
    url = new URL(binding.baseUrl);
  } catch {
    throw new AdapterContractError("Alertmanager endpoint URL is invalid");
  }
  const loopback = ["localhost", "127.0.0.1", "[::1]", "::1"].includes(url.hostname);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) {
    throw new AdapterContractError("Alertmanager endpoint requires HTTPS except on loopback");
  }
  if (url.username !== "" || url.password !== "" || url.search !== "" || url.hash !== "") {
    throw new AdapterContractError("Alertmanager endpoint cannot embed credentials, query, or fragment");
  }
  const normalizedPath = url.pathname.endsWith("/") ? url.pathname : `${url.pathname}/`;
  if (normalizedPath.split("/").includes("..")) {
    throw new AdapterContractError("Alertmanager endpoint path is invalid");
  }
  url.pathname = normalizedPath;
  return { endpointId: binding.endpointId, baseUrl: url.toString() };
}

function cloneFilters(filters: AlertmanagerAlertFilters | undefined): AlertmanagerAlertFilters {
  if (filters === undefined) return {};
  const allowed = new Set(["active", "silenced", "inhibited", "unprocessed", "filter"]);
  for (const key of Object.keys(filters)) {
    if (!allowed.has(key)) throw new AdapterContractError(`Unsupported Alertmanager filter: ${key}`);
  }
  const expressions = filters.filter ?? [];
  if (expressions.length > 16) throw new AdapterContractError("Too many Alertmanager match filters");
  for (const expression of expressions) {
    if (
      typeof expression !== "string" ||
      expression.length === 0 ||
      expression.length > 256 ||
      hasAsciiControl(expression)
    ) {
      throw new AdapterContractError("Alertmanager match filter is invalid");
    }
  }
  for (const value of [
    filters.active,
    filters.silenced,
    filters.inhibited,
    filters.unprocessed,
  ]) {
    if (value !== undefined && typeof value !== "boolean") {
      throw new AdapterContractError("Alertmanager boolean filter is invalid");
    }
  }
  return Object.freeze({
    ...(filters.active === undefined ? {} : { active: filters.active }),
    ...(filters.silenced === undefined ? {} : { silenced: filters.silenced }),
    ...(filters.inhibited === undefined ? {} : { inhibited: filters.inhibited }),
    ...(filters.unprocessed === undefined ? {} : { unprocessed: filters.unprocessed }),
    ...(expressions.length === 0 ? {} : { filter: Object.freeze([...expressions]) }),
  });
}

function cloneBinding(
  binding: AlertmanagerCatalogBinding,
  endpoints: ReadonlyMap<string, TrustedEndpoint>,
): AlertmanagerCatalogBinding {
  if (!SAFE_IDENTIFIER.test(binding.bindingId)) {
    throw new AdapterContractError("Alertmanager bindingId is invalid");
  }
  if (!endpoints.has(binding.endpointId)) {
    throw new AdapterContractError("Alertmanager binding references an unknown endpoint");
  }
  assertPositiveInteger(binding.maxBytes, "Alertmanager maxBytes");
  assertPositiveInteger(binding.maxItems, "Alertmanager maxItems");
  assertCatalogBounds(binding);
  if (binding.operation === "alertmanager.alerts") {
    return Object.freeze({ ...binding, filters: cloneFilters(binding.filters) });
  }
  if (
    binding.operation !== "alertmanager.status" &&
    binding.operation !== "alertmanager.silences.read"
  ) {
    throw new AdapterContractError("Unsupported Alertmanager operation");
  }
  if (Object.hasOwn(binding, "filters")) {
    throw new AdapterContractError("Only the alerts route accepts compiled filters");
  }
  return Object.freeze({ ...binding });
}

function filtersAsJson(filters: AlertmanagerAlertFilters | undefined): JsonObject | undefined {
  if (filters === undefined) return undefined;
  return {
    ...(filters.active === undefined ? {} : { active: filters.active }),
    ...(filters.silenced === undefined ? {} : { silenced: filters.silenced }),
    ...(filters.inhibited === undefined ? {} : { inhibited: filters.inhibited }),
    ...(filters.unprocessed === undefined ? {} : { unprocessed: filters.unprocessed }),
    ...(filters.filter === undefined ? {} : { filter: [...filters.filter] }),
  };
}

function buildUrl(endpoint: TrustedEndpoint, binding: AlertmanagerCompiledBinding): string {
  const url = new URL(ROUTES[binding.operation], endpoint.baseUrl);
  if (binding.operation === "alertmanager.alerts") {
    const filters = binding.filters ?? {};
    for (const key of ["active", "silenced", "inhibited", "unprocessed"] as const) {
      const value = filters[key];
      if (typeof value === "boolean") url.searchParams.set(key, String(value));
    }
    const matchers = filters.filter;
    if (Array.isArray(matchers)) {
      for (const matcher of matchers) {
        if (typeof matcher !== "string") throw new AdapterContractError("Compiled matcher drifted");
        url.searchParams.append("filter", matcher);
      }
    }
  }
  return url.toString();
}

function responseBody(response: AlertmanagerTransportResponse): Uint8Array {
  return typeof response.body === "string" ? Buffer.from(response.body, "utf8") : response.body;
}

function header(response: AlertmanagerTransportResponse, name: string): string | undefined {
  const match = Object.entries(response.headers ?? {}).find(
    ([key]) => key.toLowerCase() === name.toLowerCase(),
  );
  return match?.[1];
}

function errorForStatus(status: number): SanitizedError {
  if (status === 401) {
    return {
      code: "alertmanager.authentication",
      category: "AUTHENTICATION",
      message: "Alertmanager authentication failed",
      retryable: false,
      providerStatus: status,
    };
  }
  if (status === 403) {
    return {
      code: "alertmanager.authorization",
      category: "AUTHORIZATION",
      message: "Alertmanager read access is not authorized",
      retryable: false,
      providerStatus: status,
    };
  }
  if (status === 429) {
    return {
      code: "alertmanager.rate_limit",
      category: "RATE_LIMIT",
      message: "Alertmanager rate limit reached",
      retryable: true,
      providerStatus: status,
    };
  }
  return {
    code: "alertmanager.http_error",
    category: status >= 500 ? "UNAVAILABLE" : "INVALID_RESPONSE",
    message: "Alertmanager returned an unsuccessful status",
    retryable: status >= 500,
    providerStatus: status,
  };
}

function errorResult(
  operation: AlertmanagerCompiledBinding["operation"],
  evaluatedAt: string,
  error: SanitizedError,
  pagination: Pagination,
): ProviderResult {
  return {
    schemaVersion: "1.0.0",
    collectionState: "ERROR",
    evaluatedAt,
    nativeResultType: operation,
    nativeDimensions: {},
    records: [],
    pagination,
    warnings: [],
    error,
  };
}

function plainObject(value: unknown, label: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new AdapterContractError(`${label} is not an object`);
  }
  return value as Record<string, unknown>;
}

function requiredString(object: Record<string, unknown>, key: string, label: string): string {
  const value = object[key];
  if (typeof value !== "string" || value.length === 0) {
    throw new AdapterContractError(`${label}.${key} is not a non-empty string`);
  }
  return value;
}

function timestamp(value: string, label: string): string {
  if (!Number.isFinite(Date.parse(value))) throw new AdapterContractError(`${label} is not a timestamp`);
  return value;
}

function safeText(value: string, maximum: number): string {
  return replaceUnsafeControls(value)
    .replaceAll(/\s+/gu, " ")
    .trim()
    .slice(0, maximum);
}

function stringMap(value: unknown, label: string): Record<string, string> {
  const object = plainObject(value, label);
  const result: Record<string, string> = {};
  for (const [key, member] of Object.entries(object)) {
    if (typeof member !== "string") throw new AdapterContractError(`${label}.${key} is not a string`);
    result[key] = member;
  }
  return result;
}

function normalizeStatus(value: unknown): ProviderTable {
  const document = plainObject(value, "status response");
  const cluster = plainObject(document.cluster, "status response.cluster");
  const versionInfo = plainObject(document.versionInfo, "status response.versionInfo");
  const state = safeText(requiredString(cluster, "status", "status response.cluster"), 64);
  const version = safeText(requiredString(versionInfo, "version", "status response.versionInfo"), 128);
  const peers = cluster.peers;
  if (peers !== undefined && !Array.isArray(peers)) {
    throw new AdapterContractError("status response.cluster.peers is not an array");
  }
  return {
    kind: "TABLE",
    name: "alertmanager.status",
    columns: [
      { name: "cluster.status", type: "STRING" },
      { name: "cluster.peers", type: "NUMBER" },
      { name: "version", type: "STRING" },
    ],
    rows: [[state, peers?.length ?? 0, version]],
  };
}

function normalizeAlert(value: unknown, index: number): ProviderEvent {
  const alert = plainObject(value, `alerts[${index}]`);
  const labels = stringMap(alert.labels, `alerts[${index}].labels`);
  const annotations =
    alert.annotations === undefined
      ? {}
      : stringMap(alert.annotations, `alerts[${index}].annotations`);
  const status = plainObject(alert.status, `alerts[${index}].status`);
  const state = requiredString(status, "state", `alerts[${index}].status`);
  if (!ALERT_STATES.has(state)) throw new AdapterContractError("Alertmanager alert state drifted");
  const startsAt = timestamp(requiredString(alert, "startsAt", `alerts[${index}]`), "alert startsAt");
  const alertName = labels.alertname;
  if (alertName === undefined || alertName.length === 0) {
    throw new AdapterContractError("Alertmanager alert omitted alertname");
  }
  const attributes: Record<string, JsonPrimitive> = {
    state,
    alertname: safeText(alertName, 512),
  };
  for (const key of ["severity", "service", "namespace"] as const) {
    if (labels[key] !== undefined) attributes[key] = safeText(labels[key], 512);
  }
  if (typeof alert.endsAt === "string" && alert.endsAt.length > 0) {
    attributes.endsAt = timestamp(alert.endsAt, "alert endsAt");
  }
  const summary = safeText(annotations.summary ?? annotations.description ?? alertName, 2048);
  return {
    kind: "EVENT",
    name: "alert",
    occurredAt: startsAt,
    summary: summary.length === 0 ? safeText(alertName, 2048) : summary,
    attributes,
  };
}

function normalizeSilence(value: unknown, index: number): ProviderEvent {
  const silence = plainObject(value, `silences[${index}]`);
  requiredString(silence, "id", `silences[${index}]`);
  const status = plainObject(silence.status, `silences[${index}].status`);
  const state = requiredString(status, "state", `silences[${index}].status`);
  if (!SILENCE_STATES.has(state)) throw new AdapterContractError("Alertmanager silence state drifted");
  const startsAt = timestamp(
    requiredString(silence, "startsAt", `silences[${index}]`),
    "silence startsAt",
  );
  const endsAt = timestamp(
    requiredString(silence, "endsAt", `silences[${index}]`),
    "silence endsAt",
  );
  const updatedAt = timestamp(
    requiredString(silence, "updatedAt", `silences[${index}]`),
    "silence updatedAt",
  );
  if (!Array.isArray(silence.matchers)) {
    throw new AdapterContractError(`silences[${index}].matchers is not an array`);
  }
  return {
    kind: "EVENT",
    name: "silence",
    occurredAt: updatedAt,
    summary: `Silence ${state} for ${silence.matchers.length} matcher(s)`,
    attributes: {
      state,
      startsAt,
      endsAt,
      matcherCount: silence.matchers.length,
    },
  };
}

function normalizedRecords(
  operation: AlertmanagerCompiledBinding["operation"],
  document: unknown,
  maxItems: number,
): { records: ProviderValue[]; truncated: boolean } {
  if (operation === "alertmanager.status") {
    return { records: [normalizeStatus(document)], truncated: false };
  }
  if (!Array.isArray(document)) throw new AdapterContractError("Alertmanager list response drifted");
  const selected = document.slice(0, maxItems);
  const records = selected.map((item, index) =>
    operation === "alertmanager.alerts"
      ? normalizeAlert(item, index)
      : normalizeSilence(item, index),
  );
  return { records, truncated: document.length > maxItems };
}

export class AlertmanagerAdapter implements EvidenceAdapter<AlertmanagerCompiledBinding> {
  readonly descriptor = descriptor;
  readonly #endpoints: ReadonlyMap<string, TrustedEndpoint>;
  readonly #catalog: ReadonlyMap<string, AlertmanagerCatalogBinding>;
  readonly #transport: AlertmanagerTransport;

  constructor(options: AlertmanagerAdapterOptions) {
    const endpoints = new Map<string, TrustedEndpoint>();
    for (const definition of options.endpoints) {
      const endpoint = trustedEndpoint(definition);
      if (endpoints.has(endpoint.endpointId)) {
        throw new AdapterContractError(`Duplicate Alertmanager endpoint: ${endpoint.endpointId}`);
      }
      endpoints.set(endpoint.endpointId, endpoint);
    }
    const catalog = new Map<string, AlertmanagerCatalogBinding>();
    for (const definition of options.catalog) {
      const binding = cloneBinding(definition, endpoints);
      if (catalog.has(binding.bindingId)) {
        throw new AdapterContractError(`Duplicate Alertmanager binding: ${binding.bindingId}`);
      }
      catalog.set(binding.bindingId, binding);
    }
    this.#endpoints = endpoints;
    this.#catalog = catalog;
    this.#transport = options.transport;
  }

  async doctor(context: AdapterDoctorContext): Promise<AdapterDoctorResult> {
    context.signal.throwIfAborted();
    return {
      status: this.#catalog.size > 0 ? "READY" : "BLOCKED",
      checks: [
        {
          name: "trusted-read-bindings",
          status: this.#catalog.size > 0 ? "PASS" : "FAIL",
          message:
            this.#catalog.size > 0
              ? `${this.#endpoints.size} endpoint(s) and ${this.#catalog.size} GET-only binding(s) configured`
              : "No reviewed Alertmanager bindings are configured",
        },
      ],
    };
  }

  async compile(
    operation: Readonly<OperationSnapshot>,
    context: AdapterCompileContext,
  ): Promise<CompiledAdapterOperation<AlertmanagerCompiledBinding>> {
    if (context.adapterPackage.packageId !== ALERTMANAGER_ADAPTER_PACKAGE_ID) {
      throw new AdapterContractError("Alertmanager adapter package mismatch");
    }
    if (
      operation.definition.adapterPackageId !== ALERTMANAGER_ADAPTER_PACKAGE_ID ||
      !descriptor.operations.includes(
        operation.definition.adapterOperation as AlertmanagerCompiledBinding["operation"],
      )
    ) {
      throw new AdapterContractError("Operation does not target a supported Alertmanager read");
    }
    const expectedDomain =
      operation.definition.adapterOperation === "alertmanager.status" ? "RUNTIME" : "ALERTS";
    if (operation.definition.domain !== expectedDomain) {
      throw new AdapterContractError("Alertmanager operation domain mismatch");
    }
    if (computeOperationDefinitionHash(operation) !== operation.definitionSha256) {
      throw new AdapterContractError("Alertmanager operation hash mismatch");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > context.maxDefinitionBytes) {
      throw new AdapterContractError("Alertmanager operation definition exceeds compile budget");
    }
    const providerDefinition = operation.definition.sanitizedProviderDefinition;
    if (
      Object.keys(providerDefinition).length !== 1 ||
      typeof providerDefinition.bindingId !== "string"
    ) {
      throw new AdapterContractError(
        "Alertmanager operation must select exactly one compiled bindingId",
      );
    }
    const catalogBinding = this.#catalog.get(providerDefinition.bindingId);
    if (
      catalogBinding === undefined ||
      catalogBinding.operation !== operation.definition.adapterOperation
    ) {
      throw new AdapterContractError("Alertmanager binding is unavailable or operation-mismatched");
    }
    const filters =
      catalogBinding.operation === "alertmanager.alerts"
        ? filtersAsJson(catalogBinding.filters)
        : undefined;
    const binding: AlertmanagerCompiledBinding = {
      bindingId: catalogBinding.bindingId,
      endpointId: catalogBinding.endpointId,
      operation: catalogBinding.operation,
      maxBytes: Math.min(catalogBinding.maxBytes, operation.definition.limits.maxBytes),
      maxItems: Math.min(catalogBinding.maxItems, operation.definition.limits.maxRows),
      ...(filters === undefined ? {} : { filters }),
    };
    return {
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      adapterPackageId: ALERTMANAGER_ADAPTER_PACKAGE_ID,
      adapterOperation: catalogBinding.operation,
      binding,
    };
  }

  async execute(
    context: AdapterExecutionContext,
    operation: Readonly<CompiledAdapterOperation<AlertmanagerCompiledBinding>>,
  ): Promise<ProviderResult> {
    context.budget.throwIfAborted();
    const binding = operation.binding;
    const catalogBinding = this.#catalog.get(binding.bindingId);
    const endpoint = this.#endpoints.get(binding.endpointId);
    if (
      catalogBinding === undefined ||
      endpoint === undefined ||
      catalogBinding.operation !== binding.operation ||
      catalogBinding.endpointId !== binding.endpointId
    ) {
      throw new AdapterContractError("Compiled Alertmanager binding is no longer trusted");
    }
    if (
      operation.adapterPackageId !== ALERTMANAGER_ADAPTER_PACKAGE_ID ||
      operation.adapterOperation !== binding.operation ||
      !Number.isSafeInteger(binding.maxBytes) ||
      !Number.isSafeInteger(binding.maxItems) ||
      binding.maxBytes <= 0 ||
      binding.maxItems < 0 ||
      binding.maxBytes > catalogBinding.maxBytes ||
      binding.maxItems > catalogBinding.maxItems
    ) {
      throw new AdapterContractError("Compiled Alertmanager authority exceeds its reviewed bounds");
    }
    const effectiveMaxBytes = Math.min(binding.maxBytes, context.budget.limits.maxBytes);
    const effectiveMaxItems = Math.min(binding.maxItems, context.budget.limits.maxRows);
    const expectedFilters =
      catalogBinding.operation === "alertmanager.alerts"
        ? filtersAsJson(catalogBinding.filters)
        : undefined;
    if (canonicalJson(binding.filters ?? {}) !== canonicalJson(expectedFilters ?? {})) {
      throw new AdapterContractError("Compiled Alertmanager filters changed after authorization");
    }
    const url = buildUrl(endpoint, binding);
    let response: AlertmanagerTransportResponse;
    try {
      response = await this.#transport.request({
        method: "GET",
        endpointId: endpoint.endpointId,
        url,
        headers: { Accept: "application/json" },
        maxBytes: effectiveMaxBytes,
        signal: context.signal,
      });
    } catch (error) {
      if (error instanceof AdapterExecutionError || error instanceof AdapterContractError) throw error;
      if (context.signal.aborted) throw context.signal.reason ?? error;
      throw new AdapterExecutionError({
        code: "alertmanager.unavailable",
        category: "UNAVAILABLE",
        message: "Alertmanager transport is unavailable",
        retryable: true,
      });
    }

    const evaluatedAt = context.clock.now().toISOString();
    if (!Number.isInteger(response.status) || response.status < 100 || response.status > 599) {
      throw new AdapterContractError("Alertmanager transport returned an invalid HTTP status");
    }
    const bytes = responseBody(response);
    context.budget.consumeBytes(Math.min(bytes.byteLength, effectiveMaxBytes));
    if (bytes.byteLength > effectiveMaxBytes) {
      return errorResult(
        binding.operation,
        evaluatedAt,
        {
          code: "alertmanager.response_too_large",
          category: "POLICY",
          message: "Alertmanager response exceeded the reviewed byte limit",
          retryable: false,
        },
        { complete: false, pages: 1, truncatedReason: "BYTE_LIMIT" },
      );
    }
    if (response.status < 200 || response.status >= 300) {
      return errorResult(
        binding.operation,
        evaluatedAt,
        errorForStatus(response.status),
        { complete: false, pages: 1 },
      );
    }
    const contentType = header(response, "content-type");
    if (contentType !== undefined && !/^application\/json(?:\s*;|$)/iu.test(contentType)) {
      throw new AdapterContractError("Alertmanager response content type drifted");
    }
    let document: unknown;
    try {
      document = JSON.parse(Buffer.from(bytes).toString("utf8")) as unknown;
    } catch {
      throw new AdapterContractError("Alertmanager response is not valid JSON");
    }
    const normalized = normalizedRecords(binding.operation, document, effectiveMaxItems);
    context.budget.consumeRows(normalized.records.length);
    const empty = normalized.records.length === 0;
    return {
      schemaVersion: "1.0.0",
      collectionState: empty ? "EMPTY" : "COMPLETE",
      evaluatedAt,
      nativeResultType: binding.operation,
      nativeDimensions: {},
      records: normalized.records,
      pagination: normalized.truncated
        ? { complete: false, pages: 1, truncatedReason: "ROW_LIMIT" }
        : { complete: true, pages: 1 },
      warnings: normalized.truncated
        ? ["Alertmanager items were truncated by the reviewed item bound"]
        : [],
      sanitizedReference: `alertmanager:${binding.endpointId}:${binding.bindingId}`,
    };
  }
}

const DEFAULT_LIMITS: OperationLimits = {
  timeoutMs: 10_000,
  maxAgeMs: 60_000,
  maxBytes: 512_000,
  maxRows: 1_000,
  maxSeries: 0,
  maxPoints: 0,
};

export interface AlertmanagerOperationOptions {
  operationId?: OperationId;
  capturedAt?: string;
  limits?: Partial<OperationLimits>;
}

export function createAlertmanagerOperationSnapshot(
  bindingId: string,
  adapterOperation: AlertmanagerCompiledBinding["operation"],
  options: AlertmanagerOperationOptions = {},
): OperationSnapshot {
  const definition: OperationDefinition = {
    domain: adapterOperation === "alertmanager.status" ? "RUNTIME" : "ALERTS",
    sourceAlias: "alertmanager",
    adapterPackageId: ALERTMANAGER_ADAPTER_PACKAGE_ID,
    adapterOperation,
    authority: "AUTHORITATIVE",
    sanitizedProviderDefinition: { bindingId },
    scopeMapping: {},
    allowedDimensions: [],
    requiredProviderScopes: ["environment"],
    sensitivity: "INTERNAL",
    limits: { ...DEFAULT_LIMITS, ...options.limits },
    normalization: {
      resultKind: adapterOperation === "alertmanager.status" ? "TABLE" : "EVENT",
      dimensionMappings: {},
    },
  };
  const suffix =
    adapterOperation === "alertmanager.silences.read"
      ? "silences"
      : adapterOperation.split(".").at(-1)!;
  const semantic = {
    operationId:
      options.operationId ?? (`alerts.alertmanager.${suffix}` as OperationId),
    revision: 1,
    definition,
  };
  return {
    schemaVersion: "1.0.0",
    ...semantic,
    capturedAt: options.capturedAt ?? "2026-01-01T00:00:00.000Z",
    definitionSha256: computeOperationDefinitionHash(semantic),
  };
}
