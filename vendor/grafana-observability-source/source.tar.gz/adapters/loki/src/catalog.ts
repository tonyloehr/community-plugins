import { canonicalJson, sha256Canonical, type JsonObject, type Sha256 } from "../../../packages/contracts/src/index.ts";
import { AdapterContractError } from "../../../packages/adapter-sdk/src/index.ts";

import type { LokiCatalogEntry, LokiTrustedCatalog } from "./types.ts";

const SAFE_ID = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/u;
const SAFE_LABEL = /^[a-zA-Z_][a-zA-Z0-9_]*$/u;
const SAFE_SCOPE = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/u;
const SHA256 = /^[a-f0-9]{64}$/u;

function assertExactKeys(entry: LokiCatalogEntry): void {
  const allowed = new Set([
    "id",
    "sourceIdentitySha256",
    "expression",
    "outputName",
    "allowedLabels",
    "direction",
    "scope",
  ]);
  if (Object.keys(entry).some((key) => !allowed.has(key))) {
    throw new AdapterContractError("Loki catalog entry contains an unsupported field");
  }
}

export function lokiCatalogEntryHash(entry: LokiCatalogEntry): Sha256 {
  return sha256Canonical(entry as unknown as JsonObject);
}

function validateEntry(entry: LokiCatalogEntry): void {
  assertExactKeys(entry);
  if (!SAFE_ID.test(entry.id) || !SAFE_ID.test(entry.outputName)) {
    throw new AdapterContractError("Loki catalog IDs must use the bounded safe identifier format");
  }
  if (!SHA256.test(entry.sourceIdentitySha256)) {
    throw new AdapterContractError("Loki catalog source identity hash is invalid");
  }
  if (entry.expression.length === 0 || entry.expression.length > 16_384) {
    throw new AdapterContractError("Loki catalog expression is empty or too large");
  }
  if (entry.direction !== "backward" && entry.direction !== "forward") {
    throw new AdapterContractError("Loki catalog direction is invalid");
  }
  if (!SAFE_SCOPE.test(entry.scope.environment) || !SAFE_SCOPE.test(entry.scope.service)) {
    throw new AdapterContractError("Loki catalog scope is invalid");
  }
  if (
    entry.allowedLabels.length > 16 ||
    new Set(entry.allowedLabels).size !== entry.allowedLabels.length ||
    entry.allowedLabels.some((label) => !SAFE_LABEL.test(label))
  ) {
    throw new AdapterContractError("Loki allowed labels must be unique, valid, and bounded");
  }
  canonicalJson(entry);
}

export class CompiledLokiCatalog {
  readonly #entries: ReadonlyMap<string, LokiCatalogEntry>;

  constructor(catalog: Readonly<LokiTrustedCatalog>) {
    const entries = new Map<string, LokiCatalogEntry>();
    for (const supplied of catalog.entries) {
      const entry = structuredClone(supplied);
      validateEntry(entry);
      if (entries.has(entry.id)) throw new AdapterContractError(`Duplicate Loki catalog entry: ${entry.id}`);
      entries.set(entry.id, Object.freeze({
        ...entry,
        allowedLabels: Object.freeze([...entry.allowedLabels]),
        scope: Object.freeze({ ...entry.scope }),
      }) as LokiCatalogEntry);
    }
    this.#entries = entries;
  }

  resolve(id: string, expectedSha256: Sha256): LokiCatalogEntry {
    const entry = this.#entries.get(id);
    if (entry === undefined) throw new AdapterContractError("Loki catalog entry is not trusted");
    if (lokiCatalogEntryHash(entry) !== expectedSha256) {
      throw new AdapterContractError("Loki catalog entry hash mismatch");
    }
    return entry;
  }
}
