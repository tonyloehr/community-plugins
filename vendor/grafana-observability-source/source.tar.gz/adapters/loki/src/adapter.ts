import {
  canonicalJson,
  computeOperationDefinitionHash,
  type AdapterPackage,
  type AdapterPackageId,
  type JsonObject,
  type OperationSnapshot,
  type Pagination,
  type Sha256,
} from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  type AdapterCompileContext,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderEvent,
  type ProviderResult,
} from "../../../packages/adapter-sdk/src/index.ts";

import { CompiledLokiCatalog, lokiCatalogEntryHash } from "./catalog.ts";
import type {
  LokiCatalogEntry,
  LokiHttpResponse,
  LokiTransport,
  LokiTransportError,
  LokiTrustedCatalog,
} from "./types.ts";

export const LOKI_ADAPTER_PACKAGE_ID = "adapter.loki.v1" as AdapterPackageId;

export const lokiAdapterPackage: AdapterPackage = {
  schemaVersion: "1.0.0",
  packageId: LOKI_ADAPTER_PACKAGE_ID,
  name: "Loki production-read-only adapter",
  version: "1.0.0",
  protocolVersion: "1.0",
  publisher: { name: "Codex Production Monitoring" },
  entrypoint: { kind: "BUILTIN", registryKey: "loki-v1" },
  domains: ["LOGS"],
  capabilities: ["loki.logs.query-range"],
  providerCompatibility: [{ provider: "loki", versions: ">=2.9 <4" }],
  supportedContractVersions: ["1.0.0"],
  conformance: ["CORE_READ", "LOGS"],
};

type LokiBinding = JsonObject & {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
  sourceIdentitySha256: Sha256;
  expression: string;
  outputName: string;
  allowedLabels: string[];
  direction: "backward" | "forward";
  scopeEnvironment: string;
  scopeService: string;
};

interface LokiParseState {
  events: ProviderEvent[];
  evaluatedAt: string;
  truncatedReason?: Pagination["truncatedReason"];
}

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function safeString(value: unknown, label: string, maxLength = 4_096): string {
  if (typeof value !== "string" || value.length === 0 || value.length > maxLength) {
    throw new AdapterContractError(`Loki ${label} is invalid`);
  }
  return value;
}

function safeLabelValue(value: unknown): string {
  const text = safeString(value, "label value", 512);
  if ([...text].some((character) => (character.codePointAt(0) ?? 0) < 32)) {
    throw new AdapterContractError("Loki label contains a control character");
  }
  return text;
}

function safeLogLine(value: unknown): string {
  const text = safeString(value, "log line", 16_384);
  const redacted = text
    .replaceAll(/\bBearer\s+[A-Za-z0-9._~+/-]+=*\b/giu, "[REDACTED]")
    .replaceAll(/\b(?:token|password|secret|api[_-]?key)\s*[=:]\s*\S+/giu, "[REDACTED]");
  return [...redacted]
    .map((character) => {
      const codePoint = character.codePointAt(0) ?? 0;
      return codePoint <= 31 || codePoint === 127 ? "�" : character;
    })
    .join("")
    .slice(0, 2_048);
}

function timestampFromNanoseconds(value: unknown): string {
  const text = safeString(value, "timestamp", 32);
  if (!/^\d{1,20}$/u.test(text)) throw new AdapterContractError("Loki timestamp is invalid");
  const nanoseconds = BigInt(text);
  const milliseconds = nanoseconds / 1_000_000n;
  if (milliseconds > BigInt(Number.MAX_SAFE_INTEGER)) throw new AdapterContractError("Loki timestamp is out of range");
  const date = new Date(Number(milliseconds));
  if (Number.isNaN(date.getTime())) throw new AdapterContractError("Loki timestamp is out of range");
  return date.toISOString();
}

async function readJson(response: LokiHttpResponse, context: AdapterExecutionContext): Promise<unknown> {
  const chunks: Uint8Array[] = [];
  for await (const chunk of response.body) {
    context.budget.throwIfAborted();
    context.budget.consumeBytes(chunk.byteLength);
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
  } catch {
    throw new AdapterContractError("Loki response is not valid JSON");
  }
}

function statusError(status: number): AdapterExecutionError {
  if (status === 401 || status === 403) {
    return new AdapterExecutionError({
      code: "LOKI_ACCESS_DENIED",
      category: status === 401 ? "AUTHENTICATION" : "AUTHORIZATION",
      message: "Loki denied the bounded read request",
      retryable: false,
      providerStatus: status,
    });
  }
  if (status === 429) {
    return new AdapterExecutionError({
      code: "LOKI_RATE_LIMIT",
      category: "RATE_LIMIT",
      message: "Loki rate limited the bounded read request",
      retryable: true,
      providerStatus: status,
    });
  }
  return new AdapterExecutionError({
    code: "LOKI_READ_FAILED",
    category: status >= 500 ? "UNAVAILABLE" : "INVALID_RESPONSE",
    message: "Loki bounded read failed",
    retryable: status >= 500,
    providerStatus: status,
  });
}

function assertScope(
  labels: Readonly<Record<string, string>>,
  context: AdapterExecutionContext,
): void {
  const environment = labels.environment;
  const service = labels.service;
  if (environment !== undefined && environment !== context.scope.environment) {
    throw new AdapterContractError("Loki response crossed the authorized environment scope");
  }
  if (service !== undefined && context.scope.service !== undefined && service !== context.scope.service) {
    throw new AdapterContractError("Loki response crossed the authorized service scope");
  }
}

function parseLabels(value: unknown, allowed: readonly string[]): Record<string, string> {
  if (!isObject(value)) throw new AdapterContractError("Loki stream labels are invalid");
  const labels: Record<string, string> = {};
  for (const [key, raw] of Object.entries(value)) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/u.test(key)) throw new AdapterContractError("Loki label name is invalid");
    const parsed = safeLabelValue(raw);
    if (allowed.includes(key) || key === "environment" || key === "service") labels[key] = parsed;
  }
  return labels;
}

function parseStreams(
  data: unknown,
  binding: LokiBinding,
  context: AdapterExecutionContext,
): LokiParseState {
  if (!isObject(data) || data.resultType !== "streams" || !Array.isArray(data.result)) {
    throw new AdapterContractError("Loki query response shape drifted");
  }
  const state: LokiParseState = { events: [], evaluatedAt: new Date(context.window.end).toISOString() };
  for (const streamResult of data.result) {
    context.budget.throwIfAborted();
    if (!isObject(streamResult) || !Array.isArray(streamResult.values)) {
      throw new AdapterContractError("Loki stream result is invalid");
    }
    const labels = parseLabels(streamResult.stream, binding.allowedLabels);
    assertScope(labels, context);
    const attributes = Object.fromEntries(
      Object.entries(labels).filter(([key]) => binding.allowedLabels.includes(key)),
    );
    for (const pair of streamResult.values) {
      if (!Array.isArray(pair) || pair.length !== 2) throw new AdapterContractError("Loki log entry is invalid");
      if (state.events.length >= context.budget.limits.maxRows) {
        state.truncatedReason = "ROW_LIMIT";
        break;
      }
      const occurredAt = timestampFromNanoseconds(pair[0]);
      const event: ProviderEvent = {
        kind: "EVENT",
        name: binding.outputName,
        occurredAt,
        summary: safeLogLine(pair[1]),
        attributes,
      };
      context.budget.consumeRows(1);
      state.events.push(event);
      if (Date.parse(occurredAt) > Date.parse(state.evaluatedAt)) state.evaluatedAt = occurredAt;
    }
    if (state.truncatedReason !== undefined) break;
  }
  return state;
}

function bindingFor(entry: LokiCatalogEntry): LokiBinding {
  return {
    catalogEntryId: entry.id,
    catalogEntrySha256: lokiCatalogEntryHash(entry),
    sourceIdentitySha256: entry.sourceIdentitySha256,
    expression: entry.expression,
    outputName: entry.outputName,
    allowedLabels: [...entry.allowedLabels],
    direction: entry.direction,
    scopeEnvironment: entry.scope.environment,
    scopeService: entry.scope.service,
  };
}

export interface LokiAdapterOptions {
  transport: LokiTransport;
  catalog: LokiTrustedCatalog;
}

export class LokiAdapter implements EvidenceAdapter<LokiBinding> {
  readonly descriptor = {
    packageId: LOKI_ADAPTER_PACKAGE_ID,
    name: lokiAdapterPackage.name,
    version: lokiAdapterPackage.version,
    provider: "loki",
    domains: ["LOGS"] as const,
    operations: lokiAdapterPackage.capabilities,
    resultSchemaVersions: ["1.0.0"] as const,
  };

  readonly #transport: LokiTransport;
  readonly #catalog: CompiledLokiCatalog;

  constructor(options: LokiAdapterOptions) {
    this.#transport = options.transport;
    this.#catalog = new CompiledLokiCatalog(options.catalog);
  }

  async doctor() {
    return {
      status: "READY" as const,
      checks: [{ name: "production-read-only", status: "PASS" as const, message: "Trusted Loki catalog loaded" }],
    };
  }

  async compile(operation: Readonly<OperationSnapshot>, context: AdapterCompileContext) {
    if (context.adapterPackage.packageId !== LOKI_ADAPTER_PACKAGE_ID) {
      throw new AdapterContractError("Loki adapter package mismatch");
    }
    if (
      operation.definition.adapterPackageId !== LOKI_ADAPTER_PACKAGE_ID ||
      computeOperationDefinitionHash(operation) !== operation.definitionSha256
    ) {
      throw new AdapterContractError("Loki operation is not bound to this adapter and hash");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > context.maxDefinitionBytes) {
      throw new AdapterContractError("Loki operation definition exceeds the compile budget");
    }
    const reference = operation.definition.sanitizedProviderDefinition;
    if (
      Object.keys(reference).length !== 2 ||
      typeof reference.catalogEntryId !== "string" ||
      typeof reference.catalogEntrySha256 !== "string"
    ) {
      throw new AdapterContractError("Loki operation must contain only a trusted catalog reference");
    }
    const entry = this.#catalog.resolve(reference.catalogEntryId, reference.catalogEntrySha256 as Sha256);
    if (operation.definition.adapterOperation !== "loki.logs.query-range") {
      throw new AdapterContractError("Loki adapter operation is not a production-read-only range read");
    }
    if (operation.definition.domain !== "LOGS" || operation.definition.normalization.resultKind !== "EVENT") {
      throw new AdapterContractError("Loki operation result contract is invalid");
    }
    const expectedSourceLineage = {
      accessPath: "DIRECT" as const,
      datasourceType: "loki" as const,
      sourceIdentitySha256: entry.sourceIdentitySha256,
    };
    if (canonicalJson(operation.definition.expectedSourceLineage ?? null) !== canonicalJson(expectedSourceLineage)) {
      throw new AdapterContractError("Loki source lineage does not match the trusted catalog");
    }
    if (entry.allowedLabels.some((label) => !operation.definition.allowedDimensions.includes(label))) {
      throw new AdapterContractError("Loki catalog labels exceed the operation dimension allowlist");
    }
    return {
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      adapterPackageId: LOKI_ADAPTER_PACKAGE_ID,
      adapterOperation: operation.definition.adapterOperation,
      binding: bindingFor(entry),
    } satisfies CompiledAdapterOperation<LokiBinding>;
  }

  async execute(
    context: AdapterExecutionContext,
    operation: Readonly<CompiledAdapterOperation<LokiBinding>>,
  ): Promise<ProviderResult> {
    context.budget.throwIfAborted();
    const trustedEntry = this.#catalog.resolve(
      operation.binding.catalogEntryId,
      operation.binding.catalogEntrySha256,
    );
    if (
      operation.adapterPackageId !== LOKI_ADAPTER_PACKAGE_ID ||
      operation.adapterOperation !== "loki.logs.query-range" ||
      canonicalJson(operation.binding) !== canonicalJson(bindingFor(trustedEntry))
    ) {
      throw new AdapterContractError("Compiled Loki binding no longer matches the trusted catalog");
    }
    if (
      operation.binding.scopeEnvironment !== context.scope.environment ||
      operation.binding.scopeService !== context.scope.service
    ) {
      throw new AdapterExecutionError({
        code: "LOKI_SCOPE_NOT_ALLOWED",
        category: "POLICY",
        message: "The requested scope does not match the reviewed Loki catalog entry",
        retryable: false,
      });
    }
    let response: LokiHttpResponse;
    try {
      response = await this.#transport.request({
        method: "GET",
        route: "QUERY_RANGE",
        expression: operation.binding.expression,
        start: context.window.start,
        end: context.window.end,
        direction: operation.binding.direction,
        limit: context.budget.limits.maxRows,
        signal: context.signal,
        maxResponseBytes: context.budget.limits.maxBytes,
      });
    } catch (error) {
      if (error instanceof AdapterExecutionError || error instanceof AdapterContractError || error instanceof BudgetExceededError) {
        throw error;
      }
      if ((error as LokiTransportError | undefined)?.name === "LokiTransportError") {
        const transportError = error as LokiTransportError;
        throw new AdapterExecutionError({
          code: transportError.kind === "TIMEOUT" ? "LOKI_TIMEOUT" : "LOKI_UNAVAILABLE",
          category: transportError.kind,
          message: transportError.kind === "TIMEOUT" ? "Loki read timed out" : "Loki is unavailable",
          retryable: true,
        });
      }
      if (context.signal.aborted) throw context.signal.reason ?? error;
      throw new AdapterExecutionError({
        code: "LOKI_UNAVAILABLE",
        category: "UNAVAILABLE",
        message: "Loki is unavailable",
        retryable: true,
      });
    }
    const body = await readJson(response, context);
    if (response.status < 200 || response.status >= 300) throw statusError(response.status);
    if (!isObject(body) || body.status !== "success") {
      throw new AdapterContractError("Loki response envelope is invalid");
    }
    const state = parseStreams(body.data, operation.binding, context);
    const providerTruncated = isObject(body.data) && isObject(body.data.stats) && body.data.stats.truncated === true;
    const truncatedReason = state.truncatedReason ?? (providerTruncated ? "ROW_LIMIT" : undefined);
    return {
      schemaVersion: "1.0.0",
      collectionState: state.events.length === 0 ? "EMPTY" : "COMPLETE",
      evaluatedAt: state.evaluatedAt,
      nativeResultType: "streams",
      nativeDimensions: {},
      records: state.events,
      pagination: truncatedReason === undefined
        ? { complete: true, pages: 1 }
        : { complete: false, pages: 1, truncatedReason },
      warnings: truncatedReason === undefined ? [] : ["Loki result was truncated by the bounded read policy"],
      sanitizedReference: "loki:query-range",
      sourceLineage: {
        accessPath: "DIRECT",
        datasourceType: "loki",
        sourceIdentitySha256: operation.binding.sourceIdentitySha256,
      },
      providerScope: {
        environment: context.scope.environment,
        ...(context.scope.service === undefined ? {} : { service: context.scope.service }),
        mappings: {
          environment: "environment",
          ...(context.scope.service === undefined ? {} : { service: "service" }),
        },
      },
    };
  }
}
