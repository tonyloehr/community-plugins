import type { Sha256 } from "../../../packages/contracts/src/index.ts";

export interface LokiCatalogEntry {
  id: string;
  /** Administrator-enrolled canonical identity shared with Grafana-mediated access. */
  sourceIdentitySha256: Sha256;
  expression: string;
  outputName: string;
  allowedLabels: string[];
  direction: "backward" | "forward";
  scope: { environment: string; service: string };
}

export interface LokiTrustedCatalog {
  entries: LokiCatalogEntry[];
}

export interface LokiCatalogReference {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
}

export interface LokiHttpRequest {
  method: "GET";
  route: "QUERY_RANGE";
  expression: string;
  start: string;
  end: string;
  direction: "backward" | "forward";
  limit: number;
  signal: AbortSignal;
  maxResponseBytes: number;
}

export interface LokiHttpResponse {
  status: number;
  body: AsyncIterable<Uint8Array>;
}

export interface LokiTransport {
  request(request: Readonly<LokiHttpRequest>): Promise<LokiHttpResponse>;
}

export class LokiTransportError extends Error {
  readonly kind: "TIMEOUT" | "UNAVAILABLE";

  constructor(kind: "TIMEOUT" | "UNAVAILABLE") {
    super(`Loki transport ${kind.toLowerCase()}`);
    this.name = "LokiTransportError";
    this.kind = kind;
  }
}
