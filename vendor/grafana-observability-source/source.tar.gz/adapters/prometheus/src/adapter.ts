import {
  canonicalJson,
  computeOperationDefinitionHash,
  type AdapterPackage,
  type AdapterPackageId,
  type JsonObject,
  type JsonPrimitive,
  type OperationSnapshot,
  type Pagination,
  type Sha256,
} from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  type AdapterCompileContext,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderResult,
  type ProviderValue,
} from "../../../packages/adapter-sdk/src/index.ts";

import { CompiledPrometheusCatalog, prometheusCatalogEntryHash } from "./catalog.ts";
import type {
  PrometheusCatalogEntry,
  PrometheusHttpRequest,
  PrometheusHttpResponse,
  PrometheusRoute,
  PrometheusTransport,
  PrometheusTrustedCatalog,
  PrometheusValueKind,
} from "./types.ts";
import { PrometheusTransportError } from "./types.ts";

export const PROMETHEUS_ADAPTER_PACKAGE_ID = "adapter.prometheus.v1" as AdapterPackageId;

export const prometheusAdapterPackage: AdapterPackage = {
  schemaVersion: "1.0.0",
  packageId: PROMETHEUS_ADAPTER_PACKAGE_ID,
  name: "Prometheus read-only adapter",
  version: "1.0.0",
  protocolVersion: "1.0",
  publisher: { name: "Codex Production Monitoring" },
  entrypoint: { kind: "BUILTIN", registryKey: "prometheus-v1" },
  domains: ["METRICS", "ALERTS"],
  capabilities: [
    "prometheus.query.instant",
    "prometheus.query.range",
    "prometheus.alerts.list",
    "prometheus.rules.list",
  ],
  providerCompatibility: [{ provider: "prometheus", versions: ">=2.45 <4" }],
  supportedContractVersions: ["1.0.0"],
  conformance: ["CORE_READ", "METRICS", "ALERTS"],
};

type PrometheusBinding = JsonObject & {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
  sourceIdentitySha256: Sha256;
  route: PrometheusRoute;
  outputName: string;
  allowedLabels: string[];
  valueKind?: PrometheusValueKind;
  expression?: string;
  stepSeconds?: number;
  ruleType?: "alert" | "record";
  unit?: string;
  scopeEnvironment?: string;
  scopeService?: string;
};

const OPERATION_BY_ROUTE: Record<PrometheusRoute, string> = {
  instant: "prometheus.query.instant",
  range: "prometheus.query.range",
  alerts: "prometheus.alerts.list",
  rules: "prometheus.rules.list",
};

const PATH_BY_ROUTE: Record<PrometheusRoute, PrometheusHttpRequest["path"]> = {
  instant: "/api/v1/query",
  range: "/api/v1/query_range",
  alerts: "/api/v1/alerts",
  rules: "/api/v1/rules",
};

const RESULT_KIND_BY_ROUTE: Record<PrometheusRoute, OperationSnapshot["definition"]["normalization"]["resultKind"]> = {
  instant: "SCALAR",
  range: "TIMESERIES",
  alerts: "EVENT",
  rules: "TABLE",
};

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function safeString(value: unknown, field: string, maxLength = 4_096): string {
  const hasUnsafeControl = typeof value === "string" && [...value].some((character) => {
    const code = character.codePointAt(0) ?? 0;
    return (code < 32 && code !== 9 && code !== 10 && code !== 13) || code === 127;
  });
  if (typeof value !== "string" || value.length > maxLength || hasUnsafeControl) {
    throw new AdapterContractError(`Prometheus ${field} is invalid`);
  }
  return value;
}

function parseTimestamp(value: unknown): { seconds: number; iso: string } {
  const seconds = typeof value === "number" ? value : typeof value === "string" ? Number(value) : Number.NaN;
  if (!Number.isFinite(seconds) || seconds < 0) throw new AdapterContractError("Prometheus timestamp is invalid");
  const milliseconds = seconds * 1_000;
  if (!Number.isFinite(milliseconds)) throw new AdapterContractError("Prometheus timestamp is out of range");
  const date = new Date(milliseconds);
  if (Number.isNaN(date.getTime())) throw new AdapterContractError("Prometheus timestamp is out of range");
  return { seconds, iso: date.toISOString() };
}

function parseSample(value: unknown, warnings: string[]): number | null {
  const text = safeString(value, "sample value", 128);
  if (["NaN", "Inf", "+Inf", "-Inf"].includes(text)) {
    warnings.push("Prometheus returned a non-finite sample; normalized value is null");
    return null;
  }
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/u.test(text)) {
    throw new AdapterContractError("Prometheus sample value is invalid");
  }
  const number = Number(text);
  if (!Number.isFinite(number)) throw new AdapterContractError("Prometheus sample value is out of range");
  return number;
}

function parseBoundary(value: unknown): string {
  const text = safeString(value, "native histogram boundary", 128);
  if (["Inf", "+Inf", "-Inf"].includes(text)) return text;
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/u.test(text) || !Number.isFinite(Number(text))) {
    throw new AdapterContractError("Prometheus native histogram boundary is invalid");
  }
  return text;
}

function boundaryNumber(value: string): number {
  if (value === "Inf" || value === "+Inf") return Number.POSITIVE_INFINITY;
  if (value === "-Inf") return Number.NEGATIVE_INFINITY;
  return Number(value);
}

function parseMetric(value: unknown, allowedLabels: readonly string[]): Record<string, string> {
  if (!isObject(value)) throw new AdapterContractError("Prometheus metric labels are invalid");
  const output: Record<string, string> = {};
  for (const [label, rawValue] of Object.entries(value)) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/u.test(label)) {
      throw new AdapterContractError("Prometheus response contains an invalid label name");
    }
    const labelValue = safeString(rawValue, "label value", 512);
    if ([...labelValue].some((character) => (character.codePointAt(0) ?? 0) < 32)) {
      throw new AdapterContractError("Prometheus response contains a control character in a label");
    }
    if (allowedLabels.includes(label)) output[label] = labelValue;
  }
  return output;
}

async function readJson(response: PrometheusHttpResponse, context: AdapterExecutionContext): Promise<unknown> {
  const chunks: Uint8Array[] = [];
  for await (const chunk of response.body) {
    context.budget.throwIfAborted();
    context.budget.consumeBytes(chunk.byteLength);
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
  } catch {
    throw new AdapterContractError("Prometheus response is not valid JSON");
  }
}

function parseWarnings(envelope: Record<string, unknown>): string[] {
  const warnings: string[] = [];
  for (const field of ["warnings", "infos"] as const) {
    const value = envelope[field];
      if (value === undefined) continue;
    if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
      throw new AdapterContractError(`Prometheus ${field} field is invalid`);
    }
    warnings.push(...value.map((item) => {
      const warning = safeString(item, field, 4_096);
      return field === "infos" ? `info: ${warning}` : warning;
    }));
  }
  return warnings;
}

function statusError(status: number): AdapterExecutionError {
  if (status === 401 || status === 403) {
    return new AdapterExecutionError({
      code: "PROMETHEUS_AUTHORIZATION",
      category: status === 401 ? "AUTHENTICATION" : "AUTHORIZATION",
      message: "Prometheus denied the read request",
      retryable: false,
      providerStatus: status,
    });
  }
  if (status === 429) {
    return new AdapterExecutionError({
      code: "PROMETHEUS_RATE_LIMIT",
      category: "RATE_LIMIT",
      message: "Prometheus rate limited the read request",
      retryable: true,
      providerStatus: status,
    });
  }
  return new AdapterExecutionError({
    code: "PROMETHEUS_HTTP_ERROR",
    category: status === 503 ? "UNAVAILABLE" : "INVALID_RESPONSE",
    message: "Prometheus read request failed",
    retryable: status >= 500,
    providerStatus: status,
  });
}

function apiError(envelope: Record<string, unknown>): AdapterExecutionError {
  const errorType = typeof envelope.errorType === "string" ? envelope.errorType : "unknown";
  const timeout = errorType === "timeout" || errorType === "canceled";
  return new AdapterExecutionError({
    code: timeout ? "PROMETHEUS_QUERY_TIMEOUT" : "PROMETHEUS_API_ERROR",
    category: timeout ? "TIMEOUT" : "INVALID_RESPONSE",
    message: timeout ? "Prometheus query timed out" : "Prometheus rejected the trusted catalog request",
    retryable: timeout,
  });
}

function samplePair(value: unknown, warnings: string[]): { timestamp: { seconds: number; iso: string }; value: number | null } {
  if (!Array.isArray(value) || value.length !== 2) throw new AdapterContractError("Prometheus sample pair is invalid");
  return { timestamp: parseTimestamp(value[0]), value: parseSample(value[1], warnings) };
}

interface NativeHistogram {
  timestamp: { seconds: number; iso: string };
  count: number;
  sum: number;
  buckets: Array<{ rule: number; left: string; right: string; count: number }>;
}

function nativeHistogram(value: unknown, warnings: string[]): NativeHistogram {
  if (!Array.isArray(value) || value.length !== 2 || !isObject(value[1])) {
    throw new AdapterContractError("Prometheus native histogram sample is invalid");
  }
  const histogram = value[1];
  const count = parseSample(histogram.count, warnings);
  const sum = parseSample(histogram.sum, warnings);
  if (count === null || sum === null || count < 0) {
    throw new AdapterContractError("Prometheus native histogram count or sum is invalid");
  }
  if (!Array.isArray(histogram.buckets)) throw new AdapterContractError("Prometheus native histogram buckets are invalid");
  const buckets = histogram.buckets.map((bucket) => {
    if (!Array.isArray(bucket) || bucket.length !== 4) {
      throw new AdapterContractError("Prometheus native histogram bucket is invalid");
    }
    const rule = bucket[0];
    if (!Number.isSafeInteger(rule) || (rule as number) < 0 || (rule as number) > 3) {
      throw new AdapterContractError("Prometheus native histogram boundary rule is invalid");
    }
    const bucketCount = parseSample(bucket[3], warnings);
    if (bucketCount === null || bucketCount < 0) {
      throw new AdapterContractError("Prometheus native histogram bucket count is invalid");
    }
    const left = parseBoundary(bucket[1]);
    const right = parseBoundary(bucket[2]);
    if (boundaryNumber(left) >= boundaryNumber(right)) {
      throw new AdapterContractError("Prometheus native histogram bucket boundaries are not increasing");
    }
    return {
      rule: rule as number,
      left,
      right,
      count: bucketCount,
    };
  });
  return { timestamp: parseTimestamp(value[0]), count, sum, buckets };
}

interface ParseState {
  records: ProviderValue[];
  warnings: string[];
  evaluatedAt: string;
  series: number;
  points: number;
  rows: number;
  truncatedReason?: Pagination["truncatedReason"];
}

function canAdd(state: ParseState, context: AdapterExecutionContext, kind: "series" | "points" | "rows"): boolean {
  const current = kind === "series" ? state.series : kind === "points" ? state.points : state.rows;
  const maximum = kind === "series"
    ? context.budget.limits.maxSeries
    : kind === "points"
      ? context.budget.limits.maxPoints
      : context.budget.limits.maxRows;
  if (current < maximum) return true;
  state.truncatedReason ??= kind === "series" ? "SERIES_LIMIT" : kind === "points" ? "POINT_LIMIT" : "ROW_LIMIT";
  return false;
}

function addSeries(state: ParseState, context: AdapterExecutionContext): boolean {
  if (!canAdd(state, context, "series")) return false;
  context.budget.consumeSeries(1);
  state.series += 1;
  return true;
}

function addPoint(state: ParseState, context: AdapterExecutionContext): boolean {
  if (!canAdd(state, context, "points")) return false;
  context.budget.consumePoints(1);
  state.points += 1;
  return true;
}

function addRow(state: ParseState, context: AdapterExecutionContext): boolean {
  if (!canAdd(state, context, "rows")) return false;
  context.budget.consumeRows(1);
  state.rows += 1;
  return true;
}

function updateEvaluatedAt(state: ParseState, iso: string): void {
  if (Date.parse(iso) > Date.parse(state.evaluatedAt)) state.evaluatedAt = iso;
}

function histogramTable(
  name: string,
  dimensions: Record<string, string>,
  samples: readonly NativeHistogram[],
  state: ParseState,
  context: AdapterExecutionContext,
): ProviderValue {
  const dimensionNames = Object.keys(dimensions).sort();
  const columns = [
    ...dimensionNames.map((dimension) => ({ name: dimension, type: "STRING" as const })),
    { name: "rowType", type: "STRING" as const },
    { name: "timestamp", type: "DATETIME" as const },
    { name: "boundaryRule", type: "NUMBER" as const },
    { name: "leftBoundary", type: "STRING" as const },
    { name: "rightBoundary", type: "STRING" as const },
    { name: "bucketCount", type: "NUMBER" as const },
    { name: "count", type: "NUMBER" as const },
    { name: "sum", type: "NUMBER" as const },
  ];
  const rows: JsonPrimitive[][] = [];
  const prefix = dimensionNames.map((dimension) => dimensions[dimension]!);
  for (const sample of samples) {
    if (!addPoint(state, context)) break;
    updateEvaluatedAt(state, sample.timestamp.iso);
    if (addRow(state, context)) {
      rows.push([...prefix, "summary", sample.timestamp.iso, null, null, null, null, sample.count, sample.sum]);
    }
    for (const bucket of sample.buckets) {
      if (!addRow(state, context)) break;
      rows.push([
        ...prefix,
        "bucket",
        sample.timestamp.iso,
        bucket.rule,
        bucket.left,
        bucket.right,
        bucket.count,
        sample.count,
        sample.sum,
      ]);
    }
  }
  return { kind: "TABLE", name, columns, rows };
}

function parseQueryData(
  data: unknown,
  binding: PrometheusBinding,
  context: AdapterExecutionContext,
  state: ParseState,
): void {
  if (!isObject(data) || typeof data.resultType !== "string" || data.result === undefined) {
    throw new AdapterContractError("Prometheus query data is invalid");
  }
  if (binding.route === "instant") {
    if (data.resultType === "scalar" && binding.valueKind === "FLOAT") {
      if (!addSeries(state, context) || !addPoint(state, context)) return;
      const sample = samplePair(data.result, state.warnings);
      updateEvaluatedAt(state, sample.timestamp.iso);
      state.records.push({
        kind: "SCALAR",
        name: binding.outputName,
        value: sample.value,
        dimensions: {},
        observedAt: sample.timestamp.iso,
        ...(binding.unit === undefined ? {} : { unit: binding.unit }),
      });
      return;
    }
    if (data.resultType !== "vector" || !Array.isArray(data.result)) {
      throw new AdapterContractError("Prometheus instant result type drifted from the catalog contract");
    }
    if (context.budget.limits.maxSeries > 0 && data.result.length >= context.budget.limits.maxSeries) {
      state.truncatedReason ??= "SERIES_LIMIT";
    }
    for (const item of data.result) {
      if (!addSeries(state, context)) break;
      if (!isObject(item)) throw new AdapterContractError("Prometheus instant vector item is invalid");
      const dimensions = parseMetric(item.metric, binding.allowedLabels);
      if (binding.valueKind === "FLOAT") {
        if (item.histogram !== undefined || item.value === undefined) {
          throw new AdapterContractError("Prometheus instant sample type drifted from FLOAT");
        }
        if (!addPoint(state, context)) break;
        const sample = samplePair(item.value, state.warnings);
        updateEvaluatedAt(state, sample.timestamp.iso);
        state.records.push({
          kind: "SCALAR",
          name: binding.outputName,
          value: sample.value,
          dimensions,
          observedAt: sample.timestamp.iso,
          ...(binding.unit === undefined ? {} : { unit: binding.unit }),
        });
      } else {
        if (item.value !== undefined || item.histogram === undefined) {
          throw new AdapterContractError("Prometheus instant sample type drifted from NATIVE_HISTOGRAM");
        }
        state.records.push(
          histogramTable(binding.outputName, dimensions, [nativeHistogram(item.histogram, state.warnings)], state, context),
        );
      }
    }
    return;
  }

  if (data.resultType !== "matrix" || !Array.isArray(data.result)) {
    throw new AdapterContractError("Prometheus range result type drifted from the catalog contract");
  }
  if (context.budget.limits.maxSeries > 0 && data.result.length >= context.budget.limits.maxSeries) {
    state.truncatedReason ??= "SERIES_LIMIT";
  }
  for (const item of data.result) {
    if (!addSeries(state, context)) break;
    if (!isObject(item)) throw new AdapterContractError("Prometheus range vector item is invalid");
    const dimensions = parseMetric(item.metric, binding.allowedLabels);
    if (binding.valueKind === "FLOAT") {
      if (!Array.isArray(item.values) || item.histograms !== undefined) {
        throw new AdapterContractError("Prometheus range sample type drifted from FLOAT");
      }
      const points: Array<{ at: string; value: number | null }> = [];
      let previous = -1;
      for (const rawPoint of item.values) {
        if (!addPoint(state, context)) break;
        const sample = samplePair(rawPoint, state.warnings);
        if (sample.timestamp.seconds <= previous) throw new AdapterContractError("Prometheus range timestamps are not increasing");
        previous = sample.timestamp.seconds;
        updateEvaluatedAt(state, sample.timestamp.iso);
        points.push({ at: sample.timestamp.iso, value: sample.value });
      }
      state.records.push({
        kind: "TIMESERIES",
        name: binding.outputName,
        dimensions,
        points,
        ...(binding.unit === undefined ? {} : { unit: binding.unit }),
      });
    } else {
      if (!Array.isArray(item.histograms) || item.values !== undefined) {
        throw new AdapterContractError("Prometheus range sample type drifted from NATIVE_HISTOGRAM");
      }
      const samples = item.histograms.map((sample) => nativeHistogram(sample, state.warnings));
      for (let index = 1; index < samples.length; index += 1) {
        if (samples[index]!.timestamp.seconds <= samples[index - 1]!.timestamp.seconds) {
          throw new AdapterContractError("Prometheus histogram timestamps are not increasing");
        }
      }
      state.records.push(histogramTable(binding.outputName, dimensions, samples, state, context));
    }
  }
}

function parseAlerts(data: unknown, binding: PrometheusBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!isObject(data) || !Array.isArray(data.alerts)) throw new AdapterContractError("Prometheus alerts data is invalid");
  for (const alert of data.alerts) {
    if (!addRow(state, context)) break;
    if (!isObject(alert) || !isObject(alert.labels)) throw new AdapterContractError("Prometheus alert is invalid");
    const activeAt = safeString(alert.activeAt, "alert activeAt", 128);
    if (!Number.isFinite(Date.parse(activeAt))) throw new AdapterContractError("Prometheus alert activeAt is invalid");
    const alertState = safeString(alert.state, "alert state", 32);
    if (!new Set(["firing", "pending"]).has(alertState)) throw new AdapterContractError("Prometheus alert state is invalid");
    const labels = parseMetric(alert.labels, binding.allowedLabels);
    const attributes: Record<string, JsonPrimitive> = { state: alertState, ...labels };
    if (typeof alert.value === "string") attributes.value = safeString(alert.value, "alert value", 128);
    state.records.push({
      kind: "EVENT",
      name: binding.outputName,
      occurredAt: new Date(activeAt).toISOString(),
      summary: `Prometheus alert is ${alertState}`,
      attributes,
    });
  }
}

function parseRules(data: unknown, binding: PrometheusBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!isObject(data) || !Array.isArray(data.groups)) throw new AdapterContractError("Prometheus rules data is invalid");
  const rows: JsonPrimitive[][] = [];
  for (const group of data.groups) {
    if (!isObject(group) || !Array.isArray(group.rules)) throw new AdapterContractError("Prometheus rule group is invalid");
    const groupName = safeString(group.name, "rule group name", 512);
    for (const rule of group.rules) {
      if (!isObject(rule)) throw new AdapterContractError("Prometheus rule metadata is invalid");
      const type = safeString(rule.type, "rule type", 32);
      if (!new Set(["alerting", "recording"]).has(type)) throw new AdapterContractError("Prometheus rule type is invalid");
      const expected = binding.ruleType === "alert" ? "alerting" : binding.ruleType === "record" ? "recording" : undefined;
      if (expected !== undefined && type !== expected) continue;
      if (!addRow(state, context)) break;
      const lastEvaluation = safeString(rule.lastEvaluation, "rule lastEvaluation", 128);
      if (!Number.isFinite(Date.parse(lastEvaluation))) throw new AdapterContractError("Prometheus rule timestamp is invalid");
      const evaluationTime = typeof rule.evaluationTime === "number" && Number.isFinite(rule.evaluationTime)
        ? rule.evaluationTime
        : null;
      rows.push([
        groupName,
        safeString(rule.name, "rule name", 512),
        type,
        typeof rule.state === "string" ? rule.state : null,
        typeof rule.health === "string" ? rule.health : null,
        new Date(lastEvaluation).toISOString(),
        evaluationTime,
      ]);
      updateEvaluatedAt(state, new Date(lastEvaluation).toISOString());
    }
    if (state.truncatedReason !== undefined) break;
  }
  if (rows.length > 0) {
    state.records.push({
      kind: "TABLE",
      name: binding.outputName,
      columns: [
        { name: "group", type: "STRING" },
        { name: "name", type: "STRING" },
        { name: "type", type: "STRING" },
        { name: "state", type: "STRING" },
        { name: "health", type: "STRING" },
        { name: "lastEvaluation", type: "DATETIME" },
        { name: "evaluationTimeSeconds", type: "NUMBER" },
      ],
      rows,
    });
  }
}

function bindingFor(entry: PrometheusCatalogEntry): PrometheusBinding {
  return {
    catalogEntryId: entry.id,
    catalogEntrySha256: prometheusCatalogEntryHash(entry),
    sourceIdentitySha256: entry.sourceIdentitySha256,
    route: entry.route,
    outputName: entry.outputName,
    allowedLabels: [...entry.allowedLabels],
    ...(entry.unit === undefined ? {} : { unit: entry.unit }),
    ...(entry.route === "instant" || entry.route === "range"
      ? { expression: entry.expression, valueKind: entry.valueKind }
      : {}),
    ...(entry.route === "range" ? { stepSeconds: entry.stepSeconds } : {}),
    ...(entry.route === "rules" && entry.ruleType !== undefined ? { ruleType: entry.ruleType } : {}),
    ...(entry.scope === undefined
      ? {}
      : { scopeEnvironment: entry.scope.environment, scopeService: entry.scope.service }),
  } as PrometheusBinding;
}

function compileExpectedResultKind(entry: PrometheusCatalogEntry): OperationSnapshot["definition"]["normalization"]["resultKind"] {
  if ((entry.route === "instant" || entry.route === "range") && entry.valueKind === "NATIVE_HISTOGRAM") return "TABLE";
  return RESULT_KIND_BY_ROUTE[entry.route];
}

function buildRequest(binding: PrometheusBinding, context: AdapterExecutionContext): PrometheusHttpRequest {
  const timeoutSeconds = Math.max(1, Math.ceil(context.budget.limits.timeoutMs / 1_000));
  const query: Record<string, string> = {};
  if (binding.route === "instant") {
    query.query = binding.expression!;
    query.time = context.window.end;
    query.timeout = `${timeoutSeconds}s`;
    query.limit = String(context.budget.limits.maxSeries);
  } else if (binding.route === "range") {
    query.query = binding.expression!;
    query.start = context.window.start;
    query.end = context.window.end;
    query.step = `${binding.stepSeconds!}s`;
    query.timeout = `${timeoutSeconds}s`;
    query.limit = String(context.budget.limits.maxSeries);
  } else if (binding.route === "rules" && binding.ruleType !== undefined) query.type = binding.ruleType;
  return {
    method: "GET",
    path: PATH_BY_ROUTE[binding.route],
    query,
    signal: context.signal,
    maxResponseBytes: context.budget.limits.maxBytes,
  };
}

export interface PrometheusAdapterOptions {
  transport: PrometheusTransport;
  catalog: PrometheusTrustedCatalog;
}

export class PrometheusAdapter implements EvidenceAdapter<PrometheusBinding> {
  readonly descriptor = {
    packageId: PROMETHEUS_ADAPTER_PACKAGE_ID,
    name: prometheusAdapterPackage.name,
    version: prometheusAdapterPackage.version,
    provider: "prometheus",
    domains: ["METRICS", "ALERTS"] as const,
    operations: prometheusAdapterPackage.capabilities,
    resultSchemaVersions: ["1.0.0"] as const,
  };

  readonly #transport: PrometheusTransport;
  readonly #catalog: CompiledPrometheusCatalog;

  constructor(options: PrometheusAdapterOptions) {
    this.#transport = options.transport;
    this.#catalog = new CompiledPrometheusCatalog(options.catalog);
  }

  async doctor() {
    return {
      status: "READY" as const,
      checks: [{ name: "read-only-transport", status: "PASS" as const, message: "Trusted Prometheus catalog loaded" }],
    };
  }

  async compile(operation: Readonly<OperationSnapshot>, context: AdapterCompileContext) {
    if (context.adapterPackage.packageId !== PROMETHEUS_ADAPTER_PACKAGE_ID) {
      throw new AdapterContractError("Prometheus adapter package mismatch");
    }
    if (
      operation.definition.adapterPackageId !== PROMETHEUS_ADAPTER_PACKAGE_ID ||
      computeOperationDefinitionHash(operation) !== operation.definitionSha256
    ) {
      throw new AdapterContractError("Prometheus operation is not bound to this adapter and hash");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > context.maxDefinitionBytes) {
      throw new AdapterContractError("Prometheus operation definition exceeds the compile budget");
    }
    const reference = operation.definition.sanitizedProviderDefinition;
    if (
      Object.keys(reference).length !== 2 ||
      typeof reference.catalogEntryId !== "string" ||
      typeof reference.catalogEntrySha256 !== "string"
    ) {
      throw new AdapterContractError("Prometheus operation must contain only a trusted catalog reference");
    }
    const entry = this.#catalog.resolve(reference.catalogEntryId, reference.catalogEntrySha256 as Sha256);
    if (operation.definition.adapterOperation !== OPERATION_BY_ROUTE[entry.route]) {
      throw new AdapterContractError("Prometheus adapter operation does not match the catalog route");
    }
    if (operation.definition.normalization.resultKind !== compileExpectedResultKind(entry)) {
      throw new AdapterContractError("Prometheus normalization kind does not match the catalog result contract");
    }
    const expectedSourceLineage = {
      accessPath: "DIRECT" as const,
      datasourceType: "prometheus" as const,
      sourceIdentitySha256: entry.sourceIdentitySha256,
    };
    if (canonicalJson(operation.definition.expectedSourceLineage ?? null) !== canonicalJson(expectedSourceLineage)) {
      throw new AdapterContractError("Prometheus source lineage does not match the trusted catalog");
    }
    if (entry.allowedLabels.some((label) => !operation.definition.allowedDimensions.includes(label))) {
      throw new AdapterContractError("Prometheus catalog labels exceed the operation dimension allowlist");
    }
    if (
      entry.scope !== undefined &&
      (operation.definition.scopeMapping.environment !== "environment" ||
        operation.definition.scopeMapping.service !== "service")
    ) {
      throw new AdapterContractError("Prometheus scoped catalog entry requires exact sealed scope mappings");
    }
    return {
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      adapterPackageId: PROMETHEUS_ADAPTER_PACKAGE_ID,
      adapterOperation: operation.definition.adapterOperation,
      binding: bindingFor(entry),
    } satisfies CompiledAdapterOperation<PrometheusBinding>;
  }

  async execute(context: AdapterExecutionContext, operation: Readonly<CompiledAdapterOperation<PrometheusBinding>>) {
    context.budget.throwIfAborted();
    const trustedEntry = this.#catalog.resolve(
      operation.binding.catalogEntryId,
      operation.binding.catalogEntrySha256,
    );
    if (
      operation.adapterPackageId !== PROMETHEUS_ADAPTER_PACKAGE_ID ||
      operation.adapterOperation !== OPERATION_BY_ROUTE[trustedEntry.route] ||
      canonicalJson(operation.binding) !== canonicalJson(bindingFor(trustedEntry))
    ) {
      throw new AdapterContractError("Compiled Prometheus binding no longer matches the trusted catalog");
    }
    if (
      operation.binding.scopeEnvironment !== undefined &&
      (operation.binding.scopeEnvironment !== context.scope.environment ||
        operation.binding.scopeService !== context.scope.service)
    ) {
      throw new AdapterExecutionError({
        code: "PROMETHEUS_SCOPE_NOT_ALLOWED",
        category: "POLICY",
        message: "The requested scope does not match the reviewed Prometheus catalog entry",
        retryable: false,
      });
    }
    const request = buildRequest(operation.binding, context);
    let response: PrometheusHttpResponse;
    try {
      response = await this.#transport.request(request);
    } catch (error) {
      if (error instanceof BudgetExceededError || error instanceof AdapterExecutionError || error instanceof AdapterContractError) throw error;
      if (error instanceof PrometheusTransportError) {
        const transportError = error;
        throw new AdapterExecutionError({
          code: transportError.kind === "TIMEOUT" ? "PROMETHEUS_TRANSPORT_TIMEOUT" : "PROMETHEUS_UNAVAILABLE",
          category: transportError.kind,
          message: transportError.kind === "TIMEOUT" ? "Prometheus request timed out" : "Prometheus is unavailable",
          retryable: true,
        });
      }
      throw error;
    }
    if (response.status === 401 || response.status === 403 || response.status === 429) throw statusError(response.status);
    const body = await readJson(response, context);
    if (isObject(body) && body.status === "error") throw apiError(body);
    if (response.status < 200 || response.status >= 300) throw statusError(response.status);
    if (!isObject(body) || (body.status !== "success" && body.status !== "error")) {
      throw new AdapterContractError("Prometheus response envelope is invalid");
    }
    const warnings = parseWarnings(body);
    const initialEvaluatedAt = operation.binding.route === "range" || operation.binding.route === "instant"
      ? new Date(context.window.end).toISOString()
      : context.clock.now().toISOString();
    const state: ParseState = {
      records: [],
      warnings,
      evaluatedAt: initialEvaluatedAt,
      series: 0,
      points: 0,
      rows: 0,
    };
    if (operation.binding.route === "instant" || operation.binding.route === "range") {
      parseQueryData(body.data, operation.binding, context, state);
    } else if (operation.binding.route === "alerts") {
      parseAlerts(body.data, operation.binding, context, state);
    } else parseRules(body.data, operation.binding, context, state);

    const result: ProviderResult = {
      schemaVersion: "1.0.0",
      collectionState: state.records.length === 0 ? "EMPTY" : "COMPLETE",
      evaluatedAt: state.evaluatedAt,
      nativeResultType: operation.binding.route,
      nativeDimensions: {},
      records: state.records,
      pagination: state.truncatedReason === undefined
        ? { complete: true, pages: 1 }
        : { complete: false, pages: 1, truncatedReason: state.truncatedReason },
      warnings: state.warnings,
      sanitizedReference: `prometheus:${PATH_BY_ROUTE[operation.binding.route]}`,
      sourceLineage: {
        accessPath: "DIRECT",
        datasourceType: "prometheus",
        sourceIdentitySha256: operation.binding.sourceIdentitySha256,
      },
      ...(operation.binding.scopeEnvironment === undefined
        ? {}
        : {
            providerScope: {
              environment: operation.binding.scopeEnvironment,
              service: operation.binding.scopeService!,
              mappings: { environment: "environment", service: "service" },
            },
          }),
      ...(operation.binding.unit === undefined ? {} : { nativeUnit: operation.binding.unit }),
    };
    return result;
  }
}
