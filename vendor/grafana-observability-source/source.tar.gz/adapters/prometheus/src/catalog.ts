import { canonicalJson, sha256Canonical, type JsonObject, type Sha256 } from "../../../packages/contracts/src/index.ts";
import { AdapterContractError } from "../../../packages/adapter-sdk/src/index.ts";

import type { PrometheusCatalogEntry, PrometheusTrustedCatalog } from "./types.ts";

const PROMETHEUS_LABEL = /^[a-zA-Z_][a-zA-Z0-9_]*$/u;
const SAFE_ID = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/u;
const SHA256 = /^[a-f0-9]{64}$/u;

function assertExactKeys(entry: PrometheusCatalogEntry): void {
  const common = ["id", "route", "sourceIdentitySha256", "outputName", "unit", "allowedLabels", "scope"];
  const specific = entry.route === "instant"
    ? ["expression", "valueKind"]
    : entry.route === "range"
      ? ["expression", "stepSeconds", "valueKind"]
      : entry.route === "rules"
        ? ["ruleType"]
        : [];
  const allowed = new Set([...common, ...specific]);
  if (Object.keys(entry).some((key) => !allowed.has(key))) {
    throw new AdapterContractError("Prometheus catalog entry contains an unsupported field");
  }
}

export function prometheusCatalogEntryHash(entry: PrometheusCatalogEntry): Sha256 {
  return sha256Canonical(entry as unknown as JsonObject);
}

function validateEntry(entry: PrometheusCatalogEntry): void {
  if (!new Set(["instant", "range", "alerts", "rules"]).has(entry.route)) {
    throw new AdapterContractError("Prometheus catalog route is not read-only and allowlisted");
  }
  assertExactKeys(entry);
  if (!SAFE_ID.test(entry.id) || !SAFE_ID.test(entry.outputName)) {
    throw new AdapterContractError("Prometheus catalog IDs must use the bounded safe identifier format");
  }
  if (!SHA256.test(entry.sourceIdentitySha256)) {
    throw new AdapterContractError("Prometheus catalog source identity hash is invalid");
  }
  if (entry.allowedLabels.length > 16 || new Set(entry.allowedLabels).size !== entry.allowedLabels.length) {
    throw new AdapterContractError("Prometheus allowed labels must be unique and bounded");
  }
  if (entry.allowedLabels.some((label) => !PROMETHEUS_LABEL.test(label) || label === "__name__")) {
    throw new AdapterContractError("Prometheus catalog contains an invalid output label");
  }
  if (
    entry.scope !== undefined &&
    (!SAFE_ID.test(entry.scope.environment) || !SAFE_ID.test(entry.scope.service))
  ) {
    throw new AdapterContractError("Prometheus catalog scope is invalid");
  }
  if (entry.route === "instant" || entry.route === "range") {
    if (entry.expression.length === 0 || entry.expression.length > 16_384) {
      throw new AdapterContractError("Prometheus catalog expression is empty or too large");
    }
  }
  if (entry.route === "range" && (!Number.isSafeInteger(entry.stepSeconds) || entry.stepSeconds <= 0)) {
    throw new AdapterContractError("Prometheus range step must be a positive integer");
  }
  canonicalJson(entry);
}

export class CompiledPrometheusCatalog {
  readonly #entries: ReadonlyMap<string, PrometheusCatalogEntry>;

  constructor(catalog: Readonly<PrometheusTrustedCatalog>) {
    const entries = new Map<string, PrometheusCatalogEntry>();
    for (const supplied of catalog.entries) {
      const entry = structuredClone(supplied);
      validateEntry(entry);
      if (entries.has(entry.id)) throw new AdapterContractError(`Duplicate Prometheus catalog entry: ${entry.id}`);
      entries.set(entry.id, Object.freeze(entry));
    }
    this.#entries = entries;
  }

  resolve(id: string, expectedSha256: Sha256): PrometheusCatalogEntry {
    const entry = this.#entries.get(id);
    if (entry === undefined) throw new AdapterContractError("Prometheus catalog entry is not trusted");
    if (prometheusCatalogEntryHash(entry) !== expectedSha256) {
      throw new AdapterContractError("Prometheus catalog entry hash mismatch");
    }
    return entry;
  }
}
