import type { Sha256 } from "../../../packages/contracts/src/index.ts";

export type PrometheusRoute = "instant" | "range" | "alerts" | "rules";
export type PrometheusValueKind = "FLOAT" | "NATIVE_HISTOGRAM";

interface PrometheusCatalogEntryBase {
  id: string;
  /** Administrator-enrolled canonical identity shared with Grafana-mediated access. */
  sourceIdentitySha256: Sha256;
  outputName: string;
  unit?: string;
  allowedLabels: string[];
  /** Administrator-reviewed scope of the fixed catalog read. */
  scope?: { environment: string; service: string };
}

export interface PrometheusInstantCatalogEntry extends PrometheusCatalogEntryBase {
  route: "instant";
  expression: string;
  valueKind: PrometheusValueKind;
}

export interface PrometheusRangeCatalogEntry extends PrometheusCatalogEntryBase {
  route: "range";
  expression: string;
  stepSeconds: number;
  valueKind: PrometheusValueKind;
}

export interface PrometheusAlertsCatalogEntry extends PrometheusCatalogEntryBase {
  route: "alerts";
}

export interface PrometheusRulesCatalogEntry extends PrometheusCatalogEntryBase {
  route: "rules";
  ruleType?: "alert" | "record";
}

export type PrometheusCatalogEntry =
  | PrometheusInstantCatalogEntry
  | PrometheusRangeCatalogEntry
  | PrometheusAlertsCatalogEntry
  | PrometheusRulesCatalogEntry;

export interface PrometheusTrustedCatalog {
  entries: PrometheusCatalogEntry[];
}

export interface PrometheusHttpRequest {
  method: "GET";
  path: "/api/v1/query" | "/api/v1/query_range" | "/api/v1/alerts" | "/api/v1/rules";
  query: Readonly<Record<string, string>>;
  signal: AbortSignal;
  maxResponseBytes: number;
}

export interface PrometheusHttpResponse {
  status: number;
  body: AsyncIterable<Uint8Array>;
}

export interface PrometheusTransport {
  request(request: Readonly<PrometheusHttpRequest>): Promise<PrometheusHttpResponse>;
}

export class PrometheusTransportError extends Error {
  readonly kind: "TIMEOUT" | "UNAVAILABLE";

  constructor(kind: "TIMEOUT" | "UNAVAILABLE") {
    super(`Prometheus transport ${kind.toLowerCase()}`);
    this.name = "PrometheusTransportError";
    this.kind = kind;
  }
}

export interface PrometheusCatalogReference {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
}
