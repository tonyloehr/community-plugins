import {
  canonicalJson,
  computeOperationDefinitionHash,
  sha256Bytes,
  type AdapterPackage,
  type AdapterPackageId,
  type JsonObject,
  type JsonPrimitive,
  type OperationSnapshot,
  type Pagination,
  type Sha256,
} from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  type AdapterCompileContext,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderEvent,
  type ProviderResult,
} from "../../../packages/adapter-sdk/src/index.ts";

import { CompiledTempoCatalog, tempoCatalogEntryHash } from "./catalog.ts";
import type {
  TempoCatalogEntry,
  TempoHttpResponse,
  TempoTransport,
  TempoTransportError,
  TempoTrustedCatalog,
} from "./types.ts";

export const TEMPO_ADAPTER_PACKAGE_ID = "adapter.tempo.v1" as AdapterPackageId;

export const tempoAdapterPackage: AdapterPackage = {
  schemaVersion: "1.0.0",
  packageId: TEMPO_ADAPTER_PACKAGE_ID,
  name: "Tempo production-read-only adapter",
  version: "1.0.0",
  protocolVersion: "1.0",
  publisher: { name: "Codex Production Monitoring" },
  entrypoint: { kind: "BUILTIN", registryKey: "tempo-v1" },
  domains: ["TRACES"],
  capabilities: ["tempo.traces.search", "tempo.trace.read"],
  providerCompatibility: [{ provider: "tempo", versions: ">=2.4 <3" }],
  supportedContractVersions: ["1.0.0"],
  conformance: ["CORE_READ", "TRACES"],
};

type TempoBinding = JsonObject & {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
  sourceIdentitySha256: Sha256;
  route: "search" | "trace";
  outputName: string;
  allowedAttributes: string[];
  scopeEnvironment: string;
  scopeService: string;
  query?: string;
  traceId?: string;
};

interface TempoParseState {
  events: ProviderEvent[];
  evaluatedAt: string;
  truncatedReason?: Pagination["truncatedReason"];
  providerTruncated: boolean;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function safeString(value: unknown, label: string, maxLength = 4_096): string {
  if (typeof value !== "string" || value.length === 0 || value.length > maxLength) {
    throw new AdapterContractError(`Tempo ${label} is invalid`);
  }
  if ([...value].some((character) => (character.codePointAt(0) ?? 0) < 32)) {
    throw new AdapterContractError(`Tempo ${label} contains a control character`);
  }
  return value;
}

function nanoTimestamp(value: unknown): { iso: string; nanoseconds: bigint } {
  const text = safeString(value, "timestamp", 32);
  if (!/^\d{1,20}$/u.test(text)) throw new AdapterContractError("Tempo timestamp is invalid");
  const nanoseconds = BigInt(text);
  const milliseconds = nanoseconds / 1_000_000n;
  if (milliseconds > BigInt(Number.MAX_SAFE_INTEGER)) throw new AdapterContractError("Tempo timestamp is out of range");
  const date = new Date(Number(milliseconds));
  if (Number.isNaN(date.getTime())) throw new AdapterContractError("Tempo timestamp is out of range");
  return { iso: date.toISOString(), nanoseconds };
}

function safeDuration(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 86_400_000) {
    throw new AdapterContractError("Tempo trace duration is invalid");
  }
  return value;
}

function safeStatus(value: unknown): string {
  if (value === undefined) return "unset";
  if (typeof value === "string" && ["ok", "error", "unset"].includes(value.toLowerCase())) {
    return value.toLowerCase();
  }
  if (isObject(value) && (typeof value.code === "number" || typeof value.code === "string")) {
    const code = String(value.code).toLowerCase();
    if (["0", "unset"].includes(code)) return "unset";
    if (["1", "ok"].includes(code)) return "ok";
    if (["2", "error"].includes(code)) return "error";
  }
  throw new AdapterContractError("Tempo status is invalid");
}

async function readJson(response: TempoHttpResponse, context: AdapterExecutionContext): Promise<unknown> {
  const chunks: Uint8Array[] = [];
  for await (const chunk of response.body) {
    context.budget.throwIfAborted();
    context.budget.consumeBytes(chunk.byteLength);
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
  } catch {
    throw new AdapterContractError("Tempo response is not valid JSON");
  }
}

function statusError(status: number): AdapterExecutionError {
  if (status === 401 || status === 403) {
    return new AdapterExecutionError({
      code: "TEMPO_ACCESS_DENIED",
      category: status === 401 ? "AUTHENTICATION" : "AUTHORIZATION",
      message: "Tempo denied the bounded read request",
      retryable: false,
      providerStatus: status,
    });
  }
  if (status === 404) {
    return new AdapterExecutionError({
      code: "TEMPO_TRACE_NOT_FOUND",
      category: "INVALID_RESPONSE",
      message: "Tempo did not find the pinned trace",
      retryable: false,
      providerStatus: status,
    });
  }
  if (status === 429) {
    return new AdapterExecutionError({
      code: "TEMPO_RATE_LIMIT",
      category: "RATE_LIMIT",
      message: "Tempo rate limited the bounded read request",
      retryable: true,
      providerStatus: status,
    });
  }
  return new AdapterExecutionError({
    code: "TEMPO_READ_FAILED",
    category: status >= 500 ? "UNAVAILABLE" : "INVALID_RESPONSE",
    message: "Tempo bounded read failed",
    retryable: status >= 500,
    providerStatus: status,
  });
}

function assertScope(environment: string | undefined, service: string | undefined, context: AdapterExecutionContext): void {
  if (environment !== undefined && environment !== context.scope.environment) {
    throw new AdapterContractError("Tempo response crossed the authorized environment scope");
  }
  if (service !== undefined && context.scope.service !== undefined && service !== context.scope.service) {
    throw new AdapterContractError("Tempo response crossed the authorized service scope");
  }
}

function appendEvent(state: TempoParseState, event: ProviderEvent, context: AdapterExecutionContext): boolean {
  if (state.events.length >= context.budget.limits.maxRows) {
    state.truncatedReason = "ROW_LIMIT";
    return false;
  }
  context.budget.consumeRows(1);
  state.events.push(event);
  if (Date.parse(event.occurredAt) > Date.parse(state.evaluatedAt)) state.evaluatedAt = event.occurredAt;
  return true;
}

function parseSearch(body: Record<string, unknown>, binding: TempoBinding, context: AdapterExecutionContext): TempoParseState {
  if (!Array.isArray(body.traces)) throw new AdapterContractError("Tempo search response shape drifted");
  const state: TempoParseState = {
    events: [],
    evaluatedAt: new Date(context.window.end).toISOString(),
    providerTruncated: typeof body.nextPageToken === "string" && body.nextPageToken.length > 0,
  };
  for (const trace of body.traces) {
    context.budget.throwIfAborted();
    if (!isObject(trace)) throw new AdapterContractError("Tempo search trace is invalid");
    const traceId = safeString(trace.traceID, "trace ID", 32);
    if (!/^[a-fA-F0-9]{32}$/u.test(traceId)) throw new AdapterContractError("Tempo trace ID is invalid");
    const service = safeString(trace.rootServiceName, "root service", 256);
    const environment = trace.environment === undefined ? undefined : safeString(trace.environment, "environment", 128);
    assertScope(environment, service, context);
    const started = nanoTimestamp(trace.startTimeUnixNano);
    const durationMs = safeDuration(trace.durationMs);
    const attributes: Record<string, JsonPrimitive> = {
      traceSha256: sha256Bytes(traceId.toLowerCase()),
      rootServiceName: service,
      durationMs,
      status: safeStatus(trace.status),
    };
    if (environment !== undefined && binding.allowedAttributes.includes("environment")) attributes.environment = environment;
    if (!appendEvent(state, {
      kind: "EVENT",
      name: binding.outputName,
      occurredAt: started.iso,
      summary: `Trace ${attributes.status as string} (${durationMs} ms)`,
      attributes: Object.fromEntries(
        Object.entries(attributes).filter(([key]) => key === "traceSha256" || key === "durationMs" || key === "status" || binding.allowedAttributes.includes(key)),
      ),
    }, context)) break;
  }
  return state;
}

function otlpAttributeValue(value: unknown): string | undefined {
  if (!isObject(value)) return undefined;
  const candidate = value.stringValue;
  return typeof candidate === "string" && candidate.length <= 512 ? candidate : undefined;
}

function resourceScope(resource: unknown): { environment?: string; service?: string } {
  if (!isObject(resource) || !Array.isArray(resource.attributes)) return {};
  const scope: { environment?: string; service?: string } = {};
  for (const attribute of resource.attributes) {
    if (!isObject(attribute) || typeof attribute.key !== "string") continue;
    const parsed = otlpAttributeValue(attribute.value);
    if (parsed === undefined) continue;
    if (attribute.key === "service.name") scope.service = parsed;
    if (attribute.key === "deployment.environment.name" || attribute.key === "deployment.environment") {
      scope.environment = parsed;
    }
  }
  return scope;
}

function parseTrace(body: Record<string, unknown>, binding: TempoBinding, context: AdapterExecutionContext): TempoParseState {
  if (!Array.isArray(body.batches)) throw new AdapterContractError("Tempo trace response shape drifted");
  const state: TempoParseState = {
    events: [],
    evaluatedAt: new Date(context.window.end).toISOString(),
    providerTruncated: body.truncated === true,
  };
  for (const batch of body.batches) {
    if (!isObject(batch) || !Array.isArray(batch.scopeSpans)) throw new AdapterContractError("Tempo trace batch is invalid");
    const scope = resourceScope(batch.resource);
    assertScope(scope.environment, scope.service, context);
    for (const scopeSpan of batch.scopeSpans) {
      if (!isObject(scopeSpan) || !Array.isArray(scopeSpan.spans)) {
        throw new AdapterContractError("Tempo scope spans are invalid");
      }
      for (const span of scopeSpan.spans) {
        context.budget.throwIfAborted();
        if (!isObject(span)) throw new AdapterContractError("Tempo span is invalid");
        const traceId = safeString(span.traceId, "trace ID", 32);
        const spanId = safeString(span.spanId, "span ID", 16);
        if (!/^[a-fA-F0-9]{32}$/u.test(traceId) || !/^[a-fA-F0-9]{16}$/u.test(spanId)) {
          throw new AdapterContractError("Tempo span identity is invalid");
        }
        const started = nanoTimestamp(span.startTimeUnixNano);
        const ended = nanoTimestamp(span.endTimeUnixNano);
        if (ended.nanoseconds < started.nanoseconds) throw new AdapterContractError("Tempo span duration is negative");
        const durationMs = Number(ended.nanoseconds - started.nanoseconds) / 1_000_000;
        const name = safeString(span.name, "span name", 512);
        const status = safeStatus(span.status);
        const attributes: Record<string, JsonPrimitive> = {
          traceSha256: sha256Bytes(traceId.toLowerCase()),
          spanSha256: sha256Bytes(spanId.toLowerCase()),
          durationMs,
          status,
        };
        if (scope.service !== undefined && binding.allowedAttributes.includes("service")) attributes.service = scope.service;
        if (scope.environment !== undefined && binding.allowedAttributes.includes("environment")) {
          attributes.environment = scope.environment;
        }
        if (!appendEvent(state, {
          kind: "EVENT",
          name: binding.outputName,
          occurredAt: started.iso,
          summary: name,
          attributes,
        }, context)) return state;
      }
    }
  }
  return state;
}

function bindingFor(entry: TempoCatalogEntry): TempoBinding {
  return {
    catalogEntryId: entry.id,
    catalogEntrySha256: tempoCatalogEntryHash(entry),
    sourceIdentitySha256: entry.sourceIdentitySha256,
    route: entry.route,
    outputName: entry.outputName,
    allowedAttributes: [...entry.allowedAttributes],
    scopeEnvironment: entry.scope.environment,
    scopeService: entry.scope.service,
    ...(entry.route === "search" ? { query: entry.query } : { traceId: entry.traceId }),
  };
}

export interface TempoAdapterOptions {
  transport: TempoTransport;
  catalog: TempoTrustedCatalog;
}

export class TempoAdapter implements EvidenceAdapter<TempoBinding> {
  readonly descriptor = {
    packageId: TEMPO_ADAPTER_PACKAGE_ID,
    name: tempoAdapterPackage.name,
    version: tempoAdapterPackage.version,
    provider: "tempo",
    domains: ["TRACES"] as const,
    operations: tempoAdapterPackage.capabilities,
    resultSchemaVersions: ["1.0.0"] as const,
  };

  readonly #transport: TempoTransport;
  readonly #catalog: CompiledTempoCatalog;

  constructor(options: TempoAdapterOptions) {
    this.#transport = options.transport;
    this.#catalog = new CompiledTempoCatalog(options.catalog);
  }

  async doctor() {
    return {
      status: "READY" as const,
      checks: [{ name: "production-read-only", status: "PASS" as const, message: "Trusted Tempo catalog loaded" }],
    };
  }

  async compile(operation: Readonly<OperationSnapshot>, context: AdapterCompileContext) {
    if (context.adapterPackage.packageId !== TEMPO_ADAPTER_PACKAGE_ID) {
      throw new AdapterContractError("Tempo adapter package mismatch");
    }
    if (
      operation.definition.adapterPackageId !== TEMPO_ADAPTER_PACKAGE_ID ||
      computeOperationDefinitionHash(operation) !== operation.definitionSha256
    ) {
      throw new AdapterContractError("Tempo operation is not bound to this adapter and hash");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > context.maxDefinitionBytes) {
      throw new AdapterContractError("Tempo operation definition exceeds the compile budget");
    }
    const reference = operation.definition.sanitizedProviderDefinition;
    if (
      Object.keys(reference).length !== 2 ||
      typeof reference.catalogEntryId !== "string" ||
      typeof reference.catalogEntrySha256 !== "string"
    ) {
      throw new AdapterContractError("Tempo operation must contain only a trusted catalog reference");
    }
    const entry = this.#catalog.resolve(reference.catalogEntryId, reference.catalogEntrySha256 as Sha256);
    const expectedOperation = entry.route === "search" ? "tempo.traces.search" : "tempo.trace.read";
    if (operation.definition.adapterOperation !== expectedOperation) {
      throw new AdapterContractError("Tempo adapter operation does not match the trusted route");
    }
    if (operation.definition.domain !== "TRACES" || operation.definition.normalization.resultKind !== "EVENT") {
      throw new AdapterContractError("Tempo operation result contract is invalid");
    }
    const expectedSourceLineage = {
      accessPath: "DIRECT" as const,
      datasourceType: "tempo" as const,
      sourceIdentitySha256: entry.sourceIdentitySha256,
    };
    if (canonicalJson(operation.definition.expectedSourceLineage ?? null) !== canonicalJson(expectedSourceLineage)) {
      throw new AdapterContractError("Tempo source lineage does not match the trusted catalog");
    }
    if (entry.allowedAttributes.some((attribute) => !operation.definition.allowedDimensions.includes(attribute))) {
      throw new AdapterContractError("Tempo catalog attributes exceed the operation allowlist");
    }
    return {
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      adapterPackageId: TEMPO_ADAPTER_PACKAGE_ID,
      adapterOperation: operation.definition.adapterOperation,
      binding: bindingFor(entry),
    } satisfies CompiledAdapterOperation<TempoBinding>;
  }

  async execute(
    context: AdapterExecutionContext,
    operation: Readonly<CompiledAdapterOperation<TempoBinding>>,
  ): Promise<ProviderResult> {
    context.budget.throwIfAborted();
    const trustedEntry = this.#catalog.resolve(
      operation.binding.catalogEntryId,
      operation.binding.catalogEntrySha256,
    );
    const expectedOperation = trustedEntry.route === "search" ? "tempo.traces.search" : "tempo.trace.read";
    if (
      operation.adapterPackageId !== TEMPO_ADAPTER_PACKAGE_ID ||
      operation.adapterOperation !== expectedOperation ||
      canonicalJson(operation.binding) !== canonicalJson(bindingFor(trustedEntry))
    ) {
      throw new AdapterContractError("Compiled Tempo binding no longer matches the trusted catalog");
    }
    if (
      operation.binding.scopeEnvironment !== context.scope.environment ||
      operation.binding.scopeService !== context.scope.service
    ) {
      throw new AdapterExecutionError({
        code: "TEMPO_SCOPE_NOT_ALLOWED",
        category: "POLICY",
        message: "The requested scope does not match the reviewed Tempo catalog entry",
        retryable: false,
      });
    }
    let response: TempoHttpResponse;
    try {
      response = await this.#transport.request(operation.binding.route === "search"
        ? {
            method: "GET",
            route: "SEARCH",
            query: operation.binding.query!,
            start: context.window.start,
            end: context.window.end,
            limit: context.budget.limits.maxRows,
            signal: context.signal,
            maxResponseBytes: context.budget.limits.maxBytes,
          }
        : {
            method: "GET",
            route: "TRACE",
            traceId: operation.binding.traceId!,
            signal: context.signal,
            maxResponseBytes: context.budget.limits.maxBytes,
          });
    } catch (error) {
      if (error instanceof AdapterExecutionError || error instanceof AdapterContractError || error instanceof BudgetExceededError) {
        throw error;
      }
      if ((error as TempoTransportError | undefined)?.name === "TempoTransportError") {
        const transportError = error as TempoTransportError;
        throw new AdapterExecutionError({
          code: transportError.kind === "TIMEOUT" ? "TEMPO_TIMEOUT" : "TEMPO_UNAVAILABLE",
          category: transportError.kind,
          message: transportError.kind === "TIMEOUT" ? "Tempo read timed out" : "Tempo is unavailable",
          retryable: true,
        });
      }
      if (context.signal.aborted) throw context.signal.reason ?? error;
      throw new AdapterExecutionError({
        code: "TEMPO_UNAVAILABLE",
        category: "UNAVAILABLE",
        message: "Tempo is unavailable",
        retryable: true,
      });
    }
    const rawBody = await readJson(response, context);
    if (response.status < 200 || response.status >= 300) throw statusError(response.status);
    if (!isObject(rawBody)) throw new AdapterContractError("Tempo response envelope is invalid");
    const state = operation.binding.route === "search"
      ? parseSearch(rawBody, operation.binding, context)
      : parseTrace(rawBody, operation.binding, context);
    const truncatedReason = state.truncatedReason ?? (state.providerTruncated ? "ROW_LIMIT" : undefined);
    return {
      schemaVersion: "1.0.0",
      collectionState: state.events.length === 0 ? "EMPTY" : "COMPLETE",
      evaluatedAt: state.evaluatedAt,
      nativeResultType: operation.binding.route,
      nativeUnit: "milliseconds",
      nativeDimensions: {},
      records: state.events,
      pagination: truncatedReason === undefined
        ? { complete: true, pages: 1 }
        : { complete: false, pages: 1, truncatedReason },
      warnings: truncatedReason === undefined ? [] : ["Tempo result was truncated by the bounded read policy"],
      sanitizedReference: operation.binding.route === "search" ? "tempo:search" : "tempo:trace",
      sourceLineage: {
        accessPath: "DIRECT",
        datasourceType: "tempo",
        sourceIdentitySha256: operation.binding.sourceIdentitySha256,
      },
      providerScope: {
        environment: context.scope.environment,
        ...(context.scope.service === undefined ? {} : { service: context.scope.service }),
        mappings: {
          environment: "environment",
          ...(context.scope.service === undefined ? {} : { service: "service" }),
        },
      },
    };
  }
}
