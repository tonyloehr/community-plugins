import type { Sha256 } from "../../../packages/contracts/src/index.ts";

interface TempoCatalogEntryBase {
  id: string;
  /** Administrator-enrolled canonical identity shared with Grafana-mediated access. */
  sourceIdentitySha256: Sha256;
  outputName: string;
  allowedAttributes: string[];
  scope: { environment: string; service: string };
}

export interface TempoSearchCatalogEntry extends TempoCatalogEntryBase {
  route: "search";
  query: string;
}

export interface TempoTraceCatalogEntry extends TempoCatalogEntryBase {
  route: "trace";
  traceId: string;
}

export type TempoCatalogEntry = TempoSearchCatalogEntry | TempoTraceCatalogEntry;

export interface TempoTrustedCatalog {
  entries: TempoCatalogEntry[];
}

export interface TempoCatalogReference {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
}

export type TempoHttpRequest =
  | {
      method: "GET";
      route: "SEARCH";
      query: string;
      start: string;
      end: string;
      limit: number;
      signal: AbortSignal;
      maxResponseBytes: number;
    }
  | {
      method: "GET";
      route: "TRACE";
      traceId: string;
      signal: AbortSignal;
      maxResponseBytes: number;
    };

export interface TempoHttpResponse {
  status: number;
  body: AsyncIterable<Uint8Array>;
}

export interface TempoTransport {
  request(request: Readonly<TempoHttpRequest>): Promise<TempoHttpResponse>;
}

export class TempoTransportError extends Error {
  readonly kind: "TIMEOUT" | "UNAVAILABLE";

  constructor(kind: "TIMEOUT" | "UNAVAILABLE") {
    super(`Tempo transport ${kind.toLowerCase()}`);
    this.name = "TempoTransportError";
    this.kind = kind;
  }
}
