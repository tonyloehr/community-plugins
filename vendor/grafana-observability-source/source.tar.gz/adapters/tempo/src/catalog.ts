import { canonicalJson, sha256Canonical, type JsonObject, type Sha256 } from "../../../packages/contracts/src/index.ts";
import { AdapterContractError } from "../../../packages/adapter-sdk/src/index.ts";

import type { TempoCatalogEntry, TempoTrustedCatalog } from "./types.ts";

const SAFE_ID = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/u;
const SAFE_ATTRIBUTE = /^[a-zA-Z][a-zA-Z0-9_.-]{0,127}$/u;
const SAFE_SCOPE = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/u;
const TRACE_ID = /^[a-fA-F0-9]{32}$/u;
const SHA256 = /^[a-f0-9]{64}$/u;

function assertExactKeys(entry: TempoCatalogEntry): void {
  const common = ["id", "sourceIdentitySha256", "outputName", "allowedAttributes", "scope", "route"];
  const specific = entry.route === "search" ? ["query"] : ["traceId"];
  const allowed = new Set([...common, ...specific]);
  if (Object.keys(entry).some((key) => !allowed.has(key))) {
    throw new AdapterContractError("Tempo catalog entry contains an unsupported field");
  }
}

export function tempoCatalogEntryHash(entry: TempoCatalogEntry): Sha256 {
  return sha256Canonical(entry as unknown as JsonObject);
}

function validateEntry(entry: TempoCatalogEntry): void {
  assertExactKeys(entry);
  if (!SAFE_ID.test(entry.id) || !SAFE_ID.test(entry.outputName)) {
    throw new AdapterContractError("Tempo catalog IDs must use the bounded safe identifier format");
  }
  if (!SHA256.test(entry.sourceIdentitySha256)) {
    throw new AdapterContractError("Tempo catalog source identity hash is invalid");
  }
  if (
    entry.allowedAttributes.length > 16 ||
    new Set(entry.allowedAttributes).size !== entry.allowedAttributes.length ||
    entry.allowedAttributes.some((attribute) => !SAFE_ATTRIBUTE.test(attribute))
  ) {
    throw new AdapterContractError("Tempo allowed attributes must be unique, valid, and bounded");
  }
  if (!SAFE_SCOPE.test(entry.scope.environment) || !SAFE_SCOPE.test(entry.scope.service)) {
    throw new AdapterContractError("Tempo catalog scope is invalid");
  }
  if (entry.route === "search") {
    if (entry.query.length === 0 || entry.query.length > 16_384) {
      throw new AdapterContractError("Tempo search query is empty or too large");
    }
  } else if (!TRACE_ID.test(entry.traceId)) {
    throw new AdapterContractError("Tempo trace catalog entry must pin a full trace ID");
  }
  canonicalJson(entry);
}

export class CompiledTempoCatalog {
  readonly #entries: ReadonlyMap<string, TempoCatalogEntry>;

  constructor(catalog: Readonly<TempoTrustedCatalog>) {
    const entries = new Map<string, TempoCatalogEntry>();
    for (const supplied of catalog.entries) {
      const entry = structuredClone(supplied);
      validateEntry(entry);
      if (entries.has(entry.id)) throw new AdapterContractError(`Duplicate Tempo catalog entry: ${entry.id}`);
      entries.set(entry.id, Object.freeze({
        ...entry,
        allowedAttributes: Object.freeze([...entry.allowedAttributes]),
        scope: Object.freeze({ ...entry.scope }),
      }) as TempoCatalogEntry);
    }
    this.#entries = entries;
  }

  resolve(id: string, expectedSha256: Sha256): TempoCatalogEntry {
    const entry = this.#entries.get(id);
    if (entry === undefined) throw new AdapterContractError("Tempo catalog entry is not trusted");
    if (tempoCatalogEntryHash(entry) !== expectedSha256) {
      throw new AdapterContractError("Tempo catalog entry hash mismatch");
    }
    return entry;
  }
}
