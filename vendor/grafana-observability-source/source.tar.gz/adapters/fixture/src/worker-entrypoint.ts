import { runFixtureWorker, type FixtureWorkerMode } from "./worker.ts";

const requestedMode = process.argv[2] ?? "normal";
const mode: FixtureWorkerMode = ["normal", "crash", "oversize", "protocol", "environment"].includes(requestedMode)
  ? (requestedMode as FixtureWorkerMode)
  : "normal";

try {
  await runFixtureWorker(mode);
} catch {
  process.exitCode = 1;
}
