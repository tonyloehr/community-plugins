import { runAdapterWorker } from "../../../packages/adapter-runner/src/index.ts";

import { fixtureAdapter } from "./fixture-adapter.ts";

export type FixtureWorkerMode = "normal" | "crash" | "oversize" | "protocol" | "environment";

function firstInputChunk(): Promise<void> {
  return new Promise((resolve) => {
    process.stdin.once("data", () => resolve());
    process.stdin.resume();
  });
}

/** Deterministic failure modes exercise host isolation without provider access. */
export async function runFixtureWorker(mode: FixtureWorkerMode = "normal"): Promise<void> {
  if (mode === "normal" || mode === "environment") {
    if (mode === "environment" && process.env.PM_ADAPTER_INHERITANCE_PROBE !== undefined) {
      process.exitCode = 73;
      return;
    }
    await runAdapterWorker(fixtureAdapter);
    return;
  }
  await firstInputChunk();
  if (mode === "crash") {
    process.stdin.destroy();
    process.exitCode = 72;
    return;
  }
  if (mode === "oversize") {
    const header = Buffer.alloc(4);
    header.writeUInt32BE(0xffff_ffff, 0);
    process.stdout.write(header);
    process.stdin.destroy();
    return;
  }
  const malformed = Buffer.from(
    JSON.stringify({
      protocol: "PM_ADAPTER_STDIO_V1",
      kind: "error",
      requestId: "unexpected-request-id",
      error: {
        code: "FIXTURE_PROTOCOL",
        category: "INTERNAL",
        message: "Fixture emitted a response for an unknown request",
        retryable: false,
      },
    }),
    "utf8",
  );
  const header = Buffer.alloc(4);
  header.writeUInt32BE(malformed.byteLength, 0);
  process.stdout.write(Buffer.concat([header, malformed]));
  process.stdin.destroy();
}
