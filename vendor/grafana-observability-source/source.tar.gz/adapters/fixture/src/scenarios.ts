export const FIXTURE_SCENARIOS = [
  "healthy",
  "degraded",
  "recovered",
  "empty",
  "stale",
  "contradictory",
  "unavailable",
  "timeout",
  "truncation",
  "rate-limit",
  "injection",
  "secret",
  "cross-tenant",
  "schema-drift",
  "clock-skew",
] as const;

export type FixtureScenario = (typeof FIXTURE_SCENARIOS)[number];

export function isFixtureScenario(value: unknown): value is FixtureScenario {
  return typeof value === "string" && (FIXTURE_SCENARIOS as readonly string[]).includes(value);
}
