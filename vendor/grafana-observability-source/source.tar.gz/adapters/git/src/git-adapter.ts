import { execFile, type ExecFileException } from "node:child_process";
import { createHash } from "node:crypto";
import {
  closeSync,
  constants,
  existsSync,
  fstatSync,
  lstatSync,
  openSync,
  readSync,
  realpathSync,
} from "node:fs";
import { basename, isAbsolute, relative, resolve, sep } from "node:path";

import {
  canonicalJson,
  computeOperationDefinitionHash,
  type AdapterPackage,
  type AdapterPackageId,
  type JsonObject,
  type OperationDefinition,
  type OperationId,
  type OperationLimits,
  type OperationSnapshot,
} from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  type AdapterCompileContext,
  type AdapterDoctorContext,
  type AdapterDoctorResult,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderResult,
  type ProviderTable,
} from "../../../packages/adapter-sdk/src/index.ts";

export const GIT_ADAPTER_PACKAGE_ID = "adapter.git.v1" as AdapterPackageId;

export const gitAdapterPackage: AdapterPackage = {
  schemaVersion: "1.0.0",
  packageId: GIT_ADAPTER_PACKAGE_ID,
  name: "Read-only Git evidence adapter",
  version: "1.0.0",
  protocolVersion: "1.0",
  publisher: { name: "Codex Production Monitoring" },
  entrypoint: { kind: "BUILTIN", registryKey: "git-readonly-v1" },
  domains: ["CHANGES"],
  capabilities: ["git.diff.read", "git.status.read"],
  providerCompatibility: [{ provider: "git", versions: ">=2.30" }],
  supportedContractVersions: ["1.0.0"],
  conformance: ["CORE_READ", "CHANGES"],
};

export interface GitWorkspaceBinding {
  workspaceId: string;
  root: string;
}

interface GitBindingBase {
  bindingId: string;
  workspaceId: string;
  allowedPaths: readonly string[];
  maxBytes: number;
  maxFiles: number;
  maxHunks: number;
  maxLines: number;
}

export interface GitDiffCatalogBinding extends GitBindingBase {
  operation: "git.diff";
  baseCommit: string;
  targetCommit: string;
}

export interface GitStatusCatalogBinding extends GitBindingBase {
  operation: "git.status";
}

export type GitCatalogBinding = GitDiffCatalogBinding | GitStatusCatalogBinding;

export interface GitExecutorRequest {
  executable: string;
  args: readonly string[];
  cwd: string;
  env: Readonly<Record<string, string>>;
  maxBufferBytes: number;
  timeoutMs: number;
  signal: AbortSignal;
}

export interface GitExecutorResult {
  stdout: string;
  stderr: string;
  exitCode: number;
}

export interface GitExecutor {
  execute(request: Readonly<GitExecutorRequest>): Promise<GitExecutorResult>;
}

export interface GitAdapterOptions {
  workspaces: readonly GitWorkspaceBinding[];
  catalog: readonly GitCatalogBinding[];
  executor?: GitExecutor;
  gitExecutable?: string;
}

interface PinnedWorkspace {
  workspaceId: string;
  root: string;
  device: number;
  inode: number;
}

type GitCompiledBinding = JsonObject & {
  bindingId: string;
  workspaceId: string;
  operation: "git.diff" | "git.status";
  allowedPaths: string[];
  maxBytes: number;
  maxFiles: number;
  maxHunks: number;
  maxLines: number;
  baseCommit?: string;
  targetCommit?: string;
};

const descriptor = {
  packageId: GIT_ADAPTER_PACKAGE_ID,
  name: gitAdapterPackage.name,
  version: gitAdapterPackage.version,
  provider: "git",
  domains: ["CHANGES"] as const,
  operations: ["git.diff", "git.status"] as const,
  resultSchemaVersions: ["1.0.0"] as const,
};

export const GIT_FIXED_ENVIRONMENT: Readonly<Record<string, string>> = Object.freeze({
  PATH: "/usr/bin:/bin",
  LANG: "C.UTF-8",
  LC_ALL: "C.UTF-8",
  GIT_CONFIG_NOSYSTEM: "1",
  GIT_CONFIG_GLOBAL: "/dev/null",
  GIT_TERMINAL_PROMPT: "0",
  GIT_OPTIONAL_LOCKS: "0",
  GIT_PAGER: "cat",
  PAGER: "cat",
  GIT_EXTERNAL_DIFF: "",
});

const FIXED_GIT_PREFIX = [
  "--no-pager",
  "--no-optional-locks",
  "-c",
  "core.pager=cat",
  "-c",
  "pager.diff=false",
  "-c",
  "diff.external=",
  "-c",
  "core.attributesfile=/dev/null",
  "-c",
  "core.hooksPath=/dev/null",
  "-c",
  "core.quotePath=true",
] as const;

const FULL_COMMIT_ID = /^(?:[a-f0-9]{40}|[a-f0-9]{64})$/u;
const SAFE_IDENTIFIER = /^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u;

function executionError(error: ExecFileException): AdapterExecutionError {
  if (error.code === "ERR_CHILD_PROCESS_STDIO_MAXBUFFER") {
    return new AdapterExecutionError({
      code: "git.snapshot_byte_limit",
      category: "POLICY",
      message: "The bounded Git read exceeded its byte limit",
      retryable: false,
    });
  }
  if (error.code === "ENOENT") {
    return new AdapterExecutionError({
      code: "git.not_available",
      category: "UNAVAILABLE",
      message: "The configured Git executable is unavailable",
      retryable: false,
    });
  }
  if (error.killed || error.code === "ETIMEDOUT" || error.name === "AbortError") {
    return new AdapterExecutionError({
      code: "git.timeout",
      category: "TIMEOUT",
      message: "The bounded Git read timed out",
      retryable: true,
    });
  }
  return new AdapterExecutionError({
    code: "git.read_failed",
    category: "INVALID_RESPONSE",
    message: "The bounded Git read failed",
    retryable: false,
  });
}

export class ExecFileGitExecutor implements GitExecutor {
  async execute(request: Readonly<GitExecutorRequest>): Promise<GitExecutorResult> {
    return new Promise<GitExecutorResult>((resolvePromise, rejectPromise) => {
      execFile(
        request.executable,
        [...request.args],
        {
          cwd: request.cwd,
          encoding: "utf8",
          env: { ...request.env },
          maxBuffer: request.maxBufferBytes,
          shell: false,
          signal: request.signal,
          timeout: request.timeoutMs,
          windowsHide: true,
        },
        (error, stdout, stderr) => {
          if (error !== null) {
            rejectPromise(executionError(error));
            return;
          }
          resolvePromise({ stdout, stderr, exitCode: 0 });
        },
      );
    });
  }
}

function assertPositiveInteger(value: number, label: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new AdapterContractError(`${label} must be a positive safe integer`);
  }
}

function assertCatalogBounds(binding: GitCatalogBinding): void {
  if (binding.maxBytes > 1_073_741_824) throw new AdapterContractError("Git maxBytes is too large");
  if (binding.maxFiles > 1_000_000) throw new AdapterContractError("Git maxFiles is too large");
  if (binding.maxHunks > 100_000) throw new AdapterContractError("Git maxHunks is too large");
  if (binding.maxLines > 1_000_000) throw new AdapterContractError("Git maxLines is too large");
}

function canonicalWorkspace(binding: GitWorkspaceBinding): PinnedWorkspace {
  if (!SAFE_IDENTIFIER.test(binding.workspaceId)) {
    throw new AdapterContractError("Git workspaceId is invalid");
  }
  if (!isAbsolute(binding.root)) throw new AdapterContractError("Git workspace root must be absolute");
  const requested = resolve(binding.root);
  const requestedStat = lstatSync(requested);
  if (!requestedStat.isDirectory() || requestedStat.isSymbolicLink()) {
    throw new AdapterContractError("Git workspace root must be a real directory");
  }
  const root = realpathSync.native(requested);
  const stat = lstatSync(root);
  return {
    workspaceId: binding.workspaceId,
    root,
    device: stat.dev,
    inode: stat.ino,
  };
}

function assertPinnedWorkspace(workspace: PinnedWorkspace): void {
  const stat = lstatSync(workspace.root);
  if (
    !stat.isDirectory() ||
    stat.isSymbolicLink() ||
    stat.dev !== workspace.device ||
    stat.ino !== workspace.inode ||
    realpathSync.native(workspace.root) !== workspace.root
  ) {
    throw new AdapterContractError("Pinned Git workspace identity changed");
  }
}

function validateConfiguredPath(workspace: PinnedWorkspace, configuredPath: string): string {
  if (
    configuredPath.length === 0 ||
    configuredPath.length > 1024 ||
    isAbsolute(configuredPath) ||
    configuredPath.includes("\\") ||
    configuredPath.includes("\0") ||
    configuredPath.includes("\r") ||
    configuredPath.includes("\n")
  ) {
    throw new AdapterContractError("Git catalog path is not a safe relative path");
  }
  if (configuredPath === ".") return configuredPath;
  const segments = configuredPath.split("/");
  if (segments.some((segment) => segment.length === 0 || segment === "." || segment === ".." || segment === ".git")) {
    throw new AdapterContractError("Git catalog path contains a forbidden segment");
  }
  const candidate = resolve(workspace.root, ...segments);
  const fromRoot = relative(workspace.root, candidate);
  if (fromRoot === ".." || fromRoot.startsWith(`..${sep}`) || isAbsolute(fromRoot)) {
    throw new AdapterContractError("Git catalog path escapes the pinned workspace");
  }

  let cursor = workspace.root;
  for (const segment of segments) {
    cursor = resolve(cursor, segment);
    if (!existsSync(cursor)) break;
    const stat = lstatSync(cursor);
    if (stat.isSymbolicLink()) {
      throw new AdapterContractError("Git catalog path cannot traverse a symbolic link");
    }
  }
  return segments.join("/");
}

function cloneCatalogBinding(
  binding: GitCatalogBinding,
  workspaces: ReadonlyMap<string, PinnedWorkspace>,
): GitCatalogBinding {
  if (!SAFE_IDENTIFIER.test(binding.bindingId)) {
    throw new AdapterContractError("Git bindingId is invalid");
  }
  const workspace = workspaces.get(binding.workspaceId);
  if (workspace === undefined) throw new AdapterContractError("Git binding references an unknown workspace");
  if (binding.allowedPaths.length === 0 || binding.allowedPaths.length > 256) {
    throw new AdapterContractError("Git binding must contain one to 256 configured paths");
  }
  const paths = binding.allowedPaths.map((path) => validateConfiguredPath(workspace, path));
  if (new Set(paths).size !== paths.length) {
    throw new AdapterContractError("Git binding paths must be unique");
  }
  assertPositiveInteger(binding.maxBytes, "Git maxBytes");
  assertPositiveInteger(binding.maxFiles, "Git maxFiles");
  assertPositiveInteger(binding.maxHunks, "Git maxHunks");
  assertPositiveInteger(binding.maxLines, "Git maxLines");
  assertCatalogBounds(binding);
  if (binding.operation === "git.diff") {
    if (!FULL_COMMIT_ID.test(binding.baseCommit) || !FULL_COMMIT_ID.test(binding.targetCommit)) {
      throw new AdapterContractError("Git diff revisions must be pinned full commit IDs");
    }
    return Object.freeze({ ...binding, allowedPaths: Object.freeze(paths) });
  }
  if (binding.operation !== "git.status") throw new AdapterContractError("Unsupported Git operation");
  return Object.freeze({ ...binding, allowedPaths: Object.freeze(paths) });
}

function safeOutputText(value: string): string {
  return [...value]
    .map((character) => {
      const code = character.charCodeAt(0);
      return code <= 0x1f || code === 0x7f ? "�" : character;
    })
    .join("");
}

interface BoundedOutput {
  rows: Array<Array<number | string>>;
  files: number;
  hunks: number;
  truncated: boolean;
  reason?: "BYTE_LIMIT" | "ROW_LIMIT";
}

interface GitStatusSnapshot {
  headState: "COMMIT" | "UNBORN";
  headCommit?: string;
  branch: string;
  rows: Array<Array<number | string>>;
  files: number;
  rawSha256: string;
}

interface GitFileReceipt {
  path: string;
  kind: "FILE" | "MISSING";
  size: number;
  contentSha256: string | null;
}

interface GitWorktreeSnapshot {
  status: GitStatusSnapshot;
  indexSha256: string;
  worktreeSnapshotSha256: string;
  fileReceipts: GitFileReceipt[];
  contentBytes: number;
  diagnostic: boolean;
}

function boundedDiff(stdout: string, binding: GitCompiledBinding): BoundedOutput {
  const bytes = Buffer.from(stdout, "utf8");
  let source = stdout;
  let truncated = false;
  let reason: BoundedOutput["reason"];
  if (bytes.length > binding.maxBytes) {
    source = bytes.subarray(0, binding.maxBytes).toString("utf8");
    truncated = true;
    reason = "BYTE_LIMIT";
  }
  const rows: Array<Array<number | string>> = [];
  let files = 0;
  let hunks = 0;
  for (const line of source.split("\n")) {
    const nextFiles = files + (line.startsWith("diff --git ") ? 1 : 0);
    const nextHunks = hunks + (line.startsWith("@@ ") ? 1 : 0);
    if (
      rows.length >= binding.maxLines ||
      nextFiles > binding.maxFiles ||
      nextHunks > binding.maxHunks
    ) {
      truncated = true;
      reason ??= "ROW_LIMIT";
      break;
    }
    files = nextFiles;
    hunks = nextHunks;
    if (line.length > 0) rows.push([rows.length + 1, safeOutputText(line)]);
  }
  return { rows, files, hunks, truncated, ...(reason === undefined ? {} : { reason }) };
}

function sha256(value: string | Buffer): string {
  return createHash("sha256").update(value).digest("hex");
}

function snapshotFailure(code: string, message: string): AdapterExecutionError {
  return new AdapterExecutionError({
    code,
    category: "POLICY",
    message,
    retryable: false,
  });
}

function fixedFields(record: string, count: number): { fields: string[]; remainder: string } {
  const fields: string[] = [];
  let cursor = 0;
  for (let index = 0; index < count; index += 1) {
    const separator = record.indexOf(" ", cursor);
    if (separator < 0) throw new AdapterContractError("Git status output is malformed");
    fields.push(record.slice(cursor, separator));
    cursor = separator + 1;
  }
  const remainder = record.slice(cursor);
  if (remainder.length === 0) throw new AdapterContractError("Git status output is malformed");
  return { fields, remainder };
}

function pathWithinConfiguredScope(path: string, allowedPaths: readonly string[]): boolean {
  return allowedPaths.some((allowed) => allowed === "." || path === allowed || path.startsWith(`${allowed}/`));
}

function assertEnumeratedPath(path: string, allowedPaths: readonly string[]): void {
  if (
    path.length === 0 ||
    path.length > 4096 ||
    path.includes("\0") ||
    isAbsolute(path)
  ) {
    throw snapshotFailure("git.snapshot_unsafe_path", "Git returned an unsafe workspace path");
  }
  const segments = path.split("/");
  if (
    segments.some((segment) => segment.length === 0 || segment === "." || segment === ".." || segment === ".git") ||
    !pathWithinConfiguredScope(path, allowedPaths)
  ) {
    throw snapshotFailure("git.snapshot_unsafe_path", "Git returned a path outside the reviewed scope");
  }
}

function parseStatusSnapshot(stdout: string, binding: GitCompiledBinding): GitStatusSnapshot {
  if (Buffer.byteLength(stdout, "utf8") > binding.maxBytes) {
    throw snapshotFailure("git.snapshot_byte_limit", "Git status exceeded the reviewed byte bound");
  }
  let oid: string | undefined;
  let branch: string | undefined;
  const rows: Array<Array<number | string>> = [];
  const entries = stdout.split("\0");
  for (let index = 0; index < entries.length; index += 1) {
    const entry = entries[index]!;
    if (entry.length === 0) continue;
    if (entry.startsWith("# branch.oid ")) {
      if (oid !== undefined) throw new AdapterContractError("Git status repeated the HEAD identity");
      oid = entry.slice("# branch.oid ".length);
      continue;
    }
    if (entry.startsWith("# branch.head ")) {
      if (branch !== undefined) throw new AdapterContractError("Git status repeated the branch identity");
      branch = entry.slice("# branch.head ".length);
      continue;
    }
    if (entry.startsWith("# branch.")) continue;
    if (rows.length >= binding.maxFiles || rows.length >= binding.maxLines) {
      throw snapshotFailure("git.snapshot_file_limit", "Git status exceeded the reviewed file bound");
    }

    let status: string;
    let path: string;
    if (entry.startsWith("? ") || entry.startsWith("! ")) {
      status = entry[0]!;
      path = entry.slice(2);
    } else if (entry.startsWith("1 ")) {
      const parsed = fixedFields(entry, 8);
      status = parsed.fields[1]!;
      path = parsed.remainder;
    } else if (entry.startsWith("2 ")) {
      const parsed = fixedFields(entry, 9);
      status = parsed.fields[1]!;
      const originalPath = entries[index + 1];
      if (originalPath === undefined || originalPath.length === 0) {
        throw new AdapterContractError("Git rename status output is malformed");
      }
      assertEnumeratedPath(originalPath, binding.allowedPaths);
      path = `${originalPath} -> ${parsed.remainder}`;
      assertEnumeratedPath(parsed.remainder, binding.allowedPaths);
      index += 1;
      rows.push([safeOutputText(status), safeOutputText(path)]);
      continue;
    } else if (entry.startsWith("u ")) {
      const parsed = fixedFields(entry, 10);
      status = parsed.fields[1]!;
      path = parsed.remainder;
    } else {
      throw new AdapterContractError("Git status output is malformed");
    }
    assertEnumeratedPath(path, binding.allowedPaths);
    rows.push([safeOutputText(status), safeOutputText(path)]);
  }
  if (oid === undefined || branch === undefined) {
    throw new AdapterContractError("Git status omitted the HEAD snapshot");
  }
  if (oid !== "(initial)" && !FULL_COMMIT_ID.test(oid)) {
    throw new AdapterContractError("Git status returned an invalid HEAD identity");
  }
  return {
    headState: oid === "(initial)" ? "UNBORN" : "COMMIT",
    ...(oid === "(initial)" ? {} : { headCommit: oid }),
    branch: safeOutputText(branch),
    rows,
    files: rows.length,
    rawSha256: sha256(stdout),
  };
}

function parseNulPaths(stdout: string, binding: GitCompiledBinding): string[] {
  if (Buffer.byteLength(stdout, "utf8") > binding.maxBytes) {
    throw snapshotFailure("git.snapshot_byte_limit", "Git path inventory exceeded the reviewed byte bound");
  }
  const paths = stdout.split("\0").filter((path) => path.length > 0);
  if (paths.length > binding.maxFiles) {
    throw snapshotFailure("git.snapshot_file_limit", "Git path inventory exceeded the reviewed file bound");
  }
  for (const path of paths) assertEnumeratedPath(path, binding.allowedPaths);
  if (new Set(paths).size !== paths.length) {
    throw new AdapterContractError("Git path inventory contains duplicate paths");
  }
  return paths.sort((left, right) => left.localeCompare(right));
}

function validateIndexInventory(stdout: string, binding: GitCompiledBinding): void {
  if (Buffer.byteLength(stdout, "utf8") > binding.maxBytes) {
    throw snapshotFailure("git.snapshot_byte_limit", "Git index inventory exceeded the reviewed byte bound");
  }
  const entries = stdout.split("\0").filter((entry) => entry.length > 0);
  if (entries.length > binding.maxLines) {
    throw snapshotFailure("git.snapshot_file_limit", "Git index inventory exceeded the reviewed row bound");
  }
  for (const entry of entries) {
    const tab = entry.indexOf("\t");
    if (tab < 1 || tab === entry.length - 1) {
      throw new AdapterContractError("Git index inventory is malformed");
    }
    assertEnumeratedPath(entry.slice(tab + 1), binding.allowedPaths);
  }
}

function assertSecureSnapshotTarget(root: string, path: string): string | undefined {
  const candidate = resolve(root, ...path.split("/"));
  const fromRoot = relative(root, candidate);
  if (fromRoot === ".." || fromRoot.startsWith(`..${sep}`) || isAbsolute(fromRoot)) {
    throw snapshotFailure("git.snapshot_unsafe_path", "Git returned a path outside the pinned workspace");
  }
  let cursor = root;
  for (const segment of path.split("/")) {
    cursor = resolve(cursor, segment);
    if (!existsSync(cursor)) return undefined;
    const stat = lstatSync(cursor);
    if (stat.isSymbolicLink()) {
      throw snapshotFailure("git.snapshot_unsafe_file", "Git snapshot refused a symbolic link");
    }
  }
  return candidate;
}

function fileReceipt(root: string, path: string, remainingBytes: number): GitFileReceipt {
  const target = assertSecureSnapshotTarget(root, path);
  if (target === undefined) return { path, kind: "MISSING", size: 0, contentSha256: null };
  const descriptor = openSync(target, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const before = fstatSync(descriptor, { bigint: true });
    if (!before.isFile() || before.nlink !== 1n) {
      throw snapshotFailure("git.snapshot_unsafe_file", "Git snapshot accepts only non-linked regular files");
    }
    if (before.size > BigInt(remainingBytes)) {
      throw snapshotFailure("git.snapshot_byte_limit", "Git snapshot exceeded the reviewed content byte bound");
    }
    const hash = createHash("sha256");
    const buffer = Buffer.allocUnsafe(Math.min(64 * 1024, Math.max(1, remainingBytes + 1)));
    let position = 0;
    while (true) {
      const read = readSync(descriptor, buffer, 0, buffer.length, position);
      if (read === 0) break;
      position += read;
      if (position > remainingBytes) {
        throw snapshotFailure("git.snapshot_byte_limit", "Git snapshot exceeded the reviewed content byte bound");
      }
      hash.update(buffer.subarray(0, read));
    }
    const after = fstatSync(descriptor, { bigint: true });
    if (
      before.dev !== after.dev ||
      before.ino !== after.ino ||
      before.size !== after.size ||
      before.mtimeNs !== after.mtimeNs ||
      before.ctimeNs !== after.ctimeNs ||
      BigInt(position) !== after.size
    ) {
      throw snapshotFailure("git.worktree_changed", "Git worktree changed during snapshot collection");
    }
    return { path, kind: "FILE", size: position, contentSha256: hash.digest("hex") };
  } finally {
    closeSync(descriptor);
  }
}


async function collectWorktreeSnapshot(input: {
  executor: GitExecutor;
  executable: string;
  workspace: PinnedWorkspace;
  binding: GitCompiledBinding;
  context: AdapterExecutionContext;
}): Promise<GitWorktreeSnapshot> {
  const { executor, executable, workspace, binding, context } = input;
  const prefix = [...FIXED_GIT_PREFIX, "-C", workspace.root];
  const statusArgs = [
    ...prefix,
    "status",
    "--porcelain=v2",
    "--branch",
    "-z",
    "--untracked-files=all",
    "--ignore-submodules=all",
    "--",
    ...binding.allowedPaths,
  ];
  const indexArgs = [
    ...prefix,
    "ls-files",
    "--stage",
    "-z",
    "--",
    ...binding.allowedPaths,
  ];
  const inventoryArgs = [
    ...prefix,
    "ls-files",
    "--cached",
    "--others",
    "--exclude-standard",
    "-z",
    "--",
    ...binding.allowedPaths,
  ];
  const execute = async (args: string[]): Promise<GitExecutorResult> => {
    const result = await executor.execute({
      executable,
      args,
      cwd: workspace.root,
      env: GIT_FIXED_ENVIRONMENT,
      maxBufferBytes: binding.maxBytes + 1,
      timeoutMs: context.budget.limits.timeoutMs,
      signal: context.signal,
    });
    if (result.exitCode !== 0) {
      throw new AdapterExecutionError({
        code: "git.read_failed",
        category: "INVALID_RESPONSE",
        message: "The bounded Git read failed",
        retryable: false,
      });
    }
    return result;
  };

  const statusBeforeResult = await execute(statusArgs);
  const status = parseStatusSnapshot(statusBeforeResult.stdout, binding);
  const indexBefore = await execute(indexArgs);
  validateIndexInventory(indexBefore.stdout, binding);
  const inventoryBefore = await execute(inventoryArgs);
  const paths = parseNulPaths(inventoryBefore.stdout, binding);

  let contentBytes = 0;
  const fileReceipts: GitFileReceipt[] = [];
  for (const path of paths) {
    context.budget.throwIfAborted();
    const receipt = fileReceipt(workspace.root, path, binding.maxBytes - contentBytes);
    contentBytes += receipt.size;
    fileReceipts.push(receipt);
  }

  const inventoryAfter = await execute(inventoryArgs);
  const indexAfter = await execute(indexArgs);
  const statusAfterResult = await execute(statusArgs);
  if (
    inventoryAfter.stdout !== inventoryBefore.stdout ||
    indexAfter.stdout !== indexBefore.stdout ||
    statusAfterResult.stdout !== statusBeforeResult.stdout
  ) {
    throw snapshotFailure("git.worktree_changed", "Git worktree changed during snapshot collection");
  }

  let verificationBytes = 0;
  const verificationReceipts: GitFileReceipt[] = [];
  for (const path of paths) {
    context.budget.throwIfAborted();
    const receipt = fileReceipt(workspace.root, path, binding.maxBytes - verificationBytes);
    verificationBytes += receipt.size;
    verificationReceipts.push(receipt);
  }
  const inventoryFinal = await execute(inventoryArgs);
  const indexFinal = await execute(indexArgs);
  const statusFinalResult = await execute(statusArgs);
  if (
    canonicalJson(verificationReceipts) !== canonicalJson(fileReceipts) ||
    inventoryFinal.stdout !== inventoryBefore.stdout ||
    indexFinal.stdout !== indexBefore.stdout ||
    statusFinalResult.stdout !== statusBeforeResult.stdout
  ) {
    throw snapshotFailure("git.worktree_changed", "Git worktree changed during snapshot collection");
  }

  const commandBytes = [
    statusBeforeResult.stdout,
    indexBefore.stdout,
    inventoryBefore.stdout,
    inventoryAfter.stdout,
    indexAfter.stdout,
    statusAfterResult.stdout,
    inventoryFinal.stdout,
    indexFinal.stdout,
    statusFinalResult.stdout,
  ].reduce((total, output) => total + Buffer.byteLength(output, "utf8"), 0);
  if (commandBytes + contentBytes + verificationBytes > binding.maxBytes) {
    throw snapshotFailure("git.snapshot_byte_limit", "Git snapshot exceeded the reviewed total byte bound");
  }
  context.budget.consumeBytes(commandBytes + contentBytes + verificationBytes);
  context.budget.consumeRows(1 + status.rows.length);

  const indexSha256 = sha256(indexBefore.stdout);
  const worktreeSnapshotSha256 = sha256(canonicalJson({
    version: "git-worktree-snapshot-v1",
    headState: status.headState,
    ...(status.headCommit === undefined ? {} : { headCommit: status.headCommit }),
    branch: status.branch,
    allowedPaths: [...binding.allowedPaths].sort((left, right) => left.localeCompare(right)),
    statusSha256: status.rawSha256,
    indexSha256,
    ignoredFiles: "EXCLUDED",
    fileReceipts,
  }));
  return {
    status,
    indexSha256,
    worktreeSnapshotSha256,
    fileReceipts,
    contentBytes,
    diagnostic: [
      statusBeforeResult,
      indexBefore,
      inventoryBefore,
      inventoryAfter,
      indexAfter,
      statusAfterResult,
      inventoryFinal,
      indexFinal,
      statusFinalResult,
    ].some((result) => result.stderr.length > 0),
  };
}

function tableFor(binding: GitCompiledBinding, output: BoundedOutput): ProviderTable {
  if (binding.operation === "git.status") {
    return {
      kind: "TABLE",
      name: "git.status",
      columns: [
        { name: "status", type: "STRING" },
        { name: "path", type: "STRING" },
      ],
      rows: output.rows,
    };
  }
  return {
    kind: "TABLE",
    name: "git.diff",
    columns: [
      { name: "line.number", type: "NUMBER" },
      { name: "content", type: "STRING" },
    ],
    rows: output.rows,
  };
}

function snapshotTables(snapshot: GitWorktreeSnapshot): ProviderTable[] {
  const metadata: ProviderTable = {
    kind: "TABLE",
    name: "git.worktree-snapshot",
    columns: [
      { name: "head.state", type: "STRING" },
      { name: "head.commit", type: "STRING" },
      { name: "branch", type: "STRING" },
      { name: "worktree.snapshot.sha256", type: "STRING" },
      { name: "index.sha256", type: "STRING" },
      { name: "status.sha256", type: "STRING" },
      { name: "file.count", type: "NUMBER" },
      { name: "content.bytes", type: "NUMBER" },
      { name: "ignored.files", type: "STRING" },
      { name: "complete", type: "BOOLEAN" },
    ],
    rows: [[
      snapshot.status.headState,
      snapshot.status.headCommit ?? "UNBORN",
      snapshot.status.branch,
      snapshot.worktreeSnapshotSha256,
      snapshot.indexSha256,
      snapshot.status.rawSha256,
      snapshot.fileReceipts.length,
      snapshot.contentBytes,
      "EXCLUDED",
      true,
    ]],
  };
  if (snapshot.status.rows.length === 0) return [metadata];
  return [
    metadata,
    {
      kind: "TABLE",
      name: "git.status",
      columns: [
        { name: "status", type: "STRING" },
        { name: "path", type: "STRING" },
      ],
      rows: snapshot.status.rows,
    },
  ];
}

export class GitAdapter implements EvidenceAdapter<GitCompiledBinding> {
  readonly descriptor = descriptor;
  readonly #workspaces: ReadonlyMap<string, PinnedWorkspace>;
  readonly #catalog: ReadonlyMap<string, GitCatalogBinding>;
  readonly #executor: GitExecutor;
  readonly #gitExecutable: string;

  constructor(options: GitAdapterOptions) {
    const workspaces = new Map<string, PinnedWorkspace>();
    for (const binding of options.workspaces) {
      const workspace = canonicalWorkspace(binding);
      if (workspaces.has(workspace.workspaceId)) {
        throw new AdapterContractError(`Duplicate Git workspace: ${workspace.workspaceId}`);
      }
      workspaces.set(workspace.workspaceId, workspace);
    }
    const catalog = new Map<string, GitCatalogBinding>();
    for (const definition of options.catalog) {
      const binding = cloneCatalogBinding(definition, workspaces);
      if (catalog.has(binding.bindingId)) {
        throw new AdapterContractError(`Duplicate Git binding: ${binding.bindingId}`);
      }
      catalog.set(binding.bindingId, binding);
    }
    this.#workspaces = workspaces;
    this.#catalog = catalog;
    this.#executor = options.executor ?? new ExecFileGitExecutor();
    this.#gitExecutable = options.gitExecutable ?? "/usr/bin/git";
    if (!isAbsolute(this.#gitExecutable) || basename(this.#gitExecutable) !== "git") {
      throw new AdapterContractError("Git executable must be an absolute administrator path");
    }
  }

  async doctor(context: AdapterDoctorContext): Promise<AdapterDoctorResult> {
    context.signal.throwIfAborted();
    for (const workspace of this.#workspaces.values()) assertPinnedWorkspace(workspace);
    return {
      status: this.#catalog.size > 0 ? "READY" : "BLOCKED",
      checks: [
        {
          name: "pinned-workspaces",
          status: this.#catalog.size > 0 ? "PASS" : "FAIL",
          message:
            this.#catalog.size > 0
              ? `${this.#workspaces.size} canonical workspace(s) and ${this.#catalog.size} binding(s) pinned`
              : "No reviewed Git bindings are configured",
        },
      ],
    };
  }

  async compile(
    operation: Readonly<OperationSnapshot>,
    context: AdapterCompileContext,
  ): Promise<CompiledAdapterOperation<GitCompiledBinding>> {
    if (context.adapterPackage.packageId !== GIT_ADAPTER_PACKAGE_ID) {
      throw new AdapterContractError("Git adapter package mismatch");
    }
    if (
      operation.definition.adapterPackageId !== GIT_ADAPTER_PACKAGE_ID ||
      operation.definition.domain !== "CHANGES" ||
      !descriptor.operations.includes(operation.definition.adapterOperation as "git.diff" | "git.status")
    ) {
      throw new AdapterContractError("Operation does not target a supported Git read");
    }
    if (computeOperationDefinitionHash(operation) !== operation.definitionSha256) {
      throw new AdapterContractError("Git operation hash mismatch");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > context.maxDefinitionBytes) {
      throw new AdapterContractError("Git operation definition exceeds compile budget");
    }
    const providerDefinition = operation.definition.sanitizedProviderDefinition;
    if (
      Object.keys(providerDefinition).length !== 1 ||
      typeof providerDefinition.bindingId !== "string"
    ) {
      throw new AdapterContractError("Git operation must select exactly one compiled bindingId");
    }
    const catalogBinding = this.#catalog.get(providerDefinition.bindingId);
    if (
      catalogBinding === undefined ||
      catalogBinding.operation !== operation.definition.adapterOperation
    ) {
      throw new AdapterContractError("Git binding is unavailable or operation-mismatched");
    }
    const workspace = this.#workspaces.get(catalogBinding.workspaceId);
    if (workspace === undefined) throw new AdapterContractError("Git workspace binding is unavailable");
    assertPinnedWorkspace(workspace);
    const paths = catalogBinding.allowedPaths.map((path) => validateConfiguredPath(workspace, path));
    const binding: GitCompiledBinding = {
      bindingId: catalogBinding.bindingId,
      workspaceId: catalogBinding.workspaceId,
      operation: catalogBinding.operation,
      allowedPaths: paths,
      maxBytes: Math.min(catalogBinding.maxBytes, operation.definition.limits.maxBytes),
      maxFiles: Math.min(catalogBinding.maxFiles, operation.definition.limits.maxRows),
      maxHunks: Math.min(catalogBinding.maxHunks, operation.definition.limits.maxSeries),
      maxLines: Math.min(catalogBinding.maxLines, operation.definition.limits.maxRows),
      ...(catalogBinding.operation === "git.diff"
        ? {
            baseCommit: catalogBinding.baseCommit,
            targetCommit: catalogBinding.targetCommit,
          }
        : {}),
    };
    return {
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      adapterPackageId: GIT_ADAPTER_PACKAGE_ID,
      adapterOperation: catalogBinding.operation,
      binding,
    };
  }

  async execute(
    context: AdapterExecutionContext,
    operation: Readonly<CompiledAdapterOperation<GitCompiledBinding>>,
  ): Promise<ProviderResult> {
    context.budget.throwIfAborted();
    const binding = operation.binding;
    const catalogBinding = this.#catalog.get(binding.bindingId);
    const workspace = this.#workspaces.get(binding.workspaceId);
    if (
      catalogBinding === undefined ||
      workspace === undefined ||
      catalogBinding.operation !== binding.operation
    ) {
      throw new AdapterContractError("Compiled Git binding is no longer trusted");
    }
    if (
      operation.adapterPackageId !== GIT_ADAPTER_PACKAGE_ID ||
      operation.adapterOperation !== binding.operation ||
      !Number.isSafeInteger(binding.maxBytes) ||
      !Number.isSafeInteger(binding.maxFiles) ||
      !Number.isSafeInteger(binding.maxHunks) ||
      !Number.isSafeInteger(binding.maxLines) ||
      binding.maxBytes <= 0 ||
      binding.maxFiles <= 0 ||
      binding.maxHunks <= 0 ||
      binding.maxLines <= 0 ||
      binding.maxBytes > catalogBinding.maxBytes ||
      binding.maxFiles > catalogBinding.maxFiles ||
      binding.maxHunks > catalogBinding.maxHunks ||
      binding.maxLines > catalogBinding.maxLines
    ) {
      throw new AdapterContractError("Compiled Git authority exceeds its reviewed bounds");
    }
    if (
      catalogBinding.operation === "git.diff" &&
      (binding.baseCommit !== catalogBinding.baseCommit ||
        binding.targetCommit !== catalogBinding.targetCommit)
    ) {
      throw new AdapterContractError("Compiled Git revisions changed after authorization");
    }
    assertPinnedWorkspace(workspace);
    const paths = catalogBinding.allowedPaths.map((path) => validateConfiguredPath(workspace, path));
    if (canonicalJson(paths) !== canonicalJson(binding.allowedPaths)) {
      throw new AdapterContractError("Compiled Git paths changed after authorization");
    }

    const effectiveRows = context.budget.limits.maxRows;
    const effectiveBinding: GitCompiledBinding = {
      ...binding,
      maxBytes: Math.min(binding.maxBytes, context.budget.limits.maxBytes),
      maxFiles: Math.min(
        binding.maxFiles,
        binding.operation === "git.status" ? Math.max(0, effectiveRows - 1) : effectiveRows,
      ),
      maxHunks: Math.min(binding.maxHunks, context.budget.limits.maxSeries),
      maxLines: Math.min(
        binding.maxLines,
        binding.operation === "git.status" ? Math.max(0, effectiveRows - 1) : effectiveRows,
      ),
    };

    if (binding.operation === "git.status") {
      const snapshot = await collectWorktreeSnapshot({
        executor: this.#executor,
        executable: this.#gitExecutable,
        workspace,
        binding: effectiveBinding,
        context,
      });
      const warnings = snapshot.diagnostic ? ["Git returned sanitized diagnostic output"] : [];
      return {
        schemaVersion: "1.0.0",
        collectionState: "COMPLETE",
        evaluatedAt: context.clock.now().toISOString(),
        nativeResultType: "git.status.snapshot",
        nativeDimensions: {
          headState: snapshot.status.headState,
          ...(snapshot.status.headCommit === undefined ? {} : { headCommit: snapshot.status.headCommit }),
          worktreeSnapshotSha256: snapshot.worktreeSnapshotSha256,
          indexSha256: snapshot.indexSha256,
          statusSha256: snapshot.status.rawSha256,
          ignoredFiles: "EXCLUDED",
          completeness: "COMPLETE",
        },
        records: snapshotTables(snapshot),
        pagination: { complete: true, pages: 1 },
        warnings,
        sanitizedReference: `git:${binding.workspaceId}:${binding.bindingId}:${snapshot.worktreeSnapshotSha256}`,
        providerScope: {
          environment: context.scope.environment,
          ...(context.scope.service === undefined ? {} : { service: context.scope.service }),
        },
      };
    }

    const args: string[] = [...FIXED_GIT_PREFIX, "-C", workspace.root];
    if (binding.baseCommit === undefined || binding.targetCommit === undefined) {
      throw new AdapterContractError("Compiled Git diff is missing pinned commits");
    }
    args.push(
      "diff",
      "--no-ext-diff",
      "--no-textconv",
      "--ignore-submodules=all",
      "--unified=3",
      binding.baseCommit,
      binding.targetCommit,
      "--",
      ...paths,
    );
    const result = await this.#executor.execute({
      executable: this.#gitExecutable,
      args,
      cwd: workspace.root,
      env: GIT_FIXED_ENVIRONMENT,
      maxBufferBytes: effectiveBinding.maxBytes + 1,
      timeoutMs: context.budget.limits.timeoutMs,
      signal: context.signal,
    });
    if (result.exitCode !== 0) {
      throw new AdapterExecutionError({
        code: "git.read_failed",
        category: "INVALID_RESPONSE",
        message: "The bounded Git read failed",
        retryable: false,
      });
    }
    context.budget.throwIfAborted();
    const bytes = Buffer.byteLength(result.stdout, "utf8");
    context.budget.consumeBytes(Math.min(bytes, effectiveBinding.maxBytes));
    const output = boundedDiff(result.stdout, effectiveBinding);
    context.budget.consumeRows(output.rows.length);
    context.budget.consumeSeries(output.hunks);
    const warnings: string[] = [];
    if (output.truncated) {
      warnings.push(
        `Git output was truncated by the reviewed ${output.reason === "BYTE_LIMIT" ? "byte" : "file, hunk, or line"} bound`,
      );
    }
    if (result.stderr.length > 0) warnings.push("Git returned sanitized diagnostic output");
    const empty = output.rows.length === 0;
    return {
      schemaVersion: "1.0.0",
      collectionState: empty ? "EMPTY" : "COMPLETE",
      evaluatedAt: context.clock.now().toISOString(),
      nativeResultType: "git.diff",
      nativeDimensions: {},
      records: empty ? [] : [tableFor(effectiveBinding, output)],
      pagination: output.truncated
        ? { complete: false, pages: 1, truncatedReason: output.reason ?? "ROW_LIMIT" }
        : { complete: true, pages: 1 },
      warnings,
      sanitizedReference: `git:${binding.workspaceId}:${binding.bindingId}`,
      providerScope: {
        environment: context.scope.environment,
        ...(context.scope.service === undefined ? {} : { service: context.scope.service }),
      },
    };
  }
}

const DEFAULT_LIMITS: OperationLimits = {
  timeoutMs: 10_000,
  maxAgeMs: 60_000,
  maxBytes: 256_000,
  maxRows: 2_000,
  maxSeries: 200,
  maxPoints: 0,
};

export interface GitOperationOptions {
  operationId?: OperationId;
  capturedAt?: string;
  limits?: Partial<OperationLimits>;
}

export function createGitOperationSnapshot(
  bindingId: string,
  adapterOperation: "git.diff" | "git.status",
  options: GitOperationOptions = {},
): OperationSnapshot {
  const definition: OperationDefinition = {
    domain: "CHANGES",
    sourceAlias: "git-workspace",
    adapterPackageId: GIT_ADAPTER_PACKAGE_ID,
    adapterOperation,
    authority: "CORROBORATING",
    sanitizedProviderDefinition: { bindingId },
    scopeMapping: {},
    allowedDimensions: [],
    requiredProviderScopes: ["environment"],
    sensitivity: "INTERNAL",
    limits: { ...DEFAULT_LIMITS, ...options.limits },
    normalization: { resultKind: "TABLE", dimensionMappings: {} },
  };
  const semantic = {
    operationId:
      options.operationId ??
      (`changes.git.${adapterOperation === "git.diff" ? "diff" : "status"}` as OperationId),
    revision: 1,
    definition,
  };
  return {
    schemaVersion: "1.0.0",
    ...semantic,
    capturedAt: options.capturedAt ?? "2026-01-01T00:00:00.000Z",
    definitionSha256: computeOperationDefinitionHash(semantic),
  };
}
