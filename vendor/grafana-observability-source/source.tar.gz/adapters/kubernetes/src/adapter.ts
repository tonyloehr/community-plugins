import {
  canonicalJson,
  computeOperationDefinitionHash,
  type AdapterPackage,
  type AdapterPackageId,
  type JsonObject,
  type JsonPrimitive,
  type OperationSnapshot,
  type Pagination,
  type Sha256,
} from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  type AdapterCompileContext,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderResult,
  type ProviderTable,
} from "../../../packages/adapter-sdk/src/index.ts";

import { CompiledKubernetesCatalog } from "./catalog.ts";
import type {
  KubernetesCatalogEntry,
  KubernetesReadResponse,
  KubernetesResource,
  KubernetesTransport,
  KubernetesTransportError,
  KubernetesTrustedCatalog,
} from "./types.ts";

export const KUBERNETES_ADAPTER_PACKAGE_ID = "adapter.kubernetes.v1" as AdapterPackageId;

export const kubernetesAdapterPackage: AdapterPackage = {
  schemaVersion: "1.0.0",
  packageId: KUBERNETES_ADAPTER_PACKAGE_ID,
  name: "Kubernetes production-read-only adapter",
  version: "1.0.0",
  protocolVersion: "1.0",
  publisher: { name: "Codex Production Monitoring" },
  entrypoint: { kind: "BUILTIN", registryKey: "kubernetes-v1" },
  domains: ["RUNTIME"],
  capabilities: ["kubernetes.resources.list", "kubernetes.resource.get"],
  providerCompatibility: [{ provider: "kubernetes", versions: ">=1.28 <2" }],
  supportedContractVersions: ["1.0.0"],
  conformance: ["CORE_READ", "RUNTIME"],
};

type KubernetesBinding = JsonObject & {
  outputName: string;
  mode: "LIST" | "GET";
  resource: KubernetesResource;
  namespaceByEnvironment: Record<string, string>;
  nameSource?: "service";
  selectorKey?: "app" | "app.kubernetes.io/name";
};

interface KubernetesObjectMetadata {
  name: string;
  namespace: string;
  labels: Record<string, string>;
  generation: number | null;
}

interface KubernetesParseState {
  rows: JsonPrimitive[][];
  providerTruncated: boolean;
  truncatedReason?: Pagination["truncatedReason"];
}

const EXPECTED_KIND: Readonly<Record<KubernetesResource, string>> = {
  pods: "Pod",
  deployments: "Deployment",
  statefulsets: "StatefulSet",
  daemonsets: "DaemonSet",
};

const EXPECTED_API_VERSION: Readonly<Record<KubernetesResource, string>> = {
  pods: "v1",
  deployments: "apps/v1",
  statefulsets: "apps/v1",
  daemonsets: "apps/v1",
};

const DNS_LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/u;

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function safeString(value: unknown, label: string, maxLength = 512): string {
  if (typeof value !== "string" || value.length === 0 || value.length > maxLength) {
    throw new AdapterContractError(`Kubernetes ${label} is invalid`);
  }
  if ([...value].some((character) => (character.codePointAt(0) ?? 0) < 32)) {
    throw new AdapterContractError(`Kubernetes ${label} contains a control character`);
  }
  return value;
}

function nonNegativeInteger(value: unknown, label: string): number | null {
  if (value === undefined) return null;
  if (!Number.isSafeInteger(value) || (value as number) < 0) {
    throw new AdapterContractError(`Kubernetes ${label} is invalid`);
  }
  return value as number;
}

function metadataOf(value: Record<string, unknown>): KubernetesObjectMetadata {
  if (!isObject(value.metadata)) throw new AdapterContractError("Kubernetes object metadata is missing");
  const name = safeString(value.metadata.name, "resource name", 253);
  const namespace = safeString(value.metadata.namespace, "namespace", 63);
  if (!DNS_LABEL.test(namespace)) throw new AdapterContractError("Kubernetes namespace is invalid");
  const labels: Record<string, string> = {};
  if (value.metadata.labels !== undefined) {
    if (!isObject(value.metadata.labels)) throw new AdapterContractError("Kubernetes labels are invalid");
    for (const key of ["app", "app.kubernetes.io/name"] as const) {
      if (value.metadata.labels[key] !== undefined) labels[key] = safeString(value.metadata.labels[key], "service label", 253);
    }
  }
  return { name, namespace, labels, generation: nonNegativeInteger(value.metadata.generation, "generation") };
}

function assertObjectScope(
  metadata: KubernetesObjectMetadata,
  namespace: string,
  service: string,
  mode: "LIST" | "GET",
): void {
  if (metadata.namespace !== namespace) {
    throw new AdapterContractError("Kubernetes response crossed the authorized namespace scope");
  }
  const serviceClaim = metadata.labels["app.kubernetes.io/name"] ?? metadata.labels.app;
  if (serviceClaim !== undefined && serviceClaim !== service) {
    throw new AdapterContractError("Kubernetes response crossed the authorized service scope");
  }
  if (mode === "GET" && metadata.name !== service) {
    throw new AdapterContractError("Kubernetes GET response crossed the authorized resource scope");
  }
}

function readyContainers(status: Record<string, unknown>): { ready: number; desired: number; restarts: number } {
  if (status.containerStatuses === undefined) return { ready: 0, desired: 0, restarts: 0 };
  if (!Array.isArray(status.containerStatuses)) throw new AdapterContractError("Kubernetes container statuses are invalid");
  let ready = 0;
  let restarts = 0;
  for (const container of status.containerStatuses) {
    if (!isObject(container) || typeof container.ready !== "boolean") {
      throw new AdapterContractError("Kubernetes container status drifted");
    }
    if (container.ready) ready += 1;
    const restartCount = nonNegativeInteger(container.restartCount, "restart count");
    if (restartCount === null) throw new AdapterContractError("Kubernetes restart count is missing");
    restarts += restartCount;
  }
  return { ready, desired: status.containerStatuses.length, restarts };
}

function objectRow(
  value: unknown,
  resource: KubernetesResource,
  namespace: string,
  service: string,
  mode: "LIST" | "GET",
): JsonPrimitive[] {
  if (!isObject(value)) throw new AdapterContractError("Kubernetes resource is invalid");
  if (value.apiVersion !== EXPECTED_API_VERSION[resource] || value.kind !== EXPECTED_KIND[resource]) {
    throw new AdapterContractError("Kubernetes resource schema drifted");
  }
  const metadata = metadataOf(value);
  assertObjectScope(metadata, namespace, service, mode);
  const status = value.status === undefined ? {} : value.status;
  if (!isObject(status)) throw new AdapterContractError("Kubernetes resource status is invalid");

  let phase: string | null = null;
  let ready: number | null = null;
  let desired: number | null = null;
  let restarts: number | null = null;
  if (resource === "pods") {
    phase = status.phase === undefined ? null : safeString(status.phase, "pod phase", 64);
    const containers = readyContainers(status);
    ready = containers.ready;
    desired = containers.desired;
    restarts = containers.restarts;
  } else if (resource === "daemonsets") {
    ready = nonNegativeInteger(status.numberReady, "ready count");
    desired = nonNegativeInteger(status.desiredNumberScheduled, "desired count");
  } else {
    ready = nonNegativeInteger(status.readyReplicas, "ready replica count") ?? 0;
    desired = nonNegativeInteger(status.replicas, "replica count") ?? 0;
  }
  const observedGeneration = nonNegativeInteger(status.observedGeneration, "observed generation");
  return [
    resource,
    metadata.name,
    metadata.namespace,
    phase,
    ready,
    desired,
    restarts,
    metadata.generation,
    observedGeneration,
  ];
}

async function readJson(response: KubernetesReadResponse, context: AdapterExecutionContext): Promise<unknown> {
  const chunks: Uint8Array[] = [];
  for await (const chunk of response.body) {
    context.budget.throwIfAborted();
    context.budget.consumeBytes(chunk.byteLength);
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
  } catch {
    throw new AdapterContractError("Kubernetes response is not valid JSON");
  }
}

function statusError(status: number): AdapterExecutionError {
  if (status === 401 || status === 403) {
    return new AdapterExecutionError({
      code: "KUBERNETES_ACCESS_DENIED",
      category: status === 401 ? "AUTHENTICATION" : "AUTHORIZATION",
      message: "Kubernetes denied the bounded GET request",
      retryable: false,
      providerStatus: status,
    });
  }
  if (status === 429) {
    return new AdapterExecutionError({
      code: "KUBERNETES_RATE_LIMIT",
      category: "RATE_LIMIT",
      message: "Kubernetes rate limited the bounded GET request",
      retryable: true,
      providerStatus: status,
    });
  }
  return new AdapterExecutionError({
    code: "KUBERNETES_READ_FAILED",
    category: status >= 500 ? "UNAVAILABLE" : "INVALID_RESPONSE",
    message: "Kubernetes bounded GET request failed",
    retryable: status >= 500,
    providerStatus: status,
  });
}

function parseBody(
  body: unknown,
  binding: KubernetesBinding,
  namespace: string,
  service: string,
  context: AdapterExecutionContext,
): KubernetesParseState {
  if (!isObject(body)) throw new AdapterContractError("Kubernetes response envelope is invalid");
  const expectedApiVersion = EXPECTED_API_VERSION[binding.resource];
  const expectedKind = EXPECTED_KIND[binding.resource];
  const items = binding.mode === "LIST"
    ? (() => {
        if (
          body.apiVersion !== expectedApiVersion ||
          body.kind !== `${expectedKind}List` ||
          !Array.isArray(body.items)
        ) {
          throw new AdapterContractError("Kubernetes list schema drifted");
        }
        return body.items;
      })()
    : [body];
  let providerTruncated = false;
  if (binding.mode === "LIST" && body.metadata !== undefined) {
    if (!isObject(body.metadata)) throw new AdapterContractError("Kubernetes list metadata is invalid");
    providerTruncated = typeof body.metadata.continue === "string" && body.metadata.continue.length > 0;
  }
  const state: KubernetesParseState = { rows: [], providerTruncated };
  for (const item of items) {
    context.budget.throwIfAborted();
    if (state.rows.length >= context.budget.limits.maxRows) {
      state.truncatedReason = "ROW_LIMIT";
      break;
    }
    const row = objectRow(item, binding.resource, namespace, service, binding.mode);
    context.budget.consumeRows(1);
    state.rows.push(row);
  }
  return state;
}

function bindingFor(entry: KubernetesCatalogEntry): KubernetesBinding {
  return {
    outputName: entry.outputName,
    mode: entry.mode,
    resource: entry.resource,
    namespaceByEnvironment: { ...entry.namespaceByEnvironment },
    ...(entry.nameSource === undefined ? {} : { nameSource: entry.nameSource }),
    ...(entry.selector === undefined ? {} : { selectorKey: entry.selector.key }),
  };
}

function table(outputName: string, rows: JsonPrimitive[][]): ProviderTable {
  return {
    kind: "TABLE",
    name: outputName,
    columns: [
      { name: "resource", type: "STRING" },
      { name: "name", type: "STRING" },
      { name: "namespace", type: "STRING" },
      { name: "phase", type: "STRING" },
      { name: "ready", type: "NUMBER" },
      { name: "desired", type: "NUMBER" },
      { name: "restarts", type: "NUMBER" },
      { name: "generation", type: "NUMBER" },
      { name: "observedGeneration", type: "NUMBER" },
    ],
    rows,
  };
}

export interface KubernetesAdapterOptions {
  transport: KubernetesTransport;
  catalog: KubernetesTrustedCatalog;
}

export class KubernetesAdapter implements EvidenceAdapter<KubernetesBinding> {
  readonly descriptor = {
    packageId: KUBERNETES_ADAPTER_PACKAGE_ID,
    name: kubernetesAdapterPackage.name,
    version: kubernetesAdapterPackage.version,
    provider: "kubernetes",
    domains: ["RUNTIME"] as const,
    operations: kubernetesAdapterPackage.capabilities,
    resultSchemaVersions: ["1.0.0"] as const,
  };

  readonly #transport: KubernetesTransport;
  readonly #catalog: CompiledKubernetesCatalog;

  constructor(options: KubernetesAdapterOptions) {
    this.#transport = options.transport;
    this.#catalog = new CompiledKubernetesCatalog(options.catalog);
  }

  async doctor() {
    return {
      status: "READY" as const,
      checks: [{
        name: "production-read-only",
        status: "PASS" as const,
        message: "Only fixed GET/LIST resources and namespaces are enabled; watch and writes are unavailable",
      }],
    };
  }

  async compile(operation: Readonly<OperationSnapshot>, context: AdapterCompileContext) {
    if (context.adapterPackage.packageId !== KUBERNETES_ADAPTER_PACKAGE_ID) {
      throw new AdapterContractError("Kubernetes adapter package mismatch");
    }
    if (
      operation.definition.adapterPackageId !== KUBERNETES_ADAPTER_PACKAGE_ID ||
      computeOperationDefinitionHash(operation) !== operation.definitionSha256
    ) {
      throw new AdapterContractError("Kubernetes operation is not bound to this adapter and hash");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > context.maxDefinitionBytes) {
      throw new AdapterContractError("Kubernetes operation definition exceeds the compile budget");
    }
    const reference = operation.definition.sanitizedProviderDefinition;
    if (
      Object.keys(reference).length !== 2 ||
      typeof reference.catalogEntryId !== "string" ||
      typeof reference.catalogEntrySha256 !== "string"
    ) {
      throw new AdapterContractError("Kubernetes operation must contain only a trusted catalog reference");
    }
    const entry = this.#catalog.resolve(reference.catalogEntryId, reference.catalogEntrySha256 as Sha256);
    const expectedOperation = entry.mode === "LIST" ? "kubernetes.resources.list" : "kubernetes.resource.get";
    if (operation.definition.adapterOperation !== expectedOperation) {
      throw new AdapterContractError("Kubernetes operation does not match the trusted GET/LIST route");
    }
    if (operation.definition.domain !== "RUNTIME" || operation.definition.normalization.resultKind !== "TABLE") {
      throw new AdapterContractError("Kubernetes operation result contract is invalid");
    }
    return {
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      adapterPackageId: KUBERNETES_ADAPTER_PACKAGE_ID,
      adapterOperation: operation.definition.adapterOperation,
      binding: bindingFor(entry),
    } satisfies CompiledAdapterOperation<KubernetesBinding>;
  }

  async execute(
    context: AdapterExecutionContext,
    operation: Readonly<CompiledAdapterOperation<KubernetesBinding>>,
  ): Promise<ProviderResult> {
    context.budget.throwIfAborted();
    const namespace = operation.binding.namespaceByEnvironment[context.scope.environment];
    if (namespace === undefined) {
      throw new AdapterExecutionError({
        code: "KUBERNETES_SCOPE_NOT_ALLOWED",
        category: "POLICY",
        message: "The requested environment has no reviewed Kubernetes namespace mapping",
        retryable: false,
      });
    }
    const service = context.scope.service;
    if (service === undefined || !DNS_LABEL.test(service)) {
      throw new AdapterExecutionError({
        code: "KUBERNETES_SERVICE_SCOPE_REQUIRED",
        category: "POLICY",
        message: "A valid reviewed service scope is required for Kubernetes evidence",
        retryable: false,
      });
    }
    let response: KubernetesReadResponse;
    try {
      response = await this.#transport.request({
        verb: "GET",
        mode: operation.binding.mode,
        resource: operation.binding.resource,
        namespace,
        ...(operation.binding.mode === "GET" ? { name: service } : {}),
        ...(operation.binding.mode === "LIST"
          ? { selector: { key: operation.binding.selectorKey!, value: service } }
          : {}),
        limit: context.budget.limits.maxRows,
        signal: context.signal,
        maxResponseBytes: context.budget.limits.maxBytes,
      });
    } catch (error) {
      if (error instanceof AdapterExecutionError || error instanceof AdapterContractError || error instanceof BudgetExceededError) {
        throw error;
      }
      if ((error as KubernetesTransportError | undefined)?.name === "KubernetesTransportError") {
        const transportError = error as KubernetesTransportError;
        throw new AdapterExecutionError({
          code: transportError.kind === "TIMEOUT" ? "KUBERNETES_TIMEOUT" : "KUBERNETES_UNAVAILABLE",
          category: transportError.kind,
          message: transportError.kind === "TIMEOUT" ? "Kubernetes read timed out" : "Kubernetes is unavailable",
          retryable: true,
        });
      }
      if (context.signal.aborted) throw context.signal.reason ?? error;
      throw new AdapterExecutionError({
        code: "KUBERNETES_UNAVAILABLE",
        category: "UNAVAILABLE",
        message: "Kubernetes is unavailable",
        retryable: true,
      });
    }
    const body = await readJson(response, context);
    if (response.status < 200 || response.status >= 300) throw statusError(response.status);
    const state = parseBody(body, operation.binding, namespace, service, context);
    const truncatedReason = state.truncatedReason ?? (state.providerTruncated ? "ROW_LIMIT" : undefined);
    return {
      schemaVersion: "1.0.0",
      collectionState: state.rows.length === 0 ? "EMPTY" : "COMPLETE",
      evaluatedAt: context.clock.now().toISOString(),
      nativeResultType: `${operation.binding.resource}:${operation.binding.mode.toLowerCase()}`,
      nativeDimensions: { namespace, resource: operation.binding.resource },
      records: state.rows.length === 0 ? [] : [table(operation.binding.outputName, state.rows)],
      pagination: truncatedReason === undefined
        ? { complete: true, pages: 1 }
        : { complete: false, pages: 1, truncatedReason },
      warnings: truncatedReason === undefined ? [] : ["Kubernetes result was truncated by the bounded read policy"],
      sanitizedReference: `kubernetes:${operation.binding.resource}`,
      providerScope: {
        environment: context.scope.environment,
        service,
        mappings: { environment: "namespace", service: "service" },
      },
    };
  }
}
