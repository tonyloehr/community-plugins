import type { Sha256 } from "../../../packages/contracts/src/index.ts";

export type KubernetesResource = "pods" | "deployments" | "statefulsets" | "daemonsets";

export interface KubernetesCatalogEntry {
  id: string;
  outputName: string;
  mode: "LIST" | "GET";
  resource: KubernetesResource;
  namespaceByEnvironment: Record<string, string>;
  nameSource?: "service";
  selector?: {
    key: "app" | "app.kubernetes.io/name";
    valueSource: "service";
  };
}

export interface KubernetesTrustedCatalog {
  entries: KubernetesCatalogEntry[];
}

export interface KubernetesCatalogReference {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
}

export interface KubernetesReadRequest {
  verb: "GET";
  mode: "LIST" | "GET";
  resource: KubernetesResource;
  namespace: string;
  name?: string;
  selector?: { key: "app" | "app.kubernetes.io/name"; value: string };
  limit: number;
  signal: AbortSignal;
  maxResponseBytes: number;
}

export interface KubernetesReadResponse {
  status: number;
  body: AsyncIterable<Uint8Array>;
}

export interface KubernetesTransport {
  request(request: Readonly<KubernetesReadRequest>): Promise<KubernetesReadResponse>;
}

export class KubernetesTransportError extends Error {
  readonly kind: "TIMEOUT" | "UNAVAILABLE";

  constructor(kind: "TIMEOUT" | "UNAVAILABLE") {
    super(`Kubernetes transport ${kind.toLowerCase()}`);
    this.name = "KubernetesTransportError";
    this.kind = kind;
  }
}
