import { sha256Canonical, type JsonObject, type Sha256 } from "../../../packages/contracts/src/index.ts";
import { AdapterContractError } from "../../../packages/adapter-sdk/src/index.ts";

import type { KubernetesCatalogEntry, KubernetesResource, KubernetesTrustedCatalog } from "./types.ts";

const SAFE_ID = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/u;
const SAFE_ALIAS = /^[a-z][a-z0-9_-]{0,62}$/u;
const DNS_LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/u;
const RESOURCES: readonly KubernetesResource[] = ["pods", "deployments", "statefulsets", "daemonsets"];

export function kubernetesCatalogEntryHash(entry: KubernetesCatalogEntry): Sha256 {
  return sha256Canonical(entry as unknown as JsonObject);
}

function validateEntry(entry: KubernetesCatalogEntry): void {
  if (!SAFE_ID.test(entry.id) || !SAFE_ID.test(entry.outputName)) {
    throw new AdapterContractError("Kubernetes catalog IDs must use the bounded safe identifier format");
  }
  if (!RESOURCES.includes(entry.resource)) throw new AdapterContractError("Kubernetes resource is not allowlisted");
  const namespaceEntries = Object.entries(entry.namespaceByEnvironment);
  if (
    namespaceEntries.length === 0 ||
    namespaceEntries.length > 16 ||
    namespaceEntries.some(([environment, namespace]) => !SAFE_ALIAS.test(environment) || !DNS_LABEL.test(namespace))
  ) {
    throw new AdapterContractError("Kubernetes environment-to-namespace allowlist is invalid");
  }
  if (new Set(namespaceEntries.map(([, namespace]) => namespace)).size !== namespaceEntries.length) {
    throw new AdapterContractError("Kubernetes namespace allowlist must map environments one-to-one");
  }
  if (entry.mode === "GET") {
    if (entry.nameSource !== "service" || entry.selector !== undefined) {
      throw new AdapterContractError("Kubernetes GET entries require only a service-derived name");
    }
  } else if (
    entry.mode !== "LIST" ||
    entry.nameSource !== undefined ||
    entry.selector?.valueSource !== "service" ||
    !["app", "app.kubernetes.io/name"].includes(entry.selector.key)
  ) {
    throw new AdapterContractError("Kubernetes LIST entries require one fixed service selector");
  }
}

export class CompiledKubernetesCatalog {
  readonly #entries: ReadonlyMap<string, KubernetesCatalogEntry>;

  constructor(catalog: Readonly<KubernetesTrustedCatalog>) {
    const entries = new Map<string, KubernetesCatalogEntry>();
    for (const supplied of catalog.entries) {
      const entry = structuredClone(supplied);
      validateEntry(entry);
      if (entries.has(entry.id)) throw new AdapterContractError(`Duplicate Kubernetes catalog entry: ${entry.id}`);
      entries.set(entry.id, Object.freeze({
        ...entry,
        namespaceByEnvironment: Object.freeze({ ...entry.namespaceByEnvironment }),
        ...(entry.selector === undefined ? {} : { selector: Object.freeze({ ...entry.selector }) }),
      }));
    }
    this.#entries = entries;
  }

  resolve(id: string, expectedSha256: Sha256): KubernetesCatalogEntry {
    const entry = this.#entries.get(id);
    if (entry === undefined) throw new AdapterContractError("Kubernetes catalog entry is not trusted");
    if (kubernetesCatalogEntryHash(entry) !== expectedSha256) {
      throw new AdapterContractError("Kubernetes catalog entry hash mismatch");
    }
    return entry;
  }
}
