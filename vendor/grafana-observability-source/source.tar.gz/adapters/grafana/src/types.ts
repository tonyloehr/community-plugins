import type {
  JsonObject,
  Sha256,
  SubjectKind,
  SubjectRef,
} from "../../../packages/contracts/src/index.ts";

export const GRAFANA_POSTGRES_DATASOURCE_TYPES = [
  "postgres",
  "grafana-postgresql-datasource",
] as const;

export type GrafanaPostgresDatasourceType = typeof GRAFANA_POSTGRES_DATASOURCE_TYPES[number];
export type GrafanaCanonicalDatasourceType = "prometheus" | "loki" | "tempo" | "postgres";
export type GrafanaDatasourceType =
  | Exclude<GrafanaCanonicalDatasourceType, "postgres">
  | GrafanaPostgresDatasourceType;

export function isGrafanaPostgresDatasourceType(
  value: GrafanaDatasourceType,
): value is GrafanaPostgresDatasourceType {
  return (GRAFANA_POSTGRES_DATASOURCE_TYPES as readonly string[]).includes(value);
}

export function canonicalGrafanaDatasourceType(
  value: GrafanaDatasourceType,
): GrafanaCanonicalDatasourceType {
  return isGrafanaPostgresDatasourceType(value) ? "postgres" : value;
}

export type GrafanaRoute =
  | "health"
  | "search"
  | "datasource"
  | "datasource-health"
  | "datasource-query"
  | "annotations"
  | "unified-alerts";

interface GrafanaCatalogEntryBase {
  id: string;
  route: GrafanaRoute;
  outputName: string;
}

export interface GrafanaHealthCatalogEntry extends GrafanaCatalogEntryBase {
  route: "health";
}

export interface GrafanaSearchCatalogEntry extends GrafanaCatalogEntryBase {
  route: "search";
  query?: string;
  searchType?: "dash-db" | "dash-folder";
  tags?: string[];
}

export interface GrafanaDatasourceCatalogEntry extends GrafanaCatalogEntryBase {
  route: "datasource" | "datasource-health";
  datasourceUid: string;
}

export interface GrafanaPrometheusTarget {
  datasourceType: "prometheus";
  expression: string;
  mode: "instant" | "range";
  format: "time_series" | "table";
  legendFormat?: string;
}

export interface GrafanaLokiTarget {
  datasourceType: "loki";
  expression: string;
  queryType: "range";
  direction: "backward" | "forward";
}

export interface GrafanaTempoTarget {
  datasourceType: "tempo";
  expression: string;
  queryType: "traceql";
  limit: number;
  spansPerSpanSet: number;
  tableType: "traces" | "spans";
}

export interface GrafanaPostgresTarget {
  /** Exact Grafana plugin ID frozen during enrollment and sent back to `/api/ds/query`. */
  datasourceType: GrafanaPostgresDatasourceType;
  rawSql: string;
  format: "table" | "time_series";
  maxRows: number;
}

export type GrafanaDatasourceQueryTarget =
  | GrafanaPrometheusTarget
  | GrafanaLokiTarget
  | GrafanaTempoTarget
  | GrafanaPostgresTarget;

export function isGrafanaPostgresTarget(
  value: GrafanaDatasourceQueryTarget,
): value is GrafanaPostgresTarget {
  return isGrafanaPostgresDatasourceType(value.datasourceType);
}

export type GrafanaFrameFieldType = "time" | "number" | "string" | "boolean";
export type GrafanaFrameFieldRole = "TIME" | "VALUE" | "DIMENSION" | "COLUMN" | "SUMMARY" | "ATTRIBUTE";

export interface GrafanaFrameFieldContract {
  sourceName: string;
  outputName: string;
  type: GrafanaFrameFieldType;
  role: GrafanaFrameFieldRole;
}

export interface GrafanaFrameContract {
  resultKind: "SCALAR" | "TIMESERIES" | "TABLE" | "EVENT";
  fields: GrafanaFrameFieldContract[];
  allowedLabels: string[];
  unit?: string;
  eventSummary?: string;
}

export interface GrafanaDatasourceQueryScope {
  environment: string;
  service?: string;
  /**
   * Administrator-enrolled, one-to-one binding between a public opaque subject reference and the
   * provider-native value that the frozen target and returned frame must prove. The provider value
   * never leaves the adapter boundary.
   */
  subject?: {
    kind: SubjectKind;
    ref: SubjectRef;
    providerValue: string;
  };
}

export interface GrafanaDatasourceQueryScopeMappings {
  /** Returned frame fields used to prove normalized scope after the native query filter is enforced. */
  environment: string;
  service?: string;
  "subject.ref"?: string;
}

export interface GrafanaSavedPanelSource {
  dashboardUid: string;
  dashboardVersion: number;
  panelId: number;
  targetRefId: "A";
}

/**
 * Administrator-reviewed attestation for the database identity configured behind Grafana.
 * The opaque identity hash is safe to bind into the catalog; the database role itself is never
 * exposed to a runtime request or result.
 */
export interface GrafanaPostgresReadOnlyIdentityAttestation {
  roleIdentitySha256: Sha256;
  privilegeModel: "SELECT_ONLY";
}

export interface GrafanaDatasourceQueryCatalogEntry extends GrafanaCatalogEntryBase {
  route: "datasource-query";
  datasourceUid: string;
  /** Canonical upstream datasource identity shared with direct adapters, never the Grafana UID. */
  datasourceIdentitySha256: Sha256;
  target: GrafanaDatasourceQueryTarget;
  frame: GrafanaFrameContract;
  minIntervalMs: number;
  scope: GrafanaDatasourceQueryScope;
  scopeMappings: GrafanaDatasourceQueryScopeMappings;
  /** Required only for PostgreSQL targets and included in the catalog entry hash. */
  postgresReadOnlyIdentity?: GrafanaPostgresReadOnlyIdentityAttestation;
  sourcePanel?: GrafanaSavedPanelSource;
}

export interface GrafanaAnnotationsCatalogEntry extends GrafanaCatalogEntryBase {
  route: "annotations";
  annotationType?: "alert" | "annotation";
  tags?: string[];
}

export interface GrafanaUnifiedAlertsCatalogEntry extends GrafanaCatalogEntryBase {
  route: "unified-alerts";
}

export type GrafanaCatalogEntry =
  | GrafanaHealthCatalogEntry
  | GrafanaSearchCatalogEntry
  | GrafanaDatasourceCatalogEntry
  | GrafanaDatasourceQueryCatalogEntry
  | GrafanaAnnotationsCatalogEntry
  | GrafanaUnifiedAlertsCatalogEntry;

export interface GrafanaTrustedCatalog {
  entries: GrafanaCatalogEntry[];
}

interface GrafanaHttpRequestBase {
  signal: AbortSignal;
  maxResponseBytes: number;
}

export interface GrafanaHttpGetRequest extends GrafanaHttpRequestBase {
  method: "GET";
  path:
    | "/api/health"
    | "/api/search"
    | `/api/datasources/uid/${string}`
    | `/api/datasources/uid/${string}/health`
    | `/api/datasources/proxy/uid/${string}/api/search`
    | "/api/annotations"
    | "/api/v1/provisioning/alert-rules";
  query: Readonly<Record<string, string>>;
}

export interface GrafanaHttpPostRequest extends GrafanaHttpRequestBase {
  method: "POST";
  path: "/api/ds/query";
  query: Readonly<Record<string, never>>;
  body: Readonly<JsonObject>;
}

export type GrafanaHttpRequest = GrafanaHttpGetRequest | GrafanaHttpPostRequest;

export interface GrafanaHttpResponse {
  status: number;
  body: AsyncIterable<Uint8Array>;
}

export interface GrafanaTransport {
  request(request: Readonly<GrafanaHttpRequest>): Promise<GrafanaHttpResponse>;
}

export class GrafanaTransportError extends Error {
  readonly kind: "TIMEOUT" | "UNAVAILABLE";

  constructor(kind: "TIMEOUT" | "UNAVAILABLE") {
    super(`Grafana transport ${kind.toLowerCase()}`);
    this.name = "GrafanaTransportError";
    this.kind = kind;
  }
}

export interface GrafanaCatalogReference {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
}
