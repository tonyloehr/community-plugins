import { AdapterContractError } from "../../../packages/adapter-sdk/src/index.ts";
import { parse, type SelectFromStatement, type Statement } from "pgsql-ast-parser";

import {
  isGrafanaPostgresTarget,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaDatasourceQueryTarget,
  type GrafanaFrameContract,
  type GrafanaFrameFieldContract,
  type GrafanaPostgresTarget,
} from "./types.ts";

const SAFE_ID = /^[a-zA-Z][a-zA-Z0-9_.:-]{0,127}$/u;
const SAFE_UID = /^[a-zA-Z0-9_-]{1,128}$/u;
const SAFE_SCOPE_VALUE = /^[a-zA-Z0-9][a-zA-Z0-9_.:/-]{0,127}$/u;
const SAFE_PROVIDER_SUBJECT_VALUE = /^[a-zA-Z0-9][a-zA-Z0-9_.:/-]{0,127}$/u;
const SUBJECT_REF = /^pmsub_[A-Za-z0-9_-]{20,128}$/u;
const SHA256 = /^[a-f0-9]{64}$/u;
const QUERY_UNSAFE_MARKERS = ["$", ";", "--", "/*", "*/", "//", "#"] as const;

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function assertExactKeys(value: object, allowed: readonly string[], subject: string): void {
  const allowedKeys = new Set(allowed);
  if (Object.keys(value).some((key) => !allowedKeys.has(key))) {
    throw new AdapterContractError(`Grafana ${subject} contains an unsupported field`);
  }
}

function validateText(value: unknown, subject: string, maximum: number, allowNewlines = false): asserts value is string {
  const unsafe = typeof value === "string" && [...value].some((character) => {
    const code = character.codePointAt(0) ?? 0;
    return code === 0 || code === 127 || (code < 32 && !(allowNewlines && (code === 9 || code === 10 || code === 13)));
  });
  if (typeof value !== "string" || value.length === 0 || value.length > maximum || unsafe) {
    throw new AdapterContractError(`Grafana ${subject} is invalid`);
  }
}

function validatePositiveInteger(value: unknown, subject: string, maximum: number): asserts value is number {
  if (!Number.isSafeInteger(value) || (value as number) < 1 || (value as number) > maximum) {
    throw new AdapterContractError(`Grafana ${subject} is invalid`);
  }
}

function validateExpression(value: unknown, subject: string): asserts value is string {
  validateText(value, subject, 16_384, true);
  if (QUERY_UNSAFE_MARKERS.some((marker) => value.includes(marker))) {
    throw new AdapterContractError(`Grafana ${subject} contains a variable, statement separator, or comment`);
  }
}

function sqlForValidation(rawSql: string): string {
  const expanded = rawSql
    .replace(/\$__timeFilter\(\s*[a-zA-Z_][a-zA-Z0-9_.]*\s*\)/gu, "(time_value >= TIMESTAMP '1970-01-01')")
    .replace(/\$__timeFrom\(\)/gu, "TIMESTAMP '1970-01-01'")
    .replace(/\$__timeTo\(\)/gu, "TIMESTAMP '1970-01-02'");
  if (expanded.includes("$")) {
    throw new AdapterContractError("Grafana PostgreSQL SQL contains an unsupported macro or parameter");
  }
  if (expanded.includes("--") || expanded.includes("/*") || expanded.includes("*/")) {
    throw new AdapterContractError("Grafana PostgreSQL SQL contains a comment");
  }
  return expanded;
}

function auditPostgresAst(value: unknown): void {
  if (Array.isArray(value)) {
    for (const child of value) auditPostgresAst(child);
    return;
  }
  if (!isObject(value)) return;
  const type = value.type;
  if (type === "insert" || type === "update" || type === "delete") {
    throw new AdapterContractError("Grafana PostgreSQL SQL contains a writable statement or CTE");
  }
  if (type === "with recursive" || type === "union" || type === "union all" || type === "values") {
    throw new AdapterContractError("Grafana PostgreSQL SQL contains an unsupported compound SELECT");
  }
  if (type === "select" && (value.for !== undefined || value.skip !== undefined || value.into !== undefined)) {
    throw new AdapterContractError("Grafana PostgreSQL SQL contains a locking or SELECT INTO clause");
  }
  if (type === "parameter") {
    throw new AdapterContractError("Grafana PostgreSQL SQL contains an unsupported parameter");
  }
  if (type === "call") {
    throw new AdapterContractError("Grafana PostgreSQL SQL contains a function call");
  }
  for (const child of Object.values(value)) auditPostgresAst(child);
}

function assertReadOnlySelect(statement: Statement): void {
  if (statement.type === "select") {
    auditPostgresAst(statement);
    return;
  }
  if (statement.type === "with") {
    for (const binding of statement.bind) assertReadOnlySelect(binding.statement);
    assertReadOnlySelect(statement.in);
    auditPostgresAst(statement);
    return;
  }
  throw new AdapterContractError("Grafana PostgreSQL SQL must be one read-only SELECT or WITH SELECT");
}

function outerSelect(statement: Statement): SelectFromStatement {
  if (statement.type === "select") return statement;
  if (statement.type === "with") return outerSelect(statement.in);
  throw new AdapterContractError("Grafana PostgreSQL SQL must end in a bounded SELECT");
}

export function validateGrafanaPostgresSql(target: Readonly<GrafanaPostgresTarget>): void {
  validateText(target.rawSql, "PostgreSQL SQL", 65_536, true);
  validatePositiveInteger(target.maxRows, "PostgreSQL row limit", 10_000);
  let statements: Statement[];
  try {
    statements = parse(sqlForValidation(target.rawSql));
  } catch {
    throw new AdapterContractError("Grafana PostgreSQL SQL could not be parsed as a read-only statement");
  }
  if (statements.length !== 1) {
    throw new AdapterContractError("Grafana PostgreSQL SQL must contain exactly one statement");
  }
  const statement = statements[0]!;
  assertReadOnlySelect(statement);
  const bounded = outerSelect(statement);
  const limit = bounded.limit?.limit;
  if (bounded.limit?.offset !== undefined || limit?.type !== "integer" ||
      !Number.isSafeInteger(limit.value) || limit.value < 1 || limit.value > target.maxRows) {
    throw new AdapterContractError("Grafana PostgreSQL SQL LIMIT exceeds its enrolled row limit");
  }
}

function validateFrameField(field: GrafanaFrameFieldContract): void {
  if (!isObject(field)) throw new AdapterContractError("Grafana frame field contract is invalid");
  assertExactKeys(field, ["sourceName", "outputName", "type", "role"], "frame field contract");
  validateText(field.sourceName, "frame source field", 256);
  if (!SAFE_ID.test(field.outputName)) throw new AdapterContractError("Grafana frame output field is invalid");
  if (!new Set(["time", "number", "string", "boolean"]).has(field.type)) {
    throw new AdapterContractError("Grafana frame field type is unsupported");
  }
  if (!new Set(["TIME", "VALUE", "DIMENSION", "COLUMN", "SUMMARY", "ATTRIBUTE"]).has(field.role)) {
    throw new AdapterContractError("Grafana frame field role is unsupported");
  }
  if (field.role === "TIME" && field.type !== "time") {
    throw new AdapterContractError("Grafana TIME frame field must have time type");
  }
  if (field.role === "VALUE" && field.type !== "number") {
    throw new AdapterContractError("Grafana VALUE frame field must have number type");
  }
  if (field.role === "SUMMARY" && field.type !== "string") {
    throw new AdapterContractError("Grafana SUMMARY frame field must have string type");
  }
}

export function validateGrafanaFrameContract(frame: Readonly<GrafanaFrameContract>): void {
  if (!isObject(frame)) throw new AdapterContractError("Grafana frame contract is invalid");
  assertExactKeys(frame, ["resultKind", "fields", "allowedLabels", "unit", "eventSummary"], "frame contract");
  if (!new Set(["SCALAR", "TIMESERIES", "TABLE", "EVENT"]).has(frame.resultKind)) {
    throw new AdapterContractError("Grafana frame result kind is invalid");
  }
  if (!Array.isArray(frame.fields) || frame.fields.length === 0 || frame.fields.length > 32) {
    throw new AdapterContractError("Grafana frame fields must be non-empty and bounded");
  }
  for (const field of frame.fields) validateFrameField(field);
  if (new Set(frame.fields.map((field) => field.sourceName)).size !== frame.fields.length ||
      new Set(frame.fields.map((field) => field.outputName)).size !== frame.fields.length) {
    throw new AdapterContractError("Grafana frame fields must have unique source and output names");
  }
  if (!Array.isArray(frame.allowedLabels) || frame.allowedLabels.length > 16 ||
      new Set(frame.allowedLabels).size !== frame.allowedLabels.length ||
      frame.allowedLabels.some((label) => !SAFE_ID.test(label))) {
    throw new AdapterContractError("Grafana frame labels must be unique, safe, and bounded");
  }
  const roles = frame.fields.map((field) => field.role);
  const count = (role: GrafanaFrameFieldContract["role"]) => roles.filter((candidate) => candidate === role).length;
  if (frame.resultKind === "SCALAR" && (count("VALUE") !== 1 || count("TIME") > 1 || roles.some((role) => !new Set(["VALUE", "TIME", "DIMENSION"]).has(role)))) {
    throw new AdapterContractError("Grafana SCALAR frame contract roles are invalid");
  }
  if (frame.resultKind === "TIMESERIES" && (count("VALUE") < 1 || count("TIME") !== 1 || roles.some((role) => !new Set(["VALUE", "TIME", "DIMENSION"]).has(role)))) {
    throw new AdapterContractError("Grafana TIMESERIES frame contract roles are invalid");
  }
  if (frame.resultKind === "TABLE" && roles.some((role) => !new Set(["COLUMN", "DIMENSION"]).has(role))) {
    throw new AdapterContractError("Grafana TABLE frame contract roles are invalid");
  }
  if (frame.resultKind === "EVENT" && (count("TIME") !== 1 || count("SUMMARY") > 1 || roles.some((role) => !new Set(["TIME", "SUMMARY", "ATTRIBUTE", "DIMENSION"]).has(role)))) {
    throw new AdapterContractError("Grafana EVENT frame contract roles are invalid");
  }
  if (frame.unit !== undefined) {
    validateText(frame.unit, "frame unit", 64);
    if (frame.resultKind !== "SCALAR" && frame.resultKind !== "TIMESERIES") {
      throw new AdapterContractError("Grafana frame unit is only valid for numeric output");
    }
  }
  if (frame.eventSummary !== undefined) validateText(frame.eventSummary, "event summary", 256);
  if (frame.resultKind === "EVENT" && count("SUMMARY") === 0 && frame.eventSummary === undefined) {
    throw new AdapterContractError("Grafana EVENT frame contract requires a fixed or mapped summary");
  }
}

export function validateGrafanaDatasourceQueryTarget(target: Readonly<GrafanaDatasourceQueryTarget>): void {
  if (!isObject(target)) throw new AdapterContractError("Grafana datasource query target is invalid");
  if (target.datasourceType === "prometheus") {
    assertExactKeys(target, ["datasourceType", "expression", "mode", "format", "legendFormat"], "Prometheus target");
    validateExpression(target.expression, "Prometheus expression");
    if (!new Set(["instant", "range"]).has(target.mode) || !new Set(["time_series", "table"]).has(target.format)) {
      throw new AdapterContractError("Grafana Prometheus target mode or format is invalid");
    }
    if (target.legendFormat !== undefined) validateText(target.legendFormat, "Prometheus legend", 256);
    return;
  }
  if (target.datasourceType === "loki") {
    assertExactKeys(target, ["datasourceType", "expression", "queryType", "direction"], "Loki target");
    validateExpression(target.expression, "Loki expression");
    if (target.queryType !== "range" || !new Set(["backward", "forward"]).has(target.direction)) {
      throw new AdapterContractError("Grafana Loki target mode is invalid");
    }
    return;
  }
  if (target.datasourceType === "tempo") {
    assertExactKeys(target, ["datasourceType", "expression", "queryType", "limit", "spansPerSpanSet", "tableType"], "Tempo target");
    validateExpression(target.expression, "Tempo TraceQL expression");
    validatePositiveInteger(target.limit, "Tempo trace limit", 1_000);
    validatePositiveInteger(target.spansPerSpanSet, "Tempo spans-per-span-set", 1_000);
    if (target.queryType !== "traceql" || !new Set(["traces", "spans"]).has(target.tableType)) {
      throw new AdapterContractError("Grafana Tempo target mode is invalid");
    }
    return;
  }
  if (isGrafanaPostgresTarget(target)) {
    assertExactKeys(target, ["datasourceType", "rawSql", "format", "maxRows"], "PostgreSQL target");
    if (!new Set(["table", "time_series"]).has(target.format)) {
      throw new AdapterContractError("Grafana PostgreSQL target format is invalid");
    }
    validateGrafanaPostgresSql(target);
    return;
  }
  throw new AdapterContractError("Grafana datasource type is not certified");
}

function validateTargetFrameCompatibility(entry: Readonly<GrafanaDatasourceQueryCatalogEntry>): void {
  const { target, frame } = entry;
  if (target.datasourceType === "prometheus") {
    if (target.format === "table" && frame.resultKind !== "TABLE") {
      throw new AdapterContractError("Grafana Prometheus table target requires TABLE normalization");
    }
    if (target.format === "time_series" && !new Set(["SCALAR", "TIMESERIES"]).has(frame.resultKind)) {
      throw new AdapterContractError("Grafana Prometheus time-series target has an incompatible frame contract");
    }
  } else if (target.datasourceType === "loki" && !new Set(["EVENT", "TABLE", "TIMESERIES"]).has(frame.resultKind)) {
    throw new AdapterContractError("Grafana Loki target has an incompatible frame contract");
  } else if (target.datasourceType === "tempo" && !new Set(["EVENT", "TABLE"]).has(frame.resultKind)) {
    throw new AdapterContractError("Grafana Tempo target has an incompatible frame contract");
  } else if (isGrafanaPostgresTarget(target)) {
    const allowed = target.format === "table" ? ["SCALAR", "TABLE"] : ["SCALAR", "TIMESERIES"];
    if (!allowed.includes(frame.resultKind)) {
      throw new AdapterContractError("Grafana PostgreSQL target has an incompatible frame contract");
    }
  }
}

interface BracedSelector {
  start: number;
  end: number;
  content: string;
}

type EnrolledScopeField = "environment" | "service" | "subject.ref";

interface TargetScopeConstraint {
  scopeField: EnrolledScopeField;
  outputField: string;
  queryField: string;
  expectedValue: string;
}

function extractBracedSelectors(expression: string, datasource: string): BracedSelector[] {
  const selectors: BracedSelector[] = [];
  let quote: "\"" | "'" | "`" | undefined;
  let escaped = false;
  let start: number | undefined;
  for (let index = 0; index < expression.length; index += 1) {
    const character = expression[index]!;
    if (quote !== undefined) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === quote) quote = undefined;
      continue;
    }
    if (character === "\"" || character === "'" || character === "`") {
      quote = character;
      continue;
    }
    if (character === "{") {
      if (start !== undefined) {
        throw new AdapterContractError(`Grafana ${datasource} enrolled scope contains nested selectors`);
      }
      start = index;
    } else if (character === "}") {
      if (start === undefined) {
        throw new AdapterContractError(`Grafana ${datasource} enrolled scope contains an unmatched selector`);
      }
      selectors.push({ start, end: index, content: expression.slice(start + 1, index) });
      start = undefined;
    }
  }
  if (quote !== undefined || start !== undefined) {
    throw new AdapterContractError(`Grafana ${datasource} enrolled scope contains an incomplete selector`);
  }
  return selectors;
}

function escapeRegularExpression(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
}

function selectorHasExactMatcher(selector: string, field: string, providerValue: string): boolean {
  const pattern = new RegExp(
    `(?:^|,)\\s*${escapeRegularExpression(field)}\\s*=\\s*"${escapeRegularExpression(providerValue)}"\\s*(?=,|$)`,
    "u",
  );
  return pattern.test(selector);
}

function maskQuotedText(value: string): string {
  const output = [...value];
  let quote: "\"" | "'" | "`" | undefined;
  let escaped = false;
  for (let index = 0; index < output.length; index += 1) {
    const character = output[index]!;
    if (quote === undefined) {
      if (character === "\"" || character === "'" || character === "`") {
        quote = character;
        output[index] = " ";
      }
      continue;
    }
    output[index] = " ";
    if (escaped) escaped = false;
    else if (character === "\\") escaped = true;
    else if (character === quote) quote = undefined;
  }
  return output.join("");
}

function selectorHasEveryExactMatcher(
  selector: string,
  constraints: readonly TargetScopeConstraint[],
): boolean {
  return constraints.every((constraint) =>
    selectorHasExactMatcher(selector, constraint.queryField, constraint.expectedValue));
}

function validatePrometheusTargetScope(
  expression: string,
  constraints: readonly TargetScopeConstraint[],
): void {
  if (/\blabel_(?:join|replace)\s*\(/iu.test(maskQuotedText(expression))) {
    throw new AdapterContractError("Grafana Prometheus target mutates enrolled scope labels");
  }
  const selectors = extractBracedSelectors(expression, "Prometheus");
  if (selectors.length === 0 || selectors.some((selector) =>
    !selectorHasEveryExactMatcher(selector.content, constraints))) {
    throw new AdapterContractError("Grafana Prometheus target does not enforce every enrolled scope constraint");
  }

  const masked = [...expression];
  for (const selector of selectors) {
    let prefix = selector.start;
    while (prefix > 0 && /[A-Za-z0-9_:]/u.test(expression[prefix - 1]!)) prefix -= 1;
    masked.fill(" ", prefix, selector.end + 1);
  }
  let remainder = maskQuotedText(masked.join(""));
  remainder = remainder
    .replace(/\b(?:by|without|on|ignoring|group_left|group_right)\s*\([^()]*\)/gu, " ")
    .replace(/\[[^\]]*\]/gu, " ")
    .replace(/\b\d+(?:\.\d+)?(?:ms|s|m|h|d|w|y)\b/gu, " ")
    .replace(/\b[A-Za-z_][A-Za-z0-9_]*\s*(?=\()/gu, " ")
    .replace(/\b(?:and|or|unless|bool|offset|by|without|on|ignoring|group_left|group_right|inf|nan)\b/gu, " ");
  if (/[A-Za-z_:][A-Za-z0-9_:]*/u.test(remainder)) {
    throw new AdapterContractError("Grafana Prometheus target contains an unscoped vector selector");
  }
}

function validateLokiTargetScope(
  expression: string,
  constraints: readonly TargetScopeConstraint[],
): void {
  if (/\b(?:label_format|label_replace)\b/iu.test(maskQuotedText(expression))) {
    throw new AdapterContractError("Grafana Loki target mutates enrolled scope labels");
  }
  const selectors = extractBracedSelectors(expression, "Loki");
  if (selectors.length === 0 || selectors.some((selector) =>
    !selectorHasEveryExactMatcher(selector.content, constraints))) {
    throw new AdapterContractError("Grafana Loki target does not enforce every enrolled scope constraint");
  }
}

function splitTempoConjuncts(selector: string): string[] | undefined {
  const conjuncts: string[] = [];
  let quote: "\"" | "'" | "`" | undefined;
  let escaped = false;
  let parentheses = 0;
  let start = 0;
  for (let index = 0; index < selector.length; index += 1) {
    const character = selector[index]!;
    if (quote !== undefined) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === quote) quote = undefined;
      continue;
    }
    if (character === "\"" || character === "'" || character === "`") {
      quote = character;
      continue;
    }
    if (character === "(") parentheses += 1;
    else if (character === ")") {
      parentheses -= 1;
      if (parentheses < 0) return undefined;
    } else if (character === "|" && selector[index + 1] === "|") {
      return undefined;
    } else if (parentheses === 0 && character === "&" && selector[index + 1] === "&") {
      conjuncts.push(selector.slice(start, index).trim());
      start = index + 2;
      index += 1;
    }
  }
  if (quote !== undefined || parentheses !== 0) return undefined;
  conjuncts.push(selector.slice(start).trim());
  return conjuncts;
}

function tempoConjunctMatchesConstraint(
  conjunct: string,
  constraint: Readonly<TargetScopeConstraint>,
): boolean {
  const exactPredicate = new RegExp(
    `^${escapeRegularExpression(constraint.queryField)}\\s*=\\s*"${escapeRegularExpression(constraint.expectedValue)}"$`,
    "u",
  );
  return exactPredicate.test(conjunct);
}

function validateTempoTargetScope(
  expression: string,
  constraints: readonly TargetScopeConstraint[],
): void {
  const selectors = extractBracedSelectors(expression, "Tempo");
  if (selectors.length === 0 || selectors.some((selector) => {
    const conjuncts = splitTempoConjuncts(selector.content);
    return conjuncts === undefined || constraints.some((constraint) =>
      !conjuncts.some((conjunct) => tempoConjunctMatchesConstraint(conjunct, constraint)));
  })) {
    throw new AdapterContractError("Grafana Tempo target does not enforce every enrolled scope constraint");
  }
}

function postgresReferenceMatches(value: unknown, field: string): boolean {
  if (!isObject(value) || value.type !== "ref" || typeof value.name !== "string") return false;
  if (value.name === field) return true;
  return isObject(value.table) && typeof value.table.name === "string" &&
    `${value.table.name}.${value.name}` === field;
}

function postgresStringMatches(value: unknown, providerValue: string): boolean {
  return isObject(value) && value.type === "string" && value.value === providerValue;
}

function postgresScopeEquality(value: unknown, field: string, expectedValue: string): boolean {
  return isObject(value) && value.type === "binary" && value.op === "=" &&
    ((postgresReferenceMatches(value.left, field) && postgresStringMatches(value.right, expectedValue)) ||
      (postgresReferenceMatches(value.right, field) && postgresStringMatches(value.left, expectedValue)));
}

function postgresWhereHasScopeConjunct(value: unknown, field: string, expectedValue: string): boolean {
  if (postgresScopeEquality(value, field, expectedValue)) return true;
  return isObject(value) && value.type === "binary" && value.op === "AND" &&
    (postgresWhereHasScopeConjunct(value.left, field, expectedValue) ||
      postgresWhereHasScopeConjunct(value.right, field, expectedValue));
}

function postgresColumnOutputName(value: unknown): string | undefined {
  if (!isObject(value)) return undefined;
  if (isObject(value.alias) && typeof value.alias.name === "string") return value.alias.name;
  return isObject(value.expr) && value.expr.type === "ref" && typeof value.expr.name === "string"
    ? value.expr.name
    : undefined;
}

function postgresDirectlyProjectsScopeField(columns: unknown, field: string): boolean {
  if (!Array.isArray(columns)) return false;
  const matching = columns.filter((column) => postgresColumnOutputName(column) === field);
  return matching.length === 1 && isObject(matching[0]) &&
    postgresReferenceMatches(matching[0].expr, field);
}

function validatePostgresTargetScope(
  rawSql: string,
  constraints: readonly TargetScopeConstraint[],
): void {
  let statements: Statement[];
  try {
    statements = parse(sqlForValidation(rawSql));
  } catch {
    throw new AdapterContractError("Grafana PostgreSQL enrolled scope could not be parsed");
  }
  const statement = statements[0];
  const source = statement?.type === "select" && Array.isArray(statement.from) && statement.from.length === 1
    ? statement.from[0]
    : undefined;
  if (statements.length !== 1 || statement?.type !== "select" || !isObject(source) ||
      source.type !== "table" || source.join !== undefined ||
      constraints.some((constraint) =>
        !postgresWhereHasScopeConjunct(statement.where, constraint.queryField, constraint.expectedValue) ||
        !postgresDirectlyProjectsScopeField(statement.columns, constraint.outputField))) {
    throw new AdapterContractError(
      "Grafana PostgreSQL target must directly filter and project every enrolled scope constraint",
    );
  }
}

function targetScopeConstraints(
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
): TargetScopeConstraint[] {
  const tempo = entry.target.datasourceType === "tempo";
  // Frame mappings name returned Grafana fields; TraceQL environment/service filters use canonical resource attributes.
  return [
    {
      scopeField: "environment",
      outputField: entry.scopeMappings.environment,
      queryField: tempo ? "resource.deployment.environment" : entry.scopeMappings.environment,
      expectedValue: entry.scope.environment,
    },
    ...(entry.scope.service === undefined
      ? []
      : [{
          scopeField: "service" as const,
          outputField: entry.scopeMappings.service!,
          queryField: tempo ? "resource.service.name" : entry.scopeMappings.service!,
          expectedValue: entry.scope.service,
        }]),
    ...(entry.scope.subject === undefined
      ? []
      : [{
          scopeField: "subject.ref" as const,
          outputField: entry.scopeMappings["subject.ref"]!,
          queryField: entry.scopeMappings["subject.ref"]!,
          expectedValue: entry.scope.subject.providerValue,
        }]),
  ];
}

function validateTargetScopeBindings(entry: Readonly<GrafanaDatasourceQueryCatalogEntry>): void {
  const subject = entry.scope.subject;
  if (subject !== undefined && entry.frame.eventSummary?.includes(subject.providerValue) === true) {
    throw new AdapterContractError("Grafana frame summary exposes its provider-native subject value");
  }
  const constraints = targetScopeConstraints(entry);
  if (entry.target.datasourceType === "prometheus") {
    validatePrometheusTargetScope(entry.target.expression, constraints);
  } else if (entry.target.datasourceType === "loki") {
    validateLokiTargetScope(entry.target.expression, constraints);
  } else if (entry.target.datasourceType === "tempo") {
    validateTempoTargetScope(entry.target.expression, constraints);
  } else {
    validatePostgresTargetScope(entry.target.rawSql, constraints);
  }
}

export function validateGrafanaDatasourceQueryEntry(entry: Readonly<GrafanaDatasourceQueryCatalogEntry>): void {
  if (!SAFE_UID.test(entry.datasourceUid)) throw new AdapterContractError("Grafana datasource UID is invalid");
  if (!SHA256.test(entry.datasourceIdentitySha256)) {
    throw new AdapterContractError("Grafana datasource identity hash is invalid");
  }
  validatePositiveInteger(entry.minIntervalMs, "minimum query interval", 3_600_000);
  validateGrafanaDatasourceQueryTarget(entry.target);
  if (isGrafanaPostgresTarget(entry.target)) {
    if (!isObject(entry.postgresReadOnlyIdentity)) {
      throw new AdapterContractError("Grafana PostgreSQL target requires a SELECT_ONLY database identity attestation");
    }
    assertExactKeys(
      entry.postgresReadOnlyIdentity,
      ["roleIdentitySha256", "privilegeModel"],
      "PostgreSQL database identity attestation",
    );
    if (!SHA256.test(entry.postgresReadOnlyIdentity.roleIdentitySha256) ||
        entry.postgresReadOnlyIdentity.privilegeModel !== "SELECT_ONLY") {
      throw new AdapterContractError("Grafana PostgreSQL database identity attestation is invalid");
    }
  } else if (entry.postgresReadOnlyIdentity !== undefined) {
    throw new AdapterContractError("Grafana PostgreSQL database identity attestation is forbidden for non-PostgreSQL targets");
  }
  validateGrafanaFrameContract(entry.frame);
  if (!isObject(entry.scope) || !isObject(entry.scopeMappings)) {
    throw new AdapterContractError("Grafana datasource query scope is invalid");
  }
  assertExactKeys(entry.scope, ["environment", "service", "subject"], "datasource query scope");
  assertExactKeys(entry.scopeMappings, ["environment", "service", "subject.ref"], "datasource query scope mappings");
  if (!SAFE_SCOPE_VALUE.test(entry.scope.environment) ||
      (entry.scope.service !== undefined && !SAFE_SCOPE_VALUE.test(entry.scope.service))) {
    throw new AdapterContractError("Grafana datasource query scope values are invalid");
  }
  if (entry.scope.subject !== undefined) {
    if (!isObject(entry.scope.subject)) throw new AdapterContractError("Grafana datasource query subject binding is invalid");
    assertExactKeys(entry.scope.subject, ["kind", "ref", "providerValue"], "datasource query subject binding");
    if (!new Set(["HOST", "DEVICE", "FLEET", "BUSINESS_UNIT", "KPI_SET"]).has(entry.scope.subject.kind) ||
        !SUBJECT_REF.test(entry.scope.subject.ref) ||
        !SAFE_PROVIDER_SUBJECT_VALUE.test(entry.scope.subject.providerValue)) {
      throw new AdapterContractError("Grafana datasource query subject binding is invalid");
    }
  }
  const scopeMappingValues = [
    entry.scopeMappings.environment,
    ...(entry.scopeMappings.service === undefined ? [] : [entry.scopeMappings.service]),
    ...(entry.scopeMappings["subject.ref"] === undefined ? [] : [entry.scopeMappings["subject.ref"]]),
  ];
  if (!SAFE_ID.test(entry.scopeMappings.environment) ||
      (entry.scopeMappings.service !== undefined && !SAFE_ID.test(entry.scopeMappings.service)) ||
      (entry.scopeMappings["subject.ref"] !== undefined && !SAFE_ID.test(entry.scopeMappings["subject.ref"])) ||
      new Set(scopeMappingValues).size !== scopeMappingValues.length ||
      (entry.scope.service === undefined) !== (entry.scopeMappings.service === undefined) ||
      (entry.scope.subject === undefined) !== (entry.scopeMappings["subject.ref"] === undefined)) {
    throw new AdapterContractError("Grafana datasource query scope mappings are invalid");
  }
  const scopeSources = new Set([
    ...entry.frame.fields
      .filter((field) => field.role === "DIMENSION")
      .map((field) => field.sourceName),
    ...entry.frame.allowedLabels,
  ]);
  if (!scopeSources.has(entry.scopeMappings.environment) ||
      (entry.scopeMappings.service !== undefined && !scopeSources.has(entry.scopeMappings.service)) ||
      (entry.scopeMappings["subject.ref"] !== undefined && !scopeSources.has(entry.scopeMappings["subject.ref"]))) {
    throw new AdapterContractError("Grafana datasource query scope mapping is not present in the enrolled frame");
  }
  if (entry.sourcePanel !== undefined) {
    if (!isObject(entry.sourcePanel)) throw new AdapterContractError("Grafana saved-panel source is invalid");
    assertExactKeys(entry.sourcePanel, ["dashboardUid", "dashboardVersion", "panelId", "targetRefId"], "saved-panel source");
    if (!SAFE_UID.test(entry.sourcePanel.dashboardUid)) throw new AdapterContractError("Grafana dashboard UID is invalid");
    validatePositiveInteger(entry.sourcePanel.dashboardVersion, "dashboard version", 2_147_483_647);
    validatePositiveInteger(entry.sourcePanel.panelId, "panel ID", 2_147_483_647);
    if (entry.sourcePanel.targetRefId !== "A") throw new AdapterContractError("Grafana saved panel must bind target A");
  }
  validateTargetFrameCompatibility(entry);
  validateTargetScopeBindings(entry);
}
