import { canonicalJson, type JsonPrimitive } from "../../../packages/contracts/src/index.ts";
import { AdapterContractError, type AdapterExecutionContext } from "../../../packages/adapter-sdk/src/index.ts";

import type {
  GrafanaDatasourceQueryCatalogEntry,
  GrafanaFrameFieldContract,
  GrafanaFrameFieldType,
} from "./types.ts";

type ObjectValue = Record<string, unknown>;
type NativeValues = Record<string, JsonPrimitive>;

function object(value: unknown): value is ObjectValue {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function invalid(message: string): never {
  throw new AdapterContractError(`Grafana native response ${message}`);
}

function text(value: unknown, maximum = 4_096): string {
  if (typeof value !== "string" || value.length > maximum || [...value].some((character) => {
    const code = character.codePointAt(0) ?? 0;
    return code === 127 || (code < 32 && code !== 9 && code !== 10 && code !== 13);
  })) {
    return invalid("contains an invalid string");
  }
  return value;
}

function decimal(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$/u.test(value)) {
    const converted = Number(value);
    if (Number.isFinite(converted)) return converted;
  }
  return invalid("contains an invalid number");
}

function nanosToMilliseconds(value: unknown): number {
  if (typeof value !== "string" || !/^[0-9]{1,30}$/u.test(value)) return invalid("contains invalid nanoseconds");
  const milliseconds = Number(BigInt(value) / 1_000_000n);
  if (!Number.isSafeInteger(milliseconds)) return invalid("timestamp is outside the safe range");
  return milliseconds;
}

function typedPrimitive(value: unknown, type: GrafanaFrameFieldType): JsonPrimitive {
  if (value === null) return null;
  if (type === "number") return decimal(value);
  if (type === "string") return text(value);
  if (type === "boolean") {
    if (value === true || value === false) return value;
    if (value === "true" || value === "false") return value === "true";
    return invalid("contains an invalid boolean");
  }
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") return text(value);
  return invalid("contains an invalid time");
}

function projectedFrame(
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  values: Readonly<NativeValues>,
  fieldValue: (field: GrafanaFrameFieldContract) => unknown = (field) => values[field.sourceName],
): ObjectValue {
  const labels = Object.fromEntries(entry.frame.allowedLabels.flatMap((name) => {
    const value = values[name];
    return value === undefined || value === null ? [] : [[name, text(String(value), 128)]];
  }));
  return {
    schema: {
      refId: "A",
      fields: entry.frame.fields.map((field, index) => ({
        name: field.sourceName,
        type: field.type,
        ...(index === 0 && Object.keys(labels).length > 0 ? { labels } : {}),
      })),
    },
    data: {
      values: entry.frame.fields.map((field) => {
        const value = fieldValue(field);
        if (value === undefined) return invalid("omits an enrolled field");
        return [typedPrimitive(value, field.type)];
      }),
    },
  };
}

function envelope(frames: ObjectValue[]): ObjectValue {
  return { results: { A: { frames } } };
}

function stringLabels(value: unknown): Record<string, string> {
  if (!object(value) || Object.keys(value).length > 128) return invalid("labels are invalid");
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [text(key, 256), text(item)]));
}

const LOKI_FIELD_SHAPES = new Set([
  "labels:other,Time:time,Line:string,tsNs:string,id:string",
  "labels:other,Time:time,Line:string,tsNs:string,labelTypes:other,id:string",
  "labels:other,timestamp:time,body:string,id:string",
  "labels:other,timestamp:time,body:string,id:string,labelTypes:other",
]);

/** Project only the documented Grafana 10–13 native Loki log-frame layouts. */
function normalizeLokiLogs(
  body: unknown,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
): unknown {
  if (!object(body) || !object(body.results) || !object(body.results.A) || !Array.isArray(body.results.A.frames)) return body;
  const result = body.results.A;
  if (Object.keys(body.results).length !== 1 || result.error !== undefined ||
      (typeof result.status === "number" && result.status >= 400)) return body;
  const supplied = result.frames as unknown[];
  const native = supplied.some((frame) => object(frame) && object(frame.schema) &&
    Array.isArray(frame.schema.fields) && frame.schema.fields.some((field) =>
      object(field) && field.name === "labels" && field.type === "other"));
  if (!native) return body; // Existing exact, primitive enrolled frames remain valid.
  const output: ObjectValue[] = [];
  for (const frame of supplied) {
    if (!object(frame) || !object(frame.schema) || frame.schema.refId !== "A" ||
        !Array.isArray(frame.schema.fields) || !object(frame.data) || !Array.isArray(frame.data.values)) {
      return invalid("Loki frame is invalid");
    }
    const names = frame.schema.fields.map((field) => {
      if (!object(field) || typeof field.name !== "string" || typeof field.type !== "string") return invalid("Loki field is invalid");
      return `${field.name}:${field.type}`;
    });
    if (!LOKI_FIELD_SHAPES.has(names.join(",")) || frame.data.values.length !== names.length) {
      return invalid("Loki frame contains unexpected fields");
    }
    const columns: Record<string, unknown[]> = {};
    let rows: number | undefined;
    for (const [index, rawField] of frame.schema.fields.entries()) {
      const field = rawField as { name: string };
      const values = frame.data.values[index];
      if (!Array.isArray(values) || (rows !== undefined && values.length !== rows)) return invalid("Loki columns have unequal lengths");
      rows = values.length;
      columns[field.name] = values;
    }
    for (let row = 0; row < (rows ?? 0); row += 1) {
      context.budget.throwIfAborted();
      const labels = stringLabels(columns.labels![row]);
      // Scope is proved in the actual JSON labels before reserved projection
      // aliases (Time/Line/body/etc.) can overwrite a same-named label.
      if (labels[entry.scopeMappings.environment] !== entry.scope.environment ||
          (entry.scope.service !== undefined && labels[entry.scopeMappings.service!] !== entry.scope.service) ||
          (entry.scope.subject !== undefined && labels[entry.scopeMappings["subject.ref"]!] !== entry.scope.subject.providerValue)) {
        return invalid("Loki log row does not prove the enrolled scope");
      }
      if (columns.labelTypes !== undefined) stringLabels(columns.labelTypes[row]);
      const time = (columns.Time ?? columns.timestamp)![row];
      const line = text((columns.Line ?? columns.body)![row]);
      const id = text(columns.id![row], 512);
      const tsNs = columns.tsNs === undefined ? undefined : text(columns.tsNs[row], 30);
      if (tsNs !== undefined && !/^[0-9]+$/u.test(tsNs)) return invalid("Loki nanoseconds are invalid");
      const values: NativeValues = {
        ...labels,
        Time: typedPrimitive(time, "time"),
        timestamp: typedPrimitive(time, "time"),
        Line: line,
        body: line,
        Summary: line,
        id,
        ...(tsNs === undefined ? {} : { tsNs }),
      };
      output.push(projectedFrame(entry, values));
      if (output.length > context.budget.limits.maxRows) return envelope(output);
    }
  }
  return envelope(output);
}

function protoPrimitive(value: unknown): JsonPrimitive {
  if (!object(value)) return invalid("Tempo attribute value is invalid");
  const keys = Object.keys(value);
  if (keys.length !== 1) return invalid("Tempo attribute value is ambiguous");
  if (keys[0] === "stringValue") return text(value.stringValue);
  if (keys[0] === "intValue" || keys[0] === "doubleValue") return decimal(value[keys[0]]);
  if (keys[0] === "boolValue" && typeof value.boolValue === "boolean") return value.boolValue;
  return invalid("Tempo attribute type is unsupported");
}

function nativeAttributeName(name: string): string {
  return name.replace(/^(?:resource|span)\./u, "");
}

function tempoAttributes(value: unknown, wanted: ReadonlySet<string>): NativeValues {
  if (!Array.isArray(value) || value.length > 256) return invalid("Tempo attributes are invalid");
  const result: NativeValues = {};
  for (const attribute of value) {
    if (!object(attribute)) return invalid("Tempo attribute is invalid");
    const key = text(attribute.key, 256);
    if (!wanted.has(key)) continue;
    if (Object.hasOwn(result, key)) return invalid("Tempo attributes repeat an enrolled key");
    result[key] = protoPrimitive(attribute.value);
  }
  return result;
}

function assertTempoScope(attributes: Readonly<NativeValues>, entry: Readonly<GrafanaDatasourceQueryCatalogEntry>): void {
  if (attributes["deployment.environment"] !== entry.scope.environment ||
      (entry.scope.service !== undefined && attributes["service.name"] !== entry.scope.service) ||
      (entry.scope.subject !== undefined &&
        attributes[nativeAttributeName(entry.scopeMappings["subject.ref"]!)] !== entry.scope.subject.providerValue)) {
    return invalid("Tempo matching span does not prove the enrolled scope");
  }
}

function hexId(value: unknown, length: number): string {
  const candidate = text(value, length);
  if (candidate.length !== length || !/^[a-f0-9]+$/iu.test(candidate)) return invalid("Tempo identity is invalid");
  return candidate;
}

/**
 * Tempo's search response is not a Grafana dataframe. Scope is proved from
 * each matching span's actual resource attributes, never rootServiceName or
 * the catalog's expected values. Only explicitly enrolled primitive columns
 * are projected into the existing strict dataframe normalizer.
 */
function normalizeTempoSearch(
  body: unknown,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
): unknown {
  if (entry.target.datasourceType !== "tempo") return invalid("Tempo target is invalid");
  const traceLimit = Math.max(1, Math.min(entry.target.limit, context.budget.limits.maxRows));
  const spansLimit = Math.max(1, Math.min(entry.target.spansPerSpanSet, context.budget.limits.maxRows));
  if (!object(body) || !Array.isArray(body.traces) || body.traces.length > traceLimit) return invalid("Tempo search envelope is invalid");
  const wanted = new Set([
    "deployment.environment", "service.name",
    ...entry.frame.fields.map((field) => nativeAttributeName(field.sourceName)),
    ...entry.frame.allowedLabels.map(nativeAttributeName),
    ...(entry.scope.subject === undefined ? [] : [nativeAttributeName(entry.scopeMappings["subject.ref"]!)]),
  ]);
  const output: ObjectValue[] = [];
  for (const trace of body.traces) {
    context.budget.throwIfAborted();
    if (!object(trace)) return invalid("Tempo trace is invalid");
    const traceID = hexId(trace.traceID, 32);
    const sets = Array.isArray(trace.spanSets) ? trace.spanSets : object(trace.spanSet) ? [trace.spanSet] : undefined;
    if (sets === undefined || sets.length === 0 || sets.length > 64) return invalid("Tempo trace omits matching spans");
    const matches: Array<{ span: ObjectValue; attributes: NativeValues; spanID: string }> = [];
    const seen = new Map<string, string>();
    for (const set of sets) {
      if (!object(set) || !Array.isArray(set.spans) || set.spans.length > spansLimit) return invalid("Tempo span set exceeds its reviewed bound");
      for (const span of set.spans) {
        context.budget.throwIfAborted();
        if (!object(span)) return invalid("Tempo matching span is invalid");
        const spanID = hexId(span.spanID, 16);
        const attributes = tempoAttributes(span.attributes, wanted);
        assertTempoScope(attributes, entry);
        const identity = canonicalJson({ attributes, start: span.startTimeUnixNano, duration: span.durationNanos });
        if (seen.has(spanID)) {
          if (seen.get(spanID) !== identity) return invalid("Tempo repeats a conflicting matching span");
          continue;
        }
        seen.set(spanID, identity);
        matches.push({ span, attributes, spanID });
      }
    }
    if (matches.length === 0) return invalid("Tempo trace has no scope-proven matching span");
    const selected = entry.target.tableType === "traces" ? matches.slice(0, 1) : matches;
    for (const { span, attributes, spanID } of selected) {
      context.budget.throwIfAborted();
      const traceTable = entry.target.tableType === "traces";
      const time = nanosToMilliseconds(traceTable ? trace.startTimeUnixNano : span.startTimeUnixNano);
      const duration = traceTable ? decimal(trace.durationMs) : decimal(span.durationNanos) / 1_000_000;
      const summary = text(trace.rootTraceName, 256);
      const values: NativeValues = {
        ...attributes,
        [entry.scopeMappings.environment]: attributes["deployment.environment"]!,
        ...(entry.scope.service === undefined ? {} : { [entry.scopeMappings.service!]: attributes["service.name"]! }),
        ...(entry.scope.subject === undefined ? {} : {
          [entry.scopeMappings["subject.ref"]!]: attributes[nativeAttributeName(entry.scopeMappings["subject.ref"]!)]!,
        }),
        Time: time,
        startTime: time,
        Duration: duration,
        durationMs: duration,
        Summary: summary,
        rootTraceName: summary,
        traceID,
        spanID,
      };
      output.push(projectedFrame(entry, values, (field) =>
        values[field.sourceName] ?? attributes[nativeAttributeName(field.sourceName)]));
      if (output.length > context.budget.limits.maxRows) return envelope(output);
    }
  }
  return envelope(output);
}

export function normalizeGrafanaNativeResponse(
  body: unknown,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
): unknown {
  if (entry.target.datasourceType === "tempo") return normalizeTempoSearch(body, entry, context);
  if (entry.target.datasourceType === "loki" && (entry.frame.resultKind === "EVENT" || entry.frame.resultKind === "TABLE")) {
    return normalizeLokiLogs(body, entry, context);
  }
  return body;
}
