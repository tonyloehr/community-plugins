import { canonicalJson, sha256Canonical, type JsonObject, type Sha256 } from "../../../packages/contracts/src/index.ts";
import { AdapterContractError } from "../../../packages/adapter-sdk/src/index.ts";

import { validateGrafanaDatasourceQueryEntry } from "./query-validator.ts";
import type { GrafanaCatalogEntry, GrafanaTrustedCatalog } from "./types.ts";

const SAFE_ID = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/u;
const SAFE_UID = /^[a-zA-Z0-9_-]{1,128}$/u;

function assertExactKeys(entry: GrafanaCatalogEntry): void {
  const common = ["id", "route", "outputName"];
  const specific = entry.route === "search"
    ? ["query", "searchType", "tags"]
    : entry.route === "datasource" || entry.route === "datasource-health"
      ? ["datasourceUid"]
      : entry.route === "datasource-query"
        ? [
            "datasourceUid",
            "datasourceIdentitySha256",
            "target",
            "frame",
            "minIntervalMs",
            "scope",
            "scopeMappings",
            "postgresReadOnlyIdentity",
            "sourcePanel",
          ]
      : entry.route === "annotations"
        ? ["annotationType", "tags"]
        : [];
  const allowed = new Set([...common, ...specific]);
  if (Object.keys(entry).some((key) => !allowed.has(key))) {
    throw new AdapterContractError("Grafana catalog entry contains an unsupported field");
  }
}

function validateText(value: string, name: string, maxLength: number): void {
  if (value.length > maxLength || [...value].some((character) => (character.codePointAt(0) ?? 0) < 32)) {
    throw new AdapterContractError(`Grafana catalog ${name} is invalid`);
  }
}

function validateTags(tags: readonly string[] | undefined): void {
  if (tags === undefined) return;
  if (tags.length > 16 || new Set(tags).size !== tags.length) {
    throw new AdapterContractError("Grafana catalog tags must be unique and bounded");
  }
  for (const tag of tags) validateText(tag, "tag", 128);
}

function validateEntry(entry: GrafanaCatalogEntry): void {
  if (!new Set(["health", "search", "datasource", "datasource-health", "datasource-query", "annotations", "unified-alerts"]).has(entry.route)) {
    throw new AdapterContractError("Grafana catalog route is not read-only and allowlisted");
  }
  assertExactKeys(entry);
  if (!SAFE_ID.test(entry.id) || !SAFE_ID.test(entry.outputName)) {
    throw new AdapterContractError("Grafana catalog IDs must use the bounded safe identifier format");
  }
  if (entry.route === "search") {
    if (entry.query !== undefined) validateText(entry.query, "search query", 512);
    validateTags(entry.tags);
  }
  if (entry.route === "annotations") validateTags(entry.tags);
  if ((entry.route === "datasource" || entry.route === "datasource-health") && !SAFE_UID.test(entry.datasourceUid)) {
    throw new AdapterContractError("Grafana datasource UID is invalid");
  }
  if (entry.route === "datasource-query") validateGrafanaDatasourceQueryEntry(entry);
  canonicalJson(entry);
}

function deepFreeze<T>(value: T): T {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const nested of Object.values(value)) deepFreeze(nested);
    Object.freeze(value);
  }
  return value;
}

export function grafanaCatalogEntryHash(entry: GrafanaCatalogEntry): Sha256 {
  return sha256Canonical(entry as unknown as JsonObject);
}

export class CompiledGrafanaCatalog {
  readonly #entries: ReadonlyMap<string, GrafanaCatalogEntry>;

  constructor(catalog: Readonly<GrafanaTrustedCatalog>) {
    const entries = new Map<string, GrafanaCatalogEntry>();
    for (const supplied of catalog.entries) {
      const entry = structuredClone(supplied);
      validateEntry(entry);
      if (entries.has(entry.id)) throw new AdapterContractError(`Duplicate Grafana catalog entry: ${entry.id}`);
      entries.set(entry.id, deepFreeze(entry));
    }
    this.#entries = entries;
  }

  resolve(id: string, expectedSha256: Sha256): GrafanaCatalogEntry {
    const entry = this.#entries.get(id);
    if (entry === undefined) throw new AdapterContractError("Grafana catalog entry is not trusted");
    if (grafanaCatalogEntryHash(entry) !== expectedSha256) {
      throw new AdapterContractError("Grafana catalog entry hash mismatch");
    }
    return entry;
  }
}
