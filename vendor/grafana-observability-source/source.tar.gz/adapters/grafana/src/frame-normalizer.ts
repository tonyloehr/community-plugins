import type { JsonPrimitive, Pagination } from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  type AdapterExecutionContext,
  type ProviderValue,
} from "../../../packages/adapter-sdk/src/index.ts";

import type {
  GrafanaDatasourceQueryCatalogEntry,
  GrafanaFrameFieldContract,
  GrafanaFrameFieldType,
} from "./types.ts";

interface ParsedField {
  contract: GrafanaFrameFieldContract;
  labels: Record<string, string>;
  values: JsonPrimitive[];
}

interface ParsedFrame {
  fields: ParsedField[];
  length: number;
  labels: Record<string, string>;
}

interface NormalizeState {
  records: ProviderValue[];
  evaluatedAt: string;
  rows: number;
  series: number;
  points: number;
  truncatedReason?: Pagination["truncatedReason"];
}

const TIMESTAMP_SKEW_MS = 5 * 60_000;

export interface NormalizedGrafanaFrames {
  records: ProviderValue[];
  evaluatedAt: string;
  pagination: Pagination;
  warnings: string[];
}

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function safeString(value: unknown, subject: string, maximum = 4_096): string {
  if (typeof value !== "string" || value.length > maximum || [...value].some((character) => {
    const code = character.codePointAt(0) ?? 0;
    return code === 0 || code === 127 || (code < 32 && code !== 9 && code !== 10 && code !== 13);
  })) {
    throw new AdapterContractError(`Grafana frame ${subject} is invalid`);
  }
  return value;
}

function parseTime(value: JsonPrimitive, subject: string, context: AdapterExecutionContext): string {
  const parsed = typeof value === "number" ? new Date(value) : typeof value === "string" ? new Date(value) : undefined;
  if (parsed === undefined || Number.isNaN(parsed.getTime())) {
    throw new AdapterContractError(`Grafana frame ${subject} timestamp is invalid`);
  }
  const epoch = parsed.getTime();
  const start = Date.parse(context.window.start) - TIMESTAMP_SKEW_MS;
  const end = Date.parse(context.window.end) + TIMESTAMP_SKEW_MS;
  if (epoch < start || epoch > end) {
    throw new AdapterContractError(`Grafana frame ${subject} timestamp falls outside the requested window`);
  }
  return parsed.toISOString();
}

function parseValue(
  value: unknown,
  type: GrafanaFrameFieldType,
  subject: string,
  context: AdapterExecutionContext,
): JsonPrimitive {
  if (value === null) return null;
  if (type === "time") {
    if ((typeof value !== "number" || !Number.isFinite(value)) && typeof value !== "string") {
      throw new AdapterContractError(`Grafana frame ${subject} value has drifted from time`);
    }
    return parseTime(value, subject, context);
  }
  if (type === "number") {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      throw new AdapterContractError(`Grafana frame ${subject} value has drifted from number`);
    }
    return value;
  }
  if (type === "string") return safeString(value, `${subject} string`);
  if (typeof value !== "boolean") throw new AdapterContractError(`Grafana frame ${subject} value has drifted from boolean`);
  return value;
}

function parseLabels(value: unknown, allowed: ReadonlySet<string>): Record<string, string> {
  if (value === undefined) return {};
  if (!isObject(value)) throw new AdapterContractError("Grafana frame labels are invalid");
  const labels: Record<string, string> = {};
  for (const [name, raw] of Object.entries(value)) {
    if (!allowed.has(name)) continue;
    labels[name] = safeString(raw, "label value", 128);
  }
  return labels;
}

function mergeLabels(target: Record<string, string>, source: Readonly<Record<string, string>>): void {
  for (const [name, value] of Object.entries(source)) {
    if (target[name] !== undefined && target[name] !== value) {
      throw new AdapterContractError("Grafana frame labels conflict across fields");
    }
    target[name] = value;
  }
}

function containsSubjectProviderValue(value: unknown, providerValue: string): boolean {
  if (typeof value === "string") return value.includes(providerValue);
  if (typeof value === "number" || typeof value === "boolean") return String(value) === providerValue;
  if (Array.isArray(value)) return value.some((item) => containsSubjectProviderValue(item, providerValue));
  if (isObject(value)) {
    return Object.values(value).some((item) => containsSubjectProviderValue(item, providerValue));
  }
  return false;
}

function assertSubjectProviderValueNotExposed(
  value: unknown,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
): void {
  if (entry.scope.subject !== undefined && containsSubjectProviderValue(value, entry.scope.subject.providerValue)) {
    throw new AdapterContractError("Grafana datasource query response exposed its provider-native subject value");
  }
}

function assertSubjectProviderValueConfined(
  fields: readonly ParsedField[],
  labels: Readonly<Record<string, string>>,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
): void {
  const subject = entry.scope.subject;
  const subjectSource = entry.scopeMappings["subject.ref"];
  if (subject === undefined || subjectSource === undefined) return;
  for (const [name, value] of Object.entries(labels)) {
    if (name !== subjectSource) assertSubjectProviderValueNotExposed(value, entry);
  }
  for (const field of fields) {
    if (field.contract.role !== "TIME" && field.contract.sourceName !== subjectSource) {
      assertSubjectProviderValueNotExposed(field.values, entry);
    }
  }
}

function parseFrame(
  rawFrame: unknown,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
): ParsedFrame {
  if (!isObject(rawFrame) || !isObject(rawFrame.schema) || !isObject(rawFrame.data)) {
    throw new AdapterContractError("Grafana datasource query frame is invalid");
  }
  if (rawFrame.schema.refId !== "A" || !Array.isArray(rawFrame.schema.fields) || !Array.isArray(rawFrame.data.values)) {
    throw new AdapterContractError("Grafana datasource query frame schema is invalid");
  }
  if (rawFrame.schema.fields.length !== entry.frame.fields.length || rawFrame.data.values.length !== entry.frame.fields.length) {
    throw new AdapterContractError("Grafana datasource query frame shape drifted from the enrolled contract");
  }
  const allowedLabels = new Set(entry.frame.allowedLabels);
  const fields: ParsedField[] = [];
  const frameLabels: Record<string, string> = {};
  let length: number | undefined;
  for (let index = 0; index < entry.frame.fields.length; index += 1) {
    const schemaField = rawFrame.schema.fields[index];
    const values = rawFrame.data.values[index];
    const contract = entry.frame.fields[index]!;
    if (!isObject(schemaField) || schemaField.name !== contract.sourceName || schemaField.type !== contract.type || !Array.isArray(values)) {
      throw new AdapterContractError("Grafana datasource query frame field drifted from the enrolled contract");
    }
    if (length === undefined) length = values.length;
    else if (values.length !== length) throw new AdapterContractError("Grafana datasource query frame fields have unequal lengths");
    const labels = parseLabels(schemaField.labels, allowedLabels);
    mergeLabels(frameLabels, labels);
    fields.push({
      contract,
      labels,
      values: values.map((value) => parseValue(value, contract.type, contract.sourceName, context)),
    });
  }
  assertSubjectProviderValueConfined(fields, frameLabels, entry);
  return { fields, length: length ?? 0, labels: frameLabels };
}

function canAdd(
  state: NormalizeState,
  context: AdapterExecutionContext,
  kind: "rows" | "series" | "points",
): boolean {
  const current = state[kind];
  const maximum = kind === "rows"
    ? context.budget.limits.maxRows
    : kind === "series"
      ? context.budget.limits.maxSeries
      : context.budget.limits.maxPoints;
  if (current < maximum) return true;
  state.truncatedReason ??= kind === "rows" ? "ROW_LIMIT" : kind === "series" ? "SERIES_LIMIT" : "POINT_LIMIT";
  return false;
}

function addBudget(state: NormalizeState, context: AdapterExecutionContext, kind: "rows" | "series" | "points"): boolean {
  if (!canAdd(state, context, kind)) return false;
  if (kind === "rows") context.budget.consumeRows(1);
  else if (kind === "series") context.budget.consumeSeries(1);
  else context.budget.consumePoints(1);
  state[kind] += 1;
  return true;
}

function updateEvaluatedAt(state: NormalizeState, timestamp: string): void {
  if (Date.parse(timestamp) > Date.parse(state.evaluatedAt)) state.evaluatedAt = timestamp;
}

function valueAt(frame: ParsedFrame, sourceName: string, row: number): JsonPrimitive | undefined {
  return frame.fields.find((field) => field.contract.sourceName === sourceName)?.values[row];
}

function scopeValue(frame: ParsedFrame, sourceName: string, row: number): string | undefined {
  if (frame.labels[sourceName] !== undefined) return frame.labels[sourceName];
  const value = valueAt(frame, sourceName, row);
  if (value === undefined || value === null) return undefined;
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
  return undefined;
}

function verifyScope(frame: ParsedFrame, entry: Readonly<GrafanaDatasourceQueryCatalogEntry>, row: number): void {
  if (scopeValue(frame, entry.scopeMappings.environment, row) !== entry.scope.environment) {
    throw new AdapterContractError("Grafana datasource query response environment does not match the enrolled scope");
  }
  if (entry.scope.service !== undefined &&
      scopeValue(frame, entry.scopeMappings.service!, row) !== entry.scope.service) {
    throw new AdapterContractError("Grafana datasource query response service does not match the enrolled scope");
  }
  if (entry.scope.subject !== undefined &&
      scopeValue(frame, entry.scopeMappings["subject.ref"]!, row) !== entry.scope.subject.providerValue) {
    throw new AdapterContractError("Grafana datasource query response subject does not match the enrolled scope");
  }
}

function outputScopeValue(
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  sourceName: string,
  providerValue: string,
): string {
  return entry.scope.subject !== undefined && sourceName === entry.scopeMappings["subject.ref"]
    ? entry.scope.subject.ref
    : providerValue;
}

function outputLabels(
  labels: Readonly<Record<string, string>>,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
): Record<string, string> {
  return Object.fromEntries(
    Object.entries(labels).map(([name, value]) => [name, outputScopeValue(entry, name, value)]),
  );
}

function dimensions(
  frame: ParsedFrame,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  row: number,
): Record<string, string> {
  const output: Record<string, string> = outputLabels(frame.labels, entry);
  for (const field of frame.fields.filter((candidate) => candidate.contract.role === "DIMENSION")) {
    const value = field.values[row];
    if (value !== null) {
      const safeValue = safeString(String(value), "dimension value", 128);
      output[field.contract.outputName] = outputScopeValue(entry, field.contract.sourceName, safeValue);
    }
  }
  return output;
}

function normalizeScalar(
  frame: ParsedFrame,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
  state: NormalizeState,
): void {
  if (frame.length === 0) return;
  if (frame.length !== 1) throw new AdapterContractError("Grafana SCALAR frame must contain exactly one row");
  if (!addBudget(state, context, "series") || !addBudget(state, context, "points")) return;
  verifyScope(frame, entry, 0);
  const valueField = frame.fields.find((field) => field.contract.role === "VALUE")!;
  const timeField = frame.fields.find((field) => field.contract.role === "TIME");
  const observedAt = timeField === undefined
    ? undefined
    : parseTime(timeField.values[0]!, timeField.contract.sourceName, context);
  if (observedAt !== undefined) updateEvaluatedAt(state, observedAt);
  state.records.push({
    kind: "SCALAR",
    name: valueField.contract.outputName,
    value: valueField.values[0]!,
    dimensions: dimensions(frame, entry, 0),
    ...(observedAt === undefined ? {} : { observedAt }),
    ...(entry.frame.unit === undefined ? {} : { unit: entry.frame.unit }),
  });
}

function normalizeTimeseries(
  frame: ParsedFrame,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
  state: NormalizeState,
): void {
  if (frame.length === 0) return;
  const timeField = frame.fields.find((field) => field.contract.role === "TIME")!;
  const expectedDimensions = dimensions(frame, entry, 0);
  for (let row = 0; row < frame.length; row += 1) {
    verifyScope(frame, entry, row);
    if (JSON.stringify(dimensions(frame, entry, row)) !== JSON.stringify(expectedDimensions)) {
      throw new AdapterContractError("Grafana TIMESERIES dimensions vary between points");
    }
  }
  for (const valueField of frame.fields.filter((field) => field.contract.role === "VALUE")) {
    if (!addBudget(state, context, "series")) break;
    const points: Array<{ at: string; value: number | null }> = [];
    let previous = -1;
    for (let row = 0; row < frame.length; row += 1) {
      if (!addBudget(state, context, "points")) break;
      const at = parseTime(timeField.values[row]!, timeField.contract.sourceName, context);
      const epoch = Date.parse(at);
      if (epoch <= previous) throw new AdapterContractError("Grafana TIMESERIES timestamps are not increasing");
      previous = epoch;
      updateEvaluatedAt(state, at);
      points.push({ at, value: valueField.values[row] as number | null });
    }
    if (points.length > 0) {
      state.records.push({
        kind: "TIMESERIES",
        name: valueField.contract.outputName,
        dimensions: { ...expectedDimensions, ...outputLabels(valueField.labels, entry) },
        points,
        ...(entry.frame.unit === undefined ? {} : { unit: entry.frame.unit }),
      });
    }
    if (state.truncatedReason === "POINT_LIMIT") break;
  }
}

function columnType(type: GrafanaFrameFieldType): "STRING" | "NUMBER" | "BOOLEAN" | "DATETIME" {
  if (type === "number") return "NUMBER";
  if (type === "boolean") return "BOOLEAN";
  if (type === "time") return "DATETIME";
  return "STRING";
}

function normalizeTable(
  frame: ParsedFrame,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
  state: NormalizeState,
): void {
  const rows: JsonPrimitive[][] = [];
  for (let row = 0; row < frame.length; row += 1) {
    if (!addBudget(state, context, "rows")) break;
    verifyScope(frame, entry, row);
    rows.push(frame.fields.map((field) => {
      const value = field.values[row]!;
      return entry.scope.subject !== undefined &&
        field.contract.sourceName === entry.scopeMappings["subject.ref"] &&
        value !== null
        ? entry.scope.subject.ref
        : value;
    }));
    for (const field of frame.fields.filter((candidate) => candidate.contract.role === "COLUMN" && candidate.contract.type === "time")) {
      if (field.values[row] !== null) {
        updateEvaluatedAt(state, parseTime(field.values[row]!, field.contract.sourceName, context));
      }
    }
  }
  if (rows.length > 0) {
    state.records.push({
      kind: "TABLE",
      name: entry.outputName,
      columns: frame.fields.map((field) => ({
        name: field.contract.outputName,
        type: columnType(field.contract.type),
      })),
      rows,
    });
  }
}

function normalizeEvents(
  frame: ParsedFrame,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
  state: NormalizeState,
): void {
  const timeField = frame.fields.find((field) => field.contract.role === "TIME")!;
  const summaryField = frame.fields.find((field) => field.contract.role === "SUMMARY");
  for (let row = 0; row < frame.length; row += 1) {
    if (!addBudget(state, context, "rows")) break;
    verifyScope(frame, entry, row);
    const occurredAt = parseTime(timeField.values[row]!, timeField.contract.sourceName, context);
    updateEvaluatedAt(state, occurredAt);
    const attributes: Record<string, JsonPrimitive> = {};
    for (const field of frame.fields) {
      if (field.contract.role === "ATTRIBUTE" || field.contract.role === "DIMENSION") {
        const value = field.values[row]!;
        attributes[field.contract.outputName] = entry.scope.subject !== undefined &&
          field.contract.sourceName === entry.scopeMappings["subject.ref"] &&
          value !== null
          ? entry.scope.subject.ref
          : value;
      }
    }
    for (const [name, value] of Object.entries(outputLabels(frame.labels, entry))) attributes[name] = value;
    const summary = summaryField === undefined
      ? entry.frame.eventSummary!
      : safeString(summaryField.values[row], "event summary", 256);
    assertSubjectProviderValueNotExposed(summary, entry);
    state.records.push({
      kind: "EVENT",
      name: entry.outputName,
      occurredAt,
      summary,
      attributes,
    });
  }
}

function queryResult(body: unknown): unknown[] {
  if (!isObject(body) || !isObject(body.results) || Object.keys(body.results).length !== 1 || !isObject(body.results.A)) {
    throw new AdapterContractError("Grafana datasource query response envelope is invalid");
  }
  const result = body.results.A;
  if ((typeof result.status === "number" && result.status >= 400) ||
      (typeof result.error === "string" && result.error.length > 0)) {
    const providerStatus = typeof result.status === "number" ? result.status : undefined;
    const category = providerStatus === 401
      ? "AUTHENTICATION"
      : providerStatus === 403
        ? "AUTHORIZATION"
        : providerStatus === 429
          ? "RATE_LIMIT"
          : providerStatus !== undefined && providerStatus >= 500
            ? "UNAVAILABLE"
            : "INVALID_RESPONSE";
    throw new AdapterExecutionError({
      code: "GRAFANA_DATASOURCE_QUERY_FAILED",
      category,
      message: "Grafana datasource query failed",
      retryable: category === "RATE_LIMIT" || category === "UNAVAILABLE",
      ...(providerStatus === undefined ? {} : { providerStatus }),
    });
  }
  if (!Array.isArray(result.frames)) throw new AdapterContractError("Grafana datasource query frames are invalid");
  return result.frames;
}

export function normalizeGrafanaFrames(
  body: unknown,
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
  context: AdapterExecutionContext,
): NormalizedGrafanaFrames {
  const state: NormalizeState = {
    records: [],
    evaluatedAt: new Date(context.window.end).toISOString(),
    rows: 0,
    series: 0,
    points: 0,
  };
  for (const rawFrame of queryResult(body)) {
    const frame = parseFrame(rawFrame, entry, context);
    if (entry.frame.resultKind === "SCALAR") normalizeScalar(frame, entry, context, state);
    else if (entry.frame.resultKind === "TIMESERIES") normalizeTimeseries(frame, entry, context, state);
    else if (entry.frame.resultKind === "TABLE") normalizeTable(frame, entry, context, state);
    else normalizeEvents(frame, entry, context, state);
    if (state.truncatedReason !== undefined) break;
  }
  return {
    records: state.records,
    evaluatedAt: state.evaluatedAt,
    pagination: state.truncatedReason === undefined
      ? { complete: true, pages: 1 }
      : { complete: false, pages: 1, truncatedReason: state.truncatedReason },
    warnings: state.truncatedReason === undefined ? [] : ["Grafana datasource query result was truncated by the bounded read policy"],
  };
}
