import { canonicalJson, type Sha256 } from "../../../packages/contracts/src/index.ts";
import { AdapterContractError } from "../../../packages/adapter-sdk/src/index.ts";

import { validateGrafanaDatasourceQueryEntry } from "./query-validator.ts";
import {
  GRAFANA_POSTGRES_DATASOURCE_TYPES,
  isGrafanaPostgresDatasourceType,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaDatasourceQueryScope,
  type GrafanaDatasourceQueryScopeMappings,
  type GrafanaDatasourceQueryTarget,
  type GrafanaDatasourceType,
  type GrafanaFrameContract,
  type GrafanaPostgresReadOnlyIdentityAttestation,
} from "./types.ts";

const MAX_DASHBOARD_BYTES = 1_048_576;
const MAX_PANELS = 256;
const MAX_PANEL_DEPTH = 8;

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function requiredObject(value: unknown, subject: string): Record<string, unknown> {
  if (!isObject(value)) throw new AdapterContractError(`Grafana saved-panel ${subject} is invalid`);
  return value;
}

function requiredString(value: unknown, subject: string, maximum = 16_384): string {
  if (typeof value !== "string" || value.length === 0 || value.length > maximum ||
      [...value].some((character) => (character.codePointAt(0) ?? 0) === 0)) {
    throw new AdapterContractError(`Grafana saved-panel ${subject} is invalid`);
  }
  return value;
}

function positiveInteger(value: unknown, subject: string): number {
  if (!Number.isSafeInteger(value) || (value as number) < 1 || (value as number) > 2_147_483_647) {
    throw new AdapterContractError(`Grafana saved-panel ${subject} is invalid`);
  }
  return value as number;
}

function datasource(value: unknown, subject: string): { type: GrafanaDatasourceType; uid: string } {
  const object = requiredObject(value, `${subject} datasource`);
  const type = requiredString(object.type, `${subject} datasource type`, 64);
  if (!new Set([
    "prometheus",
    "loki",
    "tempo",
    ...GRAFANA_POSTGRES_DATASOURCE_TYPES,
  ]).has(type)) {
    throw new AdapterContractError("Grafana saved panel uses a datasource type that is not certified");
  }
  return { type: type as GrafanaDatasourceType, uid: requiredString(object.uid, `${subject} datasource UID`, 128) };
}

function collectPanels(value: unknown, output: Record<number, Record<string, unknown>>, depth = 0): void {
  if (!Array.isArray(value) || depth > MAX_PANEL_DEPTH) {
    throw new AdapterContractError("Grafana saved-panel panel tree is invalid or too deep");
  }
  for (const candidate of value) {
    if (Object.keys(output).length >= MAX_PANELS) throw new AdapterContractError("Grafana saved-panel panel count exceeds the enrollment limit");
    const panel = requiredObject(candidate, "panel");
    const id = positiveInteger(panel.id, "panel ID");
    if (output[id] !== undefined) throw new AdapterContractError("Grafana saved-panel panel IDs are not unique");
    output[id] = panel;
    if (panel.panels !== undefined) collectPanels(panel.panels, output, depth + 1);
  }
}

function extractTarget(
  target: Record<string, unknown>,
  datasourceType: GrafanaDatasourceType,
  postgresMaxRows: number | undefined,
): GrafanaDatasourceQueryTarget {
  if (datasourceType === "prometheus") {
    if (target.instant === true && target.range === true) {
      throw new AdapterContractError("Grafana saved-panel Prometheus target has conflicting modes");
    }
    const format = target.format === undefined ? "time_series" : requiredString(target.format, "Prometheus format", 32);
    if (format !== "time_series" && format !== "table") {
      throw new AdapterContractError("Grafana saved-panel Prometheus format is invalid");
    }
    return {
      datasourceType,
      expression: requiredString(target.expr, "Prometheus expression"),
      mode: target.instant === true ? "instant" : "range",
      format,
      ...(target.legendFormat === undefined || target.legendFormat === ""
        ? {}
        : { legendFormat: requiredString(target.legendFormat, "Prometheus legend", 256) }),
    };
  }
  if (datasourceType === "loki") {
    const queryType = target.queryType === undefined ? "range" : requiredString(target.queryType, "Loki query type", 32);
    const direction = target.direction === undefined ? "backward" : requiredString(target.direction, "Loki direction", 32);
    if (queryType !== "range" || (direction !== "backward" && direction !== "forward")) {
      throw new AdapterContractError("Grafana saved-panel Loki mode is invalid");
    }
    return {
      datasourceType,
      expression: requiredString(target.expr, "Loki expression"),
      queryType,
      direction,
    };
  }
  if (datasourceType === "tempo") {
    const queryType = requiredString(target.queryType, "Tempo query type", 32);
    const tableType = requiredString(target.tableType, "Tempo table type", 32);
    if (queryType !== "traceql" || (tableType !== "traces" && tableType !== "spans")) {
      throw new AdapterContractError("Grafana saved-panel Tempo mode is invalid");
    }
    return {
      datasourceType,
      expression: requiredString(target.query, "Tempo TraceQL expression"),
      queryType,
      limit: positiveInteger(target.limit, "Tempo trace limit"),
      spansPerSpanSet: positiveInteger(target.spss, "Tempo spans-per-span-set"),
      tableType,
    };
  }
  if (!isGrafanaPostgresDatasourceType(datasourceType)) {
    throw new AdapterContractError("Grafana saved panel uses a datasource type that is not certified");
  }
  if (postgresMaxRows === undefined) {
    throw new AdapterContractError("Grafana saved-panel PostgreSQL enrollment requires an explicit row limit");
  }
  const format = target.format === undefined ? "table" : requiredString(target.format, "PostgreSQL format", 32);
  if (format !== "table" && format !== "time_series") {
    throw new AdapterContractError("Grafana saved-panel PostgreSQL format is invalid");
  }
  return {
    datasourceType,
    rawSql: requiredString(target.rawSql, "PostgreSQL SQL", 65_536),
    format,
    maxRows: postgresMaxRows,
  };
}

export interface GrafanaSavedPanelEnrollmentInput {
  dashboard: unknown;
  panelId: number;
  id: string;
  outputName: string;
  /** Reviewed canonical identity shared with a direct adapter for corroboration de-duplication. */
  datasourceIdentitySha256: Sha256;
  frame: GrafanaFrameContract;
  minIntervalMs: number;
  scope: GrafanaDatasourceQueryScope;
  scopeMappings: GrafanaDatasourceQueryScopeMappings;
  postgresMaxRows?: number;
  /** Required when the saved target is PostgreSQL; omitted for every other datasource type. */
  postgresReadOnlyIdentity?: GrafanaPostgresReadOnlyIdentityAttestation;
}

/**
 * Compile one exported, saved panel into a reviewable catalog proposal. This is a local enrollment
 * helper only: it does not contact Grafana and it does not activate the resulting entry.
 */
export function compileGrafanaSavedPanel(input: Readonly<GrafanaSavedPanelEnrollmentInput>): GrafanaDatasourceQueryCatalogEntry {
  let encoded: string;
  try {
    encoded = canonicalJson(input.dashboard);
  } catch {
    throw new AdapterContractError("Grafana saved-panel dashboard JSON is not canonicalizable");
  }
  if (Buffer.byteLength(encoded, "utf8") > MAX_DASHBOARD_BYTES) {
    throw new AdapterContractError("Grafana saved-panel dashboard exceeds the enrollment byte limit");
  }
  const exported = requiredObject(input.dashboard, "dashboard export");
  const dashboard = isObject(exported.dashboard) ? exported.dashboard : exported;
  const uid = requiredString(dashboard.uid, "dashboard UID", 128);
  const version = positiveInteger(dashboard.version, "dashboard version");
  if (dashboard.templating !== undefined) {
    const templating = requiredObject(dashboard.templating, "dashboard templating");
    if (!Array.isArray(templating.list) || templating.list.length !== 0) {
      throw new AdapterContractError("Grafana saved-panel enrollment rejects dashboard variables");
    }
  }
  const panels: Record<number, Record<string, unknown>> = {};
  collectPanels(dashboard.panels, panels);
  const panel = panels[input.panelId];
  if (panel === undefined) throw new AdapterContractError("Grafana saved-panel panel ID was not found");
  if (panel.libraryPanel !== undefined) throw new AdapterContractError("Grafana saved-panel enrollment rejects library panels");
  if (panel.transformations !== undefined && (!Array.isArray(panel.transformations) || panel.transformations.length !== 0)) {
    throw new AdapterContractError("Grafana saved-panel enrollment rejects transformations");
  }
  if (!Array.isArray(panel.targets) || panel.targets.length !== 1) {
    throw new AdapterContractError("Grafana saved panel must contain exactly one target");
  }
  const rawTarget = requiredObject(panel.targets[0], "target");
  if (rawTarget.refId !== "A" || rawTarget.hide === true) {
    throw new AdapterContractError("Grafana saved panel must expose exactly target A");
  }
  const targetDatasource = datasource(rawTarget.datasource, "target");
  if (panel.datasource !== undefined) {
    const panelDatasource = datasource(panel.datasource, "panel");
    if (panelDatasource.type !== targetDatasource.type || panelDatasource.uid !== targetDatasource.uid) {
      throw new AdapterContractError("Grafana saved-panel datasource bindings conflict");
    }
  }
  const entry: GrafanaDatasourceQueryCatalogEntry = {
    id: input.id,
    route: "datasource-query",
    outputName: input.outputName,
    datasourceUid: targetDatasource.uid,
    datasourceIdentitySha256: input.datasourceIdentitySha256,
    target: extractTarget(rawTarget, targetDatasource.type, input.postgresMaxRows),
    frame: structuredClone(input.frame),
    minIntervalMs: input.minIntervalMs,
    scope: structuredClone(input.scope),
    scopeMappings: structuredClone(input.scopeMappings),
    ...(input.postgresReadOnlyIdentity === undefined
      ? {}
      : { postgresReadOnlyIdentity: structuredClone(input.postgresReadOnlyIdentity) }),
    sourcePanel: {
      dashboardUid: uid,
      dashboardVersion: version,
      panelId: input.panelId,
      targetRefId: "A",
    },
  };
  validateGrafanaDatasourceQueryEntry(entry);
  return entry;
}
