import {
  canonicalJson,
  computeOperationDefinitionHash,
  type AdapterPackage,
  type AdapterPackageId,
  type EvidenceSourceLineage,
  type JsonObject,
  type JsonPrimitive,
  type OperationSnapshot,
  type Sha256,
  type SubjectKind,
  type SubjectRef,
} from "../../../packages/contracts/src/index.ts";
import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  type AdapterCompileContext,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderResult,
  type ProviderValue,
} from "../../../packages/adapter-sdk/src/index.ts";

import { CompiledGrafanaCatalog, grafanaCatalogEntryHash } from "./catalog.ts";
import { normalizeGrafanaFrames } from "./frame-normalizer.ts";
import { normalizeGrafanaNativeResponse } from "./native-response.ts";
import {
  canonicalGrafanaDatasourceType,
  GrafanaTransportError,
  isGrafanaPostgresTarget,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaCatalogEntry,
  type GrafanaDatasourceQueryTarget,
  type GrafanaFrameContract,
  type GrafanaHttpGetRequest,
  type GrafanaHttpRequest,
  type GrafanaHttpResponse,
  type GrafanaRoute,
  type GrafanaSavedPanelSource,
  type GrafanaTransport,
  type GrafanaTrustedCatalog,
} from "./types.ts";

export const GRAFANA_ADAPTER_PACKAGE_ID = "adapter.grafana.v1" as AdapterPackageId;

export const grafanaAdapterPackage: AdapterPackage = {
  schemaVersion: "1.0.0",
  packageId: GRAFANA_ADAPTER_PACKAGE_ID,
  name: "Grafana read-only evidence adapter",
  version: "1.1.0",
  protocolVersion: "1.0",
  publisher: { name: "Codex Production Monitoring" },
  entrypoint: { kind: "BUILTIN", registryKey: "grafana-v1" },
  domains: ["METRICS", "LOGS", "TRACES", "ALERTS", "RUNTIME", "CHANGES", "RUNBOOKS"],
  capabilities: [
    "grafana.health.read",
    "grafana.search.read",
    "grafana.datasource.read",
    "grafana.datasource.health.read",
    "grafana.datasource.query.read",
    "grafana.annotations.read",
    "grafana.unified-alerts.read",
  ],
  providerCompatibility: [{ provider: "grafana", versions: ">=10 <14" }],
  supportedContractVersions: ["1.0.0"],
  conformance: ["CORE_READ", "METRICS", "LOGS", "TRACES", "ALERTS", "RUNTIME", "CHANGES", "RUNBOOKS"],
};

type GrafanaBinding = JsonObject & {
  catalogEntryId: string;
  catalogEntrySha256: Sha256;
  route: GrafanaRoute;
  outputName: string;
  query?: string;
  searchType?: "dash-db" | "dash-folder";
  tags?: string[];
  datasourceUid?: string;
  datasourceIdentitySha256?: Sha256;
  target?: GrafanaDatasourceQueryTarget;
  frame?: GrafanaFrameContract;
  minIntervalMs?: number;
  scopeEnvironment?: string;
  scopeService?: string;
  scopeEnvironmentMapping?: string;
  scopeServiceMapping?: string;
  scopeSubjectKind?: SubjectKind;
  scopeSubjectRef?: SubjectRef;
  scopeSubjectProviderValue?: string;
  scopeSubjectMapping?: string;
  annotationType?: "alert" | "annotation";
};

type GrafanaLineageProviderResult = ProviderResult & {
  sourceLineage: EvidenceSourceLineage & { accessPath: "GRAFANA" };
};

const OPERATION_BY_ROUTE: Record<GrafanaRoute, string> = {
  health: "grafana.health.read",
  search: "grafana.search.read",
  datasource: "grafana.datasource.read",
  "datasource-health": "grafana.datasource.health.read",
  "datasource-query": "grafana.datasource.query.read",
  annotations: "grafana.annotations.read",
  "unified-alerts": "grafana.unified-alerts.read",
};

const RESULT_KIND_BY_ROUTE: Record<GrafanaRoute, OperationSnapshot["definition"]["normalization"]["resultKind"]> = {
  health: "TABLE",
  search: "TABLE",
  datasource: "TABLE",
  "datasource-health": "TABLE",
  "datasource-query": "TABLE",
  annotations: "EVENT",
  "unified-alerts": "TABLE",
};

function expectedResultKind(entry: Readonly<GrafanaCatalogEntry>): OperationSnapshot["definition"]["normalization"]["resultKind"] {
  return entry.route === "datasource-query" ? entry.frame.resultKind : RESULT_KIND_BY_ROUTE[entry.route];
}

function expectedDomain(entry: Readonly<GrafanaCatalogEntry>): OperationSnapshot["definition"]["domain"] | undefined {
  if (entry.route !== "datasource-query") return undefined;
  if (entry.target.datasourceType === "loki") return "LOGS";
  if (entry.target.datasourceType === "tempo") return "TRACES";
  return "METRICS";
}

function sourceLineageFor(
  entry: Readonly<GrafanaDatasourceQueryCatalogEntry>,
): EvidenceSourceLineage & { accessPath: "GRAFANA" } {
  return {
    accessPath: "GRAFANA",
    datasourceType: canonicalGrafanaDatasourceType(entry.target.datasourceType),
    sourceIdentitySha256: entry.datasourceIdentitySha256,
  };
}

function expectedDimensions(entry: Readonly<GrafanaCatalogEntry>): string[] {
  if (entry.route !== "datasource-query") return [];
  return [...new Set([
    ...entry.frame.allowedLabels,
    ...entry.frame.fields
      .filter((field) => field.role === "DIMENSION")
      .map((field) => field.outputName),
  ])].sort();
}

function sameStringSet(left: readonly string[], right: readonly string[]): boolean {
  return canonicalJson([...new Set(left)].sort()) === canonicalJson([...new Set(right)].sort());
}

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function safeString(value: unknown, field: string, maxLength = 4_096): string {
  const hasUnsafeControl = typeof value === "string" && [...value].some((character) => {
    const code = character.codePointAt(0) ?? 0;
    return (code < 32 && code !== 9 && code !== 10 && code !== 13) || code === 127;
  });
  if (typeof value !== "string" || value.length > maxLength || hasUnsafeControl) {
    throw new AdapterContractError(`Grafana ${field} is invalid`);
  }
  return value;
}

function safeOptionalString(value: unknown, field: string, maxLength = 4_096): string | null {
  return value === undefined || value === null ? null : safeString(value, field, maxLength);
}

function safeUid(value: unknown, field: string): string {
  const uid = safeString(value, field, 128);
  if (!/^[a-zA-Z0-9_-]{1,128}$/u.test(uid)) throw new AdapterContractError(`Grafana ${field} is invalid`);
  return uid;
}

function dashboardDeepLink(uid: string): string {
  return `grafana:/d/${uid}`;
}

function searchDeepLink(uid: string, type: string): string {
  return type === "dash-folder" ? `grafana:/dashboards/f/${uid}` : dashboardDeepLink(uid);
}

function alertDeepLink(uid: string): string {
  return `grafana:/alerting/grafana/${uid}/view`;
}

function panelDeepLink(panel: Readonly<GrafanaSavedPanelSource>): string {
  return `grafana:/d/${panel.dashboardUid}?viewPanel=${String(panel.panelId)}`;
}

async function readJson(response: GrafanaHttpResponse, context: AdapterExecutionContext): Promise<unknown> {
  const chunks: Uint8Array[] = [];
  for await (const chunk of response.body) {
    context.budget.throwIfAborted();
    context.budget.consumeBytes(chunk.byteLength);
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
  } catch {
    throw new AdapterContractError("Grafana response is not valid JSON");
  }
}

function statusError(status: number): AdapterExecutionError {
  if (status === 401 || status === 403) {
    return new AdapterExecutionError({
      code: "GRAFANA_AUTHORIZATION",
      category: status === 401 ? "AUTHENTICATION" : "AUTHORIZATION",
      message: "Grafana denied the read",
      retryable: false,
      providerStatus: status,
    });
  }
  if (status === 429) {
    return new AdapterExecutionError({
      code: "GRAFANA_RATE_LIMIT",
      category: "RATE_LIMIT",
      message: "Grafana rate limited the read",
      retryable: true,
      providerStatus: status,
    });
  }
  return new AdapterExecutionError({
    code: "GRAFANA_HTTP_ERROR",
    category: status >= 500 ? "UNAVAILABLE" : "INVALID_RESPONSE",
    message: "Grafana read failed",
    retryable: status >= 500,
    providerStatus: status,
  });
}

function assertDatasourceQueryVersion(body: unknown): string | undefined {
  if (!isObject(body) || body.database !== "ok" || typeof body.version !== "string") {
    throw new AdapterExecutionError({
      code: "GRAFANA_HEALTH_INVALID",
      category: "INVALID_RESPONSE",
      message: "Grafana health preflight returned an invalid response",
      retryable: false,
    });
  }
  const boundedVersion = /^(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})(?:[-+][0-9A-Za-z.-]{1,64})?$/u;
  if (!boundedVersion.test(body.version)) {
    throw new AdapterExecutionError({
      code: "GRAFANA_VERSION_INVALID",
      category: "INVALID_RESPONSE",
      message: "Grafana health preflight returned an invalid version",
      retryable: false,
    });
  }
  const certifiedVersion = /^(?:10|11|12|13)\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})(?:[-+][0-9A-Za-z.-]{1,64})?$/u;
  if (!certifiedVersion.test(body.version)) {
    throw new AdapterExecutionError({
      code: "GRAFANA_VERSION_UNSUPPORTED",
      category: "INVALID_RESPONSE",
      message: "Grafana version is not certified for datasource queries",
      retryable: false,
    });
  }
  return body.version.startsWith("13.")
    ? "Grafana 13 datasource queries use the certified legacy /api route, which is deprecated"
    : undefined;
}

async function requestJson(
  transport: GrafanaTransport,
  request: Readonly<GrafanaHttpRequest>,
  context: AdapterExecutionContext,
): Promise<unknown> {
  let response: GrafanaHttpResponse;
  try {
    response = await transport.request(request);
  } catch (error) {
    if (error instanceof BudgetExceededError || error instanceof AdapterExecutionError || error instanceof AdapterContractError) throw error;
    if (error instanceof GrafanaTransportError) {
      const transportError = error;
      throw new AdapterExecutionError({
        code: transportError.kind === "TIMEOUT" ? "GRAFANA_TRANSPORT_TIMEOUT" : "GRAFANA_UNAVAILABLE",
        category: transportError.kind,
        message: transportError.kind === "TIMEOUT" ? "Grafana request timed out" : "Grafana is unavailable",
        retryable: true,
      });
    }
    throw error;
  }
  if (response.status < 200 || response.status >= 300) throw statusError(response.status);
  return readJson(response, context);
}

interface ParseState {
  records: ProviderValue[];
  rows: number;
  truncated: boolean;
}

function takeRow(state: ParseState, context: AdapterExecutionContext): boolean {
  if (state.rows >= context.budget.limits.maxRows) {
    state.truncated = true;
    return false;
  }
  context.budget.consumeRows(1);
  state.rows += 1;
  return true;
}

function table(name: string, columns: Array<{ name: string; type: "STRING" | "NUMBER" | "BOOLEAN" | "DATETIME" | "NULL" }>, rows: JsonPrimitive[][]): ProviderValue {
  return { kind: "TABLE", name, columns, rows };
}

function parseHealth(body: unknown, binding: GrafanaBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!isObject(body)) throw new AdapterContractError("Grafana health response is invalid");
  const database = safeString(body.database, "health database", 64);
  if (!new Set(["ok", "fail"]).has(database.toLowerCase())) throw new AdapterContractError("Grafana health state drifted");
  if (!takeRow(state, context)) return;
  state.records.push(table(binding.outputName, [
    { name: "database", type: "STRING" },
    { name: "version", type: "STRING" },
    { name: "commit", type: "STRING" },
  ], [[database, safeString(body.version, "health version", 128), safeString(body.commit, "health commit", 128)]]));
}

function parseSearch(body: unknown, binding: GrafanaBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!Array.isArray(body)) throw new AdapterContractError("Grafana search response is invalid");
  if (context.budget.limits.maxRows > 0 && body.length >= context.budget.limits.maxRows) state.truncated = true;
  const rows: JsonPrimitive[][] = [];
  for (const item of body) {
    if (!takeRow(state, context)) break;
    if (!isObject(item)) throw new AdapterContractError("Grafana search item is invalid");
    const uid = safeUid(item.uid, "dashboard UID");
    const type = safeString(item.type, "search type", 64);
    if (!new Set(["dash-db", "dash-folder"]).has(type)) throw new AdapterContractError("Grafana search item type drifted");
    rows.push([
      uid,
      safeString(item.title, "dashboard title", 1_024),
      type,
      typeof item.isStarred === "boolean" ? item.isStarred : false,
      item.folderUid === undefined || item.folderUid === null || item.folderUid === ""
        ? null
        : safeUid(item.folderUid, "folder UID"),
      searchDeepLink(uid, type),
    ]);
  }
  if (rows.length > 0) state.records.push(table(binding.outputName, [
    { name: "uid", type: "STRING" },
    { name: "title", type: "STRING" },
    { name: "type", type: "STRING" },
    { name: "isStarred", type: "BOOLEAN" },
    { name: "folderUid", type: "STRING" },
    { name: "deepLink", type: "STRING" },
  ], rows));
}

function parseDatasource(body: unknown, binding: GrafanaBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!isObject(body)) throw new AdapterContractError("Grafana datasource response is invalid");
  const uid = safeUid(body.uid, "datasource UID");
  if (uid !== binding.datasourceUid) throw new AdapterContractError("Grafana datasource UID does not match the trusted route");
  if (!takeRow(state, context)) return;
  state.records.push(table(binding.outputName, [
    { name: "uid", type: "STRING" },
    { name: "name", type: "STRING" },
    { name: "type", type: "STRING" },
    { name: "access", type: "STRING" },
    { name: "isDefault", type: "BOOLEAN" },
    { name: "readOnly", type: "BOOLEAN" },
  ], [[
    uid,
    safeString(body.name, "datasource name", 512),
    safeString(body.type, "datasource type", 256),
    (() => {
      const access = safeString(body.access, "datasource access", 32);
      if (!new Set(["proxy", "direct"]).has(access)) throw new AdapterContractError("Grafana datasource access drifted");
      return access;
    })(),
    typeof body.isDefault === "boolean" ? body.isDefault : false,
    typeof body.readOnly === "boolean" ? body.readOnly : false,
  ]]));
}

function parseDatasourceHealth(body: unknown, binding: GrafanaBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!isObject(body)) throw new AdapterContractError("Grafana datasource health response is invalid");
  const status = safeString(body.status, "datasource health status", 32).toUpperCase();
  if (!new Set(["OK", "ERROR"]).has(status)) throw new AdapterContractError("Grafana datasource health status drifted");
  if (!takeRow(state, context)) return;
  state.records.push(table(binding.outputName, [
    { name: "uid", type: "STRING" },
    { name: "status", type: "STRING" },
    { name: "message", type: "STRING" },
  ], [[binding.datasourceUid ?? null, status, safeOptionalString(body.message, "datasource health message", 2_048)]]));
}

function parseAnnotations(body: unknown, binding: GrafanaBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!Array.isArray(body)) throw new AdapterContractError("Grafana annotations response is invalid");
  if (context.budget.limits.maxRows > 0 && body.length >= context.budget.limits.maxRows) state.truncated = true;
  for (const annotation of body) {
    if (!takeRow(state, context)) break;
    if (!isObject(annotation) || !Number.isFinite(annotation.time)) {
      throw new AdapterContractError("Grafana annotation is invalid");
    }
    const occurredAt = new Date(annotation.time as number);
    if (Number.isNaN(occurredAt.getTime())) throw new AdapterContractError("Grafana annotation timestamp is invalid");
    const attributes: Record<string, JsonPrimitive> = {
      text: safeOptionalString(annotation.text, "annotation text", 4_096),
      type: safeOptionalString(annotation.type, "annotation type", 64),
    };
    if (Array.isArray(annotation.tags)) {
      if (annotation.tags.some((tag) => typeof tag !== "string")) throw new AdapterContractError("Grafana annotation tags are invalid");
      attributes.tags = annotation.tags.slice(0, 16).map((tag) => safeString(tag, "annotation tag", 128)).join(",");
    }
    if (annotation.dashboardUID !== undefined) {
      const dashboardUid = safeUid(annotation.dashboardUID, "annotation dashboard UID");
      attributes.dashboardUid = dashboardUid;
      attributes.deepLink = dashboardDeepLink(dashboardUid);
    }
    state.records.push({
      kind: "EVENT",
      name: binding.outputName,
      occurredAt: occurredAt.toISOString(),
      summary: "Grafana annotation",
      attributes,
    });
  }
}

function parseUnifiedAlerts(body: unknown, binding: GrafanaBinding, context: AdapterExecutionContext, state: ParseState): void {
  if (!Array.isArray(body)) throw new AdapterContractError("Grafana unified alert response is invalid");
  const rows: JsonPrimitive[][] = [];
  for (const rule of body) {
    if (!takeRow(state, context)) break;
    if (!isObject(rule)) throw new AdapterContractError("Grafana unified alert metadata is invalid");
    const uid = safeUid(rule.uid, "alert rule UID");
    rows.push([
      uid,
      safeString(rule.title, "alert rule title", 1_024),
      rule.folderUID === undefined || rule.folderUID === null || rule.folderUID === ""
        ? null
        : safeUid(rule.folderUID, "alert folder UID"),
      safeOptionalString(rule.ruleGroup, "alert rule group", 512),
      safeOptionalString(rule.condition, "alert condition identifier", 128),
      safeOptionalString(rule.noDataState, "alert no-data state", 64),
      safeOptionalString(rule.execErrState, "alert error state", 64),
      safeOptionalString(rule.for, "alert duration", 64),
      typeof rule.isPaused === "boolean" ? rule.isPaused : false,
      alertDeepLink(uid),
    ]);
  }
  if (rows.length > 0) state.records.push(table(binding.outputName, [
    { name: "uid", type: "STRING" },
    { name: "title", type: "STRING" },
    { name: "folderUid", type: "STRING" },
    { name: "ruleGroup", type: "STRING" },
    { name: "conditionId", type: "STRING" },
    { name: "noDataState", type: "STRING" },
    { name: "execErrState", type: "STRING" },
    { name: "for", type: "STRING" },
    { name: "isPaused", type: "BOOLEAN" },
    { name: "deepLink", type: "STRING" },
  ], rows));
}

function bindingFor(entry: GrafanaCatalogEntry): GrafanaBinding {
  return {
    catalogEntryId: entry.id,
    catalogEntrySha256: grafanaCatalogEntryHash(entry),
    route: entry.route,
    outputName: entry.outputName,
    ...(entry.route === "search" && entry.query !== undefined ? { query: entry.query } : {}),
    ...(entry.route === "search" && entry.searchType !== undefined ? { searchType: entry.searchType } : {}),
    ...((entry.route === "search" || entry.route === "annotations") && entry.tags !== undefined
      ? { tags: [...entry.tags] }
      : {}),
    ...(entry.route === "datasource" || entry.route === "datasource-health"
      ? { datasourceUid: entry.datasourceUid }
      : {}),
    ...(entry.route === "datasource-query"
      ? {
          datasourceUid: entry.datasourceUid,
          datasourceIdentitySha256: entry.datasourceIdentitySha256,
          target: structuredClone(entry.target),
          frame: structuredClone(entry.frame),
          minIntervalMs: entry.minIntervalMs,
          scopeEnvironment: entry.scope.environment,
          ...(entry.scope.service === undefined ? {} : { scopeService: entry.scope.service }),
          scopeEnvironmentMapping: entry.scopeMappings.environment,
          ...(entry.scopeMappings.service === undefined ? {} : { scopeServiceMapping: entry.scopeMappings.service }),
          ...(entry.scope.subject === undefined
            ? {}
            : {
                scopeSubjectKind: entry.scope.subject.kind,
                scopeSubjectRef: entry.scope.subject.ref,
                scopeSubjectProviderValue: entry.scope.subject.providerValue,
                scopeSubjectMapping: entry.scopeMappings["subject.ref"]!,
              }),
        }
      : {}),
    ...(entry.route === "annotations" && entry.annotationType !== undefined
      ? { annotationType: entry.annotationType }
      : {}),
  } as GrafanaBinding;
}

function buildDatasourceQueryTarget(binding: GrafanaBinding, context: AdapterExecutionContext): JsonObject {
  const target = binding.target!;
  const windowMs = Date.parse(context.window.end) - Date.parse(context.window.start);
  const intervalMs = Math.max(binding.minIntervalMs!, Math.ceil(windowMs / Math.max(1, context.budget.limits.maxPoints)));
  const common: JsonObject = {
    refId: "A",
    datasource: { type: target.datasourceType, uid: binding.datasourceUid! },
    intervalMs,
    maxDataPoints: context.budget.limits.maxPoints,
  };
  if (target.datasourceType === "prometheus") {
    return {
      ...common,
      expr: target.expression,
      instant: target.mode === "instant",
      range: target.mode === "range",
      format: target.format,
      ...(target.legendFormat === undefined ? {} : { legendFormat: target.legendFormat }),
    };
  }
  if (target.datasourceType === "loki") {
    return {
      ...common,
      expr: target.expression,
      queryType: target.queryType,
      direction: target.direction,
      maxLines: context.budget.limits.maxRows,
    };
  }
  if (target.datasourceType === "tempo") {
    return {
      ...common,
      query: target.expression,
      queryType: target.queryType,
      limit: Math.max(1, Math.min(target.limit, context.budget.limits.maxRows)),
      spss: Math.max(1, Math.min(target.spansPerSpanSet, context.budget.limits.maxRows)),
      tableType: target.tableType,
      streaming: false,
    };
  }
  return {
    ...common,
    rawSql: target.rawSql,
    format: target.format,
  };
}

function buildRequest(binding: GrafanaBinding, context: AdapterExecutionContext): GrafanaHttpRequest {
  if (binding.route === "datasource-query") {
    if (binding.target?.datasourceType === "tempo") {
      // Grafana 10–12 do not implement backend TraceQL search through
      // /api/ds/query. This is one code-owned read route, not a generic proxy:
      // the datasource UID and TraceQL came from the hash-verified catalog.
      return {
        method: "GET",
        path: `/api/datasources/proxy/uid/${binding.datasourceUid!}/api/search`,
        query: {
          q: binding.target.expression,
          start: String(Math.floor(Date.parse(context.window.start) / 1_000)),
          end: String(Math.ceil(Date.parse(context.window.end) / 1_000)),
          limit: String(Math.max(1, Math.min(binding.target.limit, context.budget.limits.maxRows))),
          spss: String(Math.max(1, Math.min(binding.target.spansPerSpanSet, context.budget.limits.maxRows))),
        },
        signal: context.signal,
        maxResponseBytes: context.budget.limits.maxBytes,
      };
    }
    return {
      method: "POST",
      path: "/api/ds/query",
      query: {},
      body: {
        from: String(Date.parse(context.window.start)),
        to: String(Date.parse(context.window.end)),
        queries: [buildDatasourceQueryTarget(binding, context)],
      },
      signal: context.signal,
      maxResponseBytes: context.budget.limits.maxBytes,
    };
  }
  const query: Record<string, string> = {};
  let path: GrafanaHttpGetRequest["path"];
  if (binding.route === "health") path = "/api/health";
  else if (binding.route === "search") {
    path = "/api/search";
    if (binding.query !== undefined) query.query = binding.query;
    if (binding.searchType !== undefined) query.type = binding.searchType;
    if (binding.tags !== undefined) query.tag = binding.tags.join(",");
    query.limit = String(context.budget.limits.maxRows);
  } else if (binding.route === "datasource") path = `/api/datasources/uid/${binding.datasourceUid!}`;
  else if (binding.route === "datasource-health") path = `/api/datasources/uid/${binding.datasourceUid!}/health`;
  else if (binding.route === "annotations") {
    path = "/api/annotations";
    query.from = String(Date.parse(context.window.start));
    query.to = String(Date.parse(context.window.end));
    query.limit = String(context.budget.limits.maxRows);
    if (binding.annotationType !== undefined) query.type = binding.annotationType;
    if (binding.tags !== undefined) query.tags = binding.tags.join(",");
  } else path = "/api/v1/provisioning/alert-rules";
  return { method: "GET", path, query, signal: context.signal, maxResponseBytes: context.budget.limits.maxBytes };
}

export interface GrafanaAdapterOptions {
  transport: GrafanaTransport;
  catalog: GrafanaTrustedCatalog;
}

export class GrafanaAdapter implements EvidenceAdapter<GrafanaBinding> {
  readonly descriptor = {
    packageId: GRAFANA_ADAPTER_PACKAGE_ID,
    name: grafanaAdapterPackage.name,
    version: grafanaAdapterPackage.version,
    provider: "grafana",
    domains: ["METRICS", "LOGS", "TRACES", "ALERTS", "RUNTIME", "CHANGES", "RUNBOOKS"] as const,
    operations: grafanaAdapterPackage.capabilities,
    resultSchemaVersions: ["1.0.0"] as const,
  };

  readonly #transport: GrafanaTransport;
  readonly #catalog: CompiledGrafanaCatalog;

  constructor(options: GrafanaAdapterOptions) {
    this.#transport = options.transport;
    this.#catalog = new CompiledGrafanaCatalog(options.catalog);
  }

  async doctor() {
    return {
      status: "READY" as const,
      checks: [{ name: "read-only-transport", status: "PASS" as const, message: "Trusted Grafana read catalog loaded" }],
    };
  }

  async compile(operation: Readonly<OperationSnapshot>, context: AdapterCompileContext) {
    if (context.adapterPackage.packageId !== GRAFANA_ADAPTER_PACKAGE_ID) {
      throw new AdapterContractError("Grafana adapter package mismatch");
    }
    if (
      operation.definition.adapterPackageId !== GRAFANA_ADAPTER_PACKAGE_ID ||
      computeOperationDefinitionHash(operation) !== operation.definitionSha256
    ) {
      throw new AdapterContractError("Grafana operation is not bound to this adapter and hash");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > context.maxDefinitionBytes) {
      throw new AdapterContractError("Grafana operation definition exceeds the compile budget");
    }
    const reference = operation.definition.sanitizedProviderDefinition;
    if (
      Object.keys(reference).length !== 2 ||
      typeof reference.catalogEntryId !== "string" ||
      typeof reference.catalogEntrySha256 !== "string"
    ) {
      throw new AdapterContractError("Grafana operation must contain only a trusted catalog reference");
    }
    const entry = this.#catalog.resolve(reference.catalogEntryId, reference.catalogEntrySha256 as Sha256);
    if (operation.definition.adapterOperation !== OPERATION_BY_ROUTE[entry.route]) {
      throw new AdapterContractError("Grafana adapter operation does not match the catalog route");
    }
    if (operation.definition.normalization.resultKind !== expectedResultKind(entry)) {
      throw new AdapterContractError("Grafana normalization kind does not match the catalog route");
    }
    if (entry.route === "datasource-query") {
      if (operation.definition.domain !== expectedDomain(entry)) {
        throw new AdapterContractError("Grafana datasource query domain does not match the certified datasource type");
      }
      const expectedSourceLineage = sourceLineageFor(entry);
      if (canonicalJson(operation.definition.expectedSourceLineage ?? null) !== canonicalJson(expectedSourceLineage)) {
        throw new AdapterContractError("Grafana source lineage does not match the trusted catalog");
      }
      if (canonicalJson(operation.definition.scopeMapping) !== canonicalJson(entry.scopeMappings)) {
        throw new AdapterContractError("Grafana datasource query scope mapping does not match the catalog");
      }
      if (!sameStringSet(operation.definition.allowedDimensions, expectedDimensions(entry))) {
        throw new AdapterContractError("Grafana datasource query dimensions do not match the frame contract");
      }
      if (isGrafanaPostgresTarget(entry.target) &&
          entry.target.maxRows > operation.definition.limits.maxRows) {
        throw new AdapterContractError("Grafana PostgreSQL enrolled row limit exceeds the operation budget");
      }
      const requiredScopes = new Set(operation.definition.requiredProviderScopes);
      if (!requiredScopes.has("environment") ||
          (entry.scope.service !== undefined && !requiredScopes.has("service")) ||
          (entry.scope.subject !== undefined && !requiredScopes.has("subject.ref"))) {
        throw new AdapterContractError("Grafana datasource query operation does not require its enrolled scope claims");
      }
    }
    return {
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      adapterPackageId: GRAFANA_ADAPTER_PACKAGE_ID,
      adapterOperation: operation.definition.adapterOperation,
      binding: bindingFor(entry),
    } satisfies CompiledAdapterOperation<GrafanaBinding>;
  }

  async execute(context: AdapterExecutionContext, operation: Readonly<CompiledAdapterOperation<GrafanaBinding>>) {
    context.budget.throwIfAborted();
    const trustedEntry = this.#catalog.resolve(
      operation.binding.catalogEntryId,
      operation.binding.catalogEntrySha256,
    );
    if (
      operation.adapterPackageId !== GRAFANA_ADAPTER_PACKAGE_ID ||
      operation.adapterOperation !== OPERATION_BY_ROUTE[trustedEntry.route] ||
      canonicalJson(operation.binding) !== canonicalJson(bindingFor(trustedEntry))
    ) {
      throw new AdapterContractError("Compiled Grafana binding no longer matches the trusted catalog");
    }
    if (trustedEntry.route === "datasource-query" && (
      context.scope.environment !== trustedEntry.scope.environment ||
      context.scope.service !== trustedEntry.scope.service ||
      context.scope.region !== undefined ||
      context.scope.cohort !== undefined ||
      canonicalJson(context.scope.subject ?? null) !== canonicalJson(
        trustedEntry.scope.subject === undefined
          ? null
          : { kind: trustedEntry.scope.subject.kind, ref: trustedEntry.scope.subject.ref },
      )
    )) {
      throw new AdapterContractError("Grafana datasource query execution scope does not match the trusted catalog");
    }
    let datasourceQueryVersionWarning: string | undefined;
    if (trustedEntry.route === "datasource-query") {
      const health = await requestJson(this.#transport, {
        method: "GET",
        path: "/api/health",
        query: {},
        signal: context.signal,
        maxResponseBytes: context.budget.limits.maxBytes,
      }, context);
      datasourceQueryVersionWarning = assertDatasourceQueryVersion(health);
    }
    const request = buildRequest(operation.binding, context);
    const body = await requestJson(this.#transport, request, context);
    if (trustedEntry.route === "datasource-query") {
      const normalized = normalizeGrafanaFrames(
        normalizeGrafanaNativeResponse(body, trustedEntry, context), trustedEntry, context,
      );
      const result: GrafanaLineageProviderResult = {
        schemaVersion: "1.0.0",
        collectionState: normalized.records.length === 0 ? "EMPTY" : "COMPLETE",
        evaluatedAt: normalized.evaluatedAt,
        nativeResultType: `datasource-query:${trustedEntry.target.datasourceType}`,
        nativeDimensions: {},
        records: normalized.records,
        pagination: normalized.pagination,
        warnings: [
          ...normalized.warnings,
          ...(datasourceQueryVersionWarning === undefined ? [] : [datasourceQueryVersionWarning]),
        ],
        sanitizedReference: trustedEntry.sourcePanel === undefined
          ? `grafana:datasource-query:${trustedEntry.id}`
          : panelDeepLink(trustedEntry.sourcePanel),
        providerScope: {
          environment: trustedEntry.scope.environment,
          ...(trustedEntry.scope.service === undefined ? {} : { service: trustedEntry.scope.service }),
          ...(trustedEntry.scope.subject === undefined
            ? {}
            : {
                subject: {
                  kind: trustedEntry.scope.subject.kind,
                  ref: trustedEntry.scope.subject.ref,
                },
              }),
          mappings: {
            environment: trustedEntry.scopeMappings.environment,
            ...(trustedEntry.scopeMappings.service === undefined
              ? {}
              : { service: trustedEntry.scopeMappings.service }),
            ...(trustedEntry.scopeMappings["subject.ref"] === undefined
              ? {}
              : { "subject.ref": trustedEntry.scopeMappings["subject.ref"] }),
          },
        },
        sourceLineage: sourceLineageFor(trustedEntry),
        ...(trustedEntry.frame.unit === undefined ? {} : { nativeUnit: trustedEntry.frame.unit }),
      };
      return result;
    }
    const state: ParseState = { records: [], rows: 0, truncated: false };
    if (operation.binding.route === "health") parseHealth(body, operation.binding, context, state);
    else if (operation.binding.route === "search") parseSearch(body, operation.binding, context, state);
    else if (operation.binding.route === "datasource") parseDatasource(body, operation.binding, context, state);
    else if (operation.binding.route === "datasource-health") parseDatasourceHealth(body, operation.binding, context, state);
    else if (operation.binding.route === "annotations") parseAnnotations(body, operation.binding, context, state);
    else parseUnifiedAlerts(body, operation.binding, context, state);

    const result: ProviderResult = {
      schemaVersion: "1.0.0",
      collectionState: state.records.length === 0 ? "EMPTY" : "COMPLETE",
      evaluatedAt: context.clock.now().toISOString(),
      nativeResultType: operation.binding.route,
      nativeDimensions: {},
      records: state.records,
      pagination: state.truncated
        ? { complete: false, pages: 1, truncatedReason: "ROW_LIMIT" }
        : { complete: true, pages: 1 },
      warnings: [],
      sanitizedReference: `grafana:${request.path}`,
    };
    return result;
  }
}
