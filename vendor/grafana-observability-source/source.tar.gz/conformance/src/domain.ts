import {
  computeOperationDefinitionHash,
  type AdapterPackage,
  type EvidenceDomain,
  type JsonObject,
  type OperationLimits,
  type OperationSnapshot,
} from "@codex-production-monitoring/contracts";
import {
  AdapterContractError,
  AdapterExecutionError,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderResult,
  type ProviderValue,
} from "@codex-production-monitoring/adapter-sdk";

import {
  assertProviderResultContract,
  assertSanitizedErrorContract,
  type ProbeResult,
} from "./core-read.ts";
import type { ConformanceCheck, ConformanceReport } from "./report.ts";

export const DOMAIN_CERTIFICATIONS = [
  "METRICS",
  "ALERTS",
  "LOGS",
  "TRACES",
  "RUNTIME",
  "CHANGES",
  "RUNBOOKS",
] as const satisfies readonly EvidenceDomain[];

export type DomainCertification = (typeof DOMAIN_CERTIFICATIONS)[number];

export const DOMAIN_CONFORMANCE_CHECKS = [
  "descriptor-domain-declaration",
  "native-result-semantics",
  "provider-scope-binding",
  "empty-result-semantics",
  "error-result-semantics",
  "truncation-semantics",
  "provider-drift-rejection",
  "forbidden-mutation-rejection",
  "redaction-vector-presence",
] as const;

export type DomainConformanceCheckId = (typeof DOMAIN_CONFORMANCE_CHECKS)[number];

export type DomainConformanceReport = ConformanceReport<
  DomainCertification,
  DomainConformanceCheckId
> & { executionBoundary: "DIRECT_IN_PROCESS" };

export interface DomainConformanceVector<Binding extends JsonObject = JsonObject> {
  certification: DomainCertification;
  adapter: EvidenceAdapter<Binding>;
  adapterPackage: AdapterPackage;
  operation: OperationSnapshot;
  expectedNativeResultTypes: readonly [string, ...string[]];
  redactionCanaries: readonly [string, ...string[]];
  maxDefinitionBytes?: number;
  createExecutionContext(
    signal?: AbortSignal,
    limits?: Partial<OperationLimits>,
  ): AdapterExecutionContext;
  emptyProbe(): Promise<ProviderResult>;
  errorProbe(): Promise<ProbeResult>;
  truncationProbe(): Promise<ProviderResult>;
  driftProbe(): Promise<ProbeResult>;
}

export interface RegisteredDomainConformanceSuite {
  adapterPackageId: string;
  adapterVersion: string;
  certification: DomainCertification;
  run(): Promise<DomainConformanceReport>;
}

export interface DomainConformanceSuiteSummary {
  suiteId: string;
  adapterPackageId: string;
  adapterVersion: string;
  certification: DomainCertification;
}

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

function safeDetail(error: unknown): string {
  if (error instanceof Error && /^[A-Za-z][A-Za-z0-9]*$/u.test(error.name)) {
    return `failed with ${error.name}`;
  }
  return "failed with a non-standard error";
}

async function check(
  checks: ConformanceCheck<DomainConformanceCheckId>[],
  id: DomainConformanceCheckId,
  operation: () => void | Promise<void>,
): Promise<void> {
  try {
    await operation();
    checks.push({ id, status: "PASS", detail: "contract exercised" });
  } catch (error) {
    checks.push({ id, status: "FAIL", detail: safeDetail(error) });
  }
}

async function expectReject(operation: () => Promise<unknown>, message: string): Promise<void> {
  try {
    await operation();
  } catch {
    return;
  }
  throw new Error(message);
}

function recordKindAllowedForDomain(domain: DomainCertification, kind: ProviderValue["kind"]): boolean {
  const allowed: Record<DomainCertification, readonly ProviderValue["kind"][]> = {
    METRICS: ["SCALAR", "TIMESERIES", "TABLE"],
    ALERTS: ["EVENT", "TABLE"],
    LOGS: ["EVENT"],
    TRACES: ["EVENT"],
    RUNTIME: ["TABLE"],
    CHANGES: ["EVENT", "TABLE"],
    RUNBOOKS: ["TABLE"],
  };
  return allowed[domain].includes(kind);
}

function assertResultSemantics(
  vector: DomainConformanceVector,
  result: ProviderResult,
  expectedState: "COMPLETE" | "EMPTY",
): void {
  assertProviderResultContract(result);
  assert(result.collectionState === expectedState, `expected ${expectedState} provider result`);
  assert(
    vector.expectedNativeResultTypes.includes(result.nativeResultType),
    "native result type does not match the registered vector",
  );
  if (expectedState === "EMPTY") {
    assert(result.records.length === 0, "EMPTY provider result contains records");
    return;
  }
  assert(result.records.length > 0, "complete domain result is empty");
  const expectedKind = vector.operation.definition.normalization.resultKind;
  for (const record of result.records) {
    assert(record.kind === expectedKind, "provider record kind drifted from operation normalization");
    assert(recordKindAllowedForDomain(vector.certification, record.kind), "record kind is invalid for the domain");
    if (record.kind === "SCALAR" || record.kind === "TIMESERIES") {
      const allowedDimensions = new Set(vector.operation.definition.allowedDimensions);
      for (const dimension of Object.keys(record.dimensions)) {
        assert(allowedDimensions.has(dimension), "provider record emitted a non-allowlisted dimension");
      }
    }
  }
}

function assertScope(vector: DomainConformanceVector, context: AdapterExecutionContext, result: ProviderResult): void {
  const required = new Set(
    Object.keys(vector.operation.definition.scopeMapping).filter((key) =>
      key === "environment" || key === "service" || key === "tenantSha256"
    ),
  );
  const claim = result.providerScope;
  if (required.has("environment")) {
    assert(claim?.environment === context.scope.environment, "provider environment claim drifted");
  } else if (claim?.environment !== undefined) {
    assert(claim.environment === context.scope.environment, "provider environment claim exceeded scope");
  }
  if (required.has("service")) {
    assert(claim?.service === context.scope.service, "provider service claim drifted");
  } else if (claim?.service !== undefined) {
    assert(claim.service === context.scope.service, "provider service claim exceeded scope");
  }
  if (required.has("tenantSha256")) {
    assert(claim?.tenantSha256 === context.expectedTenantSha256, "provider tenant claim drifted");
  } else if (claim?.tenantSha256 !== undefined) {
    assert(claim.tenantSha256 === context.expectedTenantSha256, "provider tenant claim exceeded scope");
  }
}

function assertErrorProbe(probe: ProbeResult, canaries: readonly string[]): void {
  if (probe.error instanceof AdapterExecutionError) {
    assertSanitizedErrorContract(probe.error.sanitized, canaries);
    return;
  }
  if (probe.result !== undefined) {
    assertProviderResultContract(probe.result);
    assert(probe.result.collectionState === "ERROR", "error probe returned non-error evidence");
    assert(probe.result.error !== undefined, "error probe omitted a sanitized error");
    assertSanitizedErrorContract(probe.result.error, canaries);
    return;
  }
  if (probe.sanitizedError !== undefined) {
    assertSanitizedErrorContract(probe.sanitizedError, canaries);
    return;
  }
  throw new Error("error probe did not return a bounded error");
}

function assertDriftProbe(probe: ProbeResult): void {
  if (probe.error instanceof AdapterContractError || probe.error instanceof AdapterExecutionError) return;
  if (probe.result !== undefined) {
    assertProviderResultContract(probe.result);
    assert(probe.result.collectionState === "ERROR", "drift probe returned accepted provider evidence");
    return;
  }
  if (probe.sanitizedError !== undefined) return;
  throw new Error("drift probe did not fail closed");
}

function driftedOperation(operation: OperationSnapshot): OperationSnapshot {
  const copy = structuredClone(operation);
  const provider = copy.definition.sanitizedProviderDefinition;
  if (typeof provider.catalogEntrySha256 === "string") {
    provider.catalogEntrySha256 = provider.catalogEntrySha256 === "0".repeat(64) ? "1".repeat(64) : "0".repeat(64);
  } else if (typeof provider.bindingId === "string") {
    provider.bindingId = `${provider.bindingId}-conformance-drift`;
  } else if (typeof provider.scenario === "string") {
    provider.scenario = "unregistered-conformance-scenario";
  } else {
    throw new Error("domain vector has no deterministic provider-drift seam");
  }
  copy.definitionSha256 = computeOperationDefinitionHash(copy);
  return copy;
}

function mutationOperation(operation: OperationSnapshot): OperationSnapshot {
  const copy = structuredClone(operation);
  copy.definition.sanitizedProviderDefinition = {
    ...copy.definition.sanitizedProviderDefinition,
    method: "POST",
    action: "delete",
    write: true,
    url: "https://attacker.invalid/mutate",
    shell: "provider-mutation-canary",
  };
  copy.definitionSha256 = computeOperationDefinitionHash(copy);
  return copy;
}

/**
 * Executes one provider-domain receipt directly against a deterministic
 * adapter vector. It intentionally makes no signed-host or isolation claim.
 */
export async function runDomainConformance<Binding extends JsonObject>(
  vector: DomainConformanceVector<Binding>,
): Promise<DomainConformanceReport> {
  const checks: ConformanceCheck<DomainConformanceCheckId>[] = [];
  const maxDefinitionBytes = vector.maxDefinitionBytes ?? 64_000;
  let compiled: CompiledAdapterOperation<Binding> | undefined;
  let result: ProviderResult | undefined;
  let context: AdapterExecutionContext | undefined;

  await check(checks, "descriptor-domain-declaration", () => {
    assert(vector.adapterPackage.conformance.includes(vector.certification), "package omits domain conformance claim");
    assert(vector.adapterPackage.domains.includes(vector.certification), "package omits declared domain");
    assert(vector.adapter.descriptor.domains.includes(vector.certification), "descriptor omits declared domain");
    assert(vector.operation.definition.domain === vector.certification, "operation domain does not match certification");
    assert(
      vector.operation.definition.adapterPackageId === vector.adapterPackage.packageId,
      "operation package does not match certification package",
    );
    assert(
      vector.adapter.descriptor.operations.includes(vector.operation.definition.adapterOperation) &&
        vector.adapterPackage.capabilities.some((capability) =>
          capability === vector.operation.definition.adapterOperation ||
          capability.startsWith(`${vector.operation.definition.adapterOperation}.`) ||
          vector.operation.definition.adapterOperation.startsWith(`${capability}.`)
        ),
      "operation is not declared by descriptor and package",
    );
  });

  await check(checks, "native-result-semantics", async () => {
    compiled = await vector.adapter.compile(vector.operation, {
      adapterPackage: vector.adapterPackage,
      maxDefinitionBytes,
    });
    context = vector.createExecutionContext();
    result = await vector.adapter.execute(context, compiled);
    assertResultSemantics(vector, result, "COMPLETE");
  });

  await check(checks, "provider-scope-binding", () => {
    assert(context !== undefined && result !== undefined, "native result check did not complete");
    assertScope(vector, context, result);
  });

  await check(checks, "empty-result-semantics", async () => {
    assertResultSemantics(vector, await vector.emptyProbe(), "EMPTY");
  });

  await check(checks, "error-result-semantics", async () => {
    assertErrorProbe(await vector.errorProbe(), vector.redactionCanaries);
  });

  await check(checks, "truncation-semantics", async () => {
    const truncated = await vector.truncationProbe();
    assertProviderResultContract(truncated);
    assert(
      vector.expectedNativeResultTypes.includes(truncated.nativeResultType),
      "truncation native result type does not match the registered vector",
    );
    if (truncated.collectionState === "COMPLETE") {
      assertResultSemantics(vector, truncated, "COMPLETE");
    } else {
      assert(truncated.collectionState === "ERROR", "truncation probe returned EMPTY evidence");
      assert(truncated.error?.category === "POLICY", "truncation error is not a bounded policy result");
    }
    assert(!truncated.pagination.complete, "truncation probe declared complete pagination");
    assert(truncated.pagination.truncatedReason !== undefined, "truncation probe omitted its reason");
  });

  await check(checks, "provider-drift-rejection", async () => {
    await expectReject(
      () => vector.adapter.compile(driftedOperation(vector.operation), {
        adapterPackage: vector.adapterPackage,
        maxDefinitionBytes,
      }),
      "adapter accepted a drifted provider binding",
    );
    assertDriftProbe(await vector.driftProbe());
  });

  await check(checks, "forbidden-mutation-rejection", async () => {
    await expectReject(
      () => vector.adapter.compile(mutationOperation(vector.operation), {
        adapterPackage: vector.adapterPackage,
        maxDefinitionBytes,
      }),
      "adapter accepted request-time mutation material",
    );
  });

  await check(checks, "redaction-vector-presence", () => {
    assert(vector.redactionCanaries.length > 0, "domain suite omitted redaction canaries");
    assert(new Set(vector.redactionCanaries).size === vector.redactionCanaries.length, "redaction canaries are duplicated");
    for (const canary of vector.redactionCanaries) {
      assert(canary.length >= 8, "redaction canary is too weak");
    }
  });

  return {
    schemaVersion: "1.0.0",
    adapterPackageId: vector.adapterPackage.packageId,
    adapterVersion: vector.adapterPackage.version,
    certification: vector.certification,
    executionBoundary: "DIRECT_IN_PROCESS",
    passed: checks.every((item) => item.status === "PASS"),
    checks,
  };
}

export function domainConformanceSuiteId(adapterPackageId: string, certification: DomainCertification): string {
  return `${adapterPackageId}:${certification}`;
}

export class DomainConformanceSuiteRegistry {
  readonly #suites = new Map<string, RegisteredDomainConformanceSuite>();

  register(suite: RegisteredDomainConformanceSuite): this {
    const suiteId = domainConformanceSuiteId(suite.adapterPackageId, suite.certification);
    if (this.#suites.has(suiteId)) throw new Error(`Duplicate domain conformance suite: ${suiteId}`);
    this.#suites.set(suiteId, suite);
    return this;
  }

  has(adapterPackageId: string, certification: DomainCertification): boolean {
    return this.#suites.has(domainConformanceSuiteId(adapterPackageId, certification));
  }

  list(): DomainConformanceSuiteSummary[] {
    return [...this.#suites.entries()]
      .map(([suiteId, suite]) => ({
        suiteId,
        adapterPackageId: suite.adapterPackageId,
        adapterVersion: suite.adapterVersion,
        certification: suite.certification,
      }))
      .sort((left, right) => left.suiteId.localeCompare(right.suiteId));
  }

  async run(adapterPackageId: string, certification: DomainCertification): Promise<DomainConformanceReport> {
    const suiteId = domainConformanceSuiteId(adapterPackageId, certification);
    const suite = this.#suites.get(suiteId);
    if (suite === undefined) throw new Error(`No executable domain conformance suite: ${suiteId}`);
    const report = await suite.run();
    if (
      report.adapterPackageId !== suite.adapterPackageId ||
      report.adapterVersion !== suite.adapterVersion ||
      report.certification !== suite.certification
    ) {
      throw new Error(`Domain conformance suite returned a mismatched receipt: ${suiteId}`);
    }
    if (report.executionBoundary !== "DIRECT_IN_PROCESS") {
      throw new Error(`Domain conformance suite overclaimed its execution boundary: ${suiteId}`);
    }
    return report;
  }

  async runAll(): Promise<DomainConformanceReport[]> {
    const reports: DomainConformanceReport[] = [];
    for (const suite of this.list()) {
      reports.push(await this.run(suite.adapterPackageId, suite.certification));
    }
    return reports;
  }
}
