import type { EvidenceDomain } from "@codex-production-monitoring/contracts";

export const CONFORMANCE_CERTIFICATIONS = [
  "CORE_READ",
  "METRICS",
  "ALERTS",
  "LOGS",
  "TRACES",
  "RUNTIME",
  "CHANGES",
  "RUNBOOKS",
] as const satisfies readonly ("CORE_READ" | EvidenceDomain)[];

export type ConformanceCertification = (typeof CONFORMANCE_CERTIFICATIONS)[number];
export type ConformanceExecutionBoundary = "DIRECT_IN_PROCESS" | "SIGNED_HOST";

export interface ConformanceCheck<CheckId extends string = string> {
  id: CheckId;
  status: "PASS" | "FAIL" | "NOT_EXERCISED";
  detail: string;
}

export interface ConformanceReport<
  Certification extends ConformanceCertification = ConformanceCertification,
  CheckId extends string = string,
> {
  schemaVersion: "1.0.0";
  adapterPackageId: string;
  adapterVersion: string;
  certification: Certification;
  /**
   * Present when the harness knows the boundary it exercised. Absence makes no
   * signed-host claim; domain suites currently emit DIRECT_IN_PROCESS only.
   */
  executionBoundary?: ConformanceExecutionBoundary;
  passed: boolean;
  checks: ConformanceCheck<CheckId>[];
}
