import {
  computeOperationDefinitionHash,
  type AdapterPackage,
  type JsonObject,
  type JsonPrimitive,
  type OperationLimits,
  type OperationSnapshot,
  type SanitizedError,
} from "@codex-production-monitoring/contracts";
import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderResult,
  type ProviderValue,
} from "@codex-production-monitoring/adapter-sdk";

import type { ConformanceCheck, ConformanceReport } from "./report.ts";

export const CORE_READ_CHECKS = [
  "descriptor-package-binding",
  "doctor",
  "compile-identity-binding",
  "compile-hash-binding",
  "compile-closed-provider-input",
  "provider-result-schema",
  "provider-scope-binding",
  "cancellation",
  "budgets",
  "sanitized-errors",
] as const;

export type CoreReadCheckId = (typeof CORE_READ_CHECKS)[number];

export interface ProbeResult {
  result?: ProviderResult;
  error?: unknown;
  sanitizedError?: SanitizedError;
  truncatedReason?: string;
}

export interface CoreReadConformanceVector<Binding extends JsonObject = JsonObject> {
  adapter: EvidenceAdapter<Binding>;
  adapterPackage: AdapterPackage;
  operation: OperationSnapshot;
  maxDefinitionBytes?: number;
  createExecutionContext(
    signal?: AbortSignal,
    limits?: Partial<OperationLimits>,
  ): AdapterExecutionContext;
  budgetProbe?: () => Promise<ProbeResult>;
  sanitizedErrorProbe?: () => Promise<ProbeResult>;
  forbiddenErrorFragments?: readonly string[];
}

function safeDetail(error: unknown): string {
  if (error instanceof Error && /^[A-Za-z][A-Za-z0-9]*$/u.test(error.name)) {
    return `failed with ${error.name}`;
  }
  return "failed with a non-standard error";
}

async function check(
  checks: ConformanceCheck<CoreReadCheckId>[],
  id: CoreReadCheckId,
  operation: () => void | Promise<void>,
): Promise<void> {
  try {
    await operation();
    checks.push({ id, status: "PASS", detail: "contract exercised" });
  } catch (error) {
    checks.push({ id, status: "FAIL", detail: safeDetail(error) });
  }
}

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

async function expectReject(operation: () => Promise<unknown>, message: string): Promise<void> {
  try {
    await operation();
  } catch {
    return;
  }
  throw new Error(message);
}

function isIsoTimestamp(value: string): boolean {
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) && new Date(parsed).toISOString() === value;
}

function assertPrimitive(value: unknown): asserts value is JsonPrimitive {
  assert(
    value === null || typeof value === "boolean" || typeof value === "number" || typeof value === "string",
    "provider value is not a JSON primitive",
  );
  if (typeof value === "number") assert(Number.isFinite(value), "provider value is not finite");
}

function assertStringMap(value: unknown): asserts value is Record<string, string> {
  assert(value !== null && typeof value === "object" && !Array.isArray(value), "expected a string map");
  for (const [key, member] of Object.entries(value)) {
    assert(key.length > 0 && typeof member === "string", "invalid string map member");
  }
}

function assertProviderValue(value: ProviderValue): void {
  assert(typeof value.name === "string" && value.name.length > 0, "provider record name is invalid");
  if (value.kind === "SCALAR") {
    assertPrimitive(value.value);
    assertStringMap(value.dimensions);
    if (value.observedAt !== undefined) assert(isIsoTimestamp(value.observedAt), "scalar timestamp is invalid");
    return;
  }
  if (value.kind === "TIMESERIES") {
    assertStringMap(value.dimensions);
    for (const point of value.points) {
      assert(isIsoTimestamp(point.at), "timeseries timestamp is invalid");
      assert(point.value === null || Number.isFinite(point.value), "timeseries value is invalid");
    }
    return;
  }
  if (value.kind === "TABLE") {
    assert(value.columns.length > 0, "table has no columns");
    for (const row of value.rows) {
      assert(row.length === value.columns.length, "table row width does not match columns");
      row.forEach(assertPrimitive);
    }
    return;
  }
  if (value.kind === "EVENT") {
    assert(isIsoTimestamp(value.occurredAt), "event timestamp is invalid");
    assert(typeof value.summary === "string", "event summary is invalid");
    for (const member of Object.values(value.attributes)) assertPrimitive(member);
    return;
  }
  throw new Error("provider record kind is unsupported");
}

export function assertProviderResultContract(result: ProviderResult): void {
  assert(result.schemaVersion === "1.0.0", "unsupported provider result schema version");
  assert(
    result.collectionState === "COMPLETE" ||
      result.collectionState === "EMPTY" ||
      result.collectionState === "ERROR",
    "invalid collection state",
  );
  assert(isIsoTimestamp(result.evaluatedAt), "evaluatedAt is not canonical ISO-8601");
  assert(typeof result.nativeResultType === "string" && result.nativeResultType.length > 0, "native result type is invalid");
  assertStringMap(result.nativeDimensions);
  assert(Array.isArray(result.records), "records are not an array");
  result.records.forEach(assertProviderValue);
  assert(Array.isArray(result.warnings) && result.warnings.every((warning) => typeof warning === "string"), "warnings are invalid");
  assert(typeof result.pagination.complete === "boolean", "pagination completeness is invalid");
  assert(Number.isSafeInteger(result.pagination.pages) && result.pagination.pages >= 0, "pagination pages are invalid");
  if (result.pagination.truncatedReason !== undefined) {
    assert(
      new Set(["BYTE_LIMIT", "ROW_LIMIT", "SERIES_LIMIT", "POINT_LIMIT", "TIME_LIMIT"]).has(
        result.pagination.truncatedReason,
      ),
      "pagination truncation reason is invalid",
    );
    assert(!result.pagination.complete, "complete pagination declared a truncation reason");
  }
  if (result.collectionState === "EMPTY" || result.collectionState === "ERROR") {
    assert(result.records.length === 0, `${result.collectionState} result contains records`);
  }
  if (result.collectionState === "ERROR") assert(result.error !== undefined, "ERROR result omitted sanitized error");
}

export function assertSanitizedErrorContract(error: SanitizedError, forbidden: readonly string[] = []): void {
  const categories = new Set([
    "AUTHORIZATION",
    "AUTHENTICATION",
    "UNAVAILABLE",
    "TIMEOUT",
    "RATE_LIMIT",
    "INVALID_RESPONSE",
    "POLICY",
    "INTERNAL",
  ]);
  assert(error.code.length > 0 && categories.has(error.category), "sanitized error shape is invalid");
  assert(typeof error.retryable === "boolean", "sanitized error retryability is invalid");
  const serialized = JSON.stringify(error).toLowerCase();
  for (const fragment of forbidden) {
    assert(!serialized.includes(fragment.toLowerCase()), "sanitized error contains a forbidden fragment");
  }
}

function assertBudgetProbe(probe: ProbeResult): void {
  if (probe.error instanceof BudgetExceededError) return;
  if (probe.error instanceof AdapterContractError) return;
  if (probe.error instanceof AdapterExecutionError && probe.error.sanitized.category === "POLICY") return;
  if (probe.sanitizedError?.category === "POLICY") return;
  if (probe.truncatedReason !== undefined) return;
  if (probe.result !== undefined) {
    assertProviderResultContract(probe.result);
    if (probe.result.collectionState === "ERROR" && probe.result.error?.category === "POLICY") return;
    if (!probe.result.pagination.complete && probe.result.pagination.truncatedReason !== undefined) return;
  }
  throw new Error("budget probe neither failed closed nor declared truncation");
}

function assertErrorProbe(probe: ProbeResult, forbidden: readonly string[]): void {
  if (probe.error instanceof AdapterExecutionError) {
    assertSanitizedErrorContract(probe.error.sanitized, forbidden);
    return;
  }
  if (probe.result !== undefined) {
    assertProviderResultContract(probe.result);
    assert(probe.result.collectionState === "ERROR", "sanitized error probe returned non-error evidence");
    assert(probe.result.error !== undefined, "sanitized error probe omitted error");
    assertSanitizedErrorContract(probe.result.error, forbidden);
    return;
  }
  if (probe.sanitizedError !== undefined) {
    assertSanitizedErrorContract(probe.sanitizedError, forbidden);
    return;
  }
  throw new Error("sanitized error probe did not return a bounded error");
}

function unsafeProviderInput(operation: OperationSnapshot): OperationSnapshot {
  const copy = structuredClone(operation);
  copy.definition.sanitizedProviderDefinition = {
    ...copy.definition.sanitizedProviderDefinition,
    url: "https://attacker.invalid/collect",
    query: "{__name__=~\".*\"}",
    path: "/etc/passwd",
    headers: { authorization: "Bearer conformance-canary" },
    shell: "touch /tmp/production-monitoring-conformance",
    tenant: "another-tenant",
  };
  copy.definitionSha256 = computeOperationDefinitionHash(copy);
  return copy;
}

/**
 * Runs the portable CORE_READ contract without network access. Provider-specific
 * transports are supplied by the caller, so certification can use deterministic
 * fakes locally and the same vectors against an admitted worker in CI.
 */
export async function runCoreReadConformance<Binding extends JsonObject>(
  vector: CoreReadConformanceVector<Binding>,
): Promise<ConformanceReport<"CORE_READ", CoreReadCheckId>> {
  const checks: ConformanceCheck<CoreReadCheckId>[] = [];
  const maxDefinitionBytes = vector.maxDefinitionBytes ?? 64_000;
  let compiled: CompiledAdapterOperation<Binding> | undefined;

  await check(checks, "descriptor-package-binding", () => {
    assert(vector.adapter.descriptor.packageId === vector.adapterPackage.packageId, "descriptor package ID mismatch");
    assert(vector.adapter.descriptor.version === vector.adapterPackage.version, "descriptor version mismatch");
    assert(vector.adapter.descriptor.operations.length > 0, "descriptor has no operations");
    assert(vector.adapter.descriptor.resultSchemaVersions.includes("1.0.0"), "descriptor omits provider result schema");
    assert(vector.adapterPackage.conformance.includes("CORE_READ"), "package does not claim CORE_READ");
  });

  await check(checks, "doctor", async () => {
    const controller = new AbortController();
    const result = await vector.adapter.doctor({ signal: controller.signal, clock: vector.createExecutionContext().clock });
    assert(["READY", "WARN", "BLOCKED"].includes(result.status), "doctor status is invalid");
    assert(result.checks.length > 0, "doctor returned no checks");
    for (const item of result.checks) {
      assert(item.name.length > 0 && item.message.length > 0, "doctor check is incomplete");
      assert(["PASS", "WARN", "FAIL"].includes(item.status), "doctor check status is invalid");
    }
  });

  await check(checks, "compile-identity-binding", async () => {
    compiled = await vector.adapter.compile(vector.operation, {
      adapterPackage: vector.adapterPackage,
      maxDefinitionBytes,
    });
    assert(compiled.operationId === vector.operation.operationId, "compiled operation ID drifted");
    assert(compiled.operationDefinitionSha256 === vector.operation.definitionSha256, "compiled operation hash drifted");
    assert(compiled.adapterPackageId === vector.adapterPackage.packageId, "compiled package ID drifted");
    assert(compiled.adapterOperation === vector.operation.definition.adapterOperation, "compiled operation name drifted");
  });

  await check(checks, "compile-hash-binding", async () => {
    const tampered = structuredClone(vector.operation);
    tampered.definition.sourceAlias = `${tampered.definition.sourceAlias}-tampered`;
    await expectReject(
      () => vector.adapter.compile(tampered, { adapterPackage: vector.adapterPackage, maxDefinitionBytes }),
      "adapter accepted a definition whose hash no longer matched",
    );
  });

  await check(checks, "compile-closed-provider-input", async () => {
    const unsafe = unsafeProviderInput(vector.operation);
    await expectReject(
      () => vector.adapter.compile(unsafe, { adapterPackage: vector.adapterPackage, maxDefinitionBytes }),
      "adapter accepted request-time URL/query/path/header/shell/tenant input",
    );
  });

  await check(checks, "provider-result-schema", async () => {
    assert(compiled !== undefined, "happy-path compile did not complete");
    const result = await vector.adapter.execute(vector.createExecutionContext(), compiled);
    assertProviderResultContract(result);
  });

  await check(checks, "provider-scope-binding", async () => {
    assert(compiled !== undefined, "happy-path compile did not complete");
    const context = vector.createExecutionContext();
    const result = await vector.adapter.execute(context, compiled);
    const required = new Set(
      Object.keys(vector.operation.definition.scopeMapping).filter((key) =>
        key === "environment" || key === "service" || key === "tenantSha256"
      ),
    );
    if (required.has("environment")) {
      assert(result.providerScope?.environment === context.scope.environment, "provider environment claim drifted");
    } else if (result.providerScope?.environment !== undefined) {
      assert(result.providerScope.environment === context.scope.environment, "provider environment claim exceeded scope");
    }
    if (required.has("service")) {
      assert(result.providerScope?.service === context.scope.service, "provider service claim drifted");
    } else if (result.providerScope?.service !== undefined) {
      assert(result.providerScope.service === context.scope.service, "provider service claim exceeded scope");
    }
    if (required.has("tenantSha256")) {
      assert(
        result.providerScope?.tenantSha256 === context.expectedTenantSha256,
        "provider tenant claim drifted",
      );
    } else if (result.providerScope?.tenantSha256 !== undefined) {
      assert(result.providerScope.tenantSha256 === context.expectedTenantSha256, "provider tenant claim exceeded scope");
    }
  });

  await check(checks, "cancellation", async () => {
    assert(compiled !== undefined, "happy-path compile did not complete");
    const controller = new AbortController();
    controller.abort(new Error("conformance cancellation"));
    await expectReject(
      () => vector.adapter.execute(vector.createExecutionContext(controller.signal), compiled!),
      "adapter ignored a pre-aborted execution signal",
    );
  });

  if (vector.budgetProbe === undefined) {
    checks.push({ id: "budgets", status: "NOT_EXERCISED", detail: "vector omitted a budget probe" });
  } else {
    await check(checks, "budgets", async () => assertBudgetProbe(await vector.budgetProbe!()));
  }

  if (vector.sanitizedErrorProbe === undefined) {
    checks.push({ id: "sanitized-errors", status: "NOT_EXERCISED", detail: "vector omitted an error probe" });
  } else {
    await check(checks, "sanitized-errors", async () =>
      assertErrorProbe(await vector.sanitizedErrorProbe!(), vector.forbiddenErrorFragments ?? []),
    );
  }

  return {
    schemaVersion: "1.0.0",
    adapterPackageId: vector.adapterPackage.packageId,
    adapterVersion: vector.adapterPackage.version,
    certification: "CORE_READ",
    passed: checks.every((item) => item.status === "PASS"),
    checks,
  };
}

export async function captureProbe(operation: () => Promise<ProviderResult>): Promise<ProbeResult> {
  try {
    return { result: await operation() };
  } catch (error) {
    return { error };
  }
}
