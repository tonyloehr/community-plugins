import type { AdapterPackage } from "@codex-production-monitoring/contracts";

const SHA256 = /^[a-f0-9]{64}$/u;

export interface SignedHostExpectation {
  protocol: "PM_ADAPTER_STDIO_V1";
  artifactPath: string;
  artifactSha256: string;
  signingKeyId: string;
}

/**
 * Checks the portable declaration that a conforming signed-worker host must
 * authenticate. Cryptographic signature, allowlist, revocation, and on-disk
 * artifact verification remain mandatory host responsibilities in the SDK.
 */
export function assertSignedHostExpectation(adapterPackage: AdapterPackage): SignedHostExpectation {
  const entrypoint = adapterPackage.entrypoint;
  if (entrypoint.kind !== "SIGNED_WORKER") throw new Error("expected a signed-worker entrypoint");
  if (entrypoint.protocol !== "PM_ADAPTER_STDIO_V1") throw new Error("unexpected worker protocol");
  if (
    entrypoint.artifactPath.length === 0 ||
    entrypoint.artifactPath.startsWith("/") ||
    entrypoint.artifactPath.includes("\\") ||
    entrypoint.artifactPath.split("/").some((part) => part === "" || part === "." || part === "..")
  ) {
    throw new Error("worker artifact path is not portable");
  }
  if (!SHA256.test(entrypoint.artifactSha256)) throw new Error("worker digest is not SHA-256");
  if (entrypoint.signingKeyId.length === 0 || entrypoint.signature.length === 0) {
    throw new Error("worker signature metadata is incomplete");
  }
  return Object.freeze({
    protocol: entrypoint.protocol,
    artifactPath: entrypoint.artifactPath,
    artifactSha256: entrypoint.artifactSha256,
    signingKeyId: entrypoint.signingKeyId,
  });
}
