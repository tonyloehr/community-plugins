# Offline workflow evaluation corpus

This corpus is deterministic and makes no live Codex or provider call. It
validates shipped orchestration, safety expectations, reviewer inputs, and
fresh-process test shape before a candidate is handed to a separate evaluator.

The directories are deliberately separated:

- `inputs/`: prompts and bounded `SIMULATED`/`REPLAY` evidence available to the
  workflow under test;
- `expected/`: evaluator-only routing and outcome requirements;
- `rubrics/`: evaluator-only scoring criteria and disqualifiers.

Do not load `expected/` or `rubrics/` into the workflow context. A live release
gate must freeze each generated result first, then score it in a separate fresh
context. Run at least three independent repetitions per release-gating incident
fixture and record quality, latency, misses, duplicates, unsupported claims,
false escalations, contradiction handling, recovery accuracy, and reviewer
effort.

Offline fixtures never satisfy private-pilot, live-provider, publisher, legal,
support, or human-evaluation gates. No fixture labeled `SIMULATED` may be
presented as live.

Local gates:

- `npm run eval:offline:isolation` proves 0700 roots, exact staged context,
  credential/proxy environment clearing, expectation-file denial through the
  deny-default macOS sandbox, frozen-candidate ordering, and a one-case workflow.
- `npm run eval:offline:workflow` runs every case in three independent fresh
  processes. Each process receives only `input.json`, `fixture.json`, and the
  staged plugin, and injects `deterministicEvidenceAnalysisDriver` into the real
  `runHeadlessWorkflow` orchestration. A different process loads expected output
  and rubric data only after the candidate JSON is read-only and SHA-256 frozen.

The scored summary is explicitly `OFFLINE_ORCHESTRATION_SAFETY_ONLY`. It is not
evidence of model reasoning quality, human usefulness, live provider behavior,
or production readiness.

The workflow gate fails closed when the macOS sandbox is unavailable. Linux is
reported as unsupported rather than running a weaker or unrestricted candidate;
CI therefore runs this gate in its dedicated macOS job.
