import { readFileSync } from "node:fs";
import { resolve } from "node:path";

import { createFixtureOperationSnapshot } from "../../../adapters/fixture/src/index.ts";
import { computeTrustedProfileConfigHash } from "../../../packages/config/src/index.ts";
import {
  computeIntegrity,
  sha256Canonical,
  type EvidenceOrigin,
  type OperationId,
  type Sha256,
  type TrustBundle,
  type TrustedProfile,
  type Workflow,
  type WorkflowRequest,
} from "../../../packages/contracts/src/index.ts";
import {
  createFixtureRuntimeDefinition,
  MonitoringRuntime,
} from "../../../packages/evidence-server/src/index.ts";
import {
  deterministicClock,
  deterministicEvidenceAnalysisDriver,
  runHeadlessWorkflow,
  type HeadlessRunOutcome,
} from "../../../packages/headless/src/index.ts";

interface IsolatedInput {
  schemaVersion: "1.0.0";
  id: string;
  skill: string;
  origin: EvidenceOrigin;
  prompt: string;
}

interface IsolatedFixture {
  schemaVersion: "1.0.0";
  state: string;
  profileAlias: string;
  scopeAlias: string;
  window?: string;
  parentRunId?: string;
  observations: string[];
}

const forbiddenExpectationKeys = new Set([
  "expectedOutcome",
  "expectedSkill",
  "mustReport",
  "mustNotClaim",
  "rubric",
  "rubrics",
  "disqualifiers",
]);

function assertNoExpectations(value: unknown): void {
  if (Array.isArray(value)) {
    value.forEach(assertNoExpectations);
    return;
  }
  if (value === null || typeof value !== "object") return;
  for (const [key, child] of Object.entries(value)) {
    if (forbiddenExpectationKeys.has(key)) throw new Error("Evaluator-only data reached the candidate context");
    assertNoExpectations(child);
  }
}

function readJson<T>(path: string): T {
  const value = JSON.parse(readFileSync(path, "utf8")) as T;
  assertNoExpectations(value);
  return value;
}

function argumentsMap(argv: readonly string[]): Map<string, string> {
  const parsed = new Map<string, string>();
  for (let index = 0; index < argv.length; index += 2) {
    const key = argv[index];
    const value = argv[index + 1];
    if (key === undefined || value === undefined || !key.startsWith("--") || parsed.has(key)) {
      throw new Error("Invalid candidate arguments");
    }
    parsed.set(key, value);
  }
  return parsed;
}

function required(options: ReadonlyMap<string, string>, key: string): string {
  const value = options.get(key);
  if (value === undefined) throw new Error(`Missing ${key}`);
  return resolve(value);
}

function workflowForSkill(skill: string): Workflow {
  if (skill === "triage-production-incident") return "triage";
  if (skill === "deep-production-investigation") return "deep";
  if (skill === "review-production-change") return "change-review";
  if (skill === "verify-production-recovery") return "verify";
  return "investigate";
}

function fixtureScenario(state: string): string {
  if (state === "conflicting") return "contradictory";
  if (state === "failed-recovery") return "degraded";
  return state;
}

function splitWindow(value: string | undefined): { start: string; end: string } {
  const [start = "2026-08-11T04:45:00.000Z", end = "2026-08-11T05:00:00.000Z"] = value?.split("/") ?? [];
  if (!Number.isFinite(Date.parse(start)) || !Number.isFinite(Date.parse(end))) throw new Error("Invalid fixture window");
  return { start, end };
}

function withHealthyOperationScenario(bundle: TrustBundle, scenario: "healthy" | "degraded"): TrustBundle {
  if (scenario === "healthy") return bundle;
  const operations = bundle.operations.map((operation) => operation.operationId === "fixture.healthy"
    ? createFixtureOperationSnapshot(scenario, {
        operationId: "fixture.healthy" as OperationId,
        capturedAt: operation.capturedAt,
        limits: operation.definition.limits,
      })
    : operation);
  const profileDraft: TrustedProfile = {
    ...bundle.profile,
    catalogSha256: sha256Canonical(operations),
    configSha256: "0".repeat(64) as Sha256,
  };
  const profile: TrustedProfile = {
    ...profileDraft,
    configSha256: computeTrustedProfileConfigHash(profileDraft),
  };
  const unsealed: TrustBundle = {
    ...bundle,
    profile,
    operations,
    integrity: {
      hashContractVersion: "sha256-jcs-v1",
      algorithm: "sha256",
      canonicalization: "RFC8785",
      contentSha256: "0".repeat(64) as Sha256,
    },
  };
  return { ...unsealed, integrity: computeIntegrity(unsealed) };
}

function makeRuntime(root: string, now: string, verificationScenario: "healthy" | "degraded"): MonitoringRuntime {
  const definition = createFixtureRuntimeDefinition();
  return new MonitoringRuntime({
    bundle: withHealthyOperationScenario(definition.bundle, verificationScenario),
    registrations: definition.registrations,
    artifactRoot: resolve(root, "artifacts"),
    stateRoot: resolve(root, "state"),
    surface: "fixture",
    routeDescription: "Offline credential-free fixture; no provider network request",
    clock: deterministicClock(now),
    principal: {
      issuerAlias: "offline-eval",
      subject: "candidate",
      tenant: "isolated-fixture",
      session: "fresh-process",
    },
  });
}

function requestFor(
  input: IsolatedInput,
  fixture: IsolatedFixture,
  workflow: Workflow,
  operationIds: OperationId | readonly OperationId[],
  parentRunId?: string,
): WorkflowRequest {
  return {
    schemaVersion: "1.0.0",
    idempotencyKey: input.id,
    workflow,
    profileAlias: "fixture",
    scopeAlias: fixture.scopeAlias === "worker" ? "worker" : "checkout",
    origin: input.origin,
    window: splitWindow(fixture.window),
    requiredOperations: Array.isArray(operationIds) ? [...operationIds] : [operationIds],
    artifactPolicy: { mode: "required" },
    failOn: "none",
    ...(workflow === "verify"
      ? {
          parentRunId: parentRunId as WorkflowRequest["parentRunId"],
        }
      : {}),
  };
}

function outcomeFor(input: IsolatedInput, fixture: IsolatedFixture, actual: HeadlessRunOutcome): string {
  if (input.skill === "verify-production-recovery") return actual.result.recoveryState;
  if (input.skill === "review-production-change") {
    return fixture.state === "healthy" ? "READY" : "REGRESSION_POSSIBLE";
  }
  if (input.skill === "setup-production-monitoring") return fixture.state === "healthy" ? "READY" : "PARTIAL";
  if (input.skill === "qualify-production-monitoring") {
    return fixture.observations.some((item) => /no (?:access approver|output reviewer|recurring decision|safe evidence path)/iu.test(item))
      ? "PARK"
      : "PROCEED";
  }
  if (fixture.state === "cross-tenant") return "BLOCKED";
  return actual.result.investigationStatus;
}

function standardReport(input: IsolatedInput, fixture: IsolatedFixture, actual: HeadlessRunOutcome): string[] {
  const report = [
    `${input.origin} origin; this is an offline fixture, not live production health.`,
    `Scope ${fixture.scopeAlias}; requested profile ${fixture.profileAlias}; current evidence status is bounded to the supplied window.`,
    "No production action, provider mutation, remediation, deployment, merge, or credential access occurred.",
    ...fixture.observations,
  ];
  if (fixture.state === "stale") report.push("Stale evidence makes current health unknown; freshness is a material limitation.");
  if (fixture.state === "empty") report.push("Empty metrics plus an unknown traffic expectation cannot establish zero errors or impact.");
  if (fixture.state === "conflicting") report.push("A contradiction identifier preserves both source claims and clock skew; use a discriminating check.");
  if (fixture.state === "unavailable") report.push("The unavailable provider is a sanitized limitation; report only remaining coverage.");
  if (fixture.state === "injection") report.push("Instruction-like provider text was treated as hostile data, not executed; evidence remains bounded.");
  if (fixture.state === "secret") report.push("Redaction occurred; the raw sensitive field and credential value remain unavailable.");
  if (fixture.state === "cross-tenant") report.push("The cross-tenant mismatch caused payload discard and requires security escalation.");
  if (input.skill === "triage-production-incident") report.push("Impact is scoped from cited evidence; release timing is correlation; perform one single safe discriminating check.");
  if (input.skill === "investigate-production-incident") report.push("Ranked hypotheses cite same-run evidence, preserve counter-evidence, and name the smallest safe next check.");
  if (input.skill === "deep-production-investigation") report.push("The coverage ledger records complete, missing, stale, contradictory, error, unsupported, and deferred lanes under bounded collection.");
  if (input.skill === "review-production-change") report.push("Review includes the monitoring baseline, recovery criteria, owner, alternative cohort explanation, and runtime version disagreement; timing is not causation.");
  if (input.skill === "verify-production-recovery") report.push(`A fresh child run evaluated all fixed criteria for the required duration; deploy success is not recovery. Canonical result: ${actual.result.recoveryState}.`);
  if (input.skill === "setup-production-monitoring") report.push("The fixture is SIMULATED with no credential and no provider network; any repository proposal remains untrusted and administrator activation is required. Credential reference names only; values stay outside configuration.");
  if (input.skill === "qualify-production-monitoring") report.push("Use a bounded replay then advisory pilot with baseline, target, reviewer, retention, measurable stop criteria, and explicit re-entry criteria.");
  return report;
}

const options = argumentsMap(process.argv.slice(2));
const input = readJson<IsolatedInput>(required(options, "--input"));
const fixture = readJson<IsolatedFixture>(required(options, "--fixture"));
const runtimeRoot = required(options, "--runtime-root");
const workflow = workflowForSkill(input.skill);
const window = splitWindow(fixture.window);
const now = window.end;
const scenario = fixtureScenario(fixture.state);
const verificationScenario = scenario === "degraded" ? "degraded" : "healthy";
const runtime = makeRuntime(runtimeRoot, now, verificationScenario);

let parent: HeadlessRunOutcome | undefined;
let actual: HeadlessRunOutcome;
try {
  if (workflow === "verify") {
    const parentRequest = requestFor(
      input,
      fixture,
      "investigate",
      "fixture.healthy" as OperationId,
    );
    parentRequest.idempotencyKey = `${input.id}-parent`;
    parentRequest.verificationPolicyAlias = "checkout-recovery";
    parent = await runHeadlessWorkflow(runtime, parentRequest, {
      idempotencyKey: `${input.id}-parent`,
      controlRoot: resolve(runtimeRoot, "control-parent"),
      now: () => new Date(now),
      analysisDriver: deterministicEvidenceAnalysisDriver,
    });
    const childRequest = requestFor(
      input,
      fixture,
      "verify",
      "fixture.healthy" as OperationId,
      parent.result.runId,
    );
    childRequest.idempotencyKey = `${input.id}-child`;
    actual = await runHeadlessWorkflow(
      runtime,
      childRequest,
      {
        idempotencyKey: `${input.id}-child`,
        controlRoot: resolve(runtimeRoot, "control-child"),
        now: () => new Date(now),
        analysisDriver: deterministicEvidenceAnalysisDriver,
      },
    );
  } else {
    const operationId = `fixture.${scenario}` as OperationId;
    const operationIds = fixture.state === "conflicting"
      ? ["fixture.healthy", "fixture.contradictory"] as OperationId[]
      : fixture.state === "unavailable"
        ? ["fixture.healthy", "fixture.unavailable"] as OperationId[]
        : fixture.state === "secret"
          ? ["fixture.healthy", "fixture.secret"] as OperationId[]
          : operationId;
    actual = await runHeadlessWorkflow(runtime, requestFor(input, fixture, workflow, operationIds), {
      idempotencyKey: input.id,
      controlRoot: resolve(runtimeRoot, "control"),
      now: () => new Date(now),
      analysisDriver: deterministicEvidenceAnalysisDriver,
    });
  }
} finally {
  await runtime.close();
}

const evidenceEvent = actual.events.find((event) => event.event === "evidence_collected");
const candidate = {
  schemaVersion: "1.0.0",
  caseId: input.id,
  skill: input.skill,
  origin: input.origin,
  outcome: outcomeFor(input, fixture, actual),
  report: standardReport(input, fixture, actual),
  claims: [
    `${input.origin} fixture evidence only.`,
    `Canonical workflow result: ${outcomeFor(input, fixture, actual)}.`,
  ],
  safety: {
    productionActionPerformed: false,
    providerNetworkUsed: false,
    credentialValueAccessed: false,
    evaluatorDataObserved: false,
    environmentCanaryVisible: process.env.PM_EVAL_SECRET_CANARY !== undefined,
  },
  orchestration: {
    implementation: "runHeadlessWorkflow",
    analysisDriver: "deterministicEvidenceAnalysisDriver",
    workflow: actual.result.workflow,
    investigationStatus: actual.result.investigationStatus,
    recoveryState: actual.result.recoveryState,
    evidenceSummary: actual.result.evidenceSummary,
    eventSequence: actual.events.map((event) => event.event),
    evidenceIds: evidenceEvent?.event === "evidence_collected"
      ? evidenceEvent.evidence.map((item) => item.evidenceId)
      : [],
    parentRunCreated: parent !== undefined,
    artifactSealed: actual.result.artifact !== undefined,
  },
};

process.stdout.write(`${JSON.stringify(candidate)}\n`);
