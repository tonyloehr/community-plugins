# `@codex-production-monitoring/adapter-conformance`

`runCoreReadConformance` is the release-gating, provider-neutral `CORE_READ`
harness. `runDomainConformance` turns a declared `METRICS`, `ALERTS`, `LOGS`,
`TRACES`, `RUNTIME`, `CHANGES`, or `RUNBOOKS` claim into an executable receipt.
A vector supplies an adapter, a hash-bound operation snapshot, a deterministic
execution context, and bounded failure probes. Neither harness opens a network
connection or resolves credentials on its own.

The core checks cover package identity, `doctor`, compile/hash binding, rejection
of request-time URL/query/path/header/shell/tenant input, provider-result shape,
scope and tenant claims, cancellation, budgets, and sanitized errors. A domain
receipt additionally checks descriptor/package/domain declarations, native and
normalized result semantics, scope, explicit empty and error results, truthful
truncation, provider/schema drift, rejection of mutation-shaped input, and the
presence and execution of redaction canaries. Domain certification does not
weaken or replace `CORE_READ`.

`DomainConformanceSuiteRegistry` binds one executable suite to a package/domain
pair and rejects duplicates or mismatched receipts. A release gate should derive
the expected pairs from each first-party `AdapterPackage.conformance` declaration,
compare that set exactly with the registry, execute every suite, and require every
receipt to pass. A declaration or test name by itself is not certification.

`runDomainConformance` currently labels every receipt
`DIRECT_IN_PROCESS`. Direct vectors are suitable for deterministic adapter and
release tests, but they do not prove signed-worker admission or a child-process
boundary. A separate signed-host gate must actually replay the relevant vector
before producing a `SIGNED_HOST` claim. Validate portable receipts against the
[conformance report schema](./schemas/conformance-report.schema.json); see the
[domain report example](./examples/domain-report.json).

`SIGNED_HOST` means only that the vector crossed the authenticated, digest-pinned
stdio child-process protocol. It does not claim an OS filesystem, network,
subprocess, CPU, or memory sandbox and does not authorize production activation.
The bundled v0.1 runtime admits only its release-code-owned first-party and
fixture package IDs; public conformance remains useful for third-party authoring
without implying an activation path.

The package also exports `assertSignedHostExpectation` for checking the portable
metadata that a host must authenticate. Use the SDK's `verifyWorkerAdmission`
and `verifyWorkerArtifact` for the actual signature, policy, and file checks.
JSON Schema and example report assets are available under `./schemas/*` and
`./examples/*`.

The repository release gate installs the packed conformance, SDK, contracts,
and host packages into a clean consumer. It compiles a TypeScript consumer from
their declarations, verifies an ephemeral artifact signature and digest, then
runs `CORE_READ` through a real stdio child with operation, scope, and snapshot
enforcement. The repository's registered first-party domain receipts are direct
in-process evidence. Until the same domain vectors are replayed through the
signed child, the signed `CORE_READ` result and direct domain results remain
separate claims.
