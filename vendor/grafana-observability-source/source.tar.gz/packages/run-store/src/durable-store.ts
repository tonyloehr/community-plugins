import { closeSync, constants, existsSync, fsyncSync, openSync, readdirSync, unlinkSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { join } from "node:path";

import {
  canonicalJson,
  sha256Bytes,
  sha256Canonical,
  type ContradictionId,
  type EvidenceId,
  type RunId,
  type Sha256,
} from "@codex-production-monitoring/contracts";

import { AtomicStateFile } from "./secure-state.ts";
import { InMemoryRunStore, RunStoreError } from "./store.ts";
import type {
  AllocateContradictionResult,
  AllocateEvidenceResult,
  AuditUpdateInput,
  BeginChildVerificationInput,
  BeginRunInput,
  BeginRunResult,
  DurableRunStoreOptions,
  FinalizeRunInput,
  ListOwnedRunsInput,
  LeaseResult,
  OwnedRunInventory,
  PersistedRunEntry,
  ResumeRunInput,
  ResumeRunWithHandleInput,
  RunAccess,
  RunMutationResult,
  RunRecoveryContext,
  RunStore,
  RunStoreSnapshot,
  RunView,
  SealedParentView,
} from "./types.ts";

const EMPTY_SNAPSHOT: RunStoreSnapshot = { schemaVersion: "1.0.0", runs: [] };
const LEGACY_FILENAME = "run-store.json";
const RETAINED_LEGACY_FILENAME = "run-store-v1-retained.json";
const INDEX_FILENAME = "run-store-index.json";
const BUCKET_COUNT = 256;
const INDEX_MAXIMUM_BYTES = 256 * 1_024;
const BUCKET_FILENAME = /^run-bucket-(\d{3})-([ab])\.json$/u;
const BUCKET_LOCK_FILENAME = /^run-bucket-(\d{3})-([ab])\.json\.lock(?:\.reclaim)?$/u;
const BUCKET_TEMP_FILENAME = /^\.state-run-bucket-(\d{3})-([ab])\.json(?:-[a-f0-9-]{36})?\.tmp$/u;
const ZERO_SHA256 = "0".repeat(64) as Sha256;

type BucketSlot = "a" | "b";

interface LegacyTombstoneV2 {
  schemaVersion: "2.0.0";
  migratedTo: typeof INDEX_FILENAME;
  retainedFilename: typeof RETAINED_LEGACY_FILENAME;
  sourcePayloadSha256: Sha256;
  sourceRunCount: number;
}

interface LegacyMigration {
  sourceFilename: typeof RETAINED_LEGACY_FILENAME;
  sourcePayloadSha256: Sha256;
  sourceRunCount: number;
}

interface BucketDescriptor {
  slot: BucketSlot;
  generation: number;
  payloadSha256: Sha256;
  runCount: number;
}

interface SweepJournal {
  id: string;
  atMs: number;
  targetBuckets: number[];
  nextTargetIndex: number;
  expiredCount: number;
}

interface RunStoreIndexV2 {
  schemaVersion: "2.0.0";
  format: "bucketed-a-b";
  bucketCount: typeof BUCKET_COUNT;
  buckets: Record<string, BucketDescriptor>;
  legacyMigration?: LegacyMigration;
  pendingSweep?: SweepJournal;
}

interface BucketMutation {
  kind: "ordinary" | "migration" | "sweep";
  id: string;
}

interface RunBucketV2 {
  schemaVersion: "2.0.0";
  bucket: number;
  generation: number;
  previousGenerationSha256: Sha256;
  mutation: BucketMutation;
  runs: PersistedRunEntry[];
}

class PendingSweepObserved extends Error {}

function exactKeys(value: object, expected: readonly string[]): boolean {
  return canonicalJson(Object.keys(value).sort()) === canonicalJson([...expected].sort());
}

function bucketKey(bucket: number): string {
  return bucket.toString().padStart(3, "0");
}

function bucketForRun(runId: RunId): number {
  return Number.parseInt(sha256Bytes(runId).slice(0, 2), 16);
}

function inactiveSlot(slot: BucketSlot): BucketSlot {
  return slot === "a" ? "b" : "a";
}

function unlinkAndSyncDirectory(path: string, directory: string): void {
  unlinkSync(path);
  const descriptor = openSync(directory, constants.O_RDONLY | constants.O_DIRECTORY);
  try {
    fsyncSync(descriptor);
  } finally {
    closeSync(descriptor);
  }
}

function validateDescriptor(value: unknown): BucketDescriptor {
  if (
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["generation", "payloadSha256", "runCount", "slot"])
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store bucket descriptor is invalid");
  }
  const descriptor = value as BucketDescriptor;
  if (
    !["a", "b"].includes(descriptor.slot) ||
    !Number.isSafeInteger(descriptor.generation) ||
    descriptor.generation < 1 ||
    !/^[a-f0-9]{64}$/u.test(descriptor.payloadSha256) ||
    !Number.isSafeInteger(descriptor.runCount) ||
    descriptor.runCount < 1
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store bucket descriptor is invalid");
  }
  return structuredClone(descriptor);
}

function validateMigration(value: unknown): LegacyMigration {
  if (
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["sourceFilename", "sourcePayloadSha256", "sourceRunCount"])
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store migration marker is invalid");
  }
  const migration = value as LegacyMigration;
  if (
    migration.sourceFilename !== RETAINED_LEGACY_FILENAME ||
    !/^[a-f0-9]{64}$/u.test(migration.sourcePayloadSha256) ||
    !Number.isSafeInteger(migration.sourceRunCount) ||
    migration.sourceRunCount < 0
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store migration marker is invalid");
  }
  return structuredClone(migration);
}

function validateSweep(value: unknown): SweepJournal {
  if (
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["atMs", "expiredCount", "id", "nextTargetIndex", "targetBuckets"])
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store sweep journal is invalid");
  }
  const sweep = value as SweepJournal;
  if (
    !/^[a-f0-9-]{36}$/u.test(sweep.id) ||
    !Number.isSafeInteger(sweep.atMs) ||
    sweep.atMs < 0 ||
    !Number.isSafeInteger(sweep.expiredCount) ||
    sweep.expiredCount < 1 ||
    !Array.isArray(sweep.targetBuckets) ||
    sweep.targetBuckets.length < 1 ||
    sweep.targetBuckets.length > BUCKET_COUNT ||
    sweep.targetBuckets.some((bucket, index) =>
      !Number.isSafeInteger(bucket) ||
      bucket < 0 ||
      bucket >= BUCKET_COUNT ||
      (index > 0 && sweep.targetBuckets[index - 1]! >= bucket)) ||
    !Number.isSafeInteger(sweep.nextTargetIndex) ||
    sweep.nextTargetIndex < 0 ||
    sweep.nextTargetIndex > sweep.targetBuckets.length
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store sweep journal is invalid");
  }
  return structuredClone(sweep);
}

function validateIndex(value: RunStoreIndexV2 | undefined): RunStoreIndexV2 {
  if (
    value === undefined ||
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    value.schemaVersion !== "2.0.0" ||
    value.format !== "bucketed-a-b" ||
    value.bucketCount !== BUCKET_COUNT ||
    value.buckets === null ||
    typeof value.buckets !== "object" ||
    Array.isArray(value.buckets) ||
    !exactKeys(value, [
      "bucketCount",
      "buckets",
      "format",
      ...(value.legacyMigration === undefined ? [] : ["legacyMigration"]),
      ...(value.pendingSweep === undefined ? [] : ["pendingSweep"]),
      "schemaVersion",
    ])
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store v2 index is invalid");
  }
  const buckets: Record<string, BucketDescriptor> = {};
  for (const [key, descriptor] of Object.entries(value.buckets)) {
    if (!/^\d{3}$/u.test(key)) {
      throw new RunStoreError("STATE_CORRUPT", "Run-store index contains an invalid bucket key");
    }
    const bucket = Number.parseInt(key, 10);
    if (bucket < 0 || bucket >= BUCKET_COUNT || key !== bucketKey(bucket)) {
      throw new RunStoreError("STATE_CORRUPT", "Run-store index contains an invalid bucket key");
    }
    buckets[key] = validateDescriptor(descriptor);
  }
  return {
    schemaVersion: "2.0.0",
    format: "bucketed-a-b",
    bucketCount: BUCKET_COUNT,
    buckets,
    ...(value.legacyMigration === undefined ? {} : { legacyMigration: validateMigration(value.legacyMigration) }),
    ...(value.pendingSweep === undefined ? {} : { pendingSweep: validateSweep(value.pendingSweep) }),
  };
}

function validateMutation(value: unknown): BucketMutation {
  if (
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["id", "kind"])
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store bucket mutation marker is invalid");
  }
  const mutation = value as BucketMutation;
  if (!(["ordinary", "migration", "sweep"] as string[]).includes(mutation.kind) || mutation.id.length === 0 || mutation.id.length > 128) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store bucket mutation marker is invalid");
  }
  return structuredClone(mutation);
}

function validateBucket(value: RunBucketV2 | undefined, expectedBucket: number): RunBucketV2 {
  if (
    value === undefined ||
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["bucket", "generation", "mutation", "previousGenerationSha256", "runs", "schemaVersion"]) ||
    value.schemaVersion !== "2.0.0" ||
    value.bucket !== expectedBucket ||
    !Number.isSafeInteger(value.generation) ||
    value.generation < 1 ||
    !/^[a-f0-9]{64}$/u.test(value.previousGenerationSha256) ||
    !Array.isArray(value.runs) ||
    value.runs.length < 1
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Run-store bucket is invalid");
  }
  validateMutation(value.mutation);
  let priorRunId = "";
  for (const entry of value.runs) {
    const runId = entry?.record?.runId;
    if (
      typeof runId !== "string" ||
      bucketForRun(runId as RunId) !== expectedBucket ||
      runId.localeCompare(priorRunId) <= 0
    ) {
      throw new RunStoreError("STATE_CORRUPT", "Run-store bucket ordering is invalid");
    }
    priorRunId = runId;
  }
  return structuredClone(value);
}

function validateTombstone(value: unknown): LegacyTombstoneV2 {
  if (
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["migratedTo", "retainedFilename", "schemaVersion", "sourcePayloadSha256", "sourceRunCount"])
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Legacy run-store migration tombstone is invalid");
  }
  const tombstone = value as LegacyTombstoneV2;
  if (
    tombstone.schemaVersion !== "2.0.0" ||
    tombstone.migratedTo !== INDEX_FILENAME ||
    tombstone.retainedFilename !== RETAINED_LEGACY_FILENAME ||
    !/^[a-f0-9]{64}$/u.test(tombstone.sourcePayloadSha256) ||
    !Number.isSafeInteger(tombstone.sourceRunCount) ||
    tombstone.sourceRunCount < 0
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Legacy run-store migration tombstone is invalid");
  }
  return structuredClone(tombstone);
}

/**
 * Operator-recoverable run authority split across 256 deterministic buckets.
 * The bounded integrity-protected coordinator serializes mutations and selects
 * one of two generations per bucket. Reads validate every current bucket;
 * ordinary writes replace only one bucket plus the coordinator. No record is
 * deleted implicitly. A journal makes multi-bucket expiry sweeps recoverable.
 */
export class DurableRunStore implements RunStore {
  readonly stateRoot: string;
  readonly #index: AtomicStateFile<RunStoreIndexV2>;
  readonly #options: Omit<DurableRunStoreOptions, "stateRoot">;

  constructor(options: DurableRunStoreOptions) {
    this.stateRoot = options.stateRoot;
    this.#options = {
      ...(options.now === undefined ? {} : { now: options.now }),
      ...(options.randomBytes === undefined ? {} : { randomBytes: options.randomBytes }),
      ...(options.minimumTtlMs === undefined ? {} : { minimumTtlMs: options.minimumTtlMs }),
      ...(options.maximumTtlMs === undefined ? {} : { maximumTtlMs: options.maximumTtlMs }),
      ...(options.maximumLeaseMs === undefined ? {} : { maximumLeaseMs: options.maximumLeaseMs }),
    };
    this.#index = new AtomicStateFile({
      stateRoot: options.stateRoot,
      filename: INDEX_FILENAME,
      kind: "production-monitoring-run-store-index-v2",
      maximumBytes: INDEX_MAXIMUM_BYTES,
    });
    this.#index.recoverAbandonedArtifacts();
    this.#index.transact((current) => {
      if (current !== undefined) {
        const index = validateIndex(current);
        this.#verifyMigration(index);
        this.#loadSnapshot(index, true);
        return { payload: index, result: undefined };
      }
      return this.#legacyFile().transact((legacyCurrent) => {
        const migration = this.#prepareLegacyMigrationLocked(legacyCurrent);
        const buckets = this.#writeMigrationBuckets(migration.snapshot, migration.marker.sourcePayloadSha256);
        return {
          payload: this.#legacyTombstone(migration.marker),
          result: {
            payload: { ...this.#emptyIndex(), buckets, legacyMigration: migration.marker },
            result: undefined,
          },
        };
      });
    });
    this.#recoverPendingSweep();
  }

  beginRun(input: BeginRunInput): BeginRunResult { return this.#mutate((store) => store.beginRun(input)); }
  beginChildVerification(input: BeginChildVerificationInput): BeginRunResult { return this.#mutate((store) => store.beginChildVerification(input)); }
  resumeRun(input: ResumeRunInput): BeginRunResult { return this.#mutate((store) => store.resumeRun(input)); }
  resumeRunWithHandle(input: ResumeRunWithHandleInput): BeginRunResult { return this.#mutate((store) => store.resumeRunWithHandle(input)); }
  getRunWithHandle(input: ResumeRunWithHandleInput): RunView { return this.#read((store) => store.getRunWithHandle(input)); }
  acknowledgeResume(access: RunAccess): RunView { return this.#mutate((store) => store.acknowledgeResume(access)); }
  getRun(access: RunAccess): RunView { return this.#read((store) => store.getRun(access)); }
  assertLease(access: RunAccess, leaseHandle: string): RunView { return this.#read((store) => store.assertLease(access, leaseHandle)); }
  getRecoveryContext(access: RunAccess): RunRecoveryContext { return this.#read((store) => store.getRecoveryContext(access)); }
  getSealedParent(input: Parameters<RunStore["getSealedParent"]>[0]): SealedParentView { return this.#read((store) => store.getSealedParent(input)); }
  listOwnedRuns(input: ListOwnedRunsInput): OwnedRunInventory { return this.#read((store) => store.listOwnedRuns(input)); }
  claimLease(access: RunAccess, ownerId: string, ttlMs: number): LeaseResult { return this.#mutate((store) => store.claimLease(access, ownerId, ttlMs)); }
  renewLease(access: RunAccess, leaseHandle: string, ttlMs: number): LeaseResult { return this.#mutate((store) => store.renewLease(access, leaseHandle, ttlMs)); }
  releaseLease(access: RunAccess, leaseHandle: string): RunView { return this.#mutate((store) => store.releaseLease(access, leaseHandle)); }
  allocateEvidence(access: RunAccess, leaseHandle: string): AllocateEvidenceResult { return this.#mutate((store) => store.allocateEvidence(access, leaseHandle)); }
  allocateContradiction(access: RunAccess, leaseHandle: string): AllocateContradictionResult { return this.#mutate((store) => store.allocateContradiction(access, leaseHandle)); }
  assertEvidenceOwnership(access: RunAccess, evidenceId: EvidenceId): void { this.#read((store) => store.assertEvidenceOwnership(access, evidenceId)); }
  assertContradictionOwnership(access: RunAccess, contradictionId: ContradictionId): void { this.#read((store) => store.assertContradictionOwnership(access, contradictionId)); }
  updateAudit(input: AuditUpdateInput): RunMutationResult { return this.#mutate((store) => store.updateAudit(input)); }
  beginFinalize(access: RunAccess, leaseHandle: string): RunMutationResult { return this.#mutate((store) => store.beginFinalize(access, leaseHandle)); }
  finalizeRun(input: FinalizeRunInput): RunMutationResult { return this.#mutate((store) => store.finalizeRun(input)); }
  abortRun(access: RunAccess, leaseHandle: string, reason: string): RunMutationResult { return this.#mutate((store) => store.abortRun(access, leaseHandle, reason)); }

  sweepExpired(): number {
    while (true) {
      this.#recoverPendingSweep();
      try {
        const prepared = this.#index.transact((current) => {
          const index = validateIndex(current);
          if (index.pendingSweep !== undefined) throw new PendingSweepObserved();
          const before = this.#loadSnapshot(index);
          const atMs = this.#options.now?.() ?? Date.now();
          const store = this.#memory(before, atMs);
          const expiredCount = store.sweepExpired();
          if (expiredCount === 0) return { payload: index, result: undefined };
          const after = store.exportSnapshot();
          const targetBuckets = this.#changedBuckets(before, after);
          const pendingSweep: SweepJournal = {
            id: randomUUID(),
            atMs,
            targetBuckets,
            nextTargetIndex: 0,
            expiredCount,
          };
          return { payload: { ...index, pendingSweep }, result: pendingSweep };
        });
        if (prepared === undefined) return 0;
        this.#recoverPendingSweep();
        return prepared.expiredCount;
      } catch (error) {
        if (!(error instanceof PendingSweepObserved)) throw error;
      }
    }
  }

  #emptyIndex(): RunStoreIndexV2 {
    return { schemaVersion: "2.0.0", format: "bucketed-a-b", bucketCount: BUCKET_COUNT, buckets: {} };
  }

  #memory(snapshot: RunStoreSnapshot, fixedNow?: number): InMemoryRunStore {
    return new InMemoryRunStore({
      ...this.#options,
      ...(fixedNow === undefined ? {} : { now: () => fixedNow }),
      snapshot,
    });
  }

  #read<R>(callback: (store: InMemoryRunStore) => R): R {
    while (true) {
      this.#recoverPendingSweep();
      try {
        return this.#index.inspect((current) => {
          const index = validateIndex(current);
          if (index.pendingSweep !== undefined) throw new PendingSweepObserved();
          return callback(this.#memory(this.#loadSnapshot(index)));
        });
      } catch (error) {
        if (!(error instanceof PendingSweepObserved)) throw error;
      }
    }
  }

  #mutate<R>(callback: (store: InMemoryRunStore) => R): R {
    while (true) {
      this.#recoverPendingSweep();
      try {
        return this.#index.transact((current) => {
          const index = validateIndex(current);
          if (index.pendingSweep !== undefined) throw new PendingSweepObserved();
          const before = this.#loadSnapshot(index);
          const store = this.#memory(before);
          const result = callback(store);
          const after = store.exportSnapshot();
          const changed = this.#changedBuckets(before, after);
          if (changed.length > 1) {
            throw new RunStoreError("STATE_CORRUPT", "An ordinary run-store mutation changed multiple buckets");
          }
          if (changed.length === 0) return { payload: index, result };
          const bucket = changed[0]!;
          const buckets = { ...index.buckets };
          buckets[bucketKey(bucket)] = this.#commitBucket(
            index,
            bucket,
            this.#entriesForBucket(after, bucket),
            { kind: "ordinary", id: randomUUID() },
          );
          return { payload: { ...index, buckets }, result };
        });
      } catch (error) {
        if (!(error instanceof PendingSweepObserved)) throw error;
      }
    }
  }

  #recoverPendingSweep(): void {
    const pending = this.#index.inspect((current) => validateIndex(current).pendingSweep !== undefined);
    if (!pending) return;
    while (true) {
      const complete = this.#index.transact((current) => {
        const index = validateIndex(current);
        const snapshot = this.#loadSnapshot(index);
        const sweep = index.pendingSweep;
        if (sweep === undefined) return { payload: index, result: true };
        if (sweep.nextTargetIndex >= sweep.targetBuckets.length) {
          const settled = { ...index };
          delete settled.pendingSweep;
          return { payload: settled, result: true };
        }
        const bucket = sweep.targetBuckets[sweep.nextTargetIndex]!;
        const activeEntries = this.#entriesForBucket(snapshot, bucket);
        const bucketStore = this.#memory({ schemaVersion: "1.0.0", runs: activeEntries }, sweep.atMs);
        const expiredHere = bucketStore.sweepExpired();
        if (expiredHere < 1) {
          throw new RunStoreError("STATE_CORRUPT", "Pending expiry sweep no longer changes its target bucket");
        }
        const nextEntries = bucketStore.exportSnapshot().runs;
        const buckets = { ...index.buckets };
        buckets[bucketKey(bucket)] = this.#commitBucket(
          index,
          bucket,
          nextEntries,
          { kind: "sweep", id: sweep.id },
        );
        return {
          payload: {
            ...index,
            buckets,
            pendingSweep: { ...sweep, nextTargetIndex: sweep.nextTargetIndex + 1 },
          },
          result: false,
        };
      });
      if (complete) return;
    }
  }

  #commitBucket(
    index: RunStoreIndexV2,
    bucket: number,
    entries: PersistedRunEntry[],
    mutation: BucketMutation,
  ): BucketDescriptor {
    if (entries.length < 1) {
      throw new RunStoreError("STATE_CORRUPT", "Run-store does not implicitly delete an emptied bucket");
    }
    const previous = index.buckets[bucketKey(bucket)];
    const slot: BucketSlot = previous === undefined ? "a" : inactiveSlot(previous.slot);
    const payload: RunBucketV2 = {
      schemaVersion: "2.0.0",
      bucket,
      generation: (previous?.generation ?? 0) + 1,
      previousGenerationSha256: previous?.payloadSha256 ?? ZERO_SHA256,
      mutation,
      runs: structuredClone(entries).sort((left, right) => left.record.runId.localeCompare(right.record.runId)),
    };
    validateBucket(payload, bucket);
    this.#bucketFile(bucket, slot).write(payload);
    return {
      slot,
      generation: payload.generation,
      payloadSha256: sha256Canonical(payload),
      runCount: payload.runs.length,
    };
  }

  #loadSnapshot(index: RunStoreIndexV2, fullInventory = false): RunStoreSnapshot {
    const files = fullInventory ? this.#bucketFiles() : this.#deterministicBucketFiles();
    const filesByBucket = new Map<number, Set<BucketSlot>>();
    for (const file of files) {
      const slots = filesByBucket.get(file.bucket) ?? new Set<BucketSlot>();
      slots.add(file.slot);
      filesByBucket.set(file.bucket, slots);
    }
    const runs: PersistedRunEntry[] = [];
    for (let bucket = 0; bucket < BUCKET_COUNT; bucket += 1) {
      const descriptor = index.buckets[bucketKey(bucket)];
      const slots = filesByBucket.get(bucket) ?? new Set<BucketSlot>();
      if (descriptor === undefined) {
        if (slots.size === 0) continue;
        if (slots.size !== 1 || !slots.has("a")) {
          throw new RunStoreError("STATE_CORRUPT", "Unindexed run bucket is not a bounded initial crash generation");
        }
        const debris = validateBucket(this.#bucketFile(bucket, "a").read(), bucket);
        if (debris.generation !== 1 || debris.previousGenerationSha256 !== ZERO_SHA256 || debris.mutation.kind !== "ordinary") {
          throw new RunStoreError("STATE_CORRUPT", "Unindexed run bucket is not a provable initial crash generation");
        }
        continue;
      }
      if (!slots.has(descriptor.slot)) {
        throw new RunStoreError("STATE_CORRUPT", "Indexed run bucket is missing");
      }
      const active = validateBucket(this.#bucketFile(bucket, descriptor.slot).read(), bucket);
      const activeSha256 = sha256Canonical(active);
      if (
        active.generation !== descriptor.generation ||
        activeSha256 !== descriptor.payloadSha256 ||
        active.runs.length !== descriptor.runCount
      ) {
        throw new RunStoreError("STATE_CORRUPT", "Indexed run bucket does not match its descriptor");
      }
      const other = inactiveSlot(descriptor.slot);
      if (slots.has(other)) {
        const inactive = validateBucket(this.#bucketFile(bucket, other).read(), bucket);
        const inactiveSha256 = sha256Canonical(inactive);
        const isPrevious =
          inactive.generation + 1 === active.generation &&
          active.previousGenerationSha256 === inactiveSha256;
        const isNextCrash =
          inactive.generation === active.generation + 1 &&
          inactive.previousGenerationSha256 === activeSha256;
        if (!isPrevious && !isNextCrash) {
          throw new RunStoreError("STATE_CORRUPT", "Inactive run bucket is neither the previous nor next generation");
        }
      }
      runs.push(...active.runs);
    }
    return this.#memory({ schemaVersion: "1.0.0", runs }).exportSnapshot();
  }

  #bucketFiles(): Array<{ bucket: number; slot: BucketSlot }> {
    const files: Array<{ bucket: number; slot: BucketSlot }> = [];
    for (const name of readdirSync(this.stateRoot)) {
      const artifact = BUCKET_LOCK_FILENAME.exec(name) ?? BUCKET_TEMP_FILENAME.exec(name);
      if (artifact !== null) {
        const bucket = Number.parseInt(artifact[1]!, 10);
        const slot = artifact[2] as BucketSlot;
        if (bucket < 0 || bucket >= BUCKET_COUNT || artifact[1] !== bucketKey(bucket)) {
          throw new RunStoreError("STATE_CORRUPT", "Run-store contains an invalid bucket artifact filename");
        }
        this.#bucketFile(bucket, slot).recoverAbandonedArtifacts();
        continue;
      }
      if (name.startsWith(".state-run-bucket-")) {
        throw new RunStoreError("STATE_CORRUPT", "Run-store contains malformed owned bucket temporary state");
      }
      if (!name.startsWith("run-bucket-")) continue;
      const match = BUCKET_FILENAME.exec(name);
      if (match === null) throw new RunStoreError("STATE_CORRUPT", "Run-store contains an invalid bucket filename");
      const bucket = Number.parseInt(match[1]!, 10);
      if (bucket < 0 || bucket >= BUCKET_COUNT || match[1] !== bucketKey(bucket)) {
        throw new RunStoreError("STATE_CORRUPT", "Run-store contains an invalid bucket filename");
      }
      files.push({ bucket, slot: match[2] as BucketSlot });
    }
    return files.sort((left, right) => left.bucket - right.bucket || left.slot.localeCompare(right.slot));
  }

  #deterministicBucketFiles(): Array<{ bucket: number; slot: BucketSlot }> {
    const files: Array<{ bucket: number; slot: BucketSlot }> = [];
    for (let bucket = 0; bucket < BUCKET_COUNT; bucket += 1) {
      for (const slot of ["a", "b"] as const) {
        if (existsSync(join(this.stateRoot, `run-bucket-${bucketKey(bucket)}-${slot}.json`))) {
          files.push({ bucket, slot });
        }
      }
    }
    return files;
  }

  #bucketFile(bucket: number, slot: BucketSlot): AtomicStateFile<RunBucketV2> {
    return new AtomicStateFile({
      stateRoot: this.stateRoot,
      filename: `run-bucket-${bucketKey(bucket)}-${slot}.json`,
      kind: "production-monitoring-run-bucket-v2",
    });
  }

  #entriesForBucket(snapshot: RunStoreSnapshot, bucket: number): PersistedRunEntry[] {
    return snapshot.runs.filter((entry) => bucketForRun(entry.record.runId) === bucket);
  }

  #changedBuckets(before: RunStoreSnapshot, after: RunStoreSnapshot): number[] {
    const changed: number[] = [];
    for (let bucket = 0; bucket < BUCKET_COUNT; bucket += 1) {
      if (canonicalJson(this.#entriesForBucket(before, bucket)) !== canonicalJson(this.#entriesForBucket(after, bucket))) {
        changed.push(bucket);
      }
    }
    return changed;
  }

  #legacyFile(): AtomicStateFile<unknown> {
    return new AtomicStateFile({
      stateRoot: this.stateRoot,
      filename: LEGACY_FILENAME,
      kind: "production-monitoring-run-store-v1",
    });
  }

  #retainedLegacyFile(): AtomicStateFile<RunStoreSnapshot> {
    return new AtomicStateFile({
      stateRoot: this.stateRoot,
      filename: RETAINED_LEGACY_FILENAME,
      kind: "production-monitoring-run-store-v1-retained",
    });
  }

  #prepareLegacyMigrationLocked(legacy: unknown): { snapshot: RunStoreSnapshot; marker: LegacyMigration } {
    const retainedExists = existsSync(join(this.stateRoot, RETAINED_LEGACY_FILENAME));
    if (legacy === undefined && !retainedExists) {
      const snapshot = EMPTY_SNAPSHOT;
      this.#retainedLegacyFile().write(snapshot);
      return {
        snapshot,
        marker: {
          sourceFilename: RETAINED_LEGACY_FILENAME,
          sourcePayloadSha256: sha256Canonical(snapshot),
          sourceRunCount: 0,
        },
      };
    }
    if (legacy === undefined) {
      const retained = this.#retainedLegacyFile().read();
      if (retained === undefined) throw new RunStoreError("STATE_CORRUPT", "Retained v1 run state is missing");
      const snapshot = this.#memory(retained).exportSnapshot();
      if (snapshot.runs.length !== 0 || this.#bucketFiles().length !== 0) {
        throw new RunStoreError("STATE_CORRUPT", "Uncommitted fresh-store migration staging is invalid");
      }
      return {
        snapshot,
        marker: {
          sourceFilename: RETAINED_LEGACY_FILENAME,
          sourcePayloadSha256: sha256Canonical(snapshot),
          sourceRunCount: 0,
        },
      };
    }
    let snapshot: RunStoreSnapshot;
    if ((legacy as { schemaVersion?: unknown } | undefined)?.schemaVersion === "1.0.0") {
      snapshot = this.#memory(legacy as RunStoreSnapshot).exportSnapshot();
      this.#retainedLegacyFile().write(snapshot);
    } else {
      const tombstone = validateTombstone(legacy);
      const retained = this.#retainedLegacyFile().read();
      if (retained === undefined) throw new RunStoreError("STATE_CORRUPT", "Retained v1 run state is missing");
      snapshot = this.#memory(retained).exportSnapshot();
      if (sha256Canonical(snapshot) !== tombstone.sourcePayloadSha256 || snapshot.runs.length !== tombstone.sourceRunCount) {
        throw new RunStoreError("STATE_CORRUPT", "Retained v1 run state does not match its tombstone");
      }
    }
    const marker: LegacyMigration = {
      sourceFilename: RETAINED_LEGACY_FILENAME,
      sourcePayloadSha256: sha256Canonical(snapshot),
      sourceRunCount: snapshot.runs.length,
    };
    return { snapshot, marker };
  }

  #writeMigrationBuckets(snapshot: RunStoreSnapshot, sourceSha256: Sha256): Record<string, BucketDescriptor> {
    const buckets: Record<string, BucketDescriptor> = {};
    const expected = new Map<number, RunBucketV2>();
    for (let bucket = 0; bucket < BUCKET_COUNT; bucket += 1) {
      const runs = this.#entriesForBucket(snapshot, bucket);
      if (runs.length === 0) continue;
      const payload: RunBucketV2 = {
        schemaVersion: "2.0.0",
        bucket,
        generation: 1,
        previousGenerationSha256: ZERO_SHA256,
        mutation: { kind: "migration", id: sourceSha256 },
        runs: structuredClone(runs),
      };
      expected.set(bucket, payload);
      buckets[bucketKey(bucket)] = {
        slot: "a",
        generation: 1,
        payloadSha256: sha256Canonical(payload),
        runCount: runs.length,
      };
    }
    for (const file of this.#bucketFiles()) {
      const expectedPayload = expected.get(file.bucket);
      if (file.slot !== "a") {
        throw new RunStoreError("STATE_CORRUPT", "Unexpected run bucket exists during v1 migration");
      }
      const current = validateBucket(this.#bucketFile(file.bucket, file.slot).read(), file.bucket);
      const isProvableMigrationStaging =
        current.generation === 1 &&
        current.previousGenerationSha256 === ZERO_SHA256 &&
        current.mutation.kind === "migration";
      if (expectedPayload === undefined) {
        if (!isProvableMigrationStaging) {
          throw new RunStoreError("STATE_CORRUPT", "Unexpected run bucket is not provable migration staging");
        }
        // The v2 index does not exist yet and both the index and v1 authority
        // locks are held. This slot is an uncommitted prior migration attempt,
        // not retained history; remove it before committing the new authority.
        unlinkAndSyncDirectory(
          join(this.stateRoot, `run-bucket-${bucketKey(file.bucket)}-a.json`),
          this.stateRoot,
        );
        continue;
      }
      if (canonicalJson(current) !== canonicalJson(expectedPayload)) {
        if (!isProvableMigrationStaging) {
          throw new RunStoreError("STATE_CORRUPT", "Partial v1 run migration is not a provable uncommitted generation");
        }
        this.#bucketFile(file.bucket, file.slot).write(expectedPayload);
      }
    }
    for (const [bucket, payload] of expected) {
      if (!existsSync(join(this.stateRoot, `run-bucket-${bucketKey(bucket)}-a.json`))) {
        this.#bucketFile(bucket, "a").write(payload);
      }
    }
    return buckets;
  }

  #legacyTombstone(marker: LegacyMigration): LegacyTombstoneV2 {
    return {
      schemaVersion: "2.0.0",
      migratedTo: INDEX_FILENAME,
      retainedFilename: RETAINED_LEGACY_FILENAME,
      sourcePayloadSha256: marker.sourcePayloadSha256,
      sourceRunCount: marker.sourceRunCount,
    };
  }

  #verifyMigration(index: RunStoreIndexV2): void {
    const legacyExists = existsSync(join(this.stateRoot, LEGACY_FILENAME));
    const retainedExists = existsSync(join(this.stateRoot, RETAINED_LEGACY_FILENAME));
    if (index.legacyMigration === undefined) {
      if (legacyExists || retainedExists) throw new RunStoreError("STATE_CORRUPT", "Unexpected v1 run state exists beside a fresh v2 store");
      return;
    }
    if (!legacyExists || !retainedExists) throw new RunStoreError("STATE_CORRUPT", "Migrated v1 run state is incomplete");
    const tombstone = validateTombstone(this.#legacyFile().read());
    const retained = this.#retainedLegacyFile().read();
    if (retained === undefined) throw new RunStoreError("STATE_CORRUPT", "Retained v1 run state is missing");
    const snapshot = this.#memory(retained).exportSnapshot();
    if (
      tombstone.sourcePayloadSha256 !== index.legacyMigration.sourcePayloadSha256 ||
      tombstone.sourceRunCount !== index.legacyMigration.sourceRunCount ||
      sha256Canonical(snapshot) !== index.legacyMigration.sourcePayloadSha256 ||
      snapshot.runs.length !== index.legacyMigration.sourceRunCount
    ) {
      throw new RunStoreError("STATE_CORRUPT", "Migrated v1 run state no longer matches its committed marker");
    }
    const current = this.#loadSnapshot(index);
    const currentById = new Map(current.runs.map((entry) => [entry.record.runId, entry]));
    for (const entry of snapshot.runs) {
      if (!currentById.has(entry.record.runId)) {
        throw new RunStoreError("STATE_CORRUPT", "A migrated run is missing from v2 state");
      }
    }
  }
}
