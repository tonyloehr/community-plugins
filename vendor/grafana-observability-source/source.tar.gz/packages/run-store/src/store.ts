import {
  randomBytes as secureRandomBytes,
  timingSafeEqual,
} from "node:crypto";

import {
  computeIntegrity,
  sha256Bytes,
  sha256Canonical,
  verifyIntegrity,
} from "@codex-production-monitoring/contracts";
import type {
  ContradictionId,
  EvidenceId,
  PrincipalBinding,
  RunHandle,
  RunId,
  RunRecord,
  Sha256,
} from "@codex-production-monitoring/contracts";

import {
  MAXIMUM_AUTHORITY_COMPONENT_REVISION,
  MAXIMUM_RUN_CREATION_SEQUENCE,
} from "./types.ts";
import type {
  AllocateContradictionResult,
  AllocateEvidenceResult,
  AuditUpdateInput,
  BeginChildVerificationInput,
  BeginRunInput,
  BeginRunResult,
  FinalizeRunInput,
  ListOwnedRunsInput,
  LeaseResult,
  OwnedRunInventory,
  PersistedRunEntry,
  PrincipalIdentity,
  ResumeRunInput,
  ResumeRunWithHandleInput,
  RunAccess,
  RunRecoveryContext,
  RunMutationResult,
  RunStoreOptions,
  RunStoreSnapshot,
  SealedParentView,
  RunView,
} from "./types.ts";

export class RunStoreError extends Error {
  readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = "RunStoreError";
    this.code = code;
  }
}

interface LeaseRecord {
  handleSha256: Sha256;
  ownerSha256: Sha256;
  expiresAtMs: number;
}

interface InternalRun {
  record: RunRecord;
  creationSequence: number;
  revision: number;
  idempotencySha256: Sha256;
  request: BeginRunInput["request"];
  policy: BeginRunInput["policy"];
  lease?: LeaseRecord;
  verificationContractSha256?: Sha256;
  abortReason?: string;
  recoveryHandleSha256s?: Sha256[];
}

const HANDLE_DOMAIN = "pm-run-handle-v1\0";
const LEASE_DOMAIN = "pm-run-lease-v1\0";
const IDEMPOTENCY_DOMAIN = "pm-run-idempotency-v1\0";
const PRINCIPAL_DOMAIN = "pm-principal-v1\0";
const DEFAULT_MINIMUM_TTL_MS = 1_000;
const DEFAULT_MAXIMUM_TTL_MS = 24 * 60 * 60 * 1_000;
const DEFAULT_MAXIMUM_LEASE_MS = (5 * 60 + 30) * 1_000;
const DEFAULT_RUN_INVENTORY_LIMIT = 20;
const MAXIMUM_RUN_INVENTORY_LIMIT = 32;
const RUN_ID_V3 = /^pmrun_q([0-9a-z]{8})_([A-Za-z0-9_-]{16})$/u;

function deepFreeze<T>(value: T, seen = new Set<object>()): Readonly<T> {
  if (value === null || typeof value !== "object" || seen.has(value)) return value;
  seen.add(value);
  for (const child of Object.values(value as Record<string, unknown>)) deepFreeze(child, seen);
  return Object.freeze(value);
}

function cloneFrozen<T>(value: T): Readonly<T> {
  return deepFreeze(structuredClone(value));
}

function safeEqual(left: string, right: string): boolean {
  const leftBuffer = Buffer.from(left, "utf8");
  const rightBuffer = Buffer.from(right, "utf8");
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

function assertNonEmpty(value: string, label: string, maximum = 512): void {
  const hasControlCharacter = [...value].some((character) => {
    const codePoint = character.codePointAt(0)!;
    return codePoint <= 0x1f || codePoint === 0x7f;
  });
  if (value.length === 0 || value.length > maximum || hasControlCharacter) {
    throw new RunStoreError("INVALID_INPUT", `${label} is invalid`);
  }
}

export class InMemoryRunStore {
  readonly #runs = new Map<RunId, InternalRun>();
  readonly #handleIndex = new Map<Sha256, RunId>();
  readonly #recoveryHandleIndex = new Map<Sha256, RunId>();
  readonly #idempotencyIndex = new Map<Sha256, RunId>();
  readonly #evidenceOwners = new Map<EvidenceId, RunId>();
  readonly #contradictionOwners = new Map<ContradictionId, RunId>();
  readonly #now: () => number;
  readonly #randomBytes: (size: number) => Buffer;
  readonly #minimumTtlMs: number;
  readonly #maximumTtlMs: number;
  readonly #maximumLeaseMs: number;

  constructor(options: RunStoreOptions & { snapshot?: RunStoreSnapshot } = {}) {
    this.#now = options.now ?? Date.now;
    this.#randomBytes = options.randomBytes ?? secureRandomBytes;
    this.#minimumTtlMs = options.minimumTtlMs ?? DEFAULT_MINIMUM_TTL_MS;
    this.#maximumTtlMs = options.maximumTtlMs ?? DEFAULT_MAXIMUM_TTL_MS;
    this.#maximumLeaseMs = options.maximumLeaseMs ?? DEFAULT_MAXIMUM_LEASE_MS;
    if (options.snapshot !== undefined) this.#importSnapshot(options.snapshot);
  }

  beginRun(input: BeginRunInput): BeginRunResult {
    if (input.request.workflow === "verify" || input.request.parentRunId !== undefined) {
      throw new RunStoreError(
        "INVALID_CHILD",
        "Verification requests must use the sealed-parent verification flow",
      );
    }
    return this.#begin(input);
  }

  beginChildVerification(input: BeginChildVerificationInput): BeginRunResult {
    if (input.request.workflow !== "verify" || input.request.parentRunId !== input.parentRunId) {
      throw new RunStoreError("INVALID_CHILD", "A child verification request must name its parent run");
    }
    const parent = this.#runs.get(input.parentRunId);
    if (parent === undefined || parent.record.state !== "SEALED") {
      throw new RunStoreError("PARENT_NOT_AVAILABLE", "The sealed parent run is not available");
    }
    const childPrincipal = this.#principalBinding(input.principal);
    if (
      !safeEqual(parent.record.principal.issuerAlias, childPrincipal.issuerAlias) ||
      !safeEqual(parent.record.principal.subjectSha256, childPrincipal.subjectSha256) ||
      !safeEqual(parent.record.principal.tenantSha256, childPrincipal.tenantSha256)
    ) {
      throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    }
    if (
      parent.verificationContractSha256 === undefined ||
      !safeEqual(parent.verificationContractSha256, input.verificationContractSha256)
    ) {
      throw new RunStoreError("VERIFICATION_BINDING_MISMATCH", "The parent verification contract does not match");
    }
    if (parent.record.profileAlias !== input.policy.profileAlias) {
      throw new RunStoreError("VERIFICATION_BINDING_MISMATCH", "The child profile differs from its parent");
    }
    if (sha256Canonical(parent.record.scope) !== sha256Canonical(input.policy.scope)) {
      throw new RunStoreError("VERIFICATION_BINDING_MISMATCH", "The child scope differs from its parent");
    }
    const childHashes = Object.fromEntries(
      Object.values(input.policy.operations).map((operation) => [
        operation.operationId,
        operation.definitionSha256,
      ]),
    );
    if (sha256Canonical(parent.record.allowedOperationHashes) !== sha256Canonical(childHashes)) {
      throw new RunStoreError("VERIFICATION_BINDING_MISMATCH", "The child operation snapshot differs from its parent");
    }
    return this.#begin(input, {
      runId: input.parentRunId,
      verificationContractSha256: input.verificationContractSha256,
    });
  }

  resumeRun(input: ResumeRunInput): BeginRunResult {
    const run = this.#runs.get(input.runId);
    if (run === undefined) throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    this.#expireIfNeeded(input.runId, run);
    this.#authorizePrincipalAndBindings(
      run,
      input.principal,
      input.expectedProfileAlias,
      input.expectedTrustBundleSha256,
    );
    this.#assertRevision(run, input.expectedRevision);
    if (run.record.state !== "OPEN" && run.record.state !== "FINALIZING") {
      throw new RunStoreError("RUN_TERMINAL", "A terminal run cannot be resumed");
    }
    this.#clearExpiredLease(run);
    if (run.lease !== undefined) throw new RunStoreError("LEASE_HELD", "The run has an active lease");
    this.#assertRevisionCapacity(run);

    this.#rememberRecoveryHandle(input.runId, run, run.record.handleSha256);
    this.#handleIndex.delete(run.record.handleSha256);
    const handle = this.#newUniqueRunHandle();
    const handleSha256 = this.#hashToken(HANDLE_DOMAIN, handle);
    run.record = this.#updateRecord(run.record, { handleSha256 });
    this.#incrementRevision(run);
    this.#handleIndex.set(handleSha256, input.runId);
    return { runId: input.runId, revision: run.revision, replayed: false, handle };
  }

  resumeRunWithHandle(input: ResumeRunWithHandleInput): BeginRunResult {
    const { runId, run } = this.#authorizeRetainedHandle(input);
    if (run.record.state !== "OPEN" && run.record.state !== "FINALIZING") {
      throw new RunStoreError("RUN_TERMINAL", "A terminal run cannot be resumed");
    }
    this.#clearExpiredLease(run);
    if (run.lease !== undefined) throw new RunStoreError("LEASE_HELD", "The run has an active lease");
    this.#assertRevisionCapacity(run);

    this.#rememberRecoveryHandle(runId, run, run.record.handleSha256);
    this.#handleIndex.delete(run.record.handleSha256);
    const handle = this.#newUniqueRunHandle();
    const replacementHash = this.#hashToken(HANDLE_DOMAIN, handle);
    run.record = this.#updateRecord(run.record, { handleSha256: replacementHash });
    this.#incrementRevision(run);
    this.#handleIndex.set(replacementHash, runId);
    return { runId, revision: run.revision, replayed: false, handle };
  }

  getRunWithHandle(input: ResumeRunWithHandleInput): RunView {
    const { run } = this.#authorizeRetainedHandle(input);
    this.#clearExpiredLease(run);
    return this.#view(run);
  }

  acknowledgeResume(access: RunAccess): RunView {
    const { run } = this.#authorize(access);
    this.#assertRevisionCapacity(run);
    for (const hash of run.recoveryHandleSha256s ?? []) this.#recoveryHandleIndex.delete(hash);
    delete run.recoveryHandleSha256s;
    this.#incrementRevision(run);
    return this.#view(run);
  }

  #authorizeRetainedHandle(input: ResumeRunWithHandleInput): { runId: RunId; run: InternalRun } {
    const handleSha256 = this.#hashToken(HANDLE_DOMAIN, input.handle);
    const runId = this.#handleIndex.get(handleSha256) ?? this.#recoveryHandleIndex.get(handleSha256);
    if (runId === undefined) throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    const run = this.#runs.get(runId);
    const active = run !== undefined && safeEqual(run.record.handleSha256, handleSha256);
    const recovery = run?.recoveryHandleSha256s?.some((hash) => safeEqual(hash, handleSha256)) === true;
    if (run === undefined || (!active && !recovery)) {
      throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    }
    if (this.#expireIfNeeded(runId, run)) {
      throw new RunStoreError("RUN_EXPIRED", "The run has expired");
    }
    this.#authorizePrincipalAndBindings(
      run,
      input.principal,
      input.expectedProfileAlias,
      input.expectedTrustBundleSha256,
    );
    if (input.expectedRevision !== undefined) this.#assertRevision(run, input.expectedRevision);
    return { runId, run };
  }

  getRun(access: RunAccess): RunView {
    const { run } = this.#authorize(access);
    return this.#view(run);
  }

  assertLease(access: RunAccess, leaseHandle: string): RunView {
    const { run } = this.#authorize(access);
    this.#assertLease(run, leaseHandle);
    return this.#view(run);
  }

  getRecoveryContext(access: RunAccess): RunRecoveryContext {
    const { run } = this.#authorize(access);
    return cloneFrozen({ request: run.request, policy: run.policy });
  }

  getSealedParent(input: {
    principal: PrincipalIdentity;
    runId: RunId;
    expectedProfileAlias: string;
    expectedTrustBundleSha256: Sha256;
  }): SealedParentView {
    const run = this.#runs.get(input.runId);
    if (run === undefined || run.record.state !== "SEALED" || run.verificationContractSha256 === undefined) {
      throw new RunStoreError("PARENT_NOT_AVAILABLE", "The sealed parent run is not available");
    }
    const principal = this.#principalBinding(input.principal);
    if (
      !safeEqual(run.record.principal.issuerAlias, principal.issuerAlias) ||
      !safeEqual(run.record.principal.subjectSha256, principal.subjectSha256) ||
      !safeEqual(run.record.principal.tenantSha256, principal.tenantSha256) ||
      !safeEqual(run.record.profileAlias, input.expectedProfileAlias) ||
      !safeEqual(run.record.trustBundleSha256, input.expectedTrustBundleSha256)
    ) {
      throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    }
    return cloneFrozen({
      record: run.record,
      revision: run.revision,
      verificationContractSha256: run.verificationContractSha256,
    });
  }

  listOwnedRuns(input: ListOwnedRunsInput): OwnedRunInventory {
    assertNonEmpty(input.expectedProfileAlias, "profile alias", 128);
    const limit = input.limit ?? DEFAULT_RUN_INVENTORY_LIMIT;
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > MAXIMUM_RUN_INVENTORY_LIMIT) {
      throw new RunStoreError(
        "INVALID_INPUT",
        `run inventory limit must be between 1 and ${MAXIMUM_RUN_INVENTORY_LIMIT}`,
      );
    }
    const principal = this.#principalBinding(input.principal);
    const now = this.#now();
    const owned = [...this.#runs.values()]
      .filter((run) =>
        safeEqual(run.record.principal.issuerAlias, principal.issuerAlias) &&
        safeEqual(run.record.principal.subjectSha256, principal.subjectSha256) &&
        safeEqual(run.record.principal.tenantSha256, principal.tenantSha256) &&
        safeEqual(run.record.principal.sessionSha256, principal.sessionSha256) &&
        safeEqual(run.record.profileAlias, input.expectedProfileAlias) &&
        safeEqual(run.record.trustBundleSha256, input.expectedTrustBundleSha256)
      )
      .sort((left, right) =>
        right.creationSequence - left.creationSequence ||
        right.record.runId.localeCompare(left.record.runId)
      );

    const runs = owned.slice(0, limit).map((run) => {
      const expired =
        (run.record.state === "OPEN" || run.record.state === "FINALIZING") &&
        now >= Date.parse(run.record.expiresAt);
      const activeLease = !expired && run.lease !== undefined && now < run.lease.expiresAtMs;
      return cloneFrozen({
        runId: run.record.runId,
        creationSequence: run.creationSequence,
        state: expired ? "EXPIRED" as const : run.record.state,
        workflow: run.record.workflow,
        origin: run.record.origin,
        scope: run.record.scope,
        window: run.record.window,
        ...(run.record.baselineWindow === undefined
          ? {}
          : { baselineWindow: run.record.baselineWindow }),
        ...(run.record.parent === undefined ? {} : { parent: run.record.parent }),
        evidenceIds: run.record.evidenceIds,
        contradictionIds: run.record.contradictionIds,
        audit: run.record.audit,
        createdAt: run.record.createdAt,
        expiresAt: run.record.expiresAt,
        ...(run.record.finalizedAt === undefined ? {} : { finalizedAt: run.record.finalizedAt }),
        ...(run.record.abortedAt === undefined ? {} : { abortedAt: run.record.abortedAt }),
        revision: run.revision,
        hasLease: activeLease,
        ...(activeLease ? { leaseExpiresAt: new Date(run.lease!.expiresAtMs).toISOString() } : {}),
      });
    });
    return cloneFrozen({ runs, omittedCount: owned.length - runs.length });
  }

  claimLease(access: RunAccess, ownerId: string, ttlMs: number): LeaseResult {
    assertNonEmpty(ownerId, "lease owner", 256);
    this.#validateLeaseTtl(ttlMs);
    const { run } = this.#authorize(access);
    if (run.record.state !== "OPEN" && run.record.state !== "FINALIZING") {
      throw new RunStoreError("RUN_TERMINAL", "A terminal run cannot be leased");
    }
    this.#clearExpiredLease(run);
    if (run.lease !== undefined) throw new RunStoreError("LEASE_HELD", "The run has an active lease");
    this.#assertRevisionCapacity(run);
    const leaseHandle = this.#newToken("pmls_");
    const expiresAtMs = this.#now() + ttlMs;
    run.lease = {
      handleSha256: this.#hashToken(LEASE_DOMAIN, leaseHandle),
      ownerSha256: sha256Bytes(`${LEASE_DOMAIN}${ownerId}`),
      expiresAtMs,
    };
    this.#incrementRevision(run);
    return { leaseHandle, revision: run.revision, expiresAt: new Date(expiresAtMs).toISOString() };
  }

  renewLease(access: RunAccess, leaseHandle: string, ttlMs: number): LeaseResult {
    this.#validateLeaseTtl(ttlMs);
    const { run } = this.#authorize(access);
    const now = this.#now();
    const lease = this.#assertLease(run, leaseHandle, now);
    this.#assertRevisionCapacity(run);
    const expiresAtMs = Math.max(lease.expiresAtMs, now + ttlMs);
    run.lease = { ...lease, expiresAtMs };
    this.#incrementRevision(run);
    return { leaseHandle, revision: run.revision, expiresAt: new Date(expiresAtMs).toISOString() };
  }

  releaseLease(access: RunAccess, leaseHandle: string): RunView {
    const { run } = this.#authorize(access);
    this.#assertLease(run, leaseHandle);
    this.#assertRevisionCapacity(run);
    delete run.lease;
    this.#incrementRevision(run);
    return this.#view(run);
  }

  allocateEvidence(access: RunAccess, leaseHandle: string): AllocateEvidenceResult {
    const { runId, run } = this.#authorize(access);
    this.#assertMutable(run, "OPEN");
    this.#assertLease(run, leaseHandle);
    this.#assertRevisionCapacity(run);
    const evidenceId = this.#newOwnedId("pmev_", this.#evidenceOwners) as EvidenceId;
    this.#evidenceOwners.set(evidenceId, runId);
    run.record = this.#updateRecord(run.record, {
      evidenceIds: [...run.record.evidenceIds, evidenceId],
    });
    this.#incrementRevision(run);
    return { evidenceId, revision: run.revision, record: this.#view(run).record };
  }

  allocateContradiction(access: RunAccess, leaseHandle: string): AllocateContradictionResult {
    const { runId, run } = this.#authorize(access);
    this.#assertMutable(run, "OPEN");
    this.#assertLease(run, leaseHandle);
    this.#assertRevisionCapacity(run);
    const contradictionId = this.#newOwnedId("pmcon_", this.#contradictionOwners) as ContradictionId;
    this.#contradictionOwners.set(contradictionId, runId);
    run.record = this.#updateRecord(run.record, {
      contradictionIds: [...run.record.contradictionIds, contradictionId],
    });
    this.#incrementRevision(run);
    return { contradictionId, revision: run.revision, record: this.#view(run).record };
  }

  assertEvidenceOwnership(access: RunAccess, evidenceId: EvidenceId): void {
    const { runId } = this.#authorize(access);
    if (this.#evidenceOwners.get(evidenceId) !== runId) {
      throw new RunStoreError("EVIDENCE_NOT_OWNED", "Evidence is not owned by this run");
    }
  }

  assertContradictionOwnership(access: RunAccess, contradictionId: ContradictionId): void {
    const { runId } = this.#authorize(access);
    if (this.#contradictionOwners.get(contradictionId) !== runId) {
      throw new RunStoreError("CONTRADICTION_NOT_OWNED", "Contradiction is not owned by this run");
    }
  }

  updateAudit(input: AuditUpdateInput): RunMutationResult {
    const { run } = this.#authorize(input.access);
    this.#assertLease(run, input.leaseHandle);
    this.#assertMutable(run, "OPEN", "FINALIZING");
    this.#assertRevisionCapacity(run);
    run.record = this.#updateRecord(run.record, {
      audit: { ...run.record.audit, state: input.state },
    });
    this.#incrementRevision(run);
    return { revision: run.revision, record: this.#view(run).record };
  }

  beginFinalize(access: RunAccess, leaseHandle: string): RunMutationResult {
    const { run } = this.#authorize(access);
    this.#assertMutable(run, "OPEN");
    this.#assertLease(run, leaseHandle);
    if (run.record.audit.required && run.record.audit.state !== "HEALTHY") {
      throw new RunStoreError("AUDIT_NOT_DURABLE", "Required audit state is not healthy");
    }
    this.#assertRevisionCapacity(run);
    run.record = this.#updateRecord(run.record, { state: "FINALIZING" });
    this.#incrementRevision(run);
    return { revision: run.revision, record: this.#view(run).record };
  }

  finalizeRun(input: FinalizeRunInput): RunMutationResult {
    const { runId, run } = this.#authorize(input.access);
    this.#assertMutable(run, "FINALIZING");
    this.#assertLease(run, input.leaseHandle);
    if (run.record.audit.required && run.record.audit.state !== "HEALTHY") {
      throw new RunStoreError("AUDIT_NOT_DURABLE", "Required audit state is not healthy");
    }
    this.#assertRevisionCapacity(run);
    const finalizedAt = new Date(this.#now()).toISOString();
    run.record = this.#updateRecord(run.record, { state: "SEALED", finalizedAt });
    run.verificationContractSha256 = input.verificationContractSha256;
    this.#incrementRevision(run);
    this.#invalidateAccess(runId, run);
    return { revision: run.revision, record: this.#view(run).record };
  }

  abortRun(access: RunAccess, leaseHandle: string, reason: string): RunMutationResult {
    assertNonEmpty(reason, "abort reason", 128);
    const { runId, run } = this.#authorize(access);
    this.#assertMutable(run, "OPEN", "FINALIZING");
    this.#assertLease(run, leaseHandle);
    this.#assertRevisionCapacity(run);
    run.record = this.#updateRecord(run.record, {
      state: "ABORTED",
      abortedAt: new Date(this.#now()).toISOString(),
    });
    run.abortReason = reason;
    this.#incrementRevision(run);
    this.#invalidateAccess(runId, run);
    return { revision: run.revision, record: this.#view(run).record };
  }

  sweepExpired(): number {
    let expired = 0;
    for (const [runId, run] of this.#runs) {
      if (this.#expireIfNeeded(runId, run)) expired += 1;
    }
    return expired;
  }

  #begin(
    input: BeginRunInput,
    parent?: { runId: RunId; verificationContractSha256: Sha256 },
  ): BeginRunResult {
    this.#validateTtl(input.ttlMs);
    assertNonEmpty(input.idempotencyKey, "idempotency key", 256);
    if (input.request.profileAlias !== input.policy.profileAlias) {
      throw new RunStoreError("POLICY_BINDING_MISMATCH", "Request and policy profile differ");
    }
    if (input.request.origin !== input.policy.origin) {
      throw new RunStoreError("POLICY_BINDING_MISMATCH", "Request and policy origin differ");
    }
    const requestSha256 = sha256Canonical(input.request);
    if (requestSha256 !== input.policy.requestSha256) {
      throw new RunStoreError("POLICY_BINDING_MISMATCH", "Request hash differs from compiled policy");
    }
    const principal = this.#principalBinding(input.principal);
    const idempotencySha256 = sha256Canonical({
      domain: IDEMPOTENCY_DOMAIN,
      principal,
      key: input.idempotencyKey,
    });
    const existingId = this.#idempotencyIndex.get(idempotencySha256);
    if (existingId !== undefined) {
      const existing = this.#runs.get(existingId)!;
      if (
        existing.record.requestSha256 !== requestSha256 ||
        existing.record.trustBundleSha256 !== input.policy.trustBundleSha256 ||
        existing.record.profileAlias !== input.policy.profileAlias
      ) {
        throw new RunStoreError("IDEMPOTENCY_CONFLICT", "The idempotency key is bound to another request");
      }
      return { runId: existingId, revision: existing.revision, replayed: true };
    }

    const now = this.#now();
    const creationSequence = this.#nextRunCreationSequence(
      principal,
      input.policy.profileAlias,
      input.policy.trustBundleSha256,
    );
    const runId = this.#newRunId(creationSequence);
    const handle = this.#newUniqueRunHandle();
    const handleSha256 = this.#hashToken(HANDLE_DOMAIN, handle);
    const allowedOperationHashes = Object.fromEntries(
      Object.values(input.policy.operations).map((operation) => [
        operation.operationId,
        operation.definitionSha256,
      ]),
    );
    const baseRecord: RunRecord = {
      schemaVersion: "1.0.0",
      runId,
      state: "OPEN",
      workflow: input.request.workflow,
      origin: input.request.origin,
      principal,
      handleSha256,
      requestSha256,
      trustBundleSha256: input.policy.trustBundleSha256,
      profileAlias: input.policy.profileAlias,
      scope: { ...input.policy.scope },
      window: { ...input.request.window },
      ...(input.request.baselineWindow === undefined
        ? {}
        : { baselineWindow: { ...input.request.baselineWindow } }),
      ...(input.request.incidentAlias === undefined ? {} : { incidentAlias: input.request.incidentAlias }),
      ...(parent === undefined ? {} : { parent }),
      allowedOperationHashes,
      evidenceIds: [],
      contradictionIds: [],
      audit: {
        required: input.policy.auditRequired,
        state: input.policy.auditRequired ? "DEGRADED" : "HEALTHY",
      },
      createdAt: new Date(now).toISOString(),
      expiresAt: new Date(now + input.ttlMs).toISOString(),
      integrity: {
        hashContractVersion: "sha256-jcs-v1",
        algorithm: "sha256",
        canonicalization: "RFC8785",
        contentSha256: "0".repeat(64) as Sha256,
      },
    };
    const run: InternalRun = {
      record: this.#updateRecord(baseRecord, {}),
      creationSequence,
      revision: 1,
      idempotencySha256,
      request: structuredClone(input.request),
      policy: structuredClone(input.policy),
    };
    this.#runs.set(runId, run);
    this.#handleIndex.set(handleSha256, runId);
    this.#idempotencyIndex.set(idempotencySha256, runId);
    return { runId, revision: 1, replayed: false, handle };
  }

  #authorize(access: RunAccess): { runId: RunId; run: InternalRun } {
    const handleSha256 = this.#hashToken(HANDLE_DOMAIN, access.handle);
    const runId = this.#handleIndex.get(handleSha256);
    if (runId === undefined) throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    const run = this.#runs.get(runId);
    if (run === undefined || !safeEqual(run.record.handleSha256, handleSha256)) {
      throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    }
    if (this.#expireIfNeeded(runId, run)) {
      throw new RunStoreError("RUN_EXPIRED", "The run has expired");
    }
    this.#authorizePrincipalAndBindings(
      run,
      access.principal,
      access.expectedProfileAlias,
      access.expectedTrustBundleSha256,
    );
    this.#assertRevision(run, access.expectedRevision);
    return { runId, run };
  }

  #authorizePrincipalAndBindings(
    run: InternalRun,
    identity: PrincipalIdentity,
    profileAlias: string,
    trustBundleSha256: Sha256,
  ): void {
    const principal = this.#principalBinding(identity);
    if (
      !safeEqual(run.record.principal.issuerAlias, principal.issuerAlias) ||
      !safeEqual(run.record.principal.subjectSha256, principal.subjectSha256) ||
      !safeEqual(run.record.principal.tenantSha256, principal.tenantSha256) ||
      !safeEqual(run.record.principal.sessionSha256, principal.sessionSha256) ||
      !safeEqual(run.record.profileAlias, profileAlias) ||
      !safeEqual(run.record.trustBundleSha256, trustBundleSha256)
    ) {
      throw new RunStoreError("ACCESS_DENIED", "Run access denied");
    }
  }

  #principalBinding(identity: PrincipalIdentity): PrincipalBinding {
    assertNonEmpty(identity.issuerAlias, "principal issuer", 128);
    assertNonEmpty(identity.subject, "principal subject");
    assertNonEmpty(identity.tenant, "principal tenant");
    assertNonEmpty(identity.session, "principal session");
    return {
      issuerAlias: identity.issuerAlias,
      subjectSha256: sha256Bytes(`${PRINCIPAL_DOMAIN}subject\0${identity.subject}`),
      tenantSha256: sha256Bytes(`${PRINCIPAL_DOMAIN}tenant\0${identity.tenant}`),
      sessionSha256: sha256Bytes(`${PRINCIPAL_DOMAIN}session\0${identity.session}`),
    };
  }

  #assertRevision(run: InternalRun, expectedRevision: number): void {
    if (!Number.isSafeInteger(expectedRevision) || expectedRevision !== run.revision) {
      throw new RunStoreError("STALE_REVISION", "The run revision has changed");
    }
  }

  #incrementRevision(run: InternalRun): void {
    this.#assertRevisionCapacity(run);
    run.revision += 1;
  }

  #assertRevisionCapacity(run: InternalRun): void {
    if (run.revision >= MAXIMUM_AUTHORITY_COMPONENT_REVISION) {
      throw new RunStoreError(
        "RUNTIME_CAPACITY",
        "Run authority reached its bounded revision capacity",
      );
    }
  }

  #assertLease(run: InternalRun, leaseHandle: string, now = this.#now()): LeaseRecord {
    this.#clearExpiredLease(run, now);
    if (
      run.lease === undefined ||
      !safeEqual(run.lease.handleSha256, this.#hashToken(LEASE_DOMAIN, leaseHandle))
    ) {
      throw new RunStoreError("LEASE_REQUIRED", "A current run lease is required");
    }
    return run.lease;
  }

  #clearExpiredLease(run: InternalRun, now = this.#now()): void {
    if (run.lease !== undefined && now >= run.lease.expiresAtMs) delete run.lease;
  }

  #assertMutable(run: InternalRun, ...states: RunRecord["state"][]): void {
    if (!states.includes(run.record.state)) {
      throw new RunStoreError("INVALID_STATE", `Run state ${run.record.state} does not permit this transition`);
    }
  }

  #validateTtl(ttlMs: number): void {
    if (
      !Number.isSafeInteger(ttlMs) ||
      ttlMs < this.#minimumTtlMs ||
      ttlMs > this.#maximumTtlMs
    ) {
      throw new RunStoreError("INVALID_TTL", "Run TTL is outside the approved range");
    }
  }

  #validateLeaseTtl(ttlMs: number): void {
    if (!Number.isSafeInteger(ttlMs) || ttlMs < 1 || ttlMs > this.#maximumLeaseMs) {
      throw new RunStoreError("INVALID_LEASE_TTL", "Lease TTL is outside the approved range");
    }
  }

  #hashToken(domain: string, token: string): Sha256 {
    assertNonEmpty(token, "token", 512);
    return sha256Bytes(`${domain}${token}`);
  }

  #newToken(prefix: string): string {
    const entropy = this.#randomBytes(32);
    if (entropy.byteLength !== 32) {
      throw new RunStoreError("ENTROPY_FAILURE", "The random source returned an invalid byte count");
    }
    return `${prefix}${entropy.toString("base64url")}`;
  }

  #newUniqueRunHandle(): RunHandle {
    for (let attempt = 0; attempt < 16; attempt += 1) {
      const handle = this.#newToken("pmh_") as RunHandle;
      const hash = this.#hashToken(HANDLE_DOMAIN, handle);
      if (!this.#handleIndex.has(hash) && !this.#recoveryHandleIndex.has(hash)) return handle;
    }
    throw new RunStoreError("RANDOM_COLLISION", "Unable to allocate a unique run handle");
  }

  #nextRunCreationSequence(
    principal: PrincipalBinding,
    profileAlias: string,
    trustBundleSha256: Sha256,
  ): number {
    const sequences = [...this.#runs.values()]
      .filter((run) =>
        safeEqual(run.record.principal.issuerAlias, principal.issuerAlias) &&
        safeEqual(run.record.principal.subjectSha256, principal.subjectSha256) &&
        safeEqual(run.record.principal.tenantSha256, principal.tenantSha256) &&
        safeEqual(run.record.principal.sessionSha256, principal.sessionSha256) &&
        safeEqual(run.record.profileAlias, profileAlias) &&
        safeEqual(run.record.trustBundleSha256, trustBundleSha256)
      )
      .map((run) => run.creationSequence);
    const sequence = sequences.length === 0 ? 0 : Math.max(...sequences) + 1;
    if (sequence > MAXIMUM_RUN_CREATION_SEQUENCE) {
      throw new RunStoreError(
        "RUNTIME_CAPACITY",
        "Run creation exceeded the bounded authority sequence",
      );
    }
    return sequence;
  }

  #newRunId(creationSequence: number): RunId {
    const encodedSequence = creationSequence.toString(36).padStart(8, "0");
    for (let attempt = 0; attempt < 16; attempt += 1) {
      const entropy = this.#randomBytes(12);
      if (entropy.byteLength !== 12) {
        throw new RunStoreError("ENTROPY_FAILURE", "The random source returned an invalid byte count");
      }
      const runId = `pmrun_q${encodedSequence}_${entropy.toString("base64url")}` as RunId;
      if (!this.#runs.has(runId)) return runId;
    }
    throw new RunStoreError("RANDOM_COLLISION", "Unable to allocate a globally unique run ID");
  }

  #newOwnedId<T>(prefix: string, map: Map<T, unknown>): string {
    for (let attempt = 0; attempt < 16; attempt += 1) {
      const value = `${prefix}${this.#randomBytes(18).toString("base64url")}`;
      if (!map.has(value as T)) return value;
    }
    throw new RunStoreError("RANDOM_COLLISION", "Unable to allocate a globally unique identifier");
  }

  #updateRecord(record: RunRecord, updates: Partial<RunRecord>): RunRecord {
    const provisional = { ...record, ...updates };
    return { ...provisional, integrity: computeIntegrity(provisional) };
  }

  #view(run: InternalRun): RunView {
    return cloneFrozen({
      record: run.record,
      revision: run.revision,
      hasLease: run.lease !== undefined,
      ...(run.lease === undefined ? {} : { leaseExpiresAt: new Date(run.lease.expiresAtMs).toISOString() }),
    });
  }

  #expireIfNeeded(runId: RunId, run: InternalRun): boolean {
    if (
      (run.record.state !== "OPEN" && run.record.state !== "FINALIZING") ||
      this.#now() < Date.parse(run.record.expiresAt)
    ) {
      return false;
    }
    this.#assertRevisionCapacity(run);
    run.record = this.#updateRecord(run.record, { state: "EXPIRED" });
    this.#incrementRevision(run);
    this.#invalidateAccess(runId, run);
    return true;
  }

  #invalidateAccess(_runId: RunId, run: InternalRun): void {
    this.#handleIndex.delete(run.record.handleSha256);
    for (const hash of run.recoveryHandleSha256s ?? []) this.#recoveryHandleIndex.delete(hash);
    delete run.recoveryHandleSha256s;
    delete run.lease;
  }

  exportSnapshot(): RunStoreSnapshot {
    return structuredClone({
      schemaVersion: "1.0.0",
      runs: [...this.#runs.values()]
        .map((run) => ({
          record: run.record,
          revision: run.revision,
          idempotencySha256: run.idempotencySha256,
          request: run.request,
          policy: run.policy,
          ...(run.lease === undefined ? {} : { lease: run.lease }),
          ...(run.verificationContractSha256 === undefined
            ? {}
            : { verificationContractSha256: run.verificationContractSha256 }),
          ...(run.abortReason === undefined ? {} : { abortReason: run.abortReason }),
          ...(run.recoveryHandleSha256s === undefined
            ? {}
            : { recoveryHandleSha256s: run.recoveryHandleSha256s }),
        }))
        .sort((left, right) => left.record.runId.localeCompare(right.record.runId)),
    });
  }

  #importSnapshot(snapshot: RunStoreSnapshot): void {
    if (snapshot.schemaVersion !== "1.0.0" || !Array.isArray(snapshot.runs)) {
      throw new RunStoreError("STATE_CORRUPT", "Run-store snapshot is invalid");
    }
    const creationSequences = this.#creationSequencesForSnapshot(snapshot);
    for (const entry of snapshot.runs) {
      const runId = entry.record?.runId;
      if (
        typeof runId !== "string" ||
        !runId.startsWith("pmrun_") ||
        this.#runs.has(runId as RunId) ||
        !Number.isSafeInteger(entry.revision) ||
        entry.revision < 1 ||
        entry.revision > MAXIMUM_AUTHORITY_COMPONENT_REVISION ||
        !verifyIntegrity(entry.record) ||
        sha256Canonical(entry.request) !== entry.record.requestSha256 ||
        entry.policy.requestSha256 !== entry.record.requestSha256 ||
        entry.policy.trustBundleSha256 !== entry.record.trustBundleSha256 ||
        entry.policy.profileAlias !== entry.record.profileAlias ||
        entry.policy.origin !== entry.record.origin ||
        sha256Canonical(entry.policy.scope) !== sha256Canonical(entry.record.scope) ||
        !/^[a-f0-9]{64}$/u.test(entry.idempotencySha256)
      ) {
        throw new RunStoreError("STATE_CORRUPT", "Run-store entry integrity verification failed");
      }
      if (
        entry.lease !== undefined &&
        (!/^[a-f0-9]{64}$/u.test(entry.lease.handleSha256) ||
          !/^[a-f0-9]{64}$/u.test(entry.lease.ownerSha256) ||
          !Number.isSafeInteger(entry.lease.expiresAtMs) ||
          entry.lease.expiresAtMs < 0)
      ) {
        throw new RunStoreError("STATE_CORRUPT", "Persisted lease is invalid");
      }
      if (this.#idempotencyIndex.has(entry.idempotencySha256)) {
        throw new RunStoreError("STATE_CORRUPT", "Duplicate idempotency binding in run-store state");
      }
      const internal: InternalRun = {
        ...structuredClone(entry),
        creationSequence: creationSequences.get(runId as RunId)!,
      };
      this.#runs.set(runId as RunId, internal);
      this.#idempotencyIndex.set(entry.idempotencySha256, runId as RunId);
      if (entry.record.state === "OPEN" || entry.record.state === "FINALIZING") {
        if (this.#handleIndex.has(entry.record.handleSha256) || this.#recoveryHandleIndex.has(entry.record.handleSha256)) {
          throw new RunStoreError("STATE_CORRUPT", "Duplicate handle binding in run-store state");
        }
        this.#handleIndex.set(entry.record.handleSha256, runId as RunId);
        for (const recoveryHash of entry.recoveryHandleSha256s ?? []) {
          if (
            !/^[a-f0-9]{64}$/u.test(recoveryHash) ||
            recoveryHash === entry.record.handleSha256 ||
            this.#recoveryHandleIndex.has(recoveryHash) ||
            this.#handleIndex.has(recoveryHash) ||
            (entry.recoveryHandleSha256s?.length ?? 0) > 4
          ) {
            throw new RunStoreError("STATE_CORRUPT", "Invalid recovery handle binding in run-store state");
          }
          this.#recoveryHandleIndex.set(recoveryHash, runId as RunId);
        }
      }
      for (const evidenceId of entry.record.evidenceIds) {
        if (this.#evidenceOwners.has(evidenceId)) {
          throw new RunStoreError("STATE_CORRUPT", "Duplicate evidence ownership in run-store state");
        }
        this.#evidenceOwners.set(evidenceId, runId as RunId);
      }
      for (const contradictionId of entry.record.contradictionIds) {
        if (this.#contradictionOwners.has(contradictionId)) {
          throw new RunStoreError("STATE_CORRUPT", "Duplicate contradiction ownership in run-store state");
        }
        this.#contradictionOwners.set(contradictionId, runId as RunId);
      }
    }
  }

  #creationSequencesForSnapshot(snapshot: RunStoreSnapshot): Map<RunId, number> {
    const result = new Map<RunId, number>();
    const groups = new Map<string, PersistedRunEntry[]>();
    for (const entry of snapshot.runs) {
      const record = entry.record;
      if (
        record?.principal === undefined ||
        typeof record.principal.issuerAlias !== "string" ||
        typeof record.principal.subjectSha256 !== "string" ||
        typeof record.principal.tenantSha256 !== "string" ||
        typeof record.principal.sessionSha256 !== "string" ||
        typeof record.profileAlias !== "string" ||
        typeof record.trustBundleSha256 !== "string" ||
        typeof record.runId !== "string" ||
        !Number.isSafeInteger(Date.parse(record.createdAt))
      ) {
        throw new RunStoreError("STATE_CORRUPT", "Run creation authority is invalid");
      }
      const authority = sha256Canonical({
        domain: "pm-run-creation-authority-v1",
        principal: record.principal,
        profileAlias: record.profileAlias,
        trustBundleSha256: record.trustBundleSha256,
      });
      const group = groups.get(authority) ?? [];
      group.push(entry);
      groups.set(authority, group);
    }
    for (const entries of groups.values()) {
      const used = new Set<number>();
      const legacy: PersistedRunEntry[] = [];
      for (const entry of entries) {
        const match = RUN_ID_V3.exec(entry.record.runId);
        if (match === null) {
          legacy.push(entry);
          continue;
        }
        const sequence = Number.parseInt(match[1]!, 36);
        if (
          !Number.isSafeInteger(sequence) ||
          sequence < 0 ||
          sequence > MAXIMUM_RUN_CREATION_SEQUENCE ||
          used.has(sequence)
        ) {
          throw new RunStoreError("STATE_CORRUPT", "Run creation authority sequence is invalid");
        }
        used.add(sequence);
        result.set(entry.record.runId, sequence);
      }
      let candidate = 0;
      for (const entry of legacy.sort((left, right) =>
        left.record.createdAt.localeCompare(right.record.createdAt) ||
        left.record.runId.localeCompare(right.record.runId)
      )) {
        while (used.has(candidate)) candidate += 1;
        if (candidate > MAXIMUM_RUN_CREATION_SEQUENCE) {
          throw new RunStoreError("STATE_CORRUPT", "Run creation authority sequence is exhausted");
        }
        used.add(candidate);
        result.set(entry.record.runId, candidate);
        candidate += 1;
      }
    }
    return result;
  }

  #rememberRecoveryHandle(runId: RunId, run: InternalRun, hash: Sha256): void {
    const hashes = [...new Set([...(run.recoveryHandleSha256s ?? []), hash])].slice(-4);
    for (const previous of run.recoveryHandleSha256s ?? []) {
      if (!hashes.includes(previous)) this.#recoveryHandleIndex.delete(previous);
    }
    run.recoveryHandleSha256s = hashes;
    for (const value of hashes) this.#recoveryHandleIndex.set(value, runId);
  }
}
