import {
  closeSync,
  constants,
  existsSync,
  fsyncSync,
  fstatSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import type { Stats } from "node:fs";
import { randomUUID } from "node:crypto";
import { isAbsolute, resolve } from "node:path";

import {
  canonicalJson,
  computeIntegrity,
  verifyIntegrity,
  type Integrity,
} from "@codex-production-monitoring/contracts";

import { RunStoreError } from "./store.ts";

export const DEFAULT_MAXIMUM_STATE_BYTES = 32 * 1_024 * 1_024;
const SAFE_FILENAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,180}$/u;
const LOCK_MAXIMUM_BYTES = 1_024;
const GUARD_RETRY_ATTEMPTS = 50;
const GUARD_RETRY_MS = 2;
const GUARD_WAIT = new Int32Array(new SharedArrayBuffer(4));

interface StateEnvelope<T> {
  schemaVersion: "1.0.0";
  kind: string;
  generation: number;
  payload: T;
  integrity: Integrity;
}

interface AcquiredLock {
  descriptor: number;
  stat: Stats;
  nonce: string;
}

export interface StateTransactionResult<T, R> {
  payload: T;
  result: R;
}

function currentUid(): number | undefined {
  return typeof process.getuid === "function" ? process.getuid() : undefined;
}

function assertOwner(stat: Stats, label: string): void {
  const uid = currentUid();
  if (uid !== undefined && stat.uid !== uid) {
    throw new RunStoreError("STATE_OWNER_INVALID", `${label} is not owned by the current user`);
  }
  if ((stat.mode & 0o077) !== 0) {
    throw new RunStoreError("STATE_PERMISSIONS_INVALID", `${label} grants group or other access`);
  }
}

function assertRoot(path: string): void {
  const stat = lstatSync(path);
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    throw new RunStoreError("STATE_ROOT_INVALID", "State root must be a real directory");
  }
  assertOwner(stat, "State root");
}

function assertRegularFile(
  path: string,
  label: string,
  maximumBytes = DEFAULT_MAXIMUM_STATE_BYTES,
): Stats {
  const stat = lstatSync(path);
  if (stat.isSymbolicLink() || !stat.isFile() || stat.nlink !== 1) {
    throw new RunStoreError("STATE_FILE_INVALID", `${label} must be one regular non-linked file`);
  }
  assertOwner(stat, label);
  if (stat.size > maximumBytes) {
    throw new RunStoreError("STATE_TOO_LARGE", `${label} exceeds the state size limit`);
  }
  return stat;
}

function parseEnvelope<T>(text: string, kind: string): StateEnvelope<T> {
  let value: unknown;
  try {
    value = JSON.parse(text) as unknown;
  } catch {
    throw new RunStoreError("STATE_CORRUPT", "State is not valid JSON");
  }
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new RunStoreError("STATE_CORRUPT", "State envelope is invalid");
  }
  const record = value as Record<string, unknown>;
  const keys = Object.keys(record).sort();
  if (canonicalJson(keys) !== canonicalJson(["generation", "integrity", "kind", "payload", "schemaVersion"])) {
    throw new RunStoreError("STATE_CORRUPT", "State envelope has unexpected fields");
  }
  if (
    record.schemaVersion !== "1.0.0" ||
    record.kind !== kind ||
    !Number.isSafeInteger(record.generation) ||
    (record.generation as number) < 1 ||
    !verifyIntegrity(value as StateEnvelope<T>)
  ) {
    throw new RunStoreError("STATE_CORRUPT", "State integrity verification failed");
  }
  return value as StateEnvelope<T>;
}

/**
 * A small synchronous state primitive with owner-only files, integrity envelopes,
 * per-file exclusion, fsync, and atomic rename. It never interprets the payload.
 */
export class AtomicStateFile<T> {
  readonly root: string;
  readonly path: string;
  readonly #lockPath: string;
  readonly #reclaimPath: string;
  readonly #kind: string;
  readonly #maximumBytes: number;
  readonly #filename: string;
  readonly #temporaryPath: string;

  constructor(options: {
    stateRoot: string;
    filename: string;
    kind: string;
    maximumBytes?: number;
  }) {
    if (!isAbsolute(options.stateRoot)) {
      throw new RunStoreError("STATE_ROOT_INVALID", "State root must be absolute");
    }
    if (!SAFE_FILENAME.test(options.filename)) {
      throw new RunStoreError("STATE_FILE_INVALID", "State filename is invalid");
    }
    const maximumBytes = options.maximumBytes ?? DEFAULT_MAXIMUM_STATE_BYTES;
    if (!Number.isSafeInteger(maximumBytes) || maximumBytes < 1 || maximumBytes > DEFAULT_MAXIMUM_STATE_BYTES) {
      throw new RunStoreError("STATE_FILE_INVALID", "State size limit is invalid");
    }
    this.root = resolve(options.stateRoot);
    this.path = resolve(this.root, options.filename);
    this.#lockPath = resolve(this.root, `${options.filename}.lock`);
    this.#reclaimPath = resolve(this.root, `${options.filename}.lock.reclaim`);
    this.#kind = options.kind;
    this.#maximumBytes = maximumBytes;
    this.#filename = options.filename;
    this.#temporaryPath = resolve(this.root, `.state-${options.filename}.tmp`);
    if (!existsSync(this.root)) mkdirSync(this.root, { mode: 0o700, recursive: false });
    assertRoot(this.root);
    if (realpathSync.native(this.root) !== this.root) {
      throw new RunStoreError("STATE_ROOT_INVALID", "State root cannot use symlinked ancestor aliases");
    }
    if (existsSync(this.path)) this.#readEnvelope();
  }

  read(): T | undefined {
    assertRoot(this.root);
    return existsSync(this.path) ? structuredClone(this.#readEnvelope().payload) : undefined;
  }

  write(payload: T): void {
    this.transact(() => ({ payload, result: undefined }));
  }

  /** Read and evaluate under the same exclusion lock without rewriting state. */
  inspect<R>(callback: (current: T | undefined) => R): R {
    assertRoot(this.root);
    const acquired = this.#acquireLock();
    try {
      this.#removeOwnedTemporaryFile();
      const previous = existsSync(this.path) ? this.#readEnvelope() : undefined;
      return callback(previous === undefined ? undefined : structuredClone(previous.payload));
    } finally {
      closeSync(acquired.descriptor);
      this.#withReclaimGuard(() => {
        this.#unlinkExact(this.#lockPath, acquired.stat, acquired.nonce, "State lock release");
      });
    }
  }

  /** Read and evaluate asynchronously while retaining the same exclusion lock. */
  async inspectAsync<R>(callback: (current: T | undefined) => Promise<R>): Promise<R> {
    assertRoot(this.root);
    const acquired = this.#acquireLock();
    try {
      this.#removeOwnedTemporaryFile();
      const previous = existsSync(this.path) ? this.#readEnvelope() : undefined;
      return await callback(previous === undefined ? undefined : structuredClone(previous.payload));
    } finally {
      closeSync(acquired.descriptor);
      this.#withReclaimGuard(() => {
        this.#unlinkExact(this.#lockPath, acquired.stat, acquired.nonce, "State lock release");
      });
    }
  }

  /** Recover only receipts provably abandoned by a dead process. */
  recoverAbandonedArtifacts(): void {
    assertRoot(this.root);
    this.#withReclaimGuard(() => {
      this.#recoverExactArtifactsUnderGuard();
      this.#removeLegacyOwnedTemporaryFiles();
    });
  }

  /** Recover only the deterministic lock/temp names without scanning the root. */
  recoverAbandonedExactArtifacts(): void {
    assertRoot(this.root);
    this.#withReclaimGuard(() => this.#recoverExactArtifactsUnderGuard());
  }

  /**
   * Explicit operator recovery for a dead reclaim guard. Call only after
   * quiescing this authority and reviewing the owner-only receipt.
   */
  recoverAbandonedReclaimGuard(): void {
    assertRoot(this.root);
    if (!existsSync(this.#reclaimPath)) return;
    const stat = assertRegularFile(this.#reclaimPath, "State lock reclaim mutex", LOCK_MAXIMUM_BYTES);
    const lock = this.#parseLock(this.#reclaimPath);
    try {
      process.kill(lock.pid, 0);
      throw new RunStoreError("STATE_LOCKED", "State lock guard belongs to a live process");
    } catch (error) {
      if (error instanceof RunStoreError) throw error;
      if ((error as NodeJS.ErrnoException).code !== "ESRCH") {
        throw new RunStoreError("STATE_LOCKED", "State lock guard liveness is uncertain");
      }
    }
    this.#unlinkExact(this.#reclaimPath, stat, lock.nonce, "Abandoned state lock reclaim mutex");
  }

  transact<R>(callback: (current: T | undefined) => StateTransactionResult<T, R>): R {
    assertRoot(this.root);
    const acquired = this.#acquireLock();
    try {
      this.#removeOwnedTemporaryFile();
      const previous = existsSync(this.path) ? this.#readEnvelope() : undefined;
      const transaction = callback(previous === undefined ? undefined : structuredClone(previous.payload));
      this.#assertSupportedPayload(previous?.payload, transaction.payload);
      const withoutIntegrity = {
        schemaVersion: "1.0.0" as const,
        kind: this.#kind,
        generation: (previous?.generation ?? 0) + 1,
        payload: transaction.payload,
      };
      const envelope: StateEnvelope<T> = {
        ...withoutIntegrity,
        integrity: computeIntegrity(withoutIntegrity),
      };
      this.#atomicWrite(`${canonicalJson(envelope)}\n`);
      return transaction.result;
    } finally {
      closeSync(acquired.descriptor);
      this.#withReclaimGuard(() => {
        this.#unlinkExact(this.#lockPath, acquired.stat, acquired.nonce, "State lock release");
      });
    }
  }

  #assertSupportedPayload(previous: T | undefined, next: T): void {
    if (previous === undefined || previous === null || next === null || typeof previous !== "object" || typeof next !== "object") return;
    const previousVersion = (previous as Record<string, unknown>).schemaVersion;
    const nextVersion = (next as Record<string, unknown>).schemaVersion;
    if (previousVersion === "2.0.0" && nextVersion === "1.0.0") {
      throw new RunStoreError("STATE_CORRUPT", "State format cannot be downgraded after migration");
    }
  }

  #acquireLock(): AcquiredLock {
    return this.#withReclaimGuard(() => {
      let descriptor: number;
      try {
        descriptor = openSync(
          this.#lockPath,
          constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
          0o600,
        );
      } catch (error) {
        if (
          (error as NodeJS.ErrnoException).code !== "EEXIST" ||
          !this.#removeProvablyAbandonedLockUnderGuard()
        ) {
          throw new RunStoreError("STATE_LOCKED", "State is being updated by another process");
        }
        descriptor = openSync(
          this.#lockPath,
          constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
          0o600,
        );
      }
      const stat = fstatSync(descriptor);
      const nonce = randomUUID();
      assertOwner(stat, "State lock");
      writeFileSync(descriptor, canonicalJson({
        schemaVersion: "1.0.0",
        pid: process.pid,
        createdAtMs: Date.now(),
        nonce,
      }), { encoding: "utf8" });
      fsyncSync(descriptor);
      return { descriptor, stat, nonce };
    });
  }

  #removeProvablyAbandonedLockUnderGuard(): boolean {
    const stat = assertRegularFile(this.#lockPath, "State lock", LOCK_MAXIMUM_BYTES);
    const lock = this.#parseLock(this.#lockPath);
    try {
      process.kill(lock.pid, 0);
      return false;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ESRCH") return false;
    }
    this.#unlinkExact(this.#lockPath, stat, lock.nonce, "Abandoned state lock");
    return true;
  }

  #withReclaimGuard<R>(callback: () => R): R {
    const descriptor = this.#acquireReclaimMutex();
    const stat = fstatSync(descriptor);
    const nonce = randomUUID();
    try {
      assertOwner(stat, "State lock reclaim mutex");
      writeFileSync(descriptor, canonicalJson({
        schemaVersion: "1.0.0",
        pid: process.pid,
        createdAtMs: Date.now(),
        nonce,
      }), { encoding: "utf8" });
      fsyncSync(descriptor);
      return callback();
    } finally {
      closeSync(descriptor);
      this.#unlinkExact(this.#reclaimPath, stat, nonce, "State lock reclaim mutex release");
    }
  }

  #acquireReclaimMutex(): number {
    for (let attempt = 0; attempt < GUARD_RETRY_ATTEMPTS; attempt += 1) {
      try {
        return openSync(
          this.#reclaimPath,
          constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
          0o600,
        );
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") {
          throw new RunStoreError("STATE_LOCKED", "State lock guard could not be acquired");
        }
      }
      let lock: { pid: number; nonce: string } | undefined;
      try {
        assertRegularFile(this.#reclaimPath, "State lock reclaim mutex", LOCK_MAXIMUM_BYTES);
        lock = this.#parseLock(this.#reclaimPath);
      } catch (error) {
        if (attempt === GUARD_RETRY_ATTEMPTS - 1) throw error;
      }
      if (lock !== undefined) {
        try {
          process.kill(lock.pid, 0);
        } catch (error) {
          if ((error as NodeJS.ErrnoException).code === "ESRCH") {
            throw new RunStoreError(
              "STATE_LOCKED",
              "State lock guard was abandoned; operator review is required",
            );
          }
        }
      }
      Atomics.wait(GUARD_WAIT, 0, 0, GUARD_RETRY_MS);
    }
    throw new RunStoreError("STATE_LOCKED", "State lock guard is held by another process");
  }

  #parseLock(path: string): { pid: number; nonce: string } {
    let lock: unknown;
    try {
      lock = JSON.parse(readFileSync(path, "utf8")) as unknown;
    } catch {
      throw new RunStoreError("STATE_LOCK_INVALID", "State lock is malformed");
    }
    if (
      lock === null ||
      typeof lock !== "object" ||
      Array.isArray(lock) ||
      (lock as Record<string, unknown>).schemaVersion !== "1.0.0" ||
      !Number.isSafeInteger((lock as Record<string, unknown>).pid) ||
      ((lock as Record<string, unknown>).pid as number) <= 0 ||
      !Number.isSafeInteger((lock as Record<string, unknown>).createdAtMs) ||
      typeof (lock as Record<string, unknown>).nonce !== "string" ||
      !/^[a-f0-9-]{36}$/u.test((lock as Record<string, unknown>).nonce as string)
    ) {
      throw new RunStoreError("STATE_LOCK_INVALID", "State lock is malformed");
    }
    return { pid: (lock as { pid: number }).pid, nonce: (lock as { nonce: string }).nonce };
  }

  #unlinkExact(path: string, expected: Stats, nonce: string, label: string): void {
    const current = assertRegularFile(path, label, LOCK_MAXIMUM_BYTES);
    const receipt = this.#parseLock(path);
    if (current.dev !== expected.dev || current.ino !== expected.ino || receipt.nonce !== nonce) {
      throw new RunStoreError("STATE_LOCK_INVALID", `${label} no longer names the exact acquired lock`);
    }
    unlinkSync(path);
  }

  #removeOwnedTemporaryFile(): void {
    if (!existsSync(this.#temporaryPath)) return;
    assertRegularFile(this.#temporaryPath, "Abandoned temporary state file", this.#maximumBytes);
    unlinkSync(this.#temporaryPath);
  }

  #recoverExactArtifactsUnderGuard(): void {
    if (existsSync(this.#lockPath) && !this.#removeProvablyAbandonedLockUnderGuard()) {
      throw new RunStoreError("STATE_LOCKED", "State is being updated by another process");
    }
    this.#removeOwnedTemporaryFile();
  }

  #removeLegacyOwnedTemporaryFiles(): void {
    const prefix = `.state-${this.#filename}-`;
    for (const name of readdirSync(this.root)) {
      if (/^\.state-[a-f0-9-]{36}\.tmp$/u.test(name)) {
        throw new RunStoreError("STATE_FILE_INVALID", "Legacy unowned state temporary file requires operator review");
      }
      if (!name.startsWith(prefix)) continue;
      if (!new RegExp(`^${prefix.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")}[a-f0-9-]{36}\\.tmp$`, "u").test(name)) {
        throw new RunStoreError("STATE_FILE_INVALID", "State temporary filename is invalid");
      }
      const temporary = resolve(this.root, name);
      assertRegularFile(temporary, "Abandoned temporary state file", this.#maximumBytes);
      unlinkSync(temporary);
    }
  }

  #readEnvelope(): StateEnvelope<T> {
    assertRegularFile(this.path, "State file", this.#maximumBytes);
    return parseEnvelope<T>(readFileSync(this.path, "utf8"), this.#kind);
  }

  #atomicWrite(content: string): void {
    const temporary = this.#temporaryPath;
    let descriptor: number | undefined;
    try {
      descriptor = openSync(
        temporary,
        constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
        0o600,
      );
      writeFileSync(descriptor, content, { encoding: "utf8" });
      fsyncSync(descriptor);
      closeSync(descriptor);
      descriptor = undefined;
      assertRegularFile(temporary, "Temporary state file", this.#maximumBytes);
      if (existsSync(this.path)) assertRegularFile(this.path, "State file", this.#maximumBytes);
      renameSync(temporary, this.path);
      const directoryDescriptor = openSync(this.root, constants.O_RDONLY | constants.O_DIRECTORY);
      try {
        fsyncSync(directoryDescriptor);
      } finally {
        closeSync(directoryDescriptor);
      }
    } finally {
      if (descriptor !== undefined) closeSync(descriptor);
      if (existsSync(temporary)) unlinkSync(temporary);
    }
  }
}
