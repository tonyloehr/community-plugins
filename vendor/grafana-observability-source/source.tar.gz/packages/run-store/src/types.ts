import type {
  AuditState,
  CapabilityPackId,
  ContradictionId,
  EvidenceOrigin,
  EvidenceId,
  OperationId,
  RunHandle,
  RunId,
  RunRecord,
  Scope,
  Sha256,
  WorkflowRequest,
} from "@codex-production-monitoring/contracts";

/**
 * Hard authority bounds used by the numeric workbench-version tuple. They are
 * far above the durable store's practical capacity but make overflow fail at
 * the mutation boundary rather than making later read-only projections fail.
 */
export const MAXIMUM_AUTHORITY_COMPONENT_REVISION = 536_870_911;
export const MAXIMUM_RUN_CREATION_SEQUENCE = 2_000_000;

/** The immutable subset of a compiled policy required to create a run. */
export interface RunPolicySnapshot {
  requestSha256: Sha256;
  trustBundleSha256: Sha256;
  profileAlias: string;
  scope: Readonly<Scope>;
  origin: EvidenceOrigin;
  auditRequired: boolean;
  operations: Readonly<
    Record<
      string,
      Readonly<{
        operationId: OperationId;
        definitionSha256: Sha256;
      }>
    >
  >;
  capabilityPacks?: Readonly<
    Record<
      string,
      Readonly<{
        packId: CapabilityPackId;
        revision: number;
        definitionSha256: Sha256;
        requiredOperationIds: readonly OperationId[];
      }>
    >
  >;
}

export interface PrincipalIdentity {
  issuerAlias: string;
  subject: string;
  tenant: string;
  session: string;
}

export interface BeginRunInput {
  principal: PrincipalIdentity;
  request: WorkflowRequest;
  policy: RunPolicySnapshot;
  idempotencyKey: string;
  ttlMs: number;
}

export interface BeginRunResult {
  runId: RunId;
  revision: number;
  replayed: boolean;
  handle?: RunHandle;
}

export interface RunAccess {
  principal: PrincipalIdentity;
  handle: RunHandle;
  expectedRevision: number;
  expectedProfileAlias: string;
  expectedTrustBundleSha256: Sha256;
}

export interface ResumeRunInput {
  principal: PrincipalIdentity;
  runId: RunId;
  expectedRevision: number;
  expectedProfileAlias: string;
  expectedTrustBundleSha256: Sha256;
}

/** Resume using the retained bearer itself when a caller lost only its revision cursor. */
export interface ResumeRunWithHandleInput {
  principal: PrincipalIdentity;
  handle: RunHandle;
  expectedRevision?: number;
  expectedProfileAlias: string;
  expectedTrustBundleSha256: Sha256;
}

/** Owner-authenticated access to the immutable context needed to recover a process. */
export interface RunRecoveryContext {
  request: Readonly<WorkflowRequest>;
  policy: Readonly<RunPolicySnapshot>;
}

export interface SealedParentView {
  record: Readonly<RunRecord>;
  revision: number;
  verificationContractSha256: Sha256;
}

export interface LeaseResult {
  leaseHandle: string;
  revision: number;
  expiresAt: string;
}

export interface RunView {
  record: Readonly<RunRecord>;
  revision: number;
  hasLease: boolean;
  leaseExpiresAt?: string;
}

/**
 * A bearer-free authority projection used to discover runs owned by one
 * principal. It deliberately omits principal hashes, handle hashes, integrity
 * receipts, idempotency bindings, and lease identities.
 */
export interface OwnedRunView {
  runId: RunId;
  /** Monotonic creation order within this principal/profile/trust authority. */
  creationSequence: number;
  state: RunRecord["state"];
  workflow: RunRecord["workflow"];
  origin: RunRecord["origin"];
  scope: Readonly<Scope>;
  window: Readonly<RunRecord["window"]>;
  baselineWindow?: Readonly<NonNullable<RunRecord["baselineWindow"]>>;
  parent?: Readonly<NonNullable<RunRecord["parent"]>>;
  evidenceIds: readonly EvidenceId[];
  contradictionIds: readonly ContradictionId[];
  audit: Readonly<RunRecord["audit"]>;
  createdAt: string;
  expiresAt: string;
  finalizedAt?: string;
  abortedAt?: string;
  revision: number;
  hasLease: boolean;
  leaseExpiresAt?: string;
}

export interface ListOwnedRunsInput {
  principal: PrincipalIdentity;
  expectedProfileAlias: string;
  expectedTrustBundleSha256: Sha256;
  /** Strictly bounded by the store to prevent unbounded inventory reads. */
  limit?: number;
}

export interface OwnedRunInventory {
  runs: readonly Readonly<OwnedRunView>[];
  omittedCount: number;
}

export interface BeginChildVerificationInput extends BeginRunInput {
  parentRunId: RunId;
  verificationContractSha256: Sha256;
}

export interface FinalizeRunInput {
  access: RunAccess;
  leaseHandle: string;
  verificationContractSha256?: Sha256;
}

export interface RunStoreOptions {
  now?: () => number;
  randomBytes?: (size: number) => Buffer;
  minimumTtlMs?: number;
  maximumTtlMs?: number;
  maximumLeaseMs?: number;
}

export interface DurableRunStoreOptions extends RunStoreOptions {
  /** Absolute owner-only directory. No raw run or lease bearer is persisted here. */
  stateRoot: string;
}

export interface PersistedLeaseRecord {
  handleSha256: Sha256;
  ownerSha256: Sha256;
  expiresAtMs: number;
}

export interface PersistedRunEntry {
  record: RunRecord;
  revision: number;
  idempotencySha256: Sha256;
  request: WorkflowRequest;
  policy: RunPolicySnapshot;
  lease?: PersistedLeaseRecord;
  verificationContractSha256?: Sha256;
  abortReason?: string;
  /** Previous bearers accepted only for crash-safe resume, never ordinary access. */
  recoveryHandleSha256s?: Sha256[];
}

export interface RunStoreSnapshot {
  schemaVersion: "1.0.0";
  runs: PersistedRunEntry[];
}

/** Structural interface shared by the volatile and durable implementations. */
export interface RunStore {
  beginRun(input: BeginRunInput): BeginRunResult;
  beginChildVerification(input: BeginChildVerificationInput): BeginRunResult;
  resumeRun(input: ResumeRunInput): BeginRunResult;
  resumeRunWithHandle(input: ResumeRunWithHandleInput): BeginRunResult;
  getRunWithHandle(input: ResumeRunWithHandleInput): RunView;
  acknowledgeResume(access: RunAccess): RunView;
  getRun(access: RunAccess): RunView;
  assertLease(access: RunAccess, leaseHandle: string): RunView;
  getRecoveryContext(access: RunAccess): RunRecoveryContext;
  getSealedParent(input: {
    principal: PrincipalIdentity;
    runId: RunId;
    expectedProfileAlias: string;
    expectedTrustBundleSha256: Sha256;
  }): SealedParentView;
  listOwnedRuns(input: ListOwnedRunsInput): OwnedRunInventory;
  claimLease(access: RunAccess, ownerId: string, ttlMs: number): LeaseResult;
  renewLease(access: RunAccess, leaseHandle: string, ttlMs: number): LeaseResult;
  releaseLease(access: RunAccess, leaseHandle: string): RunView;
  allocateEvidence(access: RunAccess, leaseHandle: string): AllocateEvidenceResult;
  allocateContradiction(access: RunAccess, leaseHandle: string): AllocateContradictionResult;
  assertEvidenceOwnership(access: RunAccess, evidenceId: EvidenceId): void;
  assertContradictionOwnership(access: RunAccess, contradictionId: ContradictionId): void;
  updateAudit(input: AuditUpdateInput): RunMutationResult;
  beginFinalize(access: RunAccess, leaseHandle: string): RunMutationResult;
  finalizeRun(input: FinalizeRunInput): RunMutationResult;
  abortRun(access: RunAccess, leaseHandle: string, reason: string): RunMutationResult;
  sweepExpired(): number;
}

export interface RunMutationResult {
  revision: number;
  record: Readonly<RunRecord>;
}

export interface AllocateEvidenceResult extends RunMutationResult {
  evidenceId: EvidenceId;
}

export interface AllocateContradictionResult extends RunMutationResult {
  contradictionId: ContradictionId;
}

export interface AuditUpdateInput {
  access: RunAccess;
  leaseHandle: string;
  state: AuditState;
}
