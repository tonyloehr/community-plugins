import type { OperationId, OperationLimits } from "@codex-production-monitoring/contracts";

import {
  authorizeOperationLimits,
  type CompiledWorkflowPolicy,
  PolicyError,
} from "./policy.ts";

export interface BudgetUsage {
  timeoutMs: number;
  bytes: number;
  rows: number;
  series: number;
  points: number;
}

export interface BudgetReservation {
  reservationId: string;
  operationId: OperationId;
  sourceAlias: string;
  costUnits: number;
  limits: Readonly<OperationLimits>;
}

export interface BudgetSnapshot {
  requests: number;
  requestsBySource: Readonly<Record<string, number>>;
  active: number;
  costUnits: number;
  used: Readonly<BudgetUsage>;
  reserved: Readonly<BudgetUsage>;
}

interface InternalReservation extends BudgetReservation {
  limits: Readonly<OperationLimits>;
}

const ZERO_USAGE: BudgetUsage = { timeoutMs: 0, bytes: 0, rows: 0, series: 0, points: 0 };

function cloneUsage(usage: BudgetUsage): BudgetUsage {
  return { ...usage };
}

function addLimits(target: BudgetUsage, limits: OperationLimits, direction: 1 | -1): void {
  target.timeoutMs += direction * limits.timeoutMs;
  target.bytes += direction * limits.maxBytes;
  target.rows += direction * limits.maxRows;
  target.series += direction * limits.maxSeries;
  target.points += direction * limits.maxPoints;
}

function assertUsage(usage: BudgetUsage): void {
  for (const [name, value] of Object.entries(usage)) {
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new PolicyError("INVALID_USAGE", `${name} must be a non-negative safe integer`);
    }
  }
}

export class BudgetLedger {
  readonly #policy: CompiledWorkflowPolicy;
  readonly #reservations = new Map<string, InternalReservation>();
  #requests = 0;
  readonly #requestsBySource = new Map<string, number>();
  #costUnits = 0;
  #counter = 0;
  #used = cloneUsage(ZERO_USAGE);
  #reserved = cloneUsage(ZERO_USAGE);

  constructor(policy: CompiledWorkflowPolicy) {
    this.#policy = policy;
  }

  reserve(operationId: OperationId, requested: Partial<OperationLimits> = {}): BudgetReservation {
    if (this.#requests >= this.#policy.runLimits.maxRequests) {
      throw new PolicyError("REQUEST_BUDGET_EXHAUSTED", "The run request budget is exhausted");
    }
    if (this.#reservations.size >= this.#policy.runLimits.maxConcurrent) {
      throw new PolicyError("CONCURRENCY_BUDGET_EXHAUSTED", "The run concurrency budget is exhausted");
    }
    const operation = this.#policy.operations[operationId];
    if (operation === undefined) {
      throw new PolicyError("OPERATION_NOT_ALLOWED", `Operation ${operationId} is not in the sealed policy`);
    }
    const sourceRequests = this.#requestsBySource.get(operation.sourceAlias) ?? 0;
    if (sourceRequests >= this.#policy.runLimits.maxRequestsPerSource) {
      throw new PolicyError("SOURCE_REQUEST_BUDGET_EXHAUSTED", "The provider-source request quota is exhausted");
    }
    if (this.#costUnits + operation.costUnits > this.#policy.runLimits.maxTotalCostUnits) {
      throw new PolicyError("COST_BUDGET_EXHAUSTED", "The run resource-cost budget is exhausted");
    }
    const limits = authorizeOperationLimits(this.#policy, operationId, requested);
    const prospective = cloneUsage(this.#reserved);
    addLimits(prospective, limits, 1);
    const totals = this.#policy.runLimits;
    if (this.#used.timeoutMs + prospective.timeoutMs > totals.maxTotalTimeoutMs) throw new PolicyError("TIME_BUDGET_EXHAUSTED", "The run timeout budget is exhausted");
    if (this.#used.bytes + prospective.bytes > totals.maxTotalBytes) throw new PolicyError("BYTE_BUDGET_EXHAUSTED", "The run byte budget is exhausted");
    if (this.#used.rows + prospective.rows > totals.maxTotalRows) throw new PolicyError("ROW_BUDGET_EXHAUSTED", "The run row budget is exhausted");
    if (this.#used.series + prospective.series > totals.maxTotalSeries) throw new PolicyError("SERIES_BUDGET_EXHAUSTED", "The run series budget is exhausted");
    if (this.#used.points + prospective.points > totals.maxTotalPoints) throw new PolicyError("POINT_BUDGET_EXHAUSTED", "The run point budget is exhausted");

    this.#counter += 1;
    const reservationId = `budget_${this.#counter.toString(36)}`;
    const reservation: InternalReservation = {
      reservationId,
      operationId,
      sourceAlias: operation.sourceAlias,
      costUnits: operation.costUnits,
      limits,
    };
    this.#reservations.set(reservationId, reservation);
    this.#reserved = prospective;
    this.#requests += 1;
    this.#requestsBySource.set(operation.sourceAlias, sourceRequests + 1);
    this.#costUnits += operation.costUnits;
    return Object.freeze({ ...reservation });
  }

  settle(reservationId: string, usage: BudgetUsage): BudgetSnapshot {
    const reservation = this.#reservations.get(reservationId);
    if (reservation === undefined) {
      throw new PolicyError("UNKNOWN_RESERVATION", "The budget reservation is unknown or already settled");
    }
    assertUsage(usage);
    if (
      usage.timeoutMs > reservation.limits.timeoutMs ||
      usage.bytes > reservation.limits.maxBytes ||
      usage.rows > reservation.limits.maxRows ||
      usage.series > reservation.limits.maxSeries ||
      usage.points > reservation.limits.maxPoints
    ) {
      throw new PolicyError("OPERATION_BUDGET_EXCEEDED", "Actual usage exceeds the reservation");
    }
    this.#reservations.delete(reservationId);
    addLimits(this.#reserved, reservation.limits, -1);
    this.#used.timeoutMs += usage.timeoutMs;
    this.#used.bytes += usage.bytes;
    this.#used.rows += usage.rows;
    this.#used.series += usage.series;
    this.#used.points += usage.points;
    return this.snapshot();
  }

  cancel(reservationId: string): BudgetSnapshot {
    const reservation = this.#reservations.get(reservationId);
    if (reservation === undefined) {
      throw new PolicyError("UNKNOWN_RESERVATION", "The budget reservation is unknown or already settled");
    }
    this.#reservations.delete(reservationId);
    addLimits(this.#reserved, reservation.limits, -1);
    return this.snapshot();
  }

  snapshot(): BudgetSnapshot {
    return Object.freeze({
      requests: this.#requests,
      requestsBySource: Object.freeze(Object.fromEntries(
        [...this.#requestsBySource.entries()].sort(([left], [right]) => left.localeCompare(right)),
      )),
      active: this.#reservations.size,
      costUnits: this.#costUnits,
      used: Object.freeze(cloneUsage(this.#used)),
      reserved: Object.freeze(cloneUsage(this.#reserved)),
    });
  }
}
