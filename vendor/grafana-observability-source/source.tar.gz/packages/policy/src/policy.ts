import {
  sha256Canonical,
  validateCapabilityPack,
  verifyIntegrity,
} from "@codex-production-monitoring/contracts";
import type {
  OperationId,
  CapabilityPackId,
  OperationLimits,
  Scope,
  Sha256,
  TrustedVerificationPolicy,
  TrustBundle,
  WorkflowRequest,
} from "@codex-production-monitoring/contracts";

export class PolicyError extends Error {
  readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = "PolicyError";
    this.code = code;
  }
}

export interface RunBudgetLimits {
  maxRequests: number;
  maxRequestsPerSource: number;
  maxConcurrent: number;
  maxTotalCostUnits: number;
  maxTotalTimeoutMs: number;
  maxTotalBytes: number;
  maxTotalRows: number;
  maxTotalSeries: number;
  maxTotalPoints: number;
}

export interface CompileWorkflowPolicyOptions {
  request: WorkflowRequest;
  trustBundle: TrustBundle;
  /** Code-owned policy alias recovered from a sealed parent verification contract. */
  sealedVerificationPolicyAlias?: string;
  now: string;
  maxLookbackMs: number;
  maxFutureSkewMs?: number;
  runLimits: RunBudgetLimits;
}

export interface CompiledOperationPolicy {
  operationId: OperationId;
  definitionSha256: Sha256;
  sourceAlias: string;
  costUnits: number;
  limits: Readonly<OperationLimits>;
}

export interface CompiledCapabilityPackPolicy {
  packId: CapabilityPackId;
  revision: number;
  definitionSha256: Sha256;
  requiredOperationIds: readonly OperationId[];
}

export interface CompiledWorkflowPolicy {
  requestSha256: Sha256;
  trustBundleSha256: Sha256;
  profileAlias: string;
  scopeAlias: string;
  scope: Readonly<Scope>;
  origin: WorkflowRequest["origin"];
  window: Readonly<WorkflowRequest["window"]>;
  baselineWindow?: Readonly<WorkflowRequest["baselineWindow"]>;
  auditRequired: boolean;
  verificationPolicy?: Readonly<TrustedVerificationPolicy>;
  operations: Readonly<Record<string, Readonly<CompiledOperationPolicy>>>;
  capabilityPacks: Readonly<Record<string, Readonly<CompiledCapabilityPackPolicy>>>;
  runLimits: Readonly<RunBudgetLimits>;
}

function deepFreeze<T>(value: T, seen = new Set<object>()): Readonly<T> {
  if (value === null || typeof value !== "object" || seen.has(value)) return value;
  seen.add(value);
  for (const child of Object.values(value as Record<string, unknown>)) deepFreeze(child, seen);
  return Object.freeze(value);
}

function positiveInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new PolicyError("INVALID_BUDGET", `${name} must be a positive safe integer`);
  }
  return value;
}

function nonNegativeInteger(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new PolicyError("INVALID_BUDGET", `${name} must be a non-negative safe integer`);
  }
  return value;
}

export function validateRunBudgetLimits(limits: RunBudgetLimits): Readonly<RunBudgetLimits> {
  const validated: RunBudgetLimits = {
    maxRequests: positiveInteger(limits.maxRequests, "maxRequests"),
    maxRequestsPerSource: positiveInteger(limits.maxRequestsPerSource, "maxRequestsPerSource"),
    maxConcurrent: positiveInteger(limits.maxConcurrent, "maxConcurrent"),
    maxTotalCostUnits: positiveInteger(limits.maxTotalCostUnits, "maxTotalCostUnits"),
    maxTotalTimeoutMs: positiveInteger(limits.maxTotalTimeoutMs, "maxTotalTimeoutMs"),
    maxTotalBytes: positiveInteger(limits.maxTotalBytes, "maxTotalBytes"),
    maxTotalRows: nonNegativeInteger(limits.maxTotalRows, "maxTotalRows"),
    maxTotalSeries: nonNegativeInteger(limits.maxTotalSeries, "maxTotalSeries"),
    maxTotalPoints: nonNegativeInteger(limits.maxTotalPoints, "maxTotalPoints"),
  };
  if (validated.maxConcurrent > validated.maxRequests) {
    throw new PolicyError("INVALID_BUDGET", "maxConcurrent cannot exceed maxRequests");
  }
  if (validated.maxRequestsPerSource > validated.maxRequests) {
    throw new PolicyError("INVALID_BUDGET", "maxRequestsPerSource cannot exceed maxRequests");
  }
  return deepFreeze(validated);
}

/**
 * A deterministic, provider-neutral cost weight derived only from administrator-approved
 * operation ceilings. It is deliberately not a monetary estimate.
 */
export function estimateOperationCostUnits(limits: Readonly<OperationLimits>): number {
  const units =
    Math.ceil(limits.timeoutMs / 5_000) +
    Math.ceil(limits.maxBytes / 65_536) +
    Math.ceil(limits.maxRows / 100) +
    Math.ceil(limits.maxSeries / 25) +
    Math.ceil(limits.maxPoints / 500);
  if (!Number.isSafeInteger(units) || units < 1) {
    throw new PolicyError("INVALID_BUDGET", "Operation cost units are invalid");
  }
  return units;
}

function parseWindow(
  window: WorkflowRequest["window"],
  label: string,
  nowMs: number,
  maxLookbackMs: number,
  maxFutureSkewMs: number,
): void {
  const start = Date.parse(window.start);
  const end = Date.parse(window.end);
  if (!Number.isFinite(start) || !Number.isFinite(end)) {
    throw new PolicyError("INVALID_WINDOW", `${label} must use RFC 3339 timestamps`);
  }
  if (start >= end) throw new PolicyError("INVALID_WINDOW", `${label} start must precede end`);
  if (end - start > maxLookbackMs) {
    throw new PolicyError("WINDOW_TOO_LARGE", `${label} exceeds the approved lookback`);
  }
  if (end > nowMs + maxFutureSkewMs) {
    throw new PolicyError("FUTURE_WINDOW", `${label} exceeds the allowed future clock skew`);
  }
}

function minimumLimits(left: OperationLimits, right: OperationLimits): OperationLimits {
  return {
    timeoutMs: Math.min(left.timeoutMs, right.timeoutMs),
    maxAgeMs: Math.min(left.maxAgeMs, right.maxAgeMs),
    maxBytes: Math.min(left.maxBytes, right.maxBytes),
    maxRows: Math.min(left.maxRows, right.maxRows),
    maxSeries: Math.min(left.maxSeries, right.maxSeries),
    maxPoints: Math.min(left.maxPoints, right.maxPoints),
  };
}

export function compileWorkflowPolicy(
  options: CompileWorkflowPolicyOptions,
): Readonly<CompiledWorkflowPolicy> {
  if (!verifyIntegrity(options.trustBundle)) {
    throw new PolicyError("UNTRUSTED_BUNDLE", "The trust bundle integrity check failed");
  }
  const profile = options.trustBundle.profile;
  if (options.request.profileAlias !== profile.profileAlias) {
    throw new PolicyError("PROFILE_NOT_ALLOWED", "The workflow request names a different profile");
  }
  if (!profile.allowedOrigins.includes(options.request.origin)) {
    throw new PolicyError("ORIGIN_NOT_ALLOWED", "The workflow origin is not approved for this profile");
  }
  const scope = profile.scopes[options.request.scopeAlias];
  if (scope === undefined) {
    throw new PolicyError("SCOPE_NOT_ALLOWED", "The workflow scope alias is not approved");
  }
  if (profile.policy.maxEvidenceAge.mode === "OPERATOR_REQUIRED") {
    throw new PolicyError("OPERATOR_DECISION_REQUIRED", "The profile requires an approved evidence-age limit");
  }

  const nowMs = Date.parse(options.now);
  if (!Number.isFinite(nowMs)) throw new PolicyError("INVALID_TIME", "now must be an RFC 3339 timestamp");
  const maxLookbackMs = positiveInteger(options.maxLookbackMs, "maxLookbackMs");
  const maxFutureSkewMs = options.maxFutureSkewMs ?? 30_000;
  if (!Number.isSafeInteger(maxFutureSkewMs) || maxFutureSkewMs < 0) {
    throw new PolicyError("INVALID_BUDGET", "maxFutureSkewMs must be a non-negative safe integer");
  }
  parseWindow(options.request.window, "window", nowMs, maxLookbackMs, maxFutureSkewMs);
  if (options.request.baselineWindow !== undefined) {
    parseWindow(
      options.request.baselineWindow,
      "baselineWindow",
      nowMs,
      maxLookbackMs,
      maxFutureSkewMs,
    );
    const currentStart = Date.parse(options.request.window.start);
    const currentEnd = Date.parse(options.request.window.end);
    const baselineStart = Date.parse(options.request.baselineWindow.start);
    const baselineEnd = Date.parse(options.request.baselineWindow.end);
    if (baselineEnd > currentStart) {
      throw new PolicyError(
        "OVERLAPPING_BASELINE_WINDOW",
        "baselineWindow must end before the current window starts",
      );
    }
    if (baselineEnd - baselineStart !== currentEnd - currentStart) {
      throw new PolicyError(
        "INCOMPARABLE_BASELINE_WINDOW",
        "baselineWindow and window must have equal durations",
      );
    }
  }

  const requestedCapabilityPackIds = options.request.requiredCapabilityPacks ?? [];
  if (new Set(requestedCapabilityPackIds).size !== requestedCapabilityPackIds.length) {
    throw new PolicyError("DUPLICATE_CAPABILITY_PACK", "Requested capability packs must be unique");
  }
  const approvedCapabilityPacks = new Set(profile.capabilityPackIds ?? []);
  const capabilityPackSnapshots = new Map(
    (options.trustBundle.capabilityPacks ?? []).map((pack) => [pack.packId, pack]),
  );
  const capabilityPacks: Record<string, CompiledCapabilityPackPolicy> = {};
  const capabilityOperationIds: OperationId[] = [];
  for (const packId of requestedCapabilityPackIds) {
    if (!approvedCapabilityPacks.has(packId)) {
      throw new PolicyError("CAPABILITY_PACK_NOT_ALLOWED", `Capability pack ${packId} is not approved`);
    }
    const pack = capabilityPackSnapshots.get(packId);
    if (pack === undefined) {
      throw new PolicyError("CAPABILITY_PACK_NOT_SNAPSHOTTED", `Capability pack ${packId} is missing from the bundle`);
    }
    try {
      validateCapabilityPack(pack);
    } catch {
      throw new PolicyError("CAPABILITY_PACK_INVALID", `Capability pack ${packId} failed integrity validation`);
    }
    const subject = scope.subject;
    if (subject === undefined && pack.scopeMappings.some((mapping) =>
      mapping.scopeField === "subject.ref" && mapping.required)) {
      throw new PolicyError(
        "CAPABILITY_PACK_SUBJECT_REQUIRED",
        `Capability pack ${packId} requires an approved opaque subject scope`,
      );
    }
    if (subject !== undefined && !pack.supportedSubjectKinds.includes(subject.kind)) {
      throw new PolicyError(
        "CAPABILITY_PACK_SUBJECT_NOT_ALLOWED",
        `Capability pack ${packId} does not support the approved subject kind`,
      );
    }
    capabilityOperationIds.push(...pack.requiredOperationIds);
    capabilityPacks[packId] = {
      packId,
      revision: pack.revision,
      definitionSha256: pack.definitionSha256,
      requiredOperationIds: [...pack.requiredOperationIds],
    };
  }
  const baseRequested = options.request.requiredOperations ??
    (requestedCapabilityPackIds.length === 0 ? profile.operationIds : []);
  const requested = [...new Set<OperationId>([...baseRequested, ...capabilityOperationIds])];
  if (requested.length === 0) throw new PolicyError("NO_OPERATIONS", "At least one operation is required");
  if (new Set(requested).size !== requested.length) {
    throw new PolicyError("DUPLICATE_OPERATION", "Requested operations must be unique");
  }
  const approved = new Set(profile.operationIds);
  const snapshots = new Map(options.trustBundle.operations.map((entry) => [entry.operationId, entry]));
  const operations: Record<string, CompiledOperationPolicy> = {};
  for (const operationId of requested) {
    if (!approved.has(operationId)) {
      throw new PolicyError("OPERATION_NOT_ALLOWED", `Operation ${operationId} is not approved`);
    }
    const snapshot = snapshots.get(operationId);
    if (snapshot === undefined) {
      throw new PolicyError("OPERATION_NOT_SNAPSHOTTED", `Operation ${operationId} is missing from the bundle`);
    }
    let limits = minimumLimits(profile.policy.limits, snapshot.definition.limits);
    if (profile.policy.maxEvidenceAge.mode === "FIXED") {
      limits = { ...limits, maxAgeMs: Math.min(limits.maxAgeMs, profile.policy.maxEvidenceAge.durationSeconds * 1_000) };
    }
    operations[operationId] = {
      operationId,
      definitionSha256: snapshot.definitionSha256,
      sourceAlias: snapshot.definition.sourceAlias,
      costUnits: estimateOperationCostUnits(limits),
      limits,
    };
  }
  for (const packId of requestedCapabilityPackIds) {
    const pack = capabilityPackSnapshots.get(packId)!;
    const requiredMappings = pack.scopeMappings.filter((mapping) => mapping.required);
    for (const operationId of pack.requiredOperationIds) {
      const snapshot = snapshots.get(operationId)!;
      for (const mapping of requiredMappings) {
        if (snapshot.definition.scopeMapping[mapping.scopeField] !== mapping.providerField) {
          throw new PolicyError(
            "CAPABILITY_PACK_SCOPE_UNPROVEN",
            `Capability pack ${packId} cannot prove a required scope binding for ${operationId}`,
          );
        }
      }
    }
  }

  if (options.request.workflow === "verify" && options.request.verificationPolicyAlias !== undefined) {
    throw new PolicyError(
      "VERIFICATION_POLICY_OVERRIDE",
      "Verification policy is derived from the sealed parent and cannot be supplied by the request",
    );
  }
  if (options.request.workflow !== "verify" && options.sealedVerificationPolicyAlias !== undefined) {
    throw new PolicyError("VERIFICATION_POLICY_OVERRIDE", "A sealed verification policy is valid only for verification runs");
  }
  const policyAlias = options.request.workflow === "verify"
    ? options.sealedVerificationPolicyAlias
    : options.request.verificationPolicyAlias ?? profile.defaultVerificationPolicyAlias;
  let verificationPolicy: TrustedVerificationPolicy | undefined;
  if (policyAlias !== undefined) {
    verificationPolicy = profile.verificationPolicies?.[policyAlias];
    if (verificationPolicy === undefined || verificationPolicy.policyAlias !== policyAlias) {
      throw new PolicyError("VERIFICATION_POLICY_NOT_ALLOWED", "The verification policy alias is not approved");
    }
    if (verificationPolicy.passCount > verificationPolicy.requiredSamples) {
      throw new PolicyError("INVALID_VERIFICATION_POLICY", "passCount cannot exceed requiredSamples");
    }
    const criterionIds = verificationPolicy.criteria.map((criterion) => criterion.criterionId);
    if (new Set(criterionIds).size !== criterionIds.length) {
      throw new PolicyError("INVALID_VERIFICATION_POLICY", "Verification criterion IDs must be unique");
    }
    for (const criterion of verificationPolicy.criteria) {
      const compiledOperation = operations[criterion.operationId];
      const snapshot = snapshots.get(criterion.operationId);
      if (compiledOperation === undefined || snapshot === undefined) {
        throw new PolicyError(
          "VERIFICATION_OPERATION_NOT_SELECTED",
          `Verification operation ${criterion.operationId} is not in the sealed run ledger`,
        );
      }
      if (criterion.maxEvidenceAgeMs > compiledOperation.limits.maxAgeMs) {
        throw new PolicyError("INVALID_VERIFICATION_POLICY", "Verification freshness cannot widen the operation limit");
      }
      if (criterion.requiredDurationSeconds !== undefined && criterion.requiredDurationSeconds > verificationPolicy.windowDurationSeconds) {
        throw new PolicyError("INVALID_VERIFICATION_POLICY", "Criterion duration cannot exceed the verification window");
      }
      if (snapshot.definition.normalization.resultKind !== criterion.valueSelector.kind) {
        throw new PolicyError("INVALID_VERIFICATION_POLICY", "Verification selector kind differs from the operation contract");
      }
      if (
        new Set(["LT", "LTE", "GT", "GTE"]).has(criterion.comparator) &&
        (typeof criterion.expected !== "number" || !Number.isFinite(criterion.expected))
      ) {
        throw new PolicyError("INVALID_VERIFICATION_POLICY", "Numeric verification comparators require a finite numeric expected value");
      }
      if (
        new Set(["ACTIVE", "INACTIVE"]).has(criterion.comparator) &&
        criterion.expected !== true
      ) {
        throw new PolicyError("INVALID_VERIFICATION_POLICY", "Activity comparators require the canonical expected value true");
      }
      if (
        (criterion.valueSelector.reducer === "ALL" && criterion.valueSelector.kind !== "TIMESERIES") ||
        (verificationPolicy.requiredSamples > 1 && criterion.valueSelector.kind === "SCALAR")
      ) {
        throw new PolicyError("INVALID_VERIFICATION_POLICY", "Verification sample count is incompatible with its selector");
      }
      if (
        snapshot.definition.normalization.targetUnit !== undefined &&
        criterion.unit !== snapshot.definition.normalization.targetUnit
      ) {
        throw new PolicyError("INVALID_VERIFICATION_POLICY", "Verification unit differs from the normalized operation unit");
      }
    }
  } else if (options.request.workflow === "verify") {
    throw new PolicyError("VERIFICATION_POLICY_REQUIRED", "Verification requires an administrator-owned policy");
  }

  return deepFreeze({
    requestSha256: sha256Canonical(options.request),
    trustBundleSha256: options.trustBundle.integrity.contentSha256,
    profileAlias: profile.profileAlias,
    scopeAlias: options.request.scopeAlias,
    scope: { ...scope },
    origin: options.request.origin,
    window: { ...options.request.window },
    ...(options.request.baselineWindow === undefined
      ? {}
      : { baselineWindow: { ...options.request.baselineWindow } }),
    auditRequired: profile.policy.auditRequired,
    ...(verificationPolicy === undefined ? {} : { verificationPolicy: structuredClone(verificationPolicy) }),
    operations,
    capabilityPacks,
    runLimits: validateRunBudgetLimits(options.runLimits),
  });
}

export function authorizeOperationLimits(
  policy: CompiledWorkflowPolicy,
  operationId: OperationId,
  requested: Partial<OperationLimits> = {},
): Readonly<OperationLimits> {
  const operation = policy.operations[operationId];
  if (operation === undefined) {
    throw new PolicyError("OPERATION_NOT_ALLOWED", `Operation ${operationId} is not in the sealed policy`);
  }
  const keys = ["timeoutMs", "maxAgeMs", "maxBytes", "maxRows", "maxSeries", "maxPoints"] as const;
  const zeroAllowed = new Set<(typeof keys)[number]>(["maxAgeMs", "maxRows", "maxSeries", "maxPoints"]);
  const limits = { ...operation.limits };
  for (const key of keys) {
    const value = requested[key];
    if (value === undefined) continue;
    if (zeroAllowed.has(key)) nonNegativeInteger(value, key);
    else positiveInteger(value, key);
    if (value > operation.limits[key]) {
      throw new PolicyError("BUDGET_WIDENING", `${key} exceeds the sealed operation limit`);
    }
    limits[key] = value;
  }
  return deepFreeze(limits);
}
