import {
  sha256Canonical,
  verifyIntegrity,
  type ContradictionRecord,
  type EvidenceEnvelope,
  type EvidenceId,
  type OperationId,
  type RunId,
  type VerificationContract,
  type WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import type {
  BudgetUsage,
  CompiledWorkflowPolicy,
} from "@codex-production-monitoring/policy";
import {
  estimateOperationCostUnits,
  validateRunBudgetLimits,
} from "@codex-production-monitoring/policy";
import { AtomicStateFile, RunStoreError } from "@codex-production-monitoring/run-store";

export interface BudgetHistoryEntry {
  reservationId: string;
  operationId: OperationId;
  outcome: "RESERVED" | "SETTLED" | "CANCELLED";
  usage?: BudgetUsage;
}

export interface SealedArtifactCheckpoint {
  bundleId: string;
  manifestSha256: string;
  artifactRelativePath: string;
  status: "COMPLETE" | "PARTIAL" | "BLOCKED";
}

export interface RuntimeSessionCheckpoint {
  schemaVersion: "1.0.0";
  runId: RunId;
  /** Monotonic CAS token for this checkpoint file. */
  checkpointRevision: number;
  /** Run-store revision that fenced the writer. */
  runRevision: number;
  request: WorkflowRequest;
  policy: CompiledWorkflowPolicy;
  evidence: EvidenceEnvelope[];
  contradictions: ContradictionRecord[];
  budgetHistory: BudgetHistoryEntry[];
  completedByKey: Array<[string, EvidenceId]>;
  incompleteKeys: string[];
  deferredOperations?: Array<[OperationId, string]>;
  auditEventCount: number;
  verificationContract?: VerificationContract;
  sealedArtifact?: SealedArtifactCheckpoint;
}

export type RuntimeSessionCheckpointDraft = Omit<RuntimeSessionCheckpoint, "checkpointRevision">;

function safeCollectionKey(key: string): boolean {
  return /^[A-Za-z0-9._:-]{1,128}\|[a-f0-9]{64}$/u.test(key);
}

const USAGE_KEYS = ["timeoutMs", "bytes", "rows", "series", "points"] as const;
const RUN_LIMIT_KEYS = [
  "maxRequests",
  "maxRequestsPerSource",
  "maxConcurrent",
  "maxTotalCostUnits",
  "maxTotalTimeoutMs",
  "maxTotalBytes",
  "maxTotalRows",
  "maxTotalSeries",
  "maxTotalPoints",
] as const;
const OPERATION_LIMIT_KEYS = [
  "timeoutMs",
  "maxAgeMs",
  "maxBytes",
  "maxRows",
  "maxSeries",
  "maxPoints",
] as const;

function hasExactKeys(value: object, expected: readonly string[]): boolean {
  const actual = Object.keys(value).sort();
  return actual.length === expected.length &&
    actual.every((key, index) => key === [...expected].sort()[index]);
}

function assertUsage(usage: BudgetUsage | undefined): void {
  if (
    usage === undefined ||
    usage === null ||
    typeof usage !== "object" ||
    Array.isArray(usage) ||
    !hasExactKeys(usage, USAGE_KEYS)
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Settled budget history has invalid usage");
  }
  for (const key of USAGE_KEYS) {
    const value = usage[key];
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new RunStoreError("STATE_CORRUPT", "Budget history is invalid");
    }
  }
}

function assertCompiledBudgetPolicy(policy: CompiledWorkflowPolicy): void {
  try {
    if (
      policy.runLimits === null ||
      typeof policy.runLimits !== "object" ||
      Array.isArray(policy.runLimits) ||
      !hasExactKeys(policy.runLimits, RUN_LIMIT_KEYS)
    ) {
      throw new Error("run limits are malformed");
    }
    validateRunBudgetLimits(policy.runLimits);
    if (
      policy.operations === null ||
      typeof policy.operations !== "object" ||
      Array.isArray(policy.operations) ||
      Object.keys(policy.operations).length === 0
    ) {
      throw new Error("operation policy is malformed");
    }
    for (const [key, operation] of Object.entries(policy.operations)) {
      if (
        operation === null ||
        typeof operation !== "object" ||
        Array.isArray(operation) ||
        !hasExactKeys(operation, ["operationId", "definitionSha256", "sourceAlias", "costUnits", "limits"]) ||
        key !== operation.operationId ||
        !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u.test(operation.operationId) ||
        !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u.test(operation.sourceAlias) ||
        !/^[a-f0-9]{64}$/u.test(operation.definitionSha256) ||
        operation.limits === null ||
        typeof operation.limits !== "object" ||
        Array.isArray(operation.limits) ||
        !hasExactKeys(operation.limits, OPERATION_LIMIT_KEYS)
      ) {
        throw new Error("compiled operation is malformed");
      }
      const limits = operation.limits;
      if (
        !Number.isSafeInteger(limits.timeoutMs) || limits.timeoutMs < 1 || limits.timeoutMs > 300_000 ||
        !Number.isSafeInteger(limits.maxAgeMs) || limits.maxAgeMs < 0 || limits.maxAgeMs > 31_536_000_000 ||
        !Number.isSafeInteger(limits.maxBytes) || limits.maxBytes < 1 || limits.maxBytes > 1_073_741_824 ||
        !Number.isSafeInteger(limits.maxRows) || limits.maxRows < 0 || limits.maxRows > 1_000_000 ||
        !Number.isSafeInteger(limits.maxSeries) || limits.maxSeries < 0 || limits.maxSeries > 100_000 ||
        !Number.isSafeInteger(limits.maxPoints) || limits.maxPoints < 0 || limits.maxPoints > 10_000_000 ||
        !Number.isSafeInteger(operation.costUnits) ||
        operation.costUnits !== estimateOperationCostUnits(limits)
      ) {
        throw new Error("compiled operation budget is invalid");
      }
    }
  } catch {
    throw new RunStoreError("STATE_CORRUPT", "Runtime checkpoint budget policy is invalid");
  }
}

export function validateRuntimeCheckpoint(
  value: RuntimeSessionCheckpoint,
  expected: { runId: RunId; trustBundleSha256: string; profileAlias: string },
): RuntimeSessionCheckpoint {
  if (
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    value.request === null ||
    typeof value.request !== "object" ||
    Array.isArray(value.request) ||
    value.policy === null ||
    typeof value.policy !== "object" ||
    Array.isArray(value.policy) ||
    value.schemaVersion !== "1.0.0" ||
    value.runId !== expected.runId ||
    !Number.isSafeInteger(value.checkpointRevision) ||
    value.checkpointRevision < 1 ||
    !Number.isSafeInteger(value.runRevision) ||
    value.runRevision < 0 ||
    value.request.profileAlias !== expected.profileAlias ||
    sha256Canonical(value.request) !== value.policy.requestSha256 ||
    value.policy.trustBundleSha256 !== expected.trustBundleSha256 ||
    !Array.isArray(value.evidence) ||
    !Array.isArray(value.contradictions) ||
    !Array.isArray(value.budgetHistory) ||
    !Array.isArray(value.completedByKey) ||
    !Array.isArray(value.incompleteKeys) ||
    !(value.deferredOperations === undefined || Array.isArray(value.deferredOperations)) ||
    !Number.isSafeInteger(value.auditEventCount) ||
    value.auditEventCount < 0
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Runtime session checkpoint is invalid");
  }
  assertCompiledBudgetPolicy(value.policy);
  const evidenceIds = new Set<EvidenceId>();
  for (const envelope of value.evidence) {
    if (
      envelope.runId !== expected.runId ||
      envelope.trustBundleSha256 !== expected.trustBundleSha256 ||
      !verifyIntegrity(envelope) ||
      evidenceIds.has(envelope.evidenceId)
    ) {
      throw new RunStoreError("STATE_CORRUPT", "Checkpointed evidence failed integrity validation");
    }
    evidenceIds.add(envelope.evidenceId);
  }
  for (const contradiction of value.contradictions) {
    if (contradiction.runId !== expected.runId || !verifyIntegrity(contradiction)) {
      throw new RunStoreError("STATE_CORRUPT", "Checkpointed contradiction failed integrity validation");
    }
  }
  const keys = new Set<string>();
  for (const item of value.completedByKey) {
    if (!Array.isArray(item) || item.length !== 2 || !safeCollectionKey(item[0]) || !evidenceIds.has(item[1]) || keys.has(item[0])) {
      throw new RunStoreError("STATE_CORRUPT", "Checkpointed collection index is invalid");
    }
    keys.add(item[0]);
  }
  for (const key of value.incompleteKeys) {
    if (!safeCollectionKey(key) || keys.has(key)) {
      throw new RunStoreError("STATE_CORRUPT", "Checkpointed incomplete collection index is invalid");
    }
  }
  const deferredOperationIds = new Set<OperationId>();
  for (const item of value.deferredOperations ?? []) {
    if (
      !Array.isArray(item) ||
      item.length !== 2 ||
      value.policy.operations[item[0]] === undefined ||
      deferredOperationIds.has(item[0]) ||
      !/^[A-Z][A-Z0-9_]{0,127}$/u.test(item[1])
    ) {
      throw new RunStoreError("STATE_CORRUPT", "Checkpointed deferred-operation ledger is invalid");
    }
    deferredOperationIds.add(item[0]);
  }
  const reservationIds = new Set<string>();
  for (const history of value.budgetHistory) {
    if (
      history === null ||
      typeof history !== "object" ||
      Array.isArray(history) ||
      !/^budget_[1-9a-z][0-9a-z]{0,31}$/u.test(history.reservationId) ||
      reservationIds.has(history.reservationId) ||
      value.policy.operations[history.operationId] === undefined ||
      !new Set(["RESERVED", "SETTLED", "CANCELLED"]).has(history.outcome)
    ) {
      throw new RunStoreError("STATE_CORRUPT", "Budget history names an unauthorized operation");
    }
    reservationIds.add(history.reservationId);
    if (history.outcome === "SETTLED") assertUsage(history.usage);
    else if (history.usage !== undefined) {
      throw new RunStoreError("STATE_CORRUPT", "Unsettled budget history unexpectedly contains usage");
    }
  }
  if (
    value.verificationContract !== undefined &&
    value.verificationContract.contractSha256 !== sha256Canonical({
      policyAlias: value.verificationContract.policyAlias,
      scope: value.verificationContract.scope,
      ...(value.verificationContract.cohort === undefined ? {} : { cohort: value.verificationContract.cohort }),
      windowStrategy: value.verificationContract.windowStrategy,
      windowDurationSeconds: value.verificationContract.windowDurationSeconds,
      requiredSamples: value.verificationContract.requiredSamples,
      passCount: value.verificationContract.passCount,
      criteria: value.verificationContract.criteria,
    })
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Verification contract checkpoint is invalid");
  }
  return structuredClone(value);
}

export class RuntimeCheckpointStore {
  readonly #stateRoot: string;

  constructor(stateRoot: string) {
    this.#stateRoot = stateRoot;
  }

  read(runId: RunId): RuntimeSessionCheckpoint | undefined {
    return this.#file(runId).read();
  }

  write(checkpoint: RuntimeSessionCheckpointDraft, expectedCheckpointRevision: number): number {
    if (
      !Number.isSafeInteger(expectedCheckpointRevision) ||
      expectedCheckpointRevision < 0 ||
      !Number.isSafeInteger(checkpoint.runRevision) ||
      checkpoint.runRevision < 0
    ) {
      throw new RunStoreError("STALE_REVISION", "Checkpoint revision is invalid");
    }
    return this.#file(checkpoint.runId).transact((current) => {
      if (
        current !== undefined &&
        (
          !Number.isSafeInteger(current.checkpointRevision) ||
          current.checkpointRevision < 1 ||
          current.checkpointRevision === Number.MAX_SAFE_INTEGER ||
          !Number.isSafeInteger(current.runRevision) ||
          current.runRevision < 0
        )
      ) {
        throw new RunStoreError("STATE_CORRUPT", "Checkpoint fencing metadata is invalid");
      }
      if (current === undefined && expectedCheckpointRevision !== 0) {
        throw new RunStoreError("STALE_REVISION", "The checkpoint revision has changed");
      }
      const currentCheckpointRevision = current?.checkpointRevision ?? 0;
      const currentRunRevision = current?.runRevision ?? -1;
      if (checkpoint.runRevision < currentRunRevision) {
        throw new RunStoreError("STALE_REVISION", "A newer run owner already persisted this checkpoint");
      }
      if (
        checkpoint.runRevision === currentRunRevision &&
        expectedCheckpointRevision !== currentCheckpointRevision
      ) {
        throw new RunStoreError("STALE_REVISION", "The checkpoint revision has changed");
      }
      const checkpointRevision = currentCheckpointRevision + 1;
      return {
        payload: { ...checkpoint, checkpointRevision },
        result: checkpointRevision,
      };
    });
  }

  #file(runId: RunId): AtomicStateFile<RuntimeSessionCheckpoint> {
    if (!/^pmrun_[A-Za-z0-9_-]{20,128}$/u.test(runId)) {
      throw new RunStoreError("STATE_FILE_INVALID", "Run ID cannot name a checkpoint file");
    }
    return new AtomicStateFile({
      stateRoot: this.#stateRoot,
      filename: `session-${runId}.json`,
      kind: "production-monitoring-runtime-session-v1",
    });
  }
}
