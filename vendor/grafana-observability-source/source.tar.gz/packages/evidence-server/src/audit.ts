import { existsSync, readdirSync } from "node:fs";

import type { AuditEvent, AuditSink } from "@codex-production-monitoring/adapter-host";
import { canonicalJson, computeIntegrity, sha256Canonical, type Sha256 } from "@codex-production-monitoring/contracts";
import { AtomicStateFile, RunStoreError } from "@codex-production-monitoring/run-store";

interface DurableAuditEntry {
  sequence: number;
  previousSha256: string;
  event: AuditEvent;
  entrySha256: string;
}

interface DurableAuditStateV1 {
  schemaVersion: "1.0.0";
  entries: DurableAuditEntry[];
}

interface AuditSegmentV2 {
  schemaVersion: "2.0.0";
  segment: number;
  previousSegmentSha256: Sha256;
  firstSequence: number;
  entries: DurableAuditEntry[];
}

interface AuditHeadV2 {
  schemaVersion: "2.0.0";
  format: "segmented-chain";
  segmentEntryLimit: number;
  segmentMaximumBytes: number;
  segmentCount: number;
  entryCount: number;
  lastEntrySha256: string;
  lastSegmentSha256: Sha256;
  legacySourceSha256: Sha256;
  legacyEntryCount: number;
  tailEntries: DurableAuditEntry[];
}

interface AuditLegacyTombstoneV2 {
  schemaVersion: "2.0.0";
  migratedTo: "audit-head.json";
  retainedFilename: "audit-log-v1-retained.json";
  sourcePayloadSha256: Sha256;
  sourceEntryCount: number;
}

export interface DurableAuditSinkOptions {
  /** Test/operational bound; production default is 128 and may only be narrowed. */
  segmentEntryLimit?: number;
  /** Test/operational bound; production default is 1 MiB and may only be narrowed. */
  segmentMaximumBytes?: number;
  /** Maximum number of per-run results retained by the process; defaults to 64 and may only be narrowed. */
  runCacheMaximumRuns?: number;
  /** Maximum total audit events retained across the per-run cache; defaults to 1,024 and may only be narrowed. */
  runCacheMaximumEvents?: number;
  /** Maximum canonical bytes retained across the per-run cache; defaults to 4 MiB and may only be narrowed. */
  runCacheMaximumBytes?: number;
}

export interface VolatileAuditSinkOptions {
  /** Accepted-event capacity. Once reached, append fails closed instead of dropping history. */
  maximumEvents?: number;
  /** Canonical byte capacity. Once reached, append fails closed instead of dropping history. */
  maximumBytes?: number;
}

export interface RuntimeAuditSink extends AuditSink {
  readonly durable: boolean;
  snapshot(): AuditEvent[];
  snapshotRun?(runId: AuditEvent["runId"], startIndex?: number): AuditEvent[];
  countRun?(runId: AuditEvent["runId"]): number;
}

const LEGACY_FILENAME = "audit-log.json";
const RETAINED_LEGACY_FILENAME = "audit-log-v1-retained.json";
const HEAD_FILENAME = "audit-head.json";
const DEFAULT_SEGMENT_ENTRY_LIMIT = 128;
const DEFAULT_SEGMENT_MAXIMUM_BYTES = 1_024 * 1_024;
const DEFAULT_RUN_CACHE_MAXIMUM_RUNS = 64;
const DEFAULT_RUN_CACHE_MAXIMUM_EVENTS = 1_024;
const DEFAULT_RUN_CACHE_MAXIMUM_BYTES = 4 * 1_024 * 1_024;
const DEFAULT_VOLATILE_MAXIMUM_EVENTS = 4_096;
const DEFAULT_VOLATILE_MAXIMUM_BYTES = 8 * 1_024 * 1_024;
const HEAD_MAXIMUM_BYTES = DEFAULT_SEGMENT_MAXIMUM_BYTES + 64 * 1_024;
const SEGMENT_FILENAME = /^audit-segment-(\d{8})\.json$/u;
const SEGMENT_LOCK_FILENAME = /^audit-segment-(\d{8})\.json\.lock(?:\.reclaim)?$/u;
const SEGMENT_TEMP_FILENAME = /^\.state-audit-segment-(\d{8})\.json(?:-[a-f0-9-]{36})?\.tmp$/u;
const ZERO_SHA256 = "0".repeat(64) as Sha256;

interface CachedRunEvents {
  events: AuditEvent[];
  eventCount: number;
  canonicalBytes: number;
}

function exactKeys(value: object, expected: readonly string[]): boolean {
  return canonicalJson(Object.keys(value).sort()) === canonicalJson([...expected].sort());
}

function validateEvent(event: AuditEvent): void {
  if (
    event === null ||
    typeof event !== "object" ||
    event.schemaVersion !== "1.0.0" ||
    typeof event.event !== "string" ||
    !["COLLECTION_STARTED", "COLLECTION_COMPLETED", "COLLECTION_FAILED"].includes(event.event) ||
    typeof event.at !== "string" ||
    !Number.isFinite(Date.parse(event.at)) ||
    typeof event.runId !== "string" ||
    !event.runId.startsWith("pmrun_") ||
    typeof event.operationId !== "string" ||
    event.operationId.length === 0 ||
    typeof event.adapterPackageId !== "string" ||
    event.adapterPackageId.length === 0
  ) {
    throw new RunStoreError("AUDIT_CORRUPT", "Audit event is invalid");
  }
}

function entryHash(entry: Omit<DurableAuditEntry, "entrySha256">): string {
  return sha256Canonical({
    domain: "pm-durable-audit-v1",
    sequence: entry.sequence,
    previousSha256: entry.previousSha256,
    event: entry.event,
  });
}

function validateEntries(
  entries: DurableAuditEntry[],
  firstSequence: number,
  previousEntrySha256: string,
): string {
  let previousSha256 = previousEntrySha256;
  for (let index = 0; index < entries.length; index += 1) {
    const entry = entries[index] as DurableAuditEntry | undefined;
    if (
      entry === undefined ||
      entry === null ||
      typeof entry !== "object" ||
      Array.isArray(entry) ||
      !exactKeys(entry, ["entrySha256", "event", "previousSha256", "sequence"]) ||
      !Number.isSafeInteger(entry.sequence) ||
      typeof entry.previousSha256 !== "string" ||
      !/^[a-f0-9]{64}$/u.test(entry.previousSha256) ||
      entry.event === null ||
      typeof entry.event !== "object"
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit entry is invalid");
    }
    validateEvent(entry.event);
    if (
      entry.sequence !== firstSequence + index ||
      entry.previousSha256 !== previousSha256 ||
      !/^[a-f0-9]{64}$/u.test(entry.entrySha256) ||
      entryHash({ sequence: entry.sequence, previousSha256, event: entry.event }) !== entry.entrySha256
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit append chain integrity failed");
    }
    previousSha256 = entry.entrySha256;
  }
  return previousSha256;
}

function validateLegacyState(value: DurableAuditStateV1 | undefined): DurableAuditStateV1 {
  if (
    value === undefined ||
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["entries", "schemaVersion"]) ||
    value.schemaVersion !== "1.0.0" ||
    !Array.isArray(value.entries)
  ) {
    throw new RunStoreError("AUDIT_CORRUPT", "Audit v1 state is invalid");
  }
  validateEntries(value.entries, 1, ZERO_SHA256);
  return structuredClone(value);
}

function validateTombstone(value: unknown): AuditLegacyTombstoneV2 {
  if (
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, ["migratedTo", "retainedFilename", "schemaVersion", "sourceEntryCount", "sourcePayloadSha256"])
  ) {
    throw new RunStoreError("AUDIT_CORRUPT", "Audit v1 migration tombstone is invalid");
  }
  const tombstone = value as AuditLegacyTombstoneV2;
  if (
    tombstone.schemaVersion !== "2.0.0" ||
    tombstone.migratedTo !== HEAD_FILENAME ||
    tombstone.retainedFilename !== RETAINED_LEGACY_FILENAME ||
    !Number.isSafeInteger(tombstone.sourceEntryCount) ||
    tombstone.sourceEntryCount < 0 ||
    !/^[a-f0-9]{64}$/u.test(tombstone.sourcePayloadSha256)
  ) {
    throw new RunStoreError("AUDIT_CORRUPT", "Audit v1 migration tombstone is invalid");
  }
  return structuredClone(tombstone);
}

function validateHead(value: AuditHeadV2 | undefined): AuditHeadV2 {
  if (
    value === undefined ||
    value === null ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    !exactKeys(value, [
      "entryCount",
      "format",
      "lastEntrySha256",
      "lastSegmentSha256",
      "legacyEntryCount",
      "legacySourceSha256",
      "schemaVersion",
      "segmentCount",
      "segmentEntryLimit",
      "segmentMaximumBytes",
      "tailEntries",
    ]) ||
    value.schemaVersion !== "2.0.0" ||
    value.format !== "segmented-chain" ||
    !Number.isSafeInteger(value.segmentEntryLimit) ||
    value.segmentEntryLimit < 1 ||
    value.segmentEntryLimit > DEFAULT_SEGMENT_ENTRY_LIMIT ||
    !Number.isSafeInteger(value.segmentMaximumBytes) ||
    value.segmentMaximumBytes < 1 ||
    value.segmentMaximumBytes > DEFAULT_SEGMENT_MAXIMUM_BYTES ||
    !Number.isSafeInteger(value.segmentCount) ||
    value.segmentCount < 0 ||
    !Number.isSafeInteger(value.entryCount) ||
    value.entryCount < 0 ||
    !/^[a-f0-9]{64}$/u.test(value.lastEntrySha256) ||
    !/^[a-f0-9]{64}$/u.test(value.lastSegmentSha256) ||
    !/^[a-f0-9]{64}$/u.test(value.legacySourceSha256) ||
    !Number.isSafeInteger(value.legacyEntryCount) ||
    value.legacyEntryCount < 0 ||
    !Array.isArray(value.tailEntries) ||
    value.tailEntries.length > value.segmentEntryLimit
  ) {
    throw new RunStoreError("AUDIT_CORRUPT", "Audit v2 head is invalid");
  }
  return structuredClone(value);
}

function segmentFilename(segment: number): string {
  return `audit-segment-${segment.toString().padStart(8, "0")}.json`;
}

function atomicEnvelopeBytes(payload: unknown, kind: string): number {
  const withoutIntegrity = { schemaVersion: "1.0.0" as const, kind, generation: 1, payload };
  const envelope = { ...withoutIntegrity, integrity: computeIntegrity(withoutIntegrity) };
  return Buffer.byteLength(`${canonicalJson(envelope)}\n`, "utf8");
}

/**
 * Owner-only, integrity-chained append log. History is split into fixed-entry,
 * fixed-byte immutable segments plus one bounded active tail in the head. An
 * ordinary append rewrites only the head; rotation writes the exact tail once
 * and then advances the head. Snapshot/restart verify every chain link.
 */
export class DurableAuditSink implements RuntimeAuditSink {
  readonly durable = true;
  readonly #stateRoot: string;
  readonly #head: AtomicStateFile<AuditHeadV2>;
  readonly #configuredEntryLimit: number;
  readonly #configuredMaximumBytes: number;
  readonly #runCacheMaximumRuns: number;
  readonly #runCacheMaximumEvents: number;
  readonly #runCacheMaximumBytes: number;
  readonly #runCache = new Map<AuditEvent["runId"], CachedRunEvents>();
  #runCacheEventCount = 0;
  #runCacheCanonicalBytes = 0;
  #cachedHead: AuditHeadV2 | undefined;

  constructor(stateRoot: string, options: DurableAuditSinkOptions = {}) {
    this.#stateRoot = stateRoot;
    this.#configuredEntryLimit = options.segmentEntryLimit ?? DEFAULT_SEGMENT_ENTRY_LIMIT;
    this.#configuredMaximumBytes = options.segmentMaximumBytes ?? DEFAULT_SEGMENT_MAXIMUM_BYTES;
    this.#runCacheMaximumRuns = options.runCacheMaximumRuns ?? DEFAULT_RUN_CACHE_MAXIMUM_RUNS;
    this.#runCacheMaximumEvents = options.runCacheMaximumEvents ?? DEFAULT_RUN_CACHE_MAXIMUM_EVENTS;
    this.#runCacheMaximumBytes = options.runCacheMaximumBytes ?? DEFAULT_RUN_CACHE_MAXIMUM_BYTES;
    if (
      !Number.isSafeInteger(this.#configuredEntryLimit) ||
      this.#configuredEntryLimit < 1 ||
      this.#configuredEntryLimit > DEFAULT_SEGMENT_ENTRY_LIMIT ||
      !Number.isSafeInteger(this.#configuredMaximumBytes) ||
      this.#configuredMaximumBytes < 1 ||
      this.#configuredMaximumBytes > DEFAULT_SEGMENT_MAXIMUM_BYTES ||
      !Number.isSafeInteger(this.#runCacheMaximumRuns) ||
      this.#runCacheMaximumRuns < 1 ||
      this.#runCacheMaximumRuns > DEFAULT_RUN_CACHE_MAXIMUM_RUNS ||
      !Number.isSafeInteger(this.#runCacheMaximumEvents) ||
      this.#runCacheMaximumEvents < 1 ||
      this.#runCacheMaximumEvents > DEFAULT_RUN_CACHE_MAXIMUM_EVENTS ||
      !Number.isSafeInteger(this.#runCacheMaximumBytes) ||
      this.#runCacheMaximumBytes < 1 ||
      this.#runCacheMaximumBytes > DEFAULT_RUN_CACHE_MAXIMUM_BYTES
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit segment or cache limits are invalid");
    }
    this.#head = new AtomicStateFile({
      stateRoot,
      filename: HEAD_FILENAME,
      kind: "production-monitoring-audit-head-v2",
      maximumBytes: HEAD_MAXIMUM_BYTES,
    });
    this.#head.recoverAbandonedArtifacts();
    this.#head.transact((current) => {
      if (current !== undefined) {
        let head = validateHead(current);
        if (
          head.segmentEntryLimit !== this.#configuredEntryLimit ||
          head.segmentMaximumBytes !== this.#configuredMaximumBytes
        ) {
          throw new RunStoreError("AUDIT_CORRUPT", "Audit segment limits changed after initialization");
        }
        this.#verifyLegacy(head);
        head = this.#reconcileCrashTail(head, true);
        this.#verifySegments(head, false);
        this.#cachedHead = structuredClone(head);
        return { payload: head, result: undefined };
      }
      return this.#legacyFile().transact((legacyCurrent) => {
        const legacy = this.#prepareLegacyLocked(legacyCurrent);
        const head = this.#migrateLegacy(legacy);
        this.#verifySegments(head, false);
        this.#cachedHead = structuredClone(head);
        return {
          payload: this.#legacyTombstone(head.legacySourceSha256, head.legacyEntryCount),
          result: { payload: head, result: undefined },
        };
      });
    });
  }

  async append(event: Readonly<AuditEvent>): Promise<void> {
    validateEvent(event as AuditEvent);
    try {
      this.#head.transact((current) => {
        const head = this.#reconcileCrashTail(validateHead(current));
        this.#ensureValidatedHead(head);
        const previousEntrySha256 = head.lastEntrySha256;
        const draft = {
          sequence: head.entryCount + 1,
          previousSha256: previousEntrySha256,
          event: structuredClone(event) as AuditEvent,
        };
        const entry: DurableAuditEntry = { ...draft, entrySha256: entryHash(draft) };
        const single = this.#segmentPayload(head.segmentCount + 1, head.lastSegmentSha256, [entry]);
        if (atomicEnvelopeBytes(single, "production-monitoring-audit-segment-v2") > head.segmentMaximumBytes) {
          throw new RunStoreError("STATE_TOO_LARGE", "One audit entry exceeds the segment size limit");
        }
        const candidateTail = [...head.tailEntries, entry];
        const candidate = this.#segmentPayload(
          head.segmentCount + 1,
          head.lastSegmentSha256,
          candidateTail,
        );
        if (
          candidateTail.length <= head.segmentEntryLimit &&
          atomicEnvelopeBytes(candidate, "production-monitoring-audit-segment-v2") <= head.segmentMaximumBytes
        ) {
          const nextHead: AuditHeadV2 = {
            ...head,
            entryCount: entry.sequence,
            lastEntrySha256: entry.entrySha256,
            tailEntries: candidateTail,
          };
          this.#assertHeadFits(nextHead);
          this.#recordValidatedAppend(nextHead, entry);
          return { payload: nextHead, result: undefined };
        }
        if (head.tailEntries.length === 0) {
          throw new RunStoreError("STATE_TOO_LARGE", "One audit entry exceeds the configured segment bounds");
        }
        const published = this.#segmentPayload(
          head.segmentCount + 1,
          head.lastSegmentSha256,
          head.tailEntries,
        );
        const nextHead: AuditHeadV2 = {
          ...head,
          segmentCount: head.segmentCount + 1,
          entryCount: entry.sequence,
          lastEntrySha256: entry.entrySha256,
          lastSegmentSha256: sha256Canonical(published),
          tailEntries: [entry],
        };
        // Prove both future authority files fit before publishing either one.
        this.#assertHeadFits(nextHead);
        this.#segmentFile(published.segment, head.segmentMaximumBytes).write(published);
        this.#recordValidatedAppend(nextHead, entry);
        return { payload: nextHead, result: undefined };
      });
    } catch (error) {
      if (!(error instanceof RunStoreError && error.code === "STATE_TOO_LARGE")) {
        this.#invalidateValidation();
      }
      throw error;
    }
  }

  snapshot(): AuditEvent[] {
    return this.#snapshot();
  }

  snapshotRun(runId: AuditEvent["runId"], startIndex = 0): AuditEvent[] {
    if (!Number.isSafeInteger(startIndex) || startIndex < 0) {
      throw new TypeError("Audit run snapshot start index is invalid");
    }
    return this.#snapshot(runId, startIndex);
  }

  countRun(runId: AuditEvent["runId"]): number {
    try {
      let needsCrashCommit = false;
      const inspected = this.#head.inspect((current) => {
        const head = this.#reconcileCrashTail(validateHead(current));
        if (canonicalJson(head) !== canonicalJson(current)) {
          needsCrashCommit = true;
          return undefined;
        }
        return this.#countForHead(head, runId);
      });
      if (!needsCrashCommit) return inspected!;
      return this.#head.transact((current) => {
        const head = this.#reconcileCrashTail(validateHead(current));
        return { payload: head, result: this.#countForHead(head, runId) };
      });
    } catch (error) {
      this.#invalidateValidation();
      throw error;
    }
  }

  #snapshot(runId?: AuditEvent["runId"], startIndex = 0): AuditEvent[] {
    try {
      let needsCrashCommit = false;
      const inspected = this.#head.inspect((current) => {
        const head = this.#reconcileCrashTail(validateHead(current), runId === undefined);
        if (canonicalJson(head) !== canonicalJson(current)) {
          needsCrashCommit = true;
          return undefined;
        }
        return this.#eventsForHead(head, runId, startIndex);
      });
      if (!needsCrashCommit) return inspected!;
      return this.#head.transact((current) => {
        const head = this.#reconcileCrashTail(validateHead(current), runId === undefined);
        return { payload: head, result: this.#eventsForHead(head, runId, startIndex) };
      });
    } catch (error) {
      this.#invalidateValidation();
      throw error;
    }
  }

  #eventsForHead(
    head: AuditHeadV2,
    runId?: AuditEvent["runId"],
    startIndex = 0,
  ): AuditEvent[] {
    if (runId !== undefined) {
      this.#ensureValidatedHead(head);
      const cached = this.#cachedRun(runId);
      if (cached !== undefined) return cached.slice(startIndex);
    }
    const events: AuditEvent[] = [];
    let matchingIndex = 0;
    this.#verifySegments(head, false, runId === undefined, (segment) => {
      for (const entry of segment.entries) {
        if (runId === undefined || entry.event.runId === runId) {
          if (matchingIndex >= startIndex) events.push(structuredClone(entry.event));
          matchingIndex += 1;
        }
      }
    });
    for (const entry of head.tailEntries) {
      if (runId === undefined || entry.event.runId === runId) {
        if (matchingIndex >= startIndex) events.push(structuredClone(entry.event));
        matchingIndex += 1;
      }
    }
    this.#cachedHead = structuredClone(head);
    if (runId !== undefined && startIndex === 0) this.#storeRunCache(runId, events);
    return events;
  }

  #countForHead(head: AuditHeadV2, runId: AuditEvent["runId"]): number {
    this.#ensureValidatedHead(head);
    const cached = this.#runCache.get(runId);
    if (cached !== undefined) return cached.eventCount;
    let count = 0;
    this.#verifySegments(head, false, false, (segment) => {
      for (const entry of segment.entries) {
        if (entry.event.runId === runId) count += 1;
      }
    });
    for (const entry of head.tailEntries) {
      if (entry.event.runId === runId) count += 1;
    }
    this.#cachedHead = structuredClone(head);
    return count;
  }

  #invalidateValidation(): void {
    this.#cachedHead = undefined;
    this.#clearRunCache();
  }

  #clearRunCache(): void {
    this.#runCache.clear();
    this.#runCacheEventCount = 0;
    this.#runCacheCanonicalBytes = 0;
  }

  #removeRunCache(runId: AuditEvent["runId"]): void {
    const cached = this.#runCache.get(runId);
    if (cached === undefined) return;
    this.#runCache.delete(runId);
    this.#runCacheEventCount -= cached.eventCount;
    this.#runCacheCanonicalBytes -= cached.canonicalBytes;
  }

  #cachedRun(runId: AuditEvent["runId"]): AuditEvent[] | undefined {
    const cached = this.#runCache.get(runId);
    if (cached === undefined) return undefined;
    this.#runCache.delete(runId);
    this.#runCache.set(runId, cached);
    return structuredClone(cached.events);
  }

  #storeRunCache(runId: AuditEvent["runId"], sourceEvents: readonly AuditEvent[]): void {
    const events = structuredClone([...sourceEvents]);
    const eventCount = events.length;
    const canonicalBytes = Buffer.byteLength(canonicalJson(events), "utf8");
    this.#removeRunCache(runId);
    if (
      eventCount > this.#runCacheMaximumEvents ||
      canonicalBytes > this.#runCacheMaximumBytes
    ) return;
    while (
      this.#runCache.size >= this.#runCacheMaximumRuns ||
      this.#runCacheEventCount + eventCount > this.#runCacheMaximumEvents ||
      this.#runCacheCanonicalBytes + canonicalBytes > this.#runCacheMaximumBytes
    ) {
      const oldest = this.#runCache.keys().next().value as AuditEvent["runId"] | undefined;
      if (oldest === undefined) break;
      this.#removeRunCache(oldest);
    }
    this.#runCache.set(runId, { events, eventCount, canonicalBytes });
    this.#runCacheEventCount += eventCount;
    this.#runCacheCanonicalBytes += canonicalBytes;
  }

  #recordValidatedAppend(head: AuditHeadV2, entry: DurableAuditEntry): void {
    const cached = this.#runCache.get(entry.event.runId);
    if (cached !== undefined) {
      this.#storeRunCache(entry.event.runId, [...cached.events, entry.event]);
    }
    this.#cachedHead = structuredClone(head);
  }

  #ensureValidatedHead(head: AuditHeadV2): void {
    const cached = this.#cachedHead;
    if (cached === undefined) {
      this.#verifySegments(head, false, false);
      this.#cachedHead = structuredClone(head);
      return;
    }
    if (canonicalJson(cached) === canonicalJson(head)) return;
    this.#clearRunCache();
    if (
      head.segmentCount < cached.segmentCount ||
      head.entryCount < cached.entryCount ||
      head.segmentEntryLimit !== cached.segmentEntryLimit ||
      head.segmentMaximumBytes !== cached.segmentMaximumBytes ||
      head.legacySourceSha256 !== cached.legacySourceSha256 ||
      head.legacyEntryCount !== cached.legacyEntryCount
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit head rolled back or changed immutable configuration");
    }

    let previousEntrySha256 = cached.lastEntrySha256;
    let expectedSequence = cached.entryCount + 1;
    let previousSegmentSha256 = cached.lastSegmentSha256;
    if (head.segmentCount === cached.segmentCount) {
      if (
        head.lastSegmentSha256 !== cached.lastSegmentSha256 ||
        head.tailEntries.length < cached.tailEntries.length ||
        canonicalJson(head.tailEntries.slice(0, cached.tailEntries.length)) !== canonicalJson(cached.tailEntries)
      ) {
        throw new RunStoreError("AUDIT_CORRUPT", "Audit active tail is not append-only");
      }
      const suffix = head.tailEntries.slice(cached.tailEntries.length);
      previousEntrySha256 = validateEntries(suffix, expectedSequence, previousEntrySha256);
      expectedSequence += suffix.length;
    } else {
      for (let number = cached.segmentCount + 1; number <= head.segmentCount; number += 1) {
        const segment = this.#readSegment(number, head);
        const firstNewSegment = number === cached.segmentCount + 1;
        const expectedFirst = firstNewSegment
          ? cached.entryCount - cached.tailEntries.length + 1
          : expectedSequence;
        const priorEntry = firstNewSegment && cached.tailEntries.length > 0
          ? cached.tailEntries[0]!.previousSha256
          : previousEntrySha256;
        if (
          segment.previousSegmentSha256 !== previousSegmentSha256 ||
          segment.firstSequence !== expectedFirst ||
          (firstNewSegment &&
            canonicalJson(segment.entries.slice(0, cached.tailEntries.length)) !== canonicalJson(cached.tailEntries))
        ) {
          throw new RunStoreError("AUDIT_CORRUPT", "New audit segment does not extend the validated cache");
        }
        validateEntries(segment.entries, expectedFirst, priorEntry);
        const suffix = firstNewSegment
          ? segment.entries.slice(cached.tailEntries.length)
          : segment.entries;
        if (suffix.length > 0) {
          previousEntrySha256 = suffix.at(-1)!.entrySha256;
          expectedSequence += suffix.length;
        }
        previousSegmentSha256 = sha256Canonical(segment);
      }
      previousEntrySha256 = validateEntries(head.tailEntries, expectedSequence, previousEntrySha256);
      expectedSequence += head.tailEntries.length;
    }
    if (
      expectedSequence !== head.entryCount + 1 ||
      previousEntrySha256 !== head.lastEntrySha256 ||
      previousSegmentSha256 !== head.lastSegmentSha256
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit cache catch-up does not match the committed head");
    }
    this.#cachedHead = structuredClone(head);
  }

  #readSegment(segment: number, head: AuditHeadV2): AuditSegmentV2 {
    const value = this.#segmentFile(segment, head.segmentMaximumBytes).read() as unknown;
    if (
      value === undefined ||
      value === null ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      !exactKeys(value, ["entries", "firstSequence", "previousSegmentSha256", "schemaVersion", "segment"])
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit segment envelope payload is invalid");
    }
    const candidate = value as AuditSegmentV2;
    if (
      candidate.schemaVersion !== "2.0.0" ||
      candidate.segment !== segment ||
      !Number.isSafeInteger(candidate.firstSequence) ||
      candidate.firstSequence < 1 ||
      !/^[a-f0-9]{64}$/u.test(candidate.previousSegmentSha256) ||
      !Array.isArray(candidate.entries) ||
      candidate.entries.length < 1 ||
      candidate.entries.length > head.segmentEntryLimit ||
      atomicEnvelopeBytes(candidate, "production-monitoring-audit-segment-v2") > head.segmentMaximumBytes
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit segment metadata is invalid");
    }
    return structuredClone(candidate);
  }

  #segmentPayload(
    segment: number,
    previousSegmentSha256: Sha256,
    entries: DurableAuditEntry[],
  ): AuditSegmentV2 {
    return {
      schemaVersion: "2.0.0",
      segment,
      previousSegmentSha256,
      firstSequence: entries[0]!.sequence,
      entries: structuredClone(entries),
    };
  }

  #segmentFile(segment: number, maximumBytes: number): AtomicStateFile<AuditSegmentV2> {
    return new AtomicStateFile({
      stateRoot: this.#stateRoot,
      filename: segmentFilename(segment),
      kind: "production-monitoring-audit-segment-v2",
      maximumBytes,
    });
  }

  #assertHeadFits(head: AuditHeadV2): void {
    if (atomicEnvelopeBytes(head, "production-monitoring-audit-head-v2") > HEAD_MAXIMUM_BYTES) {
      throw new RunStoreError("STATE_TOO_LARGE", "Audit active tail exceeds the head size limit");
    }
  }

  #verifySegments(
    head: AuditHeadV2,
    allowNextCrash: boolean,
    fullInventory = true,
    visit?: (segment: AuditSegmentV2) => void,
  ): void {
    const hasCrashTail = fullInventory &&
      this.#segmentInventory(head, allowNextCrash).length === head.segmentCount + 1;
    let previousSegmentSha256 = ZERO_SHA256;
    let previousEntrySha256: string = ZERO_SHA256;
    let entryCount = 0;
    for (let segmentNumber = 1; segmentNumber <= head.segmentCount; segmentNumber += 1) {
      const segment = this.#readSegment(segmentNumber, head);
      if (
        segment.previousSegmentSha256 !== previousSegmentSha256 ||
        segment.firstSequence !== entryCount + 1
      ) {
        throw new RunStoreError("AUDIT_CORRUPT", "Audit segment chain metadata is invalid");
      }
      previousEntrySha256 = validateEntries(segment.entries, segment.firstSequence, previousEntrySha256);
      entryCount += segment.entries.length;
      previousSegmentSha256 = sha256Canonical(segment);
      visit?.(segment);
    }
    const tailLastSha256 = validateEntries(head.tailEntries, entryCount + 1, previousEntrySha256);
    const tailPayload = head.tailEntries.length === 0
      ? undefined
      : this.#segmentPayload(head.segmentCount + 1, previousSegmentSha256, head.tailEntries);
    if (
      entryCount + head.tailEntries.length !== head.entryCount ||
      tailLastSha256 !== head.lastEntrySha256 ||
      (head.segmentCount === 0
        ? head.lastSegmentSha256 !== ZERO_SHA256
        : previousSegmentSha256 !== head.lastSegmentSha256) ||
      (tailPayload !== undefined &&
        atomicEnvelopeBytes(tailPayload, "production-monitoring-audit-segment-v2") > head.segmentMaximumBytes)
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit head does not match its committed segments");
    }
    if (hasCrashTail) {
      const crashTail = this.#validateCrashTail(head);
      if (allowNextCrash) visit?.(crashTail);
    }
  }

  #segmentInventory(head: AuditHeadV2, allowNextCrash: boolean): string[] {
    const inventory = readdirSync(this.#stateRoot);
    for (const name of inventory) {
      const artifact = SEGMENT_LOCK_FILENAME.exec(name) ?? SEGMENT_TEMP_FILENAME.exec(name);
      if (artifact !== null) {
        const segment = Number.parseInt(artifact[1]!, 10);
        if (segment < 1 || artifact[1] !== segment.toString().padStart(8, "0")) {
          throw new RunStoreError("AUDIT_CORRUPT", "Audit contains an invalid segment artifact filename");
        }
        this.#segmentFile(segment, head.segmentMaximumBytes).recoverAbandonedArtifacts();
      }
      if (name.startsWith(".state-audit-segment-") && artifact === null) {
        throw new RunStoreError("AUDIT_CORRUPT", "Audit contains malformed owned segment temporary state");
      }
    }
    const names = inventory
      .filter((name) => name.startsWith("audit-segment-") && SEGMENT_FILENAME.test(name))
      .sort();
    if (inventory.some((name) => name.startsWith("audit-segment-") &&
      !SEGMENT_FILENAME.test(name) && !SEGMENT_LOCK_FILENAME.test(name))) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit contains an invalid segment filename");
    }
    const maximumAllowed = head.segmentCount + (allowNextCrash ? 1 : 0);
    if (names.length < head.segmentCount || names.length > maximumAllowed) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit contains uncommitted segment files beyond one bounded crash tail");
    }
    for (let segmentNumber = 1; segmentNumber <= names.length; segmentNumber += 1) {
      const expectedName = segmentFilename(segmentNumber);
      if (names[segmentNumber - 1] !== expectedName || !SEGMENT_FILENAME.test(expectedName)) {
        throw new RunStoreError("AUDIT_CORRUPT", "Audit segment sequence has a gap or invalid filename");
      }
    }
    return names;
  }

  #validateCrashTail(head: AuditHeadV2): AuditSegmentV2 {
    const crashTail = this.#readSegment(head.segmentCount + 1, head);
    if (
      crashTail.previousSegmentSha256 !== head.lastSegmentSha256 ||
      head.tailEntries.length === 0 ||
      crashTail.firstSequence !== head.entryCount - head.tailEntries.length + 1 ||
      canonicalJson(crashTail.entries) !== canonicalJson(head.tailEntries)
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Uncommitted audit segment is not the exact authoritative head tail");
    }
    return crashTail;
  }

  #reconcileCrashTail(head: AuditHeadV2, fullInventory = false): AuditHeadV2 {
    let hasCrashTail: boolean;
    if (fullInventory) {
      hasCrashTail = this.#segmentInventory(head, true).length === head.segmentCount + 1;
    } else {
      const next = head.segmentCount + 1;
      const beyond = next + 1;
      const nextBase = `${this.#stateRoot}/${segmentFilename(next)}`;
      if (
        existsSync(`${nextBase}.lock`) ||
        existsSync(`${nextBase}.lock.reclaim`) ||
        existsSync(`${this.#stateRoot}/.state-${segmentFilename(next)}.tmp`)
      ) {
        this.#segmentFile(next, head.segmentMaximumBytes).recoverAbandonedExactArtifacts();
      }
      const beyondBase = `${this.#stateRoot}/${segmentFilename(beyond)}`;
      if (
        existsSync(beyondBase) ||
        existsSync(`${beyondBase}.lock`) ||
        existsSync(`${beyondBase}.lock.reclaim`) ||
        existsSync(`${this.#stateRoot}/.state-${segmentFilename(beyond)}.tmp`)
      ) {
        throw new RunStoreError("AUDIT_CORRUPT", "Audit contains state beyond one bounded crash tail");
      }
      hasCrashTail = existsSync(nextBase);
    }
    if (!hasCrashTail) return head;
    const tail = this.#validateCrashTail(head);
    return {
      ...head,
      segmentCount: tail.segment,
      lastSegmentSha256: sha256Canonical(tail),
      tailEntries: [],
    };
  }

  #migrateLegacy(legacy: DurableAuditStateV1): AuditHeadV2 {
    let previousSegmentSha256 = ZERO_SHA256;
    const expected = new Map<number, AuditSegmentV2>();
    const chunks: DurableAuditEntry[][] = [];
    let active: DurableAuditEntry[] = [];
    for (const entry of legacy.entries) {
      const candidate = [...active, entry];
      const candidatePayload = this.#segmentPayload(chunks.length + 1, previousSegmentSha256, candidate);
      if (
        candidate.length > this.#configuredEntryLimit ||
        atomicEnvelopeBytes(candidatePayload, "production-monitoring-audit-segment-v2") > this.#configuredMaximumBytes
      ) {
        if (active.length === 0) {
          throw new RunStoreError("STATE_TOO_LARGE", "Legacy audit entry exceeds the configured segment size");
        }
        chunks.push(active);
        active = [entry];
        const single = this.#segmentPayload(chunks.length + 1, previousSegmentSha256, active);
        if (atomicEnvelopeBytes(single, "production-monitoring-audit-segment-v2") > this.#configuredMaximumBytes) {
          throw new RunStoreError("STATE_TOO_LARGE", "Legacy audit entry exceeds the configured segment size");
        }
      } else {
        active = candidate;
      }
    }
    // Keep the final bounded chunk authoritative in the head. Only completed
    // earlier chunks become immutable files during migration.
    for (let index = 0; index < chunks.length; index += 1) {
      const segment = this.#segmentPayload(index + 1, previousSegmentSha256, chunks[index]!);
      expected.set(index + 1, segment);
      previousSegmentSha256 = sha256Canonical(segment);
    }
    const segmentCount = expected.size;
    const tailEntries = active;
    const existingNames = readdirSync(this.#stateRoot)
      .filter((name) =>
        name.startsWith("audit-segment-") &&
        !name.endsWith(".json.lock") &&
        !name.endsWith(".json.lock.reclaim"))
      .sort();
    for (const name of existingNames) {
      const match = SEGMENT_FILENAME.exec(name);
      if (match === null) throw new RunStoreError("AUDIT_CORRUPT", "Invalid audit segment exists during v1 migration");
      const number = Number.parseInt(match[1]!, 10);
      const expectedSegment = expected.get(number);
      if (expectedSegment === undefined || name !== segmentFilename(number)) {
        throw new RunStoreError("AUDIT_CORRUPT", "Unexpected audit segment exists during v1 migration");
      }
      const current = this.#segmentFile(number, this.#configuredMaximumBytes).read();
      if (canonicalJson(current) !== canonicalJson(expectedSegment)) {
        throw new RunStoreError("AUDIT_CORRUPT", "Partial audit v1 migration segment is not the exact append-only prefix");
      }
    }
    for (const [number, segment] of expected) {
      if (!existsSync(`${this.#stateRoot}/${segmentFilename(number)}`)) {
        this.#segmentFile(number, this.#configuredMaximumBytes).write(segment);
      }
    }
    const sourcePayloadSha256 = sha256Canonical(legacy);
    const head: AuditHeadV2 = {
      schemaVersion: "2.0.0",
      format: "segmented-chain",
      segmentEntryLimit: this.#configuredEntryLimit,
      segmentMaximumBytes: this.#configuredMaximumBytes,
      segmentCount,
      entryCount: legacy.entries.length,
      lastEntrySha256: legacy.entries.at(-1)?.entrySha256 ?? ZERO_SHA256,
      lastSegmentSha256: previousSegmentSha256,
      legacySourceSha256: sourcePayloadSha256,
      legacyEntryCount: legacy.entries.length,
      tailEntries: structuredClone(tailEntries),
    };
    this.#assertHeadFits(head);
    return head;
  }

  #prepareLegacyLocked(legacy: unknown): DurableAuditStateV1 {
    const retainedExists = existsSync(`${this.#stateRoot}/${RETAINED_LEGACY_FILENAME}`);
    if (legacy === undefined && !retainedExists) {
      const empty: DurableAuditStateV1 = { schemaVersion: "1.0.0", entries: [] };
      this.#retainedLegacyFile().write(empty);
      return empty;
    }
    if (legacy === undefined) {
      const retained = validateLegacyState(this.#retainedLegacyFile().read());
      const segmentNames = readdirSync(this.#stateRoot).filter((name) => SEGMENT_FILENAME.test(name));
      if (retained.entries.length !== 0 || segmentNames.length !== 0) {
        throw new RunStoreError("AUDIT_CORRUPT", "Uncommitted fresh audit migration staging is invalid");
      }
      return retained;
    }
    if ((legacy as { schemaVersion?: unknown } | undefined)?.schemaVersion === "1.0.0") {
      const state = validateLegacyState(legacy as DurableAuditStateV1);
      this.#retainedLegacyFile().write(state);
      return state;
    }
    const tombstone = validateTombstone(legacy);
    const retained = validateLegacyState(this.#retainedLegacyFile().read());
    if (
      sha256Canonical(retained) !== tombstone.sourcePayloadSha256 ||
      retained.entries.length !== tombstone.sourceEntryCount
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Retained audit v1 state does not match its tombstone");
    }
    return retained;
  }

  #legacyTombstone(sourcePayloadSha256: Sha256, sourceEntryCount: number): AuditLegacyTombstoneV2 {
    return {
      schemaVersion: "2.0.0",
      migratedTo: HEAD_FILENAME,
      retainedFilename: RETAINED_LEGACY_FILENAME,
      sourcePayloadSha256,
      sourceEntryCount,
    };
  }

  #legacyFile(): AtomicStateFile<unknown> {
    return new AtomicStateFile({
      stateRoot: this.#stateRoot,
      filename: LEGACY_FILENAME,
      kind: "production-monitoring-audit-log-v1",
    });
  }

  #retainedLegacyFile(): AtomicStateFile<DurableAuditStateV1> {
    return new AtomicStateFile({
      stateRoot: this.#stateRoot,
      filename: RETAINED_LEGACY_FILENAME,
      kind: "production-monitoring-audit-log-v1-retained",
    });
  }

  #verifyLegacy(head: AuditHeadV2): void {
    if (!existsSync(`${this.#stateRoot}/${LEGACY_FILENAME}`)) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit migration tombstone is missing");
    }
    const tombstone = validateTombstone(this.#legacyFile().read());
    const retained = validateLegacyState(this.#retainedLegacyFile().read());
    if (
      tombstone.sourcePayloadSha256 !== head.legacySourceSha256 ||
      tombstone.sourceEntryCount !== head.legacyEntryCount ||
      sha256Canonical(retained) !== head.legacySourceSha256 ||
      retained.entries.length !== head.legacyEntryCount
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Audit migration evidence does not match the committed head");
    }
  }
}

export class VolatileAuditSink implements RuntimeAuditSink {
  readonly durable = false;
  readonly #events: AuditEvent[] = [];
  readonly #maximumEvents: number;
  readonly #maximumBytes: number;
  #canonicalBytes = 0;

  constructor(options: VolatileAuditSinkOptions = {}) {
    this.#maximumEvents = options.maximumEvents ?? DEFAULT_VOLATILE_MAXIMUM_EVENTS;
    this.#maximumBytes = options.maximumBytes ?? DEFAULT_VOLATILE_MAXIMUM_BYTES;
    if (
      !Number.isSafeInteger(this.#maximumEvents) ||
      this.#maximumEvents < 1 ||
      this.#maximumEvents > DEFAULT_VOLATILE_MAXIMUM_EVENTS ||
      !Number.isSafeInteger(this.#maximumBytes) ||
      this.#maximumBytes < 1 ||
      this.#maximumBytes > DEFAULT_VOLATILE_MAXIMUM_BYTES
    ) {
      throw new RunStoreError("AUDIT_CORRUPT", "Volatile audit capacity is invalid");
    }
  }

  async append(event: Readonly<AuditEvent>): Promise<void> {
    validateEvent(event as AuditEvent);
    const cloned = structuredClone(event) as AuditEvent;
    const bytes = Buffer.byteLength(canonicalJson(cloned), "utf8");
    if (this.#events.length + 1 > this.#maximumEvents || this.#canonicalBytes + bytes > this.#maximumBytes) {
      throw new RunStoreError("STATE_TOO_LARGE", "Volatile audit capacity is exhausted");
    }
    this.#events.push(cloned);
    this.#canonicalBytes += bytes;
  }
  snapshot(): AuditEvent[] { return structuredClone(this.#events); }
  snapshotRun(runId: AuditEvent["runId"], startIndex = 0): AuditEvent[] {
    if (!Number.isSafeInteger(startIndex) || startIndex < 0) {
      throw new TypeError("Audit run snapshot start index is invalid");
    }
    return structuredClone(this.#events.filter((event) => event.runId === runId).slice(startIndex));
  }
  countRun(runId: AuditEvent["runId"]): number {
    return this.#events.reduce((count, event) => count + (event.runId === runId ? 1 : 0), 0);
  }
}
