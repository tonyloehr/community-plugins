import { tmpdir } from "node:os";
import { isAbsolute, join, resolve } from "node:path";
import { realpathSync } from "node:fs";

import { loadActivatedTrustRoot } from "@codex-production-monitoring/config";
import { sha256Bytes } from "@codex-production-monitoring/contracts";
import type { ArtifactProducer } from "@codex-production-monitoring/artifacts";
import {
  GrafanaCredentialKeyring,
  SharedGrafanaProfileCredentialSource,
  SharedGrafanaProfileStore,
  type GrafanaKeyringBackend,
  type SharedGrafanaProfileRegistryStore,
} from "../../grafana-credential-profile/src/index.ts";
import { createProviderRuntime } from "../../provider-runtime/src/index.ts";

import { createFixtureRuntimeDefinition } from "./fixture-runtime.ts";
import { MonitoringRuntime } from "./service.ts";
import type { MonitoringRuntimeOptions } from "./types.ts";

function requiredAbsolutePath(value: string, name: string): string {
  if (!isAbsolute(value)) throw new Error(`${name} must be an absolute path`);
  return resolve(value);
}

export interface RuntimeEnvironmentDependencies {
  /** Injected code-owned native keyring backend. No environment, file, shell, or keyutils fallback exists. */
  grafanaKeyringBackend?: GrafanaKeyringBackend;
  /** Injected only for tests; production resolves the shared owner-only profile registry. */
  grafanaProfileStore?: SharedGrafanaProfileRegistryStore;
  /** Code-owned caller identity; never sourced from process environment. */
  artifactProducer?: ArtifactProducer;
  /** Code-owned plugin namespace. The shared credential profile is deliberately not stored here. */
  runtimeNamespace?: "production-monitoring" | "grafana-observability";
}

export function defaultRuntimeArtifactRoot(
  runtimeNamespace: NonNullable<RuntimeEnvironmentDependencies["runtimeNamespace"]> = "production-monitoring",
): string {
  return join(
    realpathSync.native(tmpdir()),
    `codex-${runtimeNamespace}-${typeof process.getuid === "function" ? process.getuid() : "local"}`,
  );
}

export function createRuntimeFromEnvironment(
  environment: NodeJS.ProcessEnv = process.env,
  dependencies: RuntimeEnvironmentDependencies = {},
): MonitoringRuntime {
  const mode = environment.PRODUCTION_MONITORING_MODE ?? "fixture";
  const defaultRoot = defaultRuntimeArtifactRoot(dependencies.runtimeNamespace);
  const artifactRoot = requiredAbsolutePath(
    environment.PRODUCTION_MONITORING_ARTIFACT_ROOT ?? defaultRoot,
    "PRODUCTION_MONITORING_ARTIFACT_ROOT",
  );
  const stateRoot = environment.PRODUCTION_MONITORING_STATE_ROOT === undefined
    ? `${artifactRoot}.state`
    : requiredAbsolutePath(environment.PRODUCTION_MONITORING_STATE_ROOT, "PRODUCTION_MONITORING_STATE_ROOT");
  let definition: Pick<MonitoringRuntimeOptions, "bundle" | "registrations" | "configurationIssues" | "onClose">;
  let surface: MonitoringRuntimeOptions["surface"];
  if (mode === "fixture") {
    definition = createFixtureRuntimeDefinition();
    surface = "fixture";
  } else if (mode === "live") {
    const trustRoot = environment.PRODUCTION_MONITORING_TRUST_ROOT;
    if (trustRoot === undefined) {
      throw new Error("PRODUCTION_MONITORING_TRUST_ROOT is required in live mode");
    }
    const activationReceipt = environment.PRODUCTION_MONITORING_ACTIVATION_RECEIPT;
    if (activationReceipt === undefined) {
      throw new Error("PRODUCTION_MONITORING_ACTIVATION_RECEIPT is required in live mode");
    }
    const loaded = loadActivatedTrustRoot({
      receiptPath: requiredAbsolutePath(
        activationReceipt,
        "PRODUCTION_MONITORING_ACTIVATION_RECEIPT",
      ),
      trustRootPath: requiredAbsolutePath(trustRoot, "PRODUCTION_MONITORING_TRUST_ROOT"),
      forbiddenWorkspaceRoots: [process.cwd()],
    });
    const providerRuntime = createProviderRuntime(loaded, {
      environment,
      ...(dependencies.grafanaKeyringBackend === undefined
        ? {}
        : {
            credentialSource: new SharedGrafanaProfileCredentialSource(
              new GrafanaCredentialKeyring(dependencies.grafanaKeyringBackend),
              dependencies.grafanaProfileStore ?? new SharedGrafanaProfileStore(),
            ),
          }),
    });
    definition = {
      bundle: loaded.bundle as MonitoringRuntimeOptions["bundle"],
      registrations: providerRuntime.registrations,
      configurationIssues: providerRuntime.issues,
      onClose: () => providerRuntime.close(),
    };
    surface = "local-stdio";
  } else {
    throw new Error("PRODUCTION_MONITORING_MODE must be fixture or live");
  }
  return new MonitoringRuntime({
    ...definition,
    artifactRoot,
    stateRoot,
    surface,
    routeDescription: mode === "fixture"
      ? "Credential-free deterministic fixture; no provider network request"
      : "Operator-host route constrained by the active endpoint registry",
    principal: {
      issuerAlias: environment.PRODUCTION_MONITORING_PRINCIPAL_ISSUER ?? "local-process",
      subject: environment.PRODUCTION_MONITORING_PRINCIPAL_SUBJECT ?? `uid:${typeof process.getuid === "function" ? process.getuid() : "local"}`,
      tenant: environment.PRODUCTION_MONITORING_PRINCIPAL_TENANT ?? "local",
      session: environment.PRODUCTION_MONITORING_PRINCIPAL_SESSION ?? `state:${sha256Bytes(stateRoot).slice(0, 24)}`,
    },
    ...(dependencies.artifactProducer === undefined
      ? {}
      : { artifactProducer: dependencies.artifactProducer }),
  });
}
