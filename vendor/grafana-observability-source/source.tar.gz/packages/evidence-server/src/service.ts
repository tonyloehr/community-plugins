import { randomUUID } from "node:crypto";

import {
  EvidenceHost,
  MemoryEvidenceStore,
  StaticAdapterRegistry,
  detectContradictions,
  type AdapterRegistration,
  type AuditEvent,
} from "@codex-production-monitoring/adapter-host";
import { systemClock, type Clock } from "@codex-production-monitoring/adapter-sdk";
import {
  ArtifactStore,
  bundleIdForRunId,
  computeVerificationContractHash,
  incidentPresentation,
  type InvestigationDraft,
} from "@codex-production-monitoring/artifacts";
import {
  canonicalJson,
  computeIntegrity,
  deriveEvidenceState,
  sha256Canonical,
  type AnalysisDraft,
  type CapabilityPackSignalV1,
  type ContradictionId,
  type ContradictionRecord,
  type EvidenceEnvelope,
  type EvidenceId,
  type EvidenceStateSummary,
  type JsonPrimitive,
  type MonitoringWorkspaceId,
  type MonitoringWorkspaceSnapshot,
  type MonitoringWorkspaceSnapshotRead,
  type OperationId,
  type OperationSnapshot,
  type RunHandle,
  type RunId,
  type Scope,
  type Sha256,
  type TimeWindow,
  type VerificationContract,
  type VerificationCriterion,
  type WorkbenchEvidenceDetail,
  type WorkbenchEvidenceRef,
  type WorkbenchIssueRef,
  type WorkbenchLinkRef,
  type WorkbenchResolvedLinkTarget,
  type WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import {
  BudgetLedger,
  compileWorkflowPolicy,
  estimateOperationCostUnits,
  type BudgetUsage,
  type CompiledWorkflowPolicy,
} from "@codex-production-monitoring/policy";
import {
  DurableRunStore,
  InMemoryRunStore,
  MAXIMUM_AUTHORITY_COMPONENT_REVISION,
  RunStoreError,
  type PrincipalIdentity,
  type RunAccess,
  type RunStore,
} from "@codex-production-monitoring/run-store";

import {
  RuntimeCheckpointStore,
  validateRuntimeCheckpoint,
  type BudgetHistoryEntry,
  type RuntimeSessionCheckpointDraft,
  type SealedArtifactCheckpoint,
} from "./checkpoint.ts";
import { DurableAuditSink, VolatileAuditSink, type RuntimeAuditSink } from "./audit.ts";
import {
  WORKBENCH_RUN_INVENTORY_LIMIT,
  buildWorkbenchProjection,
  latestWorkspaceId,
  patchContextForProjection,
  workspaceIdForRun,
  type WorkbenchPatchContext,
  type WorkbenchProjection,
  type WorkbenchProjectionAuthority,
} from "./workbench.ts";

import type {
  BeginRunOutput,
  CollectOutput,
  FinalizeOutput,
  MonitoringRuntimeOptions,
  RuntimeAuditSnapshot,
  RuntimeCapability,
} from "./types.ts";
import { validateAnalysisDraft, validateWorkflowRequest } from "./validation.ts";

interface RuntimeSession {
  request: WorkflowRequest;
  policy: Readonly<CompiledWorkflowPolicy>;
  budget: BudgetLedger;
  evidence: Map<EvidenceId, EvidenceEnvelope>;
  contradictions: ContradictionRecord[];
  budgetHistory: BudgetHistoryEntry[];
  completedByKey: Map<string, EvidenceId>;
  incompleteKeys: Set<string>;
  deferredOperations: Map<OperationId, string>;
  auditEventCount: number;
  verificationContract?: VerificationContract;
  sealedArtifact?: SealedArtifactCheckpoint;
  activeHandle?: RunHandle;
  activeRevision?: number;
  leaseHandle?: string;
  leaseExpiresAt?: string;
  checkpointRevision: number;
}

interface CheckpointAuthority {
  runHandle: RunHandle;
  runRevision: number;
  leaseHandle?: string;
}

const DEFAULT_RUN_TTL_MS = 60 * 60 * 1_000;
const DEFAULT_LEASE_TTL_MS = 60 * 1_000;
const DEFAULT_MAX_CACHED_SESSIONS = 128;
const MAX_MAX_CACHED_SESSIONS = 4_096;
const DEFAULT_MAX_DIAGNOSTIC_EVENTS = 256;
const MAX_MAX_DIAGNOSTIC_EVENTS = 4_096;

function boundedRuntimeLimit(value: number | undefined, fallback: number, maximum: number, name: string): number {
  const selected = value ?? fallback;
  if (!Number.isSafeInteger(selected) || selected < 1 || selected > maximum) {
    throw new TypeError(`${name} must be a positive safe integer no greater than ${maximum}`);
  }
  return selected;
}

function assertAlias(value: string, label: string): void {
  if (!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u.test(value)) {
    throw new TypeError(`${label} is not a configured alias`);
  }
}

function uniqueOperationIds(values: readonly string[]): OperationId[] {
  const operationIds = values.map((value) => {
    assertAlias(value, "operation ID");
    return value as OperationId;
  });
  if (new Set(operationIds).size !== operationIds.length) {
    throw new TypeError("Operation IDs must be unique");
  }
  return operationIds;
}

function evidenceUsage(envelope: EvidenceEnvelope, elapsedMs: number): BudgetUsage {
  let rows = 0;
  let series = 0;
  let points = 0;
  for (const value of envelope.values) {
    if (value.kind === "TABLE") rows += value.rows.length;
    else if (value.kind === "TIMESERIES") {
      series += 1;
      points += value.points.length;
    } else rows += 1;
  }
  return {
    timeoutMs: Math.max(0, Math.ceil(elapsedMs)),
    bytes: Buffer.byteLength(canonicalJson(envelope), "utf8"),
    rows,
    series,
    points,
  };
}

function safeObservationStatement(envelope: EvidenceEnvelope): string {
  const state = deriveEvidenceState({
    collectionState: envelope.collectionState,
    freshnessState: envelope.freshnessState,
    hasUnresolvedContradiction: false,
  });
  return `${envelope.operationId} returned ${state} ${envelope.source.provider} evidence for the authorized scope.`;
}

function operationSnapshotHash(operations: readonly OperationSnapshot[]): Sha256 {
  return sha256Canonical(
    operations.map((operation) => ({
      operationId: operation.operationId,
      revision: operation.revision,
      definitionSha256: operation.definitionSha256,
    })),
  );
}

function collectionKey(operationId: OperationId, window: TimeWindow): string {
  return `${operationId}|${sha256Canonical(window)}`;
}

function safeFailureCode(error: unknown): string {
  const code = (error as { code?: unknown }).code;
  return typeof code === "string" && /^[A-Z][A-Z0-9_]{0,127}$/u.test(code)
    ? code
    : "COLLECTION_FAILED";
}

function finalizedEvidenceSummary(
  evidence: readonly EvidenceEnvelope[],
  contradictions: readonly ContradictionRecord[],
): EvidenceStateSummary {
  const contradictoryEvidenceIds = new Set(
    contradictions
      .filter((contradiction) => contradiction.resolutionState === "UNRESOLVED")
      .flatMap((contradiction) => contradiction.claimRefs.map((claim) => claim.evidenceId)),
  );
  const summary: EvidenceStateSummary = {
    COMPLETE: 0,
    EMPTY: 0,
    STALE: 0,
    CONTRADICTORY: 0,
    ERROR: 0,
  };
  for (const envelope of evidence) {
    const state = deriveEvidenceState({
      collectionState: envelope.collectionState,
      freshnessState: envelope.freshnessState,
      hasUnresolvedContradiction: contradictoryEvidenceIds.has(envelope.evidenceId),
    });
    summary[state] += 1;
  }
  return summary;
}

function isLeaseAuthorityFailure(error: unknown): boolean {
  const code = (error as { code?: unknown }).code;
  return typeof code === "string" && new Set([
    "ACCESS_DENIED",
    "LEASE_REQUIRED",
    "RUN_EXPIRED",
    "RUN_TERMINAL",
    "STALE_REVISION",
  ]).has(code);
}

function buildVerificationContract(
  policy: Readonly<CompiledWorkflowPolicy>,
): VerificationContract | undefined {
  const configured = policy.verificationPolicy;
  if (configured === undefined) return undefined;
  const semantic: Omit<VerificationContract, "contractSha256"> = {
    policyAlias: configured.policyAlias,
    scope: structuredClone(policy.scope),
    windowStrategy: configured.windowStrategy,
    windowDurationSeconds: configured.windowDurationSeconds,
    requiredSamples: configured.requiredSamples,
    passCount: configured.passCount,
    criteria: configured.criteria.map((criterion) => ({
      ...structuredClone(criterion),
      operationDefinitionSha256: policy.operations[criterion.operationId]!.definitionSha256,
    })),
  };
  return { ...semantic, contractSha256: computeVerificationContractHash(semantic) };
}

function comparePrimitive(left: JsonPrimitive, comparator: VerificationContract["criteria"][number]["comparator"], right: JsonPrimitive): boolean {
  if (comparator === "EQ") return canonicalJson(left) === canonicalJson(right);
  if (typeof left !== "number" || typeof right !== "number") return false;
  if (comparator === "LT") return left < right;
  if (comparator === "LTE") return left <= right;
  if (comparator === "GT") return left > right;
  if (comparator === "GTE") return left >= right;
  return false;
}

function activityState(value: JsonPrimitive): boolean | undefined {
  if (typeof value === "boolean") return value;
  if (typeof value === "number" && Number.isFinite(value)) return value !== 0;
  if (typeof value !== "string") return undefined;
  const normalized = value.trim().toLowerCase();
  if (new Set(["active", "firing", "open", "true", "1"]).has(normalized)) return true;
  if (new Set(["inactive", "resolved", "closed", "false", "0"]).has(normalized)) return false;
  return undefined;
}

function evaluateVerification(
  contract: VerificationContract,
  evidence: readonly EvidenceEnvelope[],
  contradictions: readonly ContradictionRecord[],
  currentWindow: TimeWindow,
  nowMs: number,
): { status: "PASSED" | "FAILED" | "INCOMPLETE"; evidenceIds: EvidenceId[] } {
  const cited = new Set<EvidenceId>();
  let failed = false;
  let incomplete = false;
  if ((Date.parse(currentWindow.end) - Date.parse(currentWindow.start)) / 1_000 < contract.windowDurationSeconds) {
    incomplete = true;
  }
  const contradictoryEvidence = new Set(
    contradictions
      .filter((item) => item.resolutionState === "UNRESOLVED")
      .flatMap((item) => item.claimRefs.map((claim) => claim.evidenceId)),
  );
  for (const criterion of contract.criteria) {
    const matches = evidence.filter((envelope) =>
      envelope.operationId === criterion.operationId &&
      sha256Canonical(envelope.window) === sha256Canonical(currentWindow)
    );
    matches.forEach((envelope) => cited.add(envelope.evidenceId));
    const usable = matches.filter((envelope) => {
      const evaluatedAt = Date.parse(envelope.evaluatedAt);
      return envelope.operationDefinitionSha256 === criterion.operationDefinitionSha256 &&
        envelope.authority === "AUTHORITATIVE" &&
        envelope.freshnessState === "FRESH" &&
        envelope.pagination.complete &&
        !contradictoryEvidence.has(envelope.evidenceId) &&
        Number.isFinite(evaluatedAt) &&
        nowMs - evaluatedAt <= criterion.maxEvidenceAgeMs;
    });
    if (usable.length === 0 || usable.length !== matches.length) {
      incomplete = true;
      continue;
    }
    const complete = usable.filter((envelope) => envelope.collectionState === "COMPLETE");
    if (complete.length !== usable.length) {
      incomplete = true;
      continue;
    }
    const selected = complete.map((envelope) => selectedSamples(envelope, criterion));
    if (selected.some((samples) => samples === undefined)) {
      incomplete = true;
      continue;
    }
    const candidates = selected.flatMap((samples) => samples!);
    if (candidates.length < contract.requiredSamples) {
      incomplete = true;
      continue;
    }
    if (criterion.unit !== undefined && candidates.some((candidate) => candidate.unit !== criterion.unit)) {
      incomplete = true;
      continue;
    }
    const satisfying = criterion.comparator === "ACTIVE" || criterion.comparator === "INACTIVE"
      ? (() => {
          const desired = criterion.comparator === "ACTIVE";
          const states = candidates.map((candidate) => activityState(candidate.value));
          if (states.some((state) => state === undefined)) return undefined;
          return candidates.filter((_candidate, index) => states[index] === desired);
        })()
      : candidates.filter((candidate) => comparePrimitive(candidate.value, criterion.comparator, criterion.expected));
    if (satisfying === undefined) {
      incomplete = true;
      continue;
    }
    if (satisfying.length < contract.passCount) {
      failed = true;
      continue;
    }
    if (criterion.requiredDurationSeconds !== undefined) {
      const times = satisfying.map((candidate) => Date.parse(candidate.at)).filter(Number.isFinite);
      if (times.length < 2 || (Math.max(...times) - Math.min(...times)) / 1_000 < criterion.requiredDurationSeconds) {
        incomplete = true;
      }
    }
  }
  return {
    status: incomplete ? "INCOMPLETE" : failed ? "FAILED" : "PASSED",
    evidenceIds: [...cited].sort(),
  };
}

function selectedSamples(
  envelope: EvidenceEnvelope,
  criterion: VerificationCriterion,
): Array<{ value: JsonPrimitive; unit?: string; at: string }> | undefined {
  const selected: Array<{ value: JsonPrimitive; unit?: string; at: string }> = [];
  const matching = envelope.values.filter((value) =>
    value.kind === criterion.valueSelector.kind &&
    value.name === criterion.valueSelector.name &&
    (criterion.valueSelector.dimensions === undefined ||
      ("dimensions" in value && canonicalJson(value.dimensions) === canonicalJson(criterion.valueSelector.dimensions)))
  );
  if (matching.length !== 1) return undefined;
  const value = matching[0]!;
  if (value.kind === "SCALAR") {
    selected.push({
      value: value.value,
      ...(value.unit === undefined ? {} : { unit: value.unit }),
      at: value.observedAt ?? envelope.evaluatedAt,
    });
  } else if (value.kind === "TIMESERIES") {
    const points = value.points.filter((point) => point.value !== null);
    if (criterion.valueSelector.reducer === "LATEST") {
      const latest = points.at(-1);
      if (latest !== undefined) selected.push({ value: latest.value, ...(value.unit === undefined ? {} : { unit: value.unit }), at: latest.at });
    } else if (criterion.valueSelector.reducer === "ALL") {
      selected.push(...points.map((point) => ({
        value: point.value,
        ...(value.unit === undefined ? {} : { unit: value.unit }),
        at: point.at,
      })));
    } else if (points.length === 1) {
      selected.push({ value: points[0]!.value, ...(value.unit === undefined ? {} : { unit: value.unit }), at: points[0]!.at });
    }
  }
  if (criterion.valueSelector.reducer === "SINGLE" && selected.length !== 1) return [];
  return selected;
}

function restoreBudget(
  policy: Readonly<CompiledWorkflowPolicy>,
  history: readonly BudgetHistoryEntry[],
): BudgetLedger {
  const budget = new BudgetLedger(policy);
  for (const entry of history) {
    const reservation = budget.reserve(entry.operationId);
    if (reservation.reservationId !== entry.reservationId) {
      throw new TypeError("Checkpoint budget reservation order cannot be reproduced");
    }
    if (entry.outcome === "SETTLED") budget.settle(reservation.reservationId, entry.usage!);
    else if (entry.outcome === "RESERVED") {
      budget.settle(reservation.reservationId, {
        timeoutMs: reservation.limits.timeoutMs,
        bytes: reservation.limits.maxBytes,
        rows: reservation.limits.maxRows,
        series: reservation.limits.maxSeries,
        points: reservation.limits.maxPoints,
      });
    } else budget.cancel(reservation.reservationId);
  }
  return budget;
}

function pendingBudgetHistory(
  session: RuntimeSession,
  reservationId: string,
): BudgetHistoryEntry | undefined {
  return session.budgetHistory.find(
    (entry) => entry.reservationId === reservationId && entry.outcome === "RESERVED",
  );
}

function settleBudgetHistory(
  session: RuntimeSession,
  reservationId: string,
  usage: BudgetUsage,
): void {
  const entry = pendingBudgetHistory(session, reservationId);
  if (entry === undefined) throw new TypeError("Budget reservation history is not pending");
  entry.outcome = "SETTLED";
  entry.usage = { ...usage };
}

function cancelBudgetHistory(session: RuntimeSession, reservationId: string): void {
  const entry = pendingBudgetHistory(session, reservationId);
  if (entry === undefined) return;
  session.budget.cancel(reservationId);
  entry.outcome = "CANCELLED";
}

function assertRawProviderRetentionDisabled(bundle: MonitoringRuntimeOptions["bundle"]): void {
  const retention: unknown = bundle.profile.policy.rawEvidenceRetention;
  if (
    retention === null ||
    typeof retention !== "object" ||
    Array.isArray(retention) ||
    (retention as { mode?: unknown }).mode !== "NONE" ||
    Object.keys(retention).length !== 1
  ) {
    throw new TypeError(
      "The core runtime requires rawEvidenceRetention NONE and never persists opaque provider payloads",
    );
  }
}

export class MonitoringRuntime {
  readonly #bundle: MonitoringRuntimeOptions["bundle"];
  readonly #registrations: AdapterRegistration[];
  readonly #registry: StaticAdapterRegistry;
  readonly #artifactStore: ArtifactStore;
  readonly #principal: PrincipalIdentity;
  readonly #surface: NonNullable<MonitoringRuntimeOptions["surface"]>;
  readonly #routeDescription: string;
  readonly #clock: Clock;
  readonly #workbenchStartedAt: string;
  readonly #runTtlMs: number;
  readonly #leaseTtlMs: number;
  readonly #maxCachedSessions: number;
  readonly #maxDiagnosticEvents: number;
  readonly #runStore: RunStore;
  readonly #checkpointStore?: RuntimeCheckpointStore;
  readonly #audit: RuntimeAuditSink;
  readonly #diagnosticEvents: RuntimeAuditSnapshot["diagnosticEvents"] = [];
  readonly #configurationIssues: NonNullable<MonitoringRuntimeOptions["configurationIssues"]>;
  readonly #onClose?: MonitoringRuntimeOptions["onClose"];
  readonly #sessions = new Map<RunId, RuntimeSession>();
  /** Bounded one-to-one replay index: entries exist only while their session is cached. */
  readonly #idempotencyRuns = new Map<string, RunId>();
  #diagnosticEventsDropped = 0;
  #closed = false;
  #closePromise: Promise<void> | undefined;

  constructor(options: MonitoringRuntimeOptions) {
    assertRawProviderRetentionDisabled(options.bundle);
    this.#bundle = structuredClone(options.bundle);
    this.#registrations = [...options.registrations];
    this.#registry = new StaticAdapterRegistry(options.registrations);
    this.#artifactStore = new ArtifactStore({
      root: options.artifactRoot,
      ...(options.artifactProducer === undefined ? {} : { producer: options.artifactProducer }),
    });
    this.#principal = { ...options.principal };
    this.#surface = options.surface ?? "local-stdio";
    this.#routeDescription = options.routeDescription ?? "No implicit route beyond the active local process";
    this.#clock = options.clock ?? systemClock;
    this.#workbenchStartedAt = this.#clock.now().toISOString();
    this.#runTtlMs = options.runTtlMs ?? DEFAULT_RUN_TTL_MS;
    this.#leaseTtlMs = options.leaseTtlMs ?? DEFAULT_LEASE_TTL_MS;
    this.#maxCachedSessions = boundedRuntimeLimit(
      options.maxCachedSessions,
      DEFAULT_MAX_CACHED_SESSIONS,
      MAX_MAX_CACHED_SESSIONS,
      "maxCachedSessions",
    );
    this.#maxDiagnosticEvents = boundedRuntimeLimit(
      options.maxDiagnosticEvents,
      DEFAULT_MAX_DIAGNOSTIC_EVENTS,
      MAX_MAX_DIAGNOSTIC_EVENTS,
      "maxDiagnosticEvents",
    );
    this.#runStore = options.runStore ?? (options.stateRoot === undefined
      ? new InMemoryRunStore({ now: () => this.#clock.now().getTime() })
      : new DurableRunStore({ stateRoot: options.stateRoot, now: () => this.#clock.now().getTime() }));
    this.#checkpointStore = options.stateRoot === undefined
      ? undefined
      : new RuntimeCheckpointStore(options.stateRoot);
    this.#audit = options.auditSink ?? (options.stateRoot === undefined
      ? new VolatileAuditSink()
      : new DurableAuditSink(options.stateRoot));
    this.#configurationIssues = [...(options.configurationIssues ?? [])];
    this.#onClose = options.onClose;
  }

  get profileAlias(): string {
    return this.#bundle.profile.profileAlias;
  }

  get artifactRoot(): string {
    return this.#artifactStore.root;
  }

  /** Mount or refresh the principal-owned latest-run workbench. */
  openWorkbench(profileAlias: string): MonitoringWorkspaceSnapshot {
    this.#requireOpen();
    this.#requireProfile(profileAlias);
    return this.#workbenchProjection().projection.snapshot;
  }

  /** Read the workbench projection bound to one exact owned run. */
  openWorkbenchForRun(runId: RunId): MonitoringWorkspaceSnapshot {
    this.#requireOpen();
    if (!/^pmrun_[A-Za-z0-9_-]{20,128}$/u.test(runId)) {
      throw new RunStoreError("INVALID_INPUT", "Run ID is invalid");
    }
    const workspaceId = workspaceIdForRun({
      principal: this.#principal,
      profileAlias: this.profileAlias,
      trustBundleSha256: this.#bundle.integrity.contentSha256,
      runId,
    });
    return this.#workbenchProjection(workspaceId).projection.snapshot;
  }

  /** Read one monotonic, bearer-free workbench projection without mutating run authority. */
  workspaceSnapshot(
    workspaceId: MonitoringWorkspaceId,
    afterStateVersion?: number,
  ): MonitoringWorkspaceSnapshotRead {
    this.#requireOpen();
    this.#assertWorkspaceId(workspaceId);
    if (
      afterStateVersion !== undefined &&
      (!Number.isSafeInteger(afterStateVersion) || afterStateVersion < 0)
    ) {
      throw new RunStoreError("INVALID_INPUT", "Workbench state version is invalid");
    }
    const snapshot = this.#workbenchProjection(workspaceId).projection.snapshot;
    if (afterStateVersion !== undefined && afterStateVersion > snapshot.stateVersion) {
      throw new RunStoreError("FUTURE_CURSOR", "Workbench state cursor is newer than authority");
    }
    if (afterStateVersion === snapshot.stateVersion) {
      return {
        schemaVersion: "1.0.0",
        changed: false,
        workspaceId: snapshot.workspaceId,
        stateVersion: snapshot.stateVersion,
        asOf: snapshot.asOf,
      };
    }
    return { schemaVersion: "1.0.0", changed: true, snapshot };
  }

  workspaceEvidence(
    workspaceId: MonitoringWorkspaceId,
    evidenceRef: WorkbenchEvidenceRef,
  ): WorkbenchEvidenceDetail {
    this.#requireOpen();
    this.#assertWorkspaceId(workspaceId);
    if (!/^pmwsev_[A-Za-z0-9_-]{20,128}$/u.test(evidenceRef)) {
      throw new RunStoreError("INVALID_INPUT", "Workbench evidence reference is invalid");
    }
    const detail = this.#workbenchProjection(workspaceId).projection.evidence.get(evidenceRef);
    if (detail === undefined) {
      throw new RunStoreError("WORKBENCH_NOT_FOUND", "Workbench evidence is unavailable");
    }
    return structuredClone(detail);
  }

  resolveWorkspaceLink(
    workspaceId: MonitoringWorkspaceId,
    linkRef: WorkbenchLinkRef,
  ): WorkbenchResolvedLinkTarget {
    this.#requireOpen();
    this.#assertWorkspaceId(workspaceId);
    if (!/^pmwslnk_[A-Za-z0-9_-]{20,128}$/u.test(linkRef)) {
      throw new RunStoreError("INVALID_INPUT", "Workbench link reference is invalid");
    }
    const link = this.#workbenchProjection(workspaceId).projection.links.get(linkRef);
    if (link?.target === undefined) {
      throw new RunStoreError("LINK_UNAVAILABLE", "The reviewed evidence link is unavailable");
    }
    return structuredClone(link.target);
  }

  workspacePatchContext(
    workspaceId: MonitoringWorkspaceId,
    issueRef: WorkbenchIssueRef,
    hypothesisRef: string,
    expectedStateVersion: number,
  ): WorkbenchPatchContext {
    this.#requireOpen();
    this.#assertWorkspaceId(workspaceId);
    if (!Number.isSafeInteger(expectedStateVersion) || expectedStateVersion < 1) {
      throw new RunStoreError("INVALID_INPUT", "Workbench state version is invalid");
    }
    const selected = this.#workbenchProjection(workspaceId);
    if (selected.projection.snapshot.stateVersion !== expectedStateVersion) {
      throw new RunStoreError(
        "STALE_WORKBENCH",
        "Workbench authority changed before patch handoff",
      );
    }
    if (!/^pmwsiss_[A-Za-z0-9_-]{20,128}$/u.test(issueRef)) {
      throw new RunStoreError("INVALID_INPUT", "Workbench issue reference is invalid");
    }
    if (!/^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$/u.test(hypothesisRef)) {
      throw new RunStoreError("INVALID_INPUT", "Workbench hypothesis reference is invalid");
    }
    return patchContextForProjection(selected.authority, selected.projection, issueRef, hypothesisRef);
  }

  #recordDiagnostic(event: string, outcome: string): void {
    if (this.#diagnosticEvents.length === this.#maxDiagnosticEvents) {
      this.#diagnosticEvents.shift();
      this.#diagnosticEventsDropped += 1;
    }
    this.#diagnosticEvents.push({
      at: this.#clock.now().toISOString(),
      event,
      profileAlias: this.profileAlias,
      outcome,
    });
  }

  #assertWorkspaceId(workspaceId: string): asserts workspaceId is MonitoringWorkspaceId {
    if (!/^pmws_[A-Za-z0-9_-]{20,128}$/u.test(workspaceId)) {
      throw new RunStoreError("INVALID_INPUT", "Workbench ID is invalid");
    }
  }

  #workbenchProjection(requestedWorkspaceId?: MonitoringWorkspaceId): {
    authority: WorkbenchProjectionAuthority;
    projection: WorkbenchProjection;
  } {
    const trustBundleSha256 = this.#bundle.integrity.contentSha256;
    const latestId = latestWorkspaceId({
      principal: this.#principal,
      profileAlias: this.profileAlias,
      trustBundleSha256,
    });
    const inventory = this.#runStore.listOwnedRuns({
      principal: this.#principal,
      expectedProfileAlias: this.profileAlias,
      expectedTrustBundleSha256: trustBundleSha256,
      limit: WORKBENCH_RUN_INVENTORY_LIMIT,
    });
    const selectedId = requestedWorkspaceId ?? latestId;
    const selectedRun = selectedId === latestId
      ? inventory.runs[0]
      : inventory.runs.find((run) => workspaceIdForRun({
          principal: this.#principal,
          profileAlias: this.profileAlias,
          trustBundleSha256,
          runId: run.runId,
        }) === selectedId);
    if (requestedWorkspaceId !== undefined && selectedId !== latestId && selectedRun === undefined) {
      throw new RunStoreError("WORKBENCH_NOT_FOUND", "Workbench is unavailable");
    }
    const workspaceId = selectedId;
    let authority: WorkbenchProjectionAuthority;
    if (selectedRun === undefined) {
      authority = {
        workspaceId,
        asOf: this.#workbenchStartedAt,
        profileAlias: this.profileAlias,
        capabilityProfile: this.#bundle.profile.capabilityProfile,
        profileEndpointIds: this.#bundle.profile.endpointIds,
        endpoints: this.#bundle.endpoints,
        inventoryOmittedCount: inventory.omittedCount,
        operations: [],
        capabilityPacks: this.#bundle.capabilityPacks ?? [],
        evidence: [],
        contradictions: [],
        checkpointRevision: 0,
      };
    } else if (selectedRun.state === "SEALED") {
      try {
        const bundle = this.#artifactStore.validateBundle(bundleIdForRunId(selectedRun.runId));
        if (bundle.runId !== selectedRun.runId) {
          throw new Error("Immutable bundle run identity mismatch");
        }
        authority = {
          workspaceId,
          asOf: bundle.manifest.sealedAt,
          profileAlias: bundle.profile.profileAlias,
          capabilityProfile: bundle.profile.capabilityProfile,
          profileEndpointIds: bundle.profile.endpointIds,
          endpoints: this.#bundle.endpoints,
          inventoryOmittedCount: inventory.omittedCount,
          run: selectedRun,
          request: bundle.request,
          operations: bundle.operations,
          capabilityPacks: (this.#bundle.capabilityPacks ?? []).filter((pack) =>
            bundle.profile.capabilityPackIds?.includes(pack.packId) ?? false),
          evidence: bundle.evidence,
          contradictions: bundle.contradictions,
          investigation: bundle.investigation,
          coverage: bundle.coverage,
          checkpointRevision: 0,
        };
      } catch (error) {
        authority = {
          workspaceId,
          asOf: selectedRun.finalizedAt ?? selectedRun.createdAt,
          profileAlias: this.profileAlias,
          capabilityProfile: this.#bundle.profile.capabilityProfile,
          profileEndpointIds: this.#bundle.profile.endpointIds,
          endpoints: this.#bundle.endpoints,
          inventoryOmittedCount: inventory.omittedCount,
          run: selectedRun,
          operations: [],
          capabilityPacks: this.#bundle.capabilityPacks ?? [],
          evidence: [],
          contradictions: [],
          checkpointRevision: 0,
          authorityFailure: (error as NodeJS.ErrnoException).code === "ENOENT"
            ? "ARTIFACT_UNAVAILABLE"
            : "ARTIFACT_INVALID",
        };
      }
    } else {
      authority = this.#activeWorkbenchAuthority(workspaceId, selectedRun, inventory.omittedCount);
    }
    return { authority, projection: buildWorkbenchProjection(authority) };
  }

  #activeWorkbenchAuthority(
    workspaceId: MonitoringWorkspaceId,
    run: NonNullable<ReturnType<RunStore["listOwnedRuns"]>["runs"][number]>,
    inventoryOmittedCount: number,
  ): WorkbenchProjectionAuthority {
    const common = {
      workspaceId,
      profileAlias: this.profileAlias,
      capabilityProfile: this.#bundle.profile.capabilityProfile,
      profileEndpointIds: this.#bundle.profile.endpointIds,
      endpoints: this.#bundle.endpoints,
      capabilityPacks: this.#bundle.capabilityPacks ?? [],
      inventoryOmittedCount,
      run,
    } as const;
    const cached = this.#sessions.get(run.runId);
    if (cached !== undefined) {
      const evidence = [...cached.evidence.values()];
      return {
        ...common,
        asOf: this.#workbenchAsOf(run.createdAt, evidence),
        request: cached.request,
        operations: this.#selectedOperations(cached.request),
        evidence,
        contradictions: cached.contradictions,
        checkpointRevision: cached.checkpointRevision,
      };
    }
    if (this.#checkpointStore === undefined) {
      return {
        ...common,
        asOf: run.abortedAt ?? run.createdAt,
        operations: [],
        evidence: [],
        contradictions: [],
        checkpointRevision: 0,
        authorityFailure: "CHECKPOINT_UNAVAILABLE",
      };
    }
    try {
      const checkpoint = this.#checkpointStore.read(run.runId);
      if (checkpoint === undefined) {
        return {
          ...common,
          asOf: run.abortedAt ?? run.createdAt,
          operations: [],
          evidence: [],
          contradictions: [],
          checkpointRevision: 0,
          authorityFailure: "CHECKPOINT_UNAVAILABLE",
        };
      }
      const validated = validateRuntimeCheckpoint(checkpoint, {
        runId: run.runId,
        trustBundleSha256: this.#bundle.integrity.contentSha256,
        profileAlias: this.profileAlias,
      });
      if (validated.runRevision > run.revision) {
        throw new RunStoreError("STATE_CORRUPT", "Runtime checkpoint is newer than run authority");
      }
      if (validated.checkpointRevision > MAXIMUM_AUTHORITY_COMPONENT_REVISION) {
        throw new RunStoreError("RUNTIME_CAPACITY", "Runtime checkpoint exceeds workbench authority capacity");
      }
      const operations = Object.values(validated.policy.operations).map((policyOperation) => {
        const operation = this.#bundle.operations.find((candidate) =>
          candidate.operationId === policyOperation.operationId &&
          candidate.definitionSha256 === policyOperation.definitionSha256
        );
        if (operation === undefined) {
          throw new RunStoreError("STATE_CORRUPT", "Runtime checkpoint operation cannot be reproduced");
        }
        return operation;
      });
      return {
        ...common,
        asOf: this.#workbenchAsOf(run.abortedAt ?? run.createdAt, validated.evidence),
        request: validated.request,
        operations,
        evidence: validated.evidence,
        contradictions: validated.contradictions,
        checkpointRevision: validated.checkpointRevision,
      };
    } catch {
      return {
        ...common,
        asOf: run.abortedAt ?? run.createdAt,
        operations: [],
        evidence: [],
        contradictions: [],
        checkpointRevision: 0,
        authorityFailure: "CHECKPOINT_INVALID",
      };
    }
  }

  #workbenchAsOf(fallback: string, evidence: readonly EvidenceEnvelope[]): string {
    return evidence.reduce(
      (latest, envelope) => envelope.collectedAt.localeCompare(latest) > 0 ? envelope.collectedAt : latest,
      fallback,
    );
  }

  async doctor(profileAlias: string): Promise<{
    status: "READY" | "WARN" | "BLOCKED";
    profileAlias: string;
    surface: string;
    originModes: string[];
    checks: Array<{ name: string; status: "PASS" | "WARN" | "FAIL"; message: string }>;
  }> {
    this.#requireOpen();
    assertAlias(profileAlias, "profile alias");
    if (profileAlias !== this.profileAlias) {
      this.#recordDiagnostic("DOCTOR", "BLOCKED");
      return {
        status: "BLOCKED",
        profileAlias,
        surface: this.#surface,
        originModes: [],
        checks: [{ name: "active-profile", status: "FAIL", message: "The profile is not active" }],
      };
    }
    const checks: Array<{ name: string; status: "PASS" | "WARN" | "FAIL"; message: string }> = [
      { name: "trust-bundle", status: "PASS", message: "Active trust bundle is integrity sealed" },
      { name: "production-mutation", status: "PASS", message: "No provider mutation operations are exposed" },
      { name: "raw-provider-retention", status: "PASS", message: "Opaque provider payload retention is disabled by contract" },
    ];
    const registeredPackages = new Set<string>(
      this.#registrations.map((registration) => registration.adapterPackage.packageId),
    );
    const activePackages = new Set([
      ...this.#bundle.endpoints
        .filter((endpoint) => this.#bundle.profile.endpointIds.includes(endpoint.endpointId))
        .map((endpoint) => endpoint.adapterId),
      ...this.#bundle.operations
        .filter((operation) => this.#bundle.profile.operationIds.includes(operation.operationId))
        .map((operation) => operation.definition.adapterPackageId),
    ]);
    for (const packageId of activePackages) {
      if (!registeredPackages.has(packageId)) {
        checks.push({
          name: `adapter-registration:${packageId}`,
          status: "FAIL",
          message: `Active adapter ${packageId} is not registered and cannot collect evidence`,
        });
      }
    }
    for (const issue of this.#configurationIssues) {
      checks.push({
        name: `provider-runtime:${issue.packageId ?? "configuration"}:${issue.code}`,
        status: "FAIL",
        message: issue.message,
      });
    }
    for (const registration of this.#registrations) {
      try {
        const result = await registration.adapter.doctor({ signal: AbortSignal.timeout(5_000), clock: this.#clock });
        checks.push(...result.checks);
        if (result.status === "BLOCKED" && !result.checks.some((check) => check.status === "FAIL")) {
          checks.push({
            name: `adapter-doctor:${registration.adapterPackage.packageId}`,
            status: "FAIL",
            message: `Adapter ${registration.adapterPackage.packageId} reported a blocked state`,
          });
        }
      } catch {
        checks.push({
          name: `adapter-doctor:${registration.adapterPackage.packageId}`,
          status: "FAIL",
          message: `Adapter ${registration.adapterPackage.packageId} health check was unavailable`,
        });
      }
    }
    const status = checks.some((check) => check.status === "FAIL")
      ? "BLOCKED"
      : checks.some((check) => check.status === "WARN")
        ? "WARN"
        : "READY";
    this.#recordDiagnostic("DOCTOR", status);
    return {
      status,
      profileAlias,
      surface: this.#surface,
      originModes: [...this.#bundle.profile.allowedOrigins],
      checks,
    };
  }

  listCapabilities(profileAlias: string): {
    profileAlias: string;
    surface: string;
    route: string;
    privateNetworkReachability: "HOST_DEPENDENT" | "VPC_ONLY" | "NONE" | "RELAY_ONLY" | "NOT_APPLICABLE";
    capabilities: RuntimeCapability[];
    capabilityPacks: Array<{
      packId: string;
      revision: number;
      useCase: string;
      requiredOperationIds: string[];
      optionalOperationIds: string[];
      signals: CapabilityPackSignalV1[];
      definitionSha256: string;
    }>;
    limitations: string[];
  } {
    this.#requireOpen();
    this.#requireProfile(profileAlias);
    const available = new Map(this.#registrations.map((registration) => [registration.adapterPackage.packageId, registration]));
    const capabilities = this.#bundle.adapters.map((adapter): RuntimeCapability => ({
      provider: adapter.providerCompatibility[0]?.provider ?? adapter.name,
      packageId: adapter.packageId,
      domains: [...adapter.domains],
      operations: this.#bundle.operations
        .filter((operation) =>
          this.#bundle.profile.operationIds.includes(operation.operationId) &&
          operation.definition.adapterPackageId === adapter.packageId)
        .map((operation) => operation.operationId),
      status: available.has(adapter.packageId) ? "AVAILABLE" : "UNAVAILABLE",
    }));
    this.#recordDiagnostic("LIST_CAPABILITIES", "COMPLETE");
    const reachability = this.#surface === "fixture"
      ? "NOT_APPLICABLE"
      : this.#surface === "local-stdio"
        ? "HOST_DEPENDENT"
        : this.#surface === "customer-vpc"
          ? "VPC_ONLY"
          : this.#surface === "customer-relay"
            ? "RELAY_ONLY"
            : "NONE";
    return {
      profileAlias,
      surface: this.#surface,
      route: this.#routeDescription,
      privateNetworkReachability: reachability,
      capabilities,
      capabilityPacks: (this.#bundle.capabilityPacks ?? [])
        .filter((pack) => this.#bundle.profile.capabilityPackIds?.includes(pack.packId) ?? false)
        .map((pack) => ({
          packId: pack.packId,
          revision: pack.revision,
          useCase: pack.useCase,
          requiredOperationIds: [...pack.requiredOperationIds],
          optionalOperationIds: [...pack.optionalOperationIds],
          signals: structuredClone(pack.signals),
          definitionSha256: pack.definitionSha256,
        })),
      limitations: [
        "Destinations are fixed by the administrator-owned endpoint registry.",
        "This surface does not imply reachability available to any other surface.",
      ],
    };
  }

  listOperations(profileAlias: string, domain?: string): Array<{
    operationId: OperationId;
    domain: string;
    authority: string;
    sourceAlias: string;
  }> {
    this.#requireOpen();
    this.#requireProfile(profileAlias);
    if (domain !== undefined) assertAlias(domain, "domain");
    this.#recordDiagnostic("LIST_OPERATIONS", "COMPLETE");
    const activeOperations = new Set(this.#bundle.profile.operationIds);
    return this.#bundle.operations
      .filter((operation) =>
        activeOperations.has(operation.operationId) &&
        (domain === undefined || operation.definition.domain === domain))
      .map((operation) => ({
        operationId: operation.operationId,
        domain: operation.definition.domain,
        authority: operation.definition.authority,
        sourceAlias: operation.definition.sourceAlias,
      }));
  }

  resolveScope(profileAlias: string, scopeAlias: string): {
    profileAlias: string;
    scopeAlias: string;
    scope: Scope;
    correlationKeys: string[];
  } {
    this.#requireOpen();
    this.#requireProfile(profileAlias);
    assertAlias(scopeAlias, "scope alias");
    const scope = this.#bundle.profile.scopes[scopeAlias];
    if (scope === undefined) throw new TypeError("Scope alias is not active in this profile");
    this.#recordDiagnostic("RESOLVE_SCOPE", "COMPLETE");
    return {
      profileAlias,
      scopeAlias,
      scope: structuredClone(scope),
      correlationKeys: ["environment", ...(scope.service === undefined ? [] : ["service"])],
    };
  }

  beginRun(rawRequest: unknown, idempotencyKey: string): BeginRunOutput {
    this.#requireOpen();
    const request = validateWorkflowRequest(rawRequest);
    this.#requireProfile(request.profileAlias);
    assertAlias(idempotencyKey, "idempotency key");
    const knownRun = this.#idempotencyRuns.get(idempotencyKey);
    if (knownRun === undefined || !this.#sessions.has(knownRun)) {
      this.#ensureSessionSlot();
    }
    let policy: Readonly<CompiledWorkflowPolicy>;
    let configuredContract: VerificationContract | undefined;
    let childContract: VerificationContract | undefined;
    let started: ReturnType<RunStore["beginRun"]>;
    if (request.workflow === "verify") {
      if (request.parentRunId === undefined) throw new TypeError("Verification requires a sealed parent run");
      const parent = this.#runStore.getSealedParent({
        principal: this.#principal,
        runId: request.parentRunId,
        expectedProfileAlias: this.profileAlias,
        expectedTrustBundleSha256: this.#bundle.integrity.contentSha256,
      });
      childContract = this.#sealedParentContract(request.parentRunId, parent.verificationContractSha256);
      if (childContract.contractSha256 !== parent.verificationContractSha256) {
        throw new TypeError("Verification request does not match the sealed parent contract");
      }
      policy = this.#compilePolicy(request, childContract.policyAlias);
      configuredContract = buildVerificationContract(policy);
      if (configuredContract === undefined || configuredContract.contractSha256 !== childContract.contractSha256) {
        throw new TypeError("Verification child policy does not reproduce the sealed parent contract");
      }
      started = this.#runStore.beginChildVerification({
        principal: this.#principal,
        request,
        policy,
        idempotencyKey,
        ttlMs: this.#runTtlMs,
        parentRunId: request.parentRunId,
        verificationContractSha256: childContract.contractSha256,
      });
    } else {
      policy = this.#compilePolicy(request);
      configuredContract = buildVerificationContract(policy);
      started = this.#runStore.beginRun({
        principal: this.#principal,
        request,
        policy,
        idempotencyKey,
        ttlMs: this.#runTtlMs,
      });
    }
    if (!started.replayed && !this.#sessions.has(started.runId)) {
      const session: RuntimeSession = {
        request,
        policy,
        budget: new BudgetLedger(policy),
        evidence: new Map(),
        contradictions: [],
        budgetHistory: [],
        completedByKey: new Map(),
        incompleteKeys: new Set(),
        deferredOperations: new Map(),
        auditEventCount: 0,
        checkpointRevision: 0,
        ...(childContract === undefined
          ? configuredContract === undefined ? {} : { verificationContract: configuredContract }
          : { verificationContract: childContract }),
      };
      this.#sessions.set(started.runId, session);
      if (started.handle !== undefined) {
        session.activeHandle = started.handle;
        session.activeRevision = started.revision;
      }
      if (started.handle === undefined) throw new Error("A new run did not return checkpoint authority");
      this.#persistSession(started.runId, session, {
        runHandle: started.handle,
        runRevision: started.revision,
      });
    }
    if (this.#sessions.has(started.runId)) {
      this.#idempotencyRuns.set(idempotencyKey, started.runId);
    }
    const selectedOperations = this.#selectedOperations(request);
    this.#recordDiagnostic("BEGIN_RUN", started.replayed ? "REPLAYED" : "CREATED");
    return {
      runId: started.runId,
      ...(started.handle === undefined ? {} : { runHandle: started.handle }),
      revision: started.revision,
      replayed: started.replayed,
      requestSha256: policy.requestSha256,
      trustBundleSha256: policy.trustBundleSha256,
      operationSnapshotSha256: operationSnapshotHash(selectedOperations),
      origin: request.origin,
    };
  }

  resumeRun(runHandle: RunHandle, expectedRevision?: number, retainRecoveryAlias = false): BeginRunOutput {
    this.#requireOpen();
    const resumeInput = {
      principal: this.#principal,
      handle: runHandle,
      ...(expectedRevision === undefined ? {} : { expectedRevision }),
      expectedProfileAlias: this.profileAlias,
      expectedTrustBundleSha256: this.#bundle.integrity.contentSha256,
    };
    const before = this.#runStore.getRunWithHandle(resumeInput);
    // Validate and load the full checkpoint before rotating the only retained bearer.
    const session = this.#sessionFor(before.record.runId, this.#access(runHandle, before.revision));
    const resumed = this.#runStore.resumeRunWithHandle(resumeInput);
    if (resumed.handle === undefined) throw new Error("Resume did not rotate the run handle");
    const revision = retainRecoveryAlias
      ? resumed.revision
      : this.#runStore.acknowledgeResume(this.#access(resumed.handle, resumed.revision)).revision;
    delete session.leaseHandle;
    delete session.leaseExpiresAt;
    session.activeHandle = resumed.handle;
    session.activeRevision = revision;
    this.#recordDiagnostic("RESUME_RUN", "RESUMED");
    return {
      runId: resumed.runId,
      ...(resumed.handle === undefined ? {} : { runHandle: resumed.handle }),
      revision,
      replayed: false,
      requestSha256: session.policy.requestSha256,
      trustBundleSha256: session.policy.trustBundleSha256,
      operationSnapshotSha256: operationSnapshotHash(this.#selectedOperations(session.request)),
      origin: session.request.origin,
    };
  }

  acknowledgeResume(runHandle: RunHandle, expectedRevision: number): number {
    this.#requireOpen();
    const acknowledged = this.#runStore.acknowledgeResume(this.#access(runHandle, expectedRevision));
    const session = this.#sessionFor(acknowledged.record.runId, this.#access(runHandle, acknowledged.revision));
    session.activeHandle = runHandle;
    session.activeRevision = acknowledged.revision;
    return acknowledged.revision;
  }

  async collect(
    runHandle: RunHandle,
    expectedRevision: number,
    operationIds: readonly string[],
    windowKind: "CURRENT" | "BASELINE" = "CURRENT",
    signal?: AbortSignal,
  ): Promise<CollectOutput> {
    this.#requireOpen();
    const selected = uniqueOperationIds(operationIds);
    if (selected.length === 0) throw new TypeError("At least one operation ID is required");
    let state = this.#ensureLease(runHandle, expectedRevision);
    const window = windowKind === "BASELINE"
      ? state.session.request.baselineWindow
      : state.session.request.window;
    if (window === undefined) throw new TypeError("This run has no sealed baseline window");
    for (const operationId of selected) this.#requireAuthorizedOperation(state.session, operationId);
    const output = new Array<EvidenceEnvelope | undefined>(selected.length);
    const failures = new Array<{ operationId: OperationId; code: string } | undefined>(selected.length);
    const pending: Array<{ index: number; operationId: OperationId; key: string; sourceAlias: string }> = [];
    selected.forEach((operationId, index) => {
      const key = collectionKey(operationId, window);
      const existingId = state.session.completedByKey.get(key);
      const existing = existingId === undefined ? undefined : state.session.evidence.get(existingId);
      if (existing !== undefined) output[index] = existing;
      else pending.push({
        index,
        operationId,
        key,
        sourceAlias: state.session.policy.operations[operationId]!.sourceAlias,
      });
    });
    const lanes = [...pending.reduce((groups, item) => {
      const lane = groups.get(item.sourceAlias) ?? [];
      lane.push(item);
      groups.set(item.sourceAlias, lane);
      return groups;
    }, new Map<string, typeof pending>()).values()];
    let laneCursor = 0;
    let serialWorker: number | undefined;
    let auditedAttempts = 0;
    let revision = state.revision;
    const renewLease = (operationTimeoutMs = 0): void => {
      const renewalTtlMs = Math.max(
        this.#leaseTtlMs,
        operationTimeoutMs === 0 ? 0 : operationTimeoutMs + 30_000,
      );
      const renewed = this.#runStore.renewLease(
        this.#access(runHandle, revision),
        state.session.leaseHandle!,
        renewalTtlMs,
      );
      revision = renewed.revision;
      state.session.leaseExpiresAt = renewed.expiresAt;
      state.session.activeRevision = renewed.revision;
    };
    const persistSession = (): void => {
      this.#persistSession(state.runId, state.session, {
        runHandle,
        runRevision: revision,
        leaseHandle: state.session.leaseHandle!,
      });
    };
    const auditCycleBefore = auditEventCountForRun(this.#audit, state.runId);
    if (pending.length > 0) {
      const view = this.#runStore.getRun(this.#access(runHandle, revision));
      if (view.record.audit.required && view.record.audit.state === "HEALTHY") {
        const degraded = this.#runStore.updateAudit({
          access: this.#access(runHandle, revision),
          leaseHandle: state.session.leaseHandle!,
          state: "DEGRADED",
        });
        revision = degraded.revision;
      }
    }
    const worker = async (workerId: number): Promise<void> => {
      while (laneCursor < lanes.length) {
        if (serialWorker !== undefined && serialWorker !== workerId) return;
        const lane = lanes[laneCursor++]!;
        for (let laneIndex = 0; laneIndex < lane.length; laneIndex += 1) {
          const item = lane[laneIndex]!;
          if (signal?.aborted) {
            failures[item.index] = { operationId: item.operationId, code: "INTERRUPTED" };
            state.session.deferredOperations.set(item.operationId, "INTERRUPTED");
            persistSession();
            continue;
          }
          let reservationId: string | undefined;
          try {
            state.session.deferredOperations.delete(item.operationId);
            const effectiveLimits = state.session.policy.operations[item.operationId]!.limits;
            renewLease(effectiveLimits.timeoutMs);
            const reservation = state.session.budget.reserve(item.operationId);
            reservationId = reservation.reservationId;
            state.session.budgetHistory.push({
              reservationId,
              operationId: item.operationId,
              outcome: "RESERVED",
            });
            state.session.incompleteKeys.add(item.key);
            persistSession();
            const allocated = this.#runStore.allocateEvidence(
              this.#access(runHandle, revision),
              state.session.leaseHandle!,
            );
            revision = allocated.revision;
            auditedAttempts += 1;
            const envelope = await this.#collectAllocated({
              runId: state.runId,
              session: state.session,
              operationId: item.operationId,
              window,
              evidenceId: allocated.evidenceId,
              tenantSha256: allocated.record.principal.tenantSha256,
              reservationId: reservation.reservationId,
              key: item.key,
              fenceLease: () => renewLease(),
              persistSession,
              signal,
            });
            output[item.index] = envelope;
            if (envelope.collectionState === "ERROR" && envelope.error?.category === "RATE_LIMIT") {
              serialWorker ??= workerId;
              for (const deferred of lane.slice(laneIndex + 1)) {
                failures[deferred.index] = {
                  operationId: deferred.operationId,
                  code: "PROVIDER_RATE_LIMIT_DEFERRED",
                };
                state.session.deferredOperations.set(
                  deferred.operationId,
                  "PROVIDER_RATE_LIMIT_DEFERRED",
                );
              }
              persistSession();
              break;
            }
          } catch (error) {
            if (isLeaseAuthorityFailure(error)) throw error;
            if (reservationId !== undefined) cancelBudgetHistory(state.session, reservationId);
            const code = safeFailureCode(error);
            failures[item.index] = { operationId: item.operationId, code };
            state.session.deferredOperations.set(item.operationId, code);
            persistSession();
          }
        }
      }
    };
    const concurrency = Math.min(state.session.policy.runLimits.maxConcurrent, Math.max(1, lanes.length));
    await Promise.all(Array.from({ length: concurrency }, (_, workerId) => worker(workerId)));
    const cycleEvents = auditEventsForRun(this.#audit, state.runId, auditCycleBefore);
    state.session.auditEventCount = auditCycleBefore + cycleEvents.length;
    const starts = cycleEvents.filter((event) => event.event === "COLLECTION_STARTED").length;
    const terminals = cycleEvents.filter(
      (event) => event.event === "COLLECTION_COMPLETED" || event.event === "COLLECTION_FAILED",
    ).length;
    if (
      this.#audit.durable &&
      auditedAttempts > 0 &&
      cycleEvents.length === auditedAttempts * 2 &&
      starts === auditedAttempts &&
      terminals === auditedAttempts
    ) {
      const audited = this.#runStore.updateAudit({
        access: this.#access(runHandle, revision),
        leaseHandle: state.session.leaseHandle!,
        state: "HEALTHY",
      });
      revision = audited.revision;
    }
    persistSession();
    state = { ...state, revision };
    state.session.activeRevision = revision;
    const collected = output.filter((value): value is EvidenceEnvelope => value !== undefined);
    const collectionFailures = failures.filter(
      (value): value is { operationId: OperationId; code: string } => value !== undefined,
    );
    return {
      runId: state.runId,
      revision: state.revision,
      evidence: collected,
      budget: state.session.budget.snapshot(),
      ...(collectionFailures.length === 0 ? {} : { failures: collectionFailures }),
    };
  }

  async compare(
    runHandle: RunHandle,
    expectedRevision: number,
    operationId: string,
    signal?: AbortSignal,
  ): Promise<CollectOutput & { comparison: { currentEvidenceId: EvidenceId; baselineEvidenceId: EvidenceId } }> {
    this.#requireOpen();
    const current = await this.collect(runHandle, expectedRevision, [operationId], "CURRENT", signal);
    const baseline = await this.collect(runHandle, current.revision, [operationId], "BASELINE", signal);
    if (current.evidence[0] === undefined || baseline.evidence[0] === undefined) {
      throw new TypeError("Comparison requires current and baseline evidence");
    }
    return {
      ...baseline,
      evidence: [...current.evidence, ...baseline.evidence],
      comparison: {
        currentEvidenceId: current.evidence[0]!.evidenceId,
        baselineEvidenceId: baseline.evidence[0]!.evidenceId,
      },
    };
  }

  getEvidence(runHandle: RunHandle, expectedRevision: number, evidenceId: EvidenceId): {
    runId: RunId;
    revision: number;
    evidence: EvidenceEnvelope;
  } {
    this.#requireOpen();
    const resolved = this.#resolve(runHandle, expectedRevision);
    this.#runStore.assertEvidenceOwnership(resolved.access, evidenceId);
    const evidence = resolved.session.evidence.get(evidenceId);
    if (evidence === undefined) throw new TypeError("Owned evidence is not available");
    this.#recordDiagnostic("GET_EVIDENCE", "COMPLETE");
    return { runId: resolved.runId, revision: expectedRevision, evidence: structuredClone(evidence) };
  }

  auditStatus(runHandle: RunHandle, expectedRevision: number): {
    runId: RunId;
    revision: number;
    required: boolean;
    state: string;
    collectionEventCount: number;
  } {
    this.#requireOpen();
    const resolved = this.#resolve(runHandle, expectedRevision);
    const view = this.#runStore.getRun(resolved.access);
    this.#recordDiagnostic("AUDIT_STATUS", "COMPLETE");
    return {
      runId: resolved.runId,
      revision: view.revision,
      required: view.record.audit.required,
      state: view.record.audit.state,
      collectionEventCount: auditEventCountForRun(this.#audit, resolved.runId),
    };
  }

  finalizeRun(runHandle: RunHandle, expectedRevision: number, rawAnalysisDraft?: unknown): FinalizeOutput {
    this.#requireOpen();
    let state = this.#ensureLease(runHandle, expectedRevision);
    const submittedAnalysis = rawAnalysisDraft === undefined
      ? undefined
      : validateAnalysisDraft(rawAnalysisDraft, new Set(state.session.evidence.keys()));
    if (
      submittedAnalysis?.approvalRequired === true &&
      this.#bundle.profile.capabilityProfile !== "prepare_patch"
    ) {
      throw new TypeError("Approval-required analysis is only valid for a prepare_patch profile");
    }
    if (submittedAnalysis?.approvalRequired === true && state.session.verificationContract === undefined) {
      throw new TypeError("Approval-required analysis requires a begin-time verification contract");
    }
    if (state.session.sealedArtifact === undefined && state.session.contradictions.length === 0) {
      const detected = detectContradictions([...state.session.evidence.values()], state.runId, this.#clock);
      for (const record of detected) {
        const allocated = this.#runStore.allocateContradiction(
          this.#access(runHandle, state.revision),
          state.session.leaseHandle!,
        );
        state = { ...state, revision: allocated.revision };
        const draft = { ...record, contradictionId: allocated.contradictionId };
        const withoutIntegrity = { ...draft };
        delete (withoutIntegrity as Partial<ContradictionRecord>).integrity;
        state.session.contradictions.push({
          ...withoutIntegrity,
          integrity: computeIntegrity(withoutIntegrity),
        } as ContradictionRecord);
        this.#persistSession(state.runId, state.session, {
          runHandle,
          runRevision: state.revision,
          leaseHandle: state.session.leaseHandle!,
        });
      }
    }
    const view = this.#runStore.getRun(this.#access(runHandle, state.revision));
    if (view.record.state === "OPEN") {
      const finalizing = this.#runStore.beginFinalize(
        this.#access(runHandle, state.revision),
        state.session.leaseHandle!,
      );
      state = { ...state, revision: finalizing.revision };
    }
    const evidence = [...state.session.evidence.values()].sort(
      (left, right) => left.operationId.localeCompare(right.operationId) || left.evidenceId.localeCompare(right.evidenceId),
    );
    const fallbackObservations = evidence.map((envelope, index) => ({
      observationId: `observation.${index + 1}`,
      statement: safeObservationStatement(envelope),
      evidenceIds: [envelope.evidenceId],
    }));
    const incomplete = evidence
      .filter((envelope) => envelope.collectionState !== "COMPLETE" || envelope.freshnessState !== "FRESH")
      .map((envelope) => `${envelope.operationId} did not produce fresh complete evidence`)
      .concat([...state.session.incompleteKeys].map((key) => `${key.split("|")[0]} was interrupted before evidence completion`))
      .concat([...state.session.deferredOperations.entries()]
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([operationId, code]) => `${operationId} was deferred by scheduler policy (${code})`));
    const analysis: AnalysisDraft = submittedAnalysis ?? {
      schemaVersion: "1.0.0",
      observations: fallbackObservations,
      inferences: [],
      hypotheses: [],
      checksPerformed: [...new Set(evidence.map((envelope) => envelope.operationId))],
      missingEvidence: [
        "No analysis draft was submitted; this artifact is evidence-only and cannot claim a complete investigation.",
      ],
      smallestSafeNextStep: incomplete.length === 0
        ? "Submit a bounded evidence-linked analysis before drawing a production conclusion."
        : "Resolve the named evidence gaps and submit a bounded evidence-linked analysis.",
      approvalRequired: false,
      remainingUncertainty: [],
      owners: [],
    };
    const verification = state.session.request.workflow !== "verify"
      ? undefined
      : state.session.verificationContract === undefined
        ? (() => { throw new TypeError("Verification run has no sealed parent contract"); })()
        : evaluateVerification(
            state.session.verificationContract,
            evidence,
            state.session.contradictions,
            state.session.request.window,
            this.#clock.now().getTime(),
          );
    const recoveryState = state.session.request.workflow === "verify"
      ? verification!.status === "PASSED"
        ? "RECOVERED" as const
        : verification!.status === "FAILED"
          ? "NOT_RECOVERED" as const
          : "INCOMPLETE" as const
      : analysis.approvalRequired
        ? "APPROVAL_REQUIRED" as const
        : "NONE" as const;
    const investigation: InvestigationDraft = {
      analysisState: submittedAnalysis === undefined ? "EVIDENCE_ONLY" : "SUBMITTED",
      recoveryState,
      scope: structuredClone(state.session.policy.scope),
      requestedWindow: structuredClone(state.session.request.window),
      evaluatedWindow: structuredClone(state.session.request.window),
      observations: analysis.observations,
      inferences: analysis.inferences,
      hypotheses: analysis.hypotheses,
      checksPerformed: analysis.checksPerformed,
      missingEvidence: [...new Set([...analysis.missingEvidence, ...incomplete])],
      smallestSafeNextStep: analysis.smallestSafeNextStep,
      approvalRequired: analysis.approvalRequired,
      ...(state.session.verificationContract === undefined
        ? {}
        : { verificationContract: structuredClone(state.session.verificationContract) }),
      ...(verification === undefined
        ? {}
        : { verificationResult: { status: verification.status, evidenceIds: verification.evidenceIds } }),
      remainingUncertainty: [
        ...analysis.remainingUncertainty,
        ...(state.session.contradictions.length === 0
          ? []
          : ["Unresolved source contradictions require operator review."]),
      ],
      owners: analysis.owners,
    };
    const bundleId = bundleIdForRunId(state.runId);
    const selectedOperations = this.#selectedOperations(state.session.request);
    // Capability-pack requests are expanded by policy at begin time. Persist
    // that exact immutable expansion alongside the requested pack IDs so the
    // artifact validator can prove its operation set without consulting a
    // later mutable runtime catalog.
    const artifactRequest: WorkflowRequest = (state.session.request.requiredCapabilityPacks?.length ?? 0) === 0
      ? state.session.request
      : {
          ...state.session.request,
          requiredOperations: selectedOperations.map((operation) => operation.operationId),
        };
    let sealed: ReturnType<ArtifactStore["seal"]>;
    if (state.session.sealedArtifact === undefined) {
      try {
        sealed = this.#artifactStore.seal({
          bundleId,
          runId: state.runId,
          createdAt: this.#clock.now().toISOString(),
          request: artifactRequest,
          profile: this.#bundle.profile,
          operations: selectedOperations,
          evidence,
          contradictions: state.session.contradictions,
          investigation,
        });
      } catch (error) {
        try {
          const existing = this.#artifactStore.validateBundle(bundleId);
          if (existing.runId !== state.runId) throw error;
          sealed = { ...existing, created: true };
        } catch {
          throw error;
        }
      }
      state.session.sealedArtifact = {
        bundleId,
        manifestSha256: sealed.manifestSha256,
        artifactRelativePath: `bundles/${bundleId}`,
        status: sealed.investigation.status,
      };
      this.#persistSession(state.runId, state.session, {
        runHandle,
        runRevision: state.revision,
        leaseHandle: state.session.leaseHandle!,
      });
    } else {
      const existing = this.#artifactStore.validateBundle(bundleId);
      if (
        existing.runId !== state.runId ||
        existing.manifestSha256 !== state.session.sealedArtifact.manifestSha256
      ) {
        throw new Error("Checkpointed artifact identity does not match immutable storage");
      }
      sealed = { ...existing, created: true };
    }
    const finalized = this.#runStore.finalizeRun({
      access: this.#access(runHandle, state.revision),
      leaseHandle: state.session.leaseHandle!,
      ...(state.session.verificationContract === undefined
        ? {}
        : { verificationContractSha256: state.session.verificationContract.contractSha256 }),
    });
    delete state.session.leaseHandle;
    delete state.session.leaseExpiresAt;
    delete state.session.activeHandle;
    delete state.session.activeRevision;
    this.#recordDiagnostic("FINALIZE_RUN", "SEALED");
    const output: FinalizeOutput = {
      runId: state.runId,
      revision: finalized.revision,
      state: "SEALED",
      status: sealed.investigation.status,
      bundleId,
      manifestSha256: sealed.manifestSha256,
      artifactRelativePath: `bundles/${bundleId}`,
      recoveryState: sealed.investigation.recoveryState,
      evidenceSummary: finalizedEvidenceSummary(sealed.evidence, sealed.contradictions),
      presentation: incidentPresentation(
        {
          runId: sealed.runId,
          request: sealed.request,
          profile: sealed.profile,
          evidence: sealed.evidence,
          contradictions: sealed.contradictions,
        },
        sealed.investigation,
        sealed.coverage,
      ),
    };
    this.#evictReconstructableSession(state.runId, state.session);
    return output;
  }

  cancelRun(
    runHandle: RunHandle,
    expectedRevision: number,
    reason: "USER_REQUEST" | "INTERRUPTED" | "BUDGET_EXCEEDED" | "PROVIDER_UNAVAILABLE",
  ): { runId: RunId; revision: number; state: "ABORTED"; retainedEvidenceIds: EvidenceId[] } {
    this.#requireOpen();
    const state = this.#ensureLease(runHandle, expectedRevision);
    const aborted = this.#runStore.abortRun(
      this.#access(runHandle, state.revision),
      state.session.leaseHandle!,
      reason,
    );
    delete state.session.leaseHandle;
    delete state.session.leaseExpiresAt;
    delete state.session.activeHandle;
    delete state.session.activeRevision;
    this.#recordDiagnostic("CANCEL_RUN", "ABORTED");
    const output = {
      runId: state.runId,
      revision: aborted.revision,
      state: "ABORTED" as const,
      retainedEvidenceIds: [...state.session.evidence.keys()],
    };
    this.#evictReconstructableSession(state.runId, state.session);
    return output;
  }

  /** Gracefully relinquish volatile execution authority while retaining an OPEN checkpoint. */
  pauseRun(
    runHandle: RunHandle,
    expectedRevision: number,
  ): { runId: RunId; revision: number; state: "OPEN" | "FINALIZING"; retainedEvidenceIds: EvidenceId[] } {
    this.#requireOpen();
    const resolved = this.#resolve(runHandle, expectedRevision);
    let revision = expectedRevision;
    this.#persistSession(resolved.runId, resolved.session, {
      runHandle,
      runRevision: revision,
      ...(resolved.session.leaseHandle === undefined
        ? {}
        : { leaseHandle: resolved.session.leaseHandle }),
    });
    if (resolved.session.leaseHandle !== undefined) {
      const released = this.#runStore.releaseLease(resolved.access, resolved.session.leaseHandle);
      revision = released.revision;
      delete resolved.session.leaseHandle;
      delete resolved.session.leaseExpiresAt;
    }
    resolved.session.activeHandle = runHandle;
    resolved.session.activeRevision = revision;
    const view = this.#runStore.getRun(this.#access(runHandle, revision));
    if (view.record.state !== "OPEN" && view.record.state !== "FINALIZING") {
      throw new TypeError("Only a recoverable run can be paused");
    }
    this.#recordDiagnostic("PAUSE_RUN", "CHECKPOINTED");
    const output = {
      runId: resolved.runId,
      revision,
      state: view.record.state,
      retainedEvidenceIds: [...resolved.session.evidence.keys()],
    };
    this.#evictReconstructableSession(resolved.runId, resolved.session);
    return output;
  }

  auditSnapshot(): RuntimeAuditSnapshot {
    this.#requireOpen();
    return {
      collectionEvents: this.#audit.snapshot(),
      diagnosticEvents: structuredClone(this.#diagnosticEvents),
      diagnosticEventsDropped: this.#diagnosticEventsDropped,
    };
  }

  close(): Promise<void> {
    this.#closePromise ??= this.#closeAll();
    return this.#closePromise;
  }

  async #closeAll(): Promise<void> {
    this.#closed = true;
    for (const session of this.#sessions.values()) {
      if (
        session.leaseHandle === undefined ||
        session.activeHandle === undefined ||
        session.activeRevision === undefined
      ) continue;
      try {
        const released = this.#runStore.releaseLease(
          this.#access(session.activeHandle, session.activeRevision),
          session.leaseHandle,
        );
        session.activeRevision = released.revision;
      } catch {
        // A stale/expired lease has no authority to retain; teardown remains best effort.
      }
      delete session.leaseHandle;
      delete session.leaseExpiresAt;
    }
    this.#sessions.clear();
    this.#idempotencyRuns.clear();
    if (this.#onClose !== undefined) {
      await this.#onClose();
    } else {
      await Promise.allSettled(this.#registrations.map(async (registration) => {
        const close = (registration.adapter as typeof registration.adapter & { close?: () => void | Promise<void> }).close;
        if (typeof close === "function") await close.call(registration.adapter);
      }));
    }
  }

  #requireOpen(): void {
    if (this.#closed) {
      throw new RunStoreError("RUNTIME_CLOSED", "Monitoring runtime is closed");
    }
  }

  #requireProfile(profileAlias: string): void {
    assertAlias(profileAlias, "profile alias");
    if (profileAlias !== this.profileAlias) throw new TypeError("Profile alias is not active");
  }

  #compilePolicy(
    request: WorkflowRequest,
    sealedVerificationPolicyAlias?: string,
  ): Readonly<CompiledWorkflowPolicy> {
    const selectedOperations = this.#selectedOperations(request);
    const operationCount = Math.max(1, selectedOperations.length);
    const perOperation = this.#bundle.profile.policy.limits;
    const maxRequests = Math.max(8, operationCount * 4);
    const selectedCosts = selectedOperations.map((operation) => estimateOperationCostUnits({
        timeoutMs: Math.min(perOperation.timeoutMs, operation.definition.limits.timeoutMs),
        maxAgeMs: Math.min(perOperation.maxAgeMs, operation.definition.limits.maxAgeMs),
        maxBytes: Math.min(perOperation.maxBytes, operation.definition.limits.maxBytes),
        maxRows: Math.min(perOperation.maxRows, operation.definition.limits.maxRows),
        maxSeries: Math.min(perOperation.maxSeries, operation.definition.limits.maxSeries),
        maxPoints: Math.min(perOperation.maxPoints, operation.definition.limits.maxPoints),
      }));
    const selectedCostTotal = Math.max(1, selectedCosts.reduce((total, cost) => total + cost, 0));
    const sourceCounts = new Map<string, number>();
    for (const operation of selectedOperations) {
      sourceCounts.set(
        operation.definition.sourceAlias,
        (sourceCounts.get(operation.definition.sourceAlias) ?? 0) + 1,
      );
    }
    const maximumOperationsPerSource = Math.max(1, ...sourceCounts.values());
    return compileWorkflowPolicy({
      request,
      trustBundle: this.#bundle,
      ...(sealedVerificationPolicyAlias === undefined ? {} : { sealedVerificationPolicyAlias }),
      now: this.#clock.now().toISOString(),
      maxLookbackMs: 7 * 24 * 60 * 60 * 1_000,
      runLimits: {
        maxRequests,
        // A source may be retried once, but cannot consume the entire run request budget.
        maxRequestsPerSource: Math.min(maxRequests, maximumOperationsPerSource * 2),
        maxConcurrent: Math.min(4, maxRequests),
        // Two complete passes are authorized; additional expensive retries exhaust cost first.
        maxTotalCostUnits: selectedCostTotal * 2,
        maxTotalTimeoutMs: perOperation.timeoutMs * maxRequests,
        maxTotalBytes: perOperation.maxBytes * maxRequests,
        maxTotalRows: perOperation.maxRows * maxRequests,
        maxTotalSeries: perOperation.maxSeries * maxRequests,
        maxTotalPoints: perOperation.maxPoints * maxRequests,
      },
    });
  }

  #selectedOperations(request: WorkflowRequest): OperationSnapshot[] {
    const requestedPacks = request.requiredCapabilityPacks ?? [];
    const selected = new Set(
      request.requiredOperations ?? (requestedPacks.length === 0 ? this.#bundle.profile.operationIds : []),
    );
    const packs = new Map((this.#bundle.capabilityPacks ?? []).map((pack) => [pack.packId, pack]));
    for (const packId of requestedPacks) {
      const pack = packs.get(packId);
      if (pack === undefined) continue;
      for (const operationId of pack.requiredOperationIds) selected.add(operationId);
    }
    return this.#bundle.operations.filter((operation) => selected.has(operation.operationId));
  }

  #access(handle: RunHandle, expectedRevision: number): RunAccess {
    return {
      principal: this.#principal,
      handle,
      expectedRevision,
      expectedProfileAlias: this.profileAlias,
      expectedTrustBundleSha256: this.#bundle.integrity.contentSha256,
    };
  }

  #resolve(handle: RunHandle, expectedRevision: number): {
    runId: RunId;
    access: RunAccess;
    session: RuntimeSession;
  } {
    const access = this.#access(handle, expectedRevision);
    const view = this.#runStore.getRun(access);
    const session = this.#sessionFor(view.record.runId, access);
    session.activeHandle = handle;
    session.activeRevision = expectedRevision;
    return { runId: view.record.runId, access, session };
  }

  #sessionFor(runId: RunId, access: RunAccess): RuntimeSession {
    const cached = this.#sessions.get(runId);
    if (cached !== undefined) {
      this.#sessions.delete(runId);
      this.#sessions.set(runId, cached);
      return cached;
    }
    this.#ensureSessionSlot();
    const checkpoint = this.#checkpointStore?.read(runId);
    let session: RuntimeSession;
    if (checkpoint !== undefined) {
      const validated = validateRuntimeCheckpoint(checkpoint, {
        runId,
        trustBundleSha256: this.#bundle.integrity.contentSha256,
        profileAlias: this.profileAlias,
      });
      session = {
        request: validated.request,
        policy: validated.policy,
        budget: restoreBudget(validated.policy, validated.budgetHistory),
        evidence: new Map(validated.evidence.map((envelope) => [envelope.evidenceId, envelope])),
        contradictions: validated.contradictions,
        budgetHistory: validated.budgetHistory,
        completedByKey: new Map(validated.completedByKey),
        incompleteKeys: new Set(validated.incompleteKeys),
        deferredOperations: new Map(validated.deferredOperations ?? []),
        auditEventCount: validated.auditEventCount,
        checkpointRevision: validated.checkpointRevision,
        ...(validated.verificationContract === undefined
          ? {}
          : { verificationContract: validated.verificationContract }),
        ...(validated.sealedArtifact === undefined ? {} : { sealedArtifact: validated.sealedArtifact }),
      };
    } else {
      const context = this.#runStore.getRecoveryContext(access);
      let recoveredContract: VerificationContract | undefined;
      let policy: Readonly<CompiledWorkflowPolicy>;
      if (context.request.workflow === "verify") {
        if (context.request.parentRunId === undefined) {
          throw new TypeError("Persisted verification run has no sealed parent binding");
        }
        const parent = this.#runStore.getSealedParent({
          principal: this.#principal,
          runId: context.request.parentRunId,
          expectedProfileAlias: this.profileAlias,
          expectedTrustBundleSha256: this.#bundle.integrity.contentSha256,
        });
        recoveredContract = this.#sealedParentContract(
          context.request.parentRunId,
          parent.verificationContractSha256,
        );
        policy = this.#compilePolicy(context.request, recoveredContract.policyAlias);
        const reproduced = buildVerificationContract(policy);
        if (reproduced === undefined || reproduced.contractSha256 !== recoveredContract.contractSha256) {
          throw new TypeError("Persisted verification contract cannot be reproduced by the active trust bundle");
        }
      } else {
        policy = this.#compilePolicy(context.request);
        recoveredContract = buildVerificationContract(policy);
      }
      if (
        policy.requestSha256 !== context.policy.requestSha256 ||
        policy.trustBundleSha256 !== context.policy.trustBundleSha256 ||
        sha256Canonical(policy.operations) !== sha256Canonical(context.policy.operations)
      ) {
        throw new TypeError("Persisted run context cannot be reproduced by the active trust bundle");
      }
      session = {
        request: structuredClone(context.request),
        policy,
        budget: new BudgetLedger(policy),
        evidence: new Map(),
        contradictions: [],
        budgetHistory: [],
        completedByKey: new Map(),
        incompleteKeys: new Set(),
        deferredOperations: new Map(),
        auditEventCount: 0,
        checkpointRevision: 0,
        ...(recoveredContract === undefined ? {} : { verificationContract: recoveredContract }),
      };
      this.#persistSession(runId, session, {
        runHandle: access.handle,
        runRevision: access.expectedRevision,
      });
    }
    this.#sessions.set(runId, session);
    return session;
  }

  #ensureSessionSlot(): void {
    if (this.#sessions.size < this.#maxCachedSessions) return;
    if (this.#checkpointStore !== undefined) {
      for (const [runId, session] of this.#sessions) {
        if (session.leaseHandle !== undefined) continue;
        this.#sessions.delete(runId);
        this.#deleteIdempotencyRun(runId);
        if (this.#sessions.size < this.#maxCachedSessions) return;
      }
    }
    throw new RunStoreError(
      "RUNTIME_CAPACITY",
      "Runtime session cache is at capacity; pause or close an active run before starting another",
    );
  }

  #evictReconstructableSession(runId: RunId, session: RuntimeSession): void {
    if (this.#checkpointStore !== undefined && session.leaseHandle === undefined) {
      this.#sessions.delete(runId);
      this.#deleteIdempotencyRun(runId);
    }
  }

  #deleteIdempotencyRun(runId: RunId): void {
    for (const [idempotencyKey, indexedRunId] of this.#idempotencyRuns) {
      if (indexedRunId === runId) this.#idempotencyRuns.delete(idempotencyKey);
    }
  }

  #sealedParentContract(runId: RunId, expectedSha256: Sha256): VerificationContract {
    const cached = this.#sessions.get(runId)?.verificationContract;
    if (cached !== undefined) {
      if (cached.contractSha256 !== expectedSha256) throw new TypeError("Sealed parent contract integrity mismatch");
      return structuredClone(cached);
    }
    const checkpoint = this.#checkpointStore?.read(runId);
    if (checkpoint === undefined) {
      throw new TypeError("Sealed parent verification contract is not recoverable in this process");
    }
    const validated = validateRuntimeCheckpoint(checkpoint, {
      runId,
      trustBundleSha256: this.#bundle.integrity.contentSha256,
      profileAlias: this.profileAlias,
    });
    if (
      validated.verificationContract === undefined ||
      validated.verificationContract.contractSha256 !== expectedSha256
    ) {
      throw new TypeError("Sealed parent contract integrity mismatch");
    }
    return structuredClone(validated.verificationContract);
  }

  #persistSession(
    runId: RunId,
    session: RuntimeSession,
    authority: CheckpointAuthority,
  ): void {
    if (this.#checkpointStore === undefined) return;
    if (session.checkpointRevision >= MAXIMUM_AUTHORITY_COMPONENT_REVISION) {
      throw new RunStoreError(
        "RUNTIME_CAPACITY",
        "Runtime checkpoint reached its bounded authority capacity",
      );
    }
    const access = this.#access(authority.runHandle, authority.runRevision);
    const view = authority.leaseHandle === undefined
      ? this.#runStore.getRun(access)
      : this.#runStore.assertLease(access, authority.leaseHandle);
    if (authority.leaseHandle === undefined && view.hasLease) {
      throw new RunStoreError("LEASE_REQUIRED", "An unleased writer cannot persist while a run lease is active");
    }
    const checkpoint: RuntimeSessionCheckpointDraft = {
      schemaVersion: "1.0.0",
      runId,
      runRevision: authority.runRevision,
      request: structuredClone(session.request),
      policy: structuredClone(session.policy),
      evidence: [...session.evidence.values()],
      contradictions: session.contradictions,
      budgetHistory: session.budgetHistory,
      completedByKey: [...session.completedByKey.entries()].sort(([left], [right]) => left.localeCompare(right)),
      incompleteKeys: [...session.incompleteKeys].sort(),
      deferredOperations: [...session.deferredOperations.entries()]
        .sort(([left], [right]) => left.localeCompare(right)),
      auditEventCount: session.auditEventCount,
      ...(session.verificationContract === undefined
        ? {}
        : { verificationContract: session.verificationContract }),
      ...(session.sealedArtifact === undefined ? {} : { sealedArtifact: session.sealedArtifact }),
    };
    validateRuntimeCheckpoint({
      ...checkpoint,
      checkpointRevision: session.checkpointRevision + 1,
    }, {
      runId,
      trustBundleSha256: this.#bundle.integrity.contentSha256,
      profileAlias: this.profileAlias,
    });
    session.checkpointRevision = this.#checkpointStore.write(
      checkpoint,
      session.checkpointRevision,
    );
  }

  #requireAuthorizedOperation(session: RuntimeSession, operationId: OperationId): OperationSnapshot {
    const operation = this.#bundle.operations.find((candidate) => candidate.operationId === operationId);
    if (operation === undefined || session.policy.operations[operationId] === undefined) {
      throw new TypeError("Operation is not present in the sealed run snapshot");
    }
    return operation;
  }

  #ensureLease(handle: RunHandle, expectedRevision: number): {
    runId: RunId;
    session: RuntimeSession;
    revision: number;
  } {
    const resolved = this.#resolve(handle, expectedRevision);
    const leaseExpired = resolved.session.leaseExpiresAt !== undefined &&
      Date.parse(resolved.session.leaseExpiresAt) <= this.#clock.now().getTime();
    if (leaseExpired) {
      delete resolved.session.leaseHandle;
      delete resolved.session.leaseExpiresAt;
    }
    if (resolved.session.leaseHandle !== undefined) {
      return { runId: resolved.runId, session: resolved.session, revision: expectedRevision };
    }
    const lease = this.#runStore.claimLease(resolved.access, `runtime-${process.pid}`, this.#leaseTtlMs);
    resolved.session.leaseHandle = lease.leaseHandle;
    resolved.session.leaseExpiresAt = lease.expiresAt;
    resolved.session.activeHandle = handle;
    resolved.session.activeRevision = lease.revision;
    return { runId: resolved.runId, session: resolved.session, revision: lease.revision };
  }

  async #collectAllocated(input: {
    runId: RunId;
    session: RuntimeSession;
    operationId: OperationId;
    window: TimeWindow;
    evidenceId: EvidenceId;
    tenantSha256: Sha256;
    reservationId: string;
    key: string;
    fenceLease: () => void;
    persistSession: () => void;
    signal?: AbortSignal;
  }): Promise<EvidenceEnvelope> {
    const { runId, session, operationId, window } = input;
    const operation = this.#requireAuthorizedOperation(session, operationId);
    const adapterPackage = this.#bundle.adapters.find(
      (candidate) => candidate.packageId === operation.definition.adapterPackageId,
    );
    if (adapterPackage === undefined) throw new TypeError("Operation adapter package is not admitted");
    const evidenceStore = new MemoryEvidenceStore();
    const host = new EvidenceHost({
      registry: this.#registry,
      audit: this.#audit,
      store: evidenceStore,
      policy: {
        auditRequired: this.#bundle.profile.policy.auditRequired,
        maxDefinitionBytes: 64 * 1_024,
        maxClockSkewMs: 30_000,
      },
      clock: this.#clock,
      ids: {
        evidenceId: () => input.evidenceId,
        contradictionId: () => `pmcon_${randomUUID().replaceAll("-", "")}` as ContradictionId,
      },
    });
    const startedAt = this.#clock.now().getTime();
    try {
      const envelope = await host.collect({
        run: {
          runId,
          trustBundleSha256: session.policy.trustBundleSha256,
          origin: session.request.origin,
          scope: structuredClone(session.policy.scope),
          window: structuredClone(window),
          allowedOperationHashes: Object.fromEntries(
            Object.values(session.policy.operations).map((item) => [item.operationId, item.definitionSha256]),
          ),
          authorizedOperationLimits: Object.fromEntries(
            Object.values(session.policy.operations).map((item) => [item.operationId, item.limits]),
          ),
          expectedTenantSha256: input.tenantSha256,
        },
        operation,
        effectiveLimits: session.policy.operations[operationId]!.limits,
        adapterPackage,
        ...(input.signal === undefined ? {} : { signal: input.signal }),
      });
      if (envelope.evidenceId !== input.evidenceId || evidenceStore.evidence.length !== 1) {
        throw new Error("Evidence host did not persist the allocated evidence identity exactly once");
      }
      input.fenceLease();
      const usage = evidenceUsage(envelope, this.#clock.now().getTime() - startedAt);
      session.budget.settle(input.reservationId, usage);
      settleBudgetHistory(session, input.reservationId, usage);
      session.evidence.set(envelope.evidenceId, envelope);
      session.completedByKey.set(input.key, envelope.evidenceId);
      session.incompleteKeys.delete(input.key);
      session.deferredOperations.delete(operationId);
      input.persistSession();
      return envelope;
    } catch (error) {
      input.fenceLease();
      cancelBudgetHistory(session, input.reservationId);
      input.persistSession();
      throw error;
    }
  }
}
function auditEventsForRun(audit: RuntimeAuditSink, runId: RunId, startIndex = 0): AuditEvent[] {
  if (audit.snapshotRun !== undefined) return audit.snapshotRun(runId, startIndex);
  return audit.snapshot().filter((event) => event.runId === runId).slice(startIndex);
}

function auditEventCountForRun(audit: RuntimeAuditSink, runId: RunId): number {
  return audit.countRun?.(runId) ?? auditEventsForRun(audit, runId).length;
}
