import type {
  AdapterRegistration,
  AuditEvent,
} from "@codex-production-monitoring/adapter-host";
import type { Clock } from "@codex-production-monitoring/adapter-sdk";
import type {
  BundleId,
  ContradictionRecord,
  EvidenceDomain,
  EvidenceEnvelope,
  EvidenceId,
  EvidenceStateSummary,
  InvestigationStatus,
  OperationId,
  RunHandle,
  RunId,
  TrustBundle,
  WorkflowRequest,
  RecoveryState,
} from "@codex-production-monitoring/contracts";
import type { PrincipalIdentity } from "@codex-production-monitoring/run-store";
import type { RunStore } from "@codex-production-monitoring/run-store";
import type { ArtifactProducer, IncidentPresentation } from "@codex-production-monitoring/artifacts";
import type { RuntimeAuditSink } from "./audit.ts";

export interface MonitoringRuntimeOptions {
  bundle: TrustBundle;
  registrations: AdapterRegistration[];
  artifactRoot: string;
  principal: PrincipalIdentity;
  surface?: "fixture" | "local-stdio" | "customer-vpc" | "publisher-hosted" | "customer-relay";
  routeDescription?: string;
  clock?: Clock;
  runTtlMs?: number;
  leaseTtlMs?: number;
  /** Strict lifetime bound for recoverable runtime-session objects. Defaults to 128. */
  maxCachedSessions?: number;
  /** Number of most-recent non-authoritative diagnostic events retained in memory. Defaults to 256. */
  maxDiagnosticEvents?: number;
  /** Enables process-recoverable authority and session checkpoints. */
  stateRoot?: string;
  /** Test/embedding override; stateRoot and runStore are mutually exclusive. */
  runStore?: RunStore;
  /** Runtime-owned adapter/transport teardown hook (for signed workers, sockets, etc.). */
  onClose?: () => void | Promise<void>;
  /** Code-owned test/embedding override. Required-audit profiles require durable=true. */
  auditSink?: RuntimeAuditSink;
  configurationIssues?: ReadonlyArray<{
    packageId?: string;
    code: string;
    message: string;
  }>;
  /** Code-owned release identity stamped into every sealed artifact manifest. */
  artifactProducer?: ArtifactProducer;
}

export interface BeginRunOutput {
  runId: RunId;
  runHandle?: RunHandle;
  revision: number;
  replayed: boolean;
  requestSha256: string;
  trustBundleSha256: string;
  operationSnapshotSha256: string;
  origin: WorkflowRequest["origin"];
}

export interface CollectOutput {
  runId: RunId;
  revision: number;
  evidence: EvidenceEnvelope[];
  budget: unknown;
  failures?: Array<{ operationId: OperationId; code: string }>;
}

export interface FinalizeOutput {
  runId: RunId;
  revision: number;
  state: "SEALED";
  status: InvestigationStatus;
  bundleId: BundleId;
  manifestSha256: string;
  artifactRelativePath: string;
  recoveryState: RecoveryState;
  evidenceSummary: EvidenceStateSummary;
  presentation: IncidentPresentation;
}

export interface RuntimeCapability {
  provider: string;
  packageId: string;
  domains: EvidenceDomain[];
  operations: string[];
  status: "AVAILABLE" | "UNAVAILABLE";
}

export interface RuntimeAuditSnapshot {
  collectionEvents: AuditEvent[];
  diagnosticEvents: Array<{
    at: string;
    event: string;
    profileAlias: string;
    outcome: string;
  }>;
  diagnosticEventsDropped: number;
}

export interface RuntimeSessionSummary {
  request: WorkflowRequest;
  evidence: EvidenceEnvelope[];
  contradictions: ContradictionRecord[];
  evidenceIds: EvidenceId[];
  operationIds: OperationId[];
}
