import {
  assertAnalysisDraftSemantics,
  loadSchemaRegistry,
  SCHEMA_IDS,
  type AnalysisDraft,
  type EvidenceId,
  type WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import { Ajv2020 } from "ajv/dist/2020.js";
import type { ErrorObject, ValidateFunction } from "ajv";
import addFormatsImport from "ajv-formats";

const ajv = new Ajv2020({ allErrors: true, allowUnionTypes: true, strict: true });
const addFormats = addFormatsImport as unknown as (instance: Ajv2020) => Ajv2020;
addFormats(ajv);
for (const schema of loadSchemaRegistry().values()) ajv.addSchema(schema);
const workflowValidator = ajv.getSchema(SCHEMA_IDS.workflowRequest);
if (workflowValidator === undefined) throw new Error("Workflow request schema is not registered");
const analysisValidator = ajv.getSchema(SCHEMA_IDS.analysisDraft);
if (analysisValidator === undefined) throw new Error("Analysis draft schema is not registered");

function summarize(errors: ErrorObject[] | null | undefined): string {
  return (errors ?? [])
    .slice(0, 5)
    .map((error) => `${error.instancePath || "/"} ${error.message ?? "is invalid"}`)
    .join("; ");
}

export class WorkflowValidationError extends Error {
  readonly code = "INVALID_WORKFLOW_REQUEST";

  constructor(message: string) {
    super(message);
    this.name = "WorkflowValidationError";
  }
}

export function validateWorkflowRequest(value: unknown): WorkflowRequest {
  const validate = workflowValidator as ValidateFunction<WorkflowRequest>;
  if (!validate(value)) {
    throw new WorkflowValidationError(`Workflow request is invalid: ${summarize(validate.errors)}`);
  }
  return structuredClone(value);
}

export function validateAnalysisDraft(
  value: unknown,
  allowedEvidenceIds?: ReadonlySet<EvidenceId>,
): AnalysisDraft {
  const validate = analysisValidator as ValidateFunction<AnalysisDraft>;
  if (!validate(value)) {
    throw new WorkflowValidationError(`Analysis draft is invalid: ${summarize(validate.errors)}`);
  }
  assertAnalysisDraftSemantics(value, allowedEvidenceIds);
  return structuredClone(value);
}
