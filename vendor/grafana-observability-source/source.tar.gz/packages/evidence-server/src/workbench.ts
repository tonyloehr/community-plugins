import {
  deriveEvidenceState,
  evidenceSourceIndependenceKey,
  sha256Canonical,
  type ContradictionRecord,
  type Coverage,
  type EvidenceEnvelope,
  type EvidenceId,
  type EvidenceState,
  type Investigation,
  type MonitoringWorkspaceId,
  type MonitoringWorkspaceSnapshot,
  type OperationSnapshot,
  type ProviderCapabilityPackV1,
  type JsonPrimitive,
  type RunId,
  type TrustedEndpoint,
  type WorkbenchEvidenceDetail,
  type WorkbenchEvidenceLink,
  type WorkbenchEvidenceRef,
  type WorkbenchIssueCard,
  type WorkbenchIssueRef,
  type WorkbenchEvidenceValue,
  type WorkbenchLinkRef,
  type WorkbenchResolvedLinkTarget,
  type WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import {
  MAXIMUM_AUTHORITY_COMPONENT_REVISION,
  MAXIMUM_RUN_CREATION_SEQUENCE,
  type OwnedRunView,
  type PrincipalIdentity,
} from "@codex-production-monitoring/run-store";

const MAX_WORKBENCH_RUNS = 20;
const MAX_EVIDENCE_CARDS = 24;
const MAX_ACTIVITY = 40;
const MAX_PATCH_VERIFICATION_CRITERIA = 16;
const AUTHORITY_PHASE_WIDTH = 1_073_741_824;
const RUN_STATE_VERSION_STRIDE = 4_294_967_296;

export interface WorkbenchProjectionAuthority {
  workspaceId: MonitoringWorkspaceId;
  asOf: string;
  profileAlias: string;
  capabilityProfile: "observe" | "investigate" | "prepare_patch";
  profileEndpointIds: readonly string[];
  endpoints: readonly TrustedEndpoint[];
  inventoryOmittedCount: number;
  run?: Readonly<OwnedRunView>;
  request?: Readonly<WorkflowRequest>;
  operations: readonly OperationSnapshot[];
  capabilityPacks: readonly ProviderCapabilityPackV1[];
  evidence: readonly EvidenceEnvelope[];
  contradictions: readonly ContradictionRecord[];
  investigation?: Readonly<Investigation>;
  coverage?: Readonly<Coverage>;
  checkpointRevision: number;
  authorityFailure?: "CHECKPOINT_UNAVAILABLE" | "CHECKPOINT_INVALID" | "ARTIFACT_UNAVAILABLE" | "ARTIFACT_INVALID";
}

export interface WorkbenchLinkProjection {
  link: WorkbenchEvidenceLink;
  target?: WorkbenchResolvedLinkTarget;
}

export interface WorkbenchProjection {
  snapshot: MonitoringWorkspaceSnapshot;
  evidence: ReadonlyMap<WorkbenchEvidenceRef, WorkbenchEvidenceDetail>;
  links: ReadonlyMap<WorkbenchLinkRef, WorkbenchLinkProjection>;
}

export interface WorkbenchPatchContext {
  schemaVersion: "1.1.0";
  workspaceId: MonitoringWorkspaceId;
  issueRef: WorkbenchIssueRef;
  hypothesisRef: string;
  issue: {
    kind: WorkbenchIssueCard["kind"];
    severity: WorkbenchIssueCard["severity"];
    title: string;
    summary: string;
  };
  origin: "LIVE" | "REPLAY" | "SIMULATED";
  scope: { service?: string; environment: string; window: { start: string; end: string } };
  profileAlias: string;
  hypothesis: {
    statement: string;
    rationale: string;
    supportingEvidence: Array<{ evidenceRef: WorkbenchEvidenceRef; title: string; summary: string }>;
    counterEvidence: Array<{ evidenceRef: WorkbenchEvidenceRef; title: string; summary: string }>;
  };
  verification: {
    policyAlias: string;
    windowStrategy: "FIXED" | "ROLLING" | "REPEATED_CHECKS";
    windowDurationSeconds: number;
    requiredSamples: number;
    passCount: number;
    criteria: Array<{
      criterionId: string;
      operationId: string;
      signalName: string;
      signalKind: "SCALAR" | "TIMESERIES";
      reducer: "SINGLE" | "LATEST" | "ALL";
      comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ" | "INACTIVE" | "ACTIVE";
      expected: JsonPrimitive;
      unit?: string;
      maxEvidenceAgeMs: number;
      requiredDurationSeconds?: number;
    }>;
    omittedCriteria: number;
  };
  nextSafeStep: string;
  limitations: string[];
}

interface LinkCandidate {
  kind: WorkbenchEvidenceLink["kind"];
  label: string;
  targetMode: "EXTERNAL" | "CODE";
  path?: string;
}

function bounded(value: string, maximum: number): string {
  if (value.length <= maximum) return value;
  return `${value.slice(0, Math.max(1, maximum - 1)).trimEnd()}…`;
}

const SENSITIVE_WORKBENCH_TEXT = [
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/u,
  /\b[a-f0-9]{64}\b/iu,
  /\b[a-f0-9]{40}\b/iu,
  /\b[a-z][a-z0-9+.-]{1,15}:\/\/\S+/iu,
  /\b(?:bearer|basic)\s+[A-Za-z0-9._~+/=-]{4,}/iu,
  /\b(?:authorization|api[ _-]?key|access[ _-]?token|refresh[ _-]?token|token|password|passwd|secret|credential|cookie)\b\s*[:=]\s*\S+/iu,
  /\b(?:sk|ghp|github_pat|xox[baprs])[-_][A-Za-z0-9_-]{12,}\b/iu,
  /\bAKIA[A-Z0-9]{12,}\b/u,
  /\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\b/u,
  /(?:^|[\s"'`([{<:=])\/(?!\/)[^\s"'`)\]}>;,]+/u,
  /(?:^|[\s"'`([{<:=])[A-Za-z]:\\[^\s"'`)\]}>;,]+/u,
  /\b(?:pmrun|pmev|pmbundle|pmh)_[A-Za-z0-9_-]+\b/u,
] as const;

function safeWorkbenchText(value: string, maximum: number): string | undefined {
  const trimmed = value.trim();
  if (
    trimmed.length === 0 ||
    [...trimmed].some((character) => {
      const code = character.codePointAt(0) ?? 0;
      return code < 0x20 || code === 0x7f;
    }) ||
    SENSITIVE_WORKBENCH_TEXT.some((pattern) => pattern.test(trimmed))
  ) return undefined;
  return bounded(trimmed, maximum);
}

function requiredWorkbenchText(value: string, maximum: number, fallback: string): string {
  return safeWorkbenchText(value, maximum) ?? fallback;
}

function uniqueBounded(values: readonly string[], maximumItems: number, maximumLength: number): string[] {
  return [...new Set(values
    .map((value) => safeWorkbenchText(value, maximumLength))
    .filter((value): value is string => value !== undefined))]
    .slice(0, maximumItems);
}

function workspaceDigest(value: unknown): string {
  const encoded = Buffer.from(sha256Canonical(value), "hex").toString("base64url");
  return encoded.match(/.{1,8}/gu)!.join("_");
}

export function latestWorkspaceId(input: {
  principal: PrincipalIdentity;
  profileAlias: string;
  trustBundleSha256: string;
}): MonitoringWorkspaceId {
  return `pmws_${workspaceDigest({
    domain: "pm-workbench-latest-v1",
    principal: input.principal,
    profileAlias: input.profileAlias,
    trustBundleSha256: input.trustBundleSha256,
  })}` as MonitoringWorkspaceId;
}

export function workspaceIdForRun(input: {
  principal: PrincipalIdentity;
  profileAlias: string;
  trustBundleSha256: string;
  runId: RunId;
}): MonitoringWorkspaceId {
  return `pmws_${workspaceDigest({
    domain: "pm-workbench-run-v1",
    principal: input.principal,
    profileAlias: input.profileAlias,
    trustBundleSha256: input.trustBundleSha256,
    runId: input.runId,
  })}` as MonitoringWorkspaceId;
}

function evidenceRef(workspaceId: MonitoringWorkspaceId, id: EvidenceId): WorkbenchEvidenceRef {
  return `pmwsev_${workspaceDigest({ domain: "pm-workbench-evidence-v1", workspaceId, id })}` as WorkbenchEvidenceRef;
}

function hypothesisRefFor(hypothesisId: string): string {
  return `hypothesis.${workspaceDigest(hypothesisId).slice(0, 24).toLowerCase()}`;
}

function issueRefFor(
  workspaceId: MonitoringWorkspaceId,
  material: unknown,
): WorkbenchIssueRef {
  return `pmwsiss_${workspaceDigest({ domain: "pm-workbench-issue-v1", workspaceId, material })}` as WorkbenchIssueRef;
}

function linkRef(
  workspaceId: MonitoringWorkspaceId,
  id: EvidenceId,
  candidate: LinkCandidate,
): WorkbenchLinkRef {
  return `pmwslnk_${workspaceDigest({
    domain: "pm-workbench-link-v1",
    workspaceId,
    id,
    candidate,
  })}` as WorkbenchLinkRef;
}

function authorityStateVersion(run: Readonly<OwnedRunView> | undefined, checkpointRevision: number): number {
  if (run === undefined) return 1;
  const sequence = run.revision + checkpointRevision;
  if (
    !Number.isSafeInteger(run.creationSequence) ||
    run.creationSequence < 0 ||
    run.creationSequence > MAXIMUM_RUN_CREATION_SEQUENCE ||
    !Number.isSafeInteger(run.revision) ||
    run.revision < 1 ||
    run.revision > MAXIMUM_AUTHORITY_COMPONENT_REVISION ||
    !Number.isSafeInteger(checkpointRevision) ||
    checkpointRevision < 0 ||
    checkpointRevision > MAXIMUM_AUTHORITY_COMPONENT_REVISION ||
    !Number.isSafeInteger(sequence) ||
    sequence < 1 ||
    sequence >= AUTHORITY_PHASE_WIDTH
  ) {
    throw new TypeError("Workbench authority cannot be represented by the bounded state-version contract");
  }
  const phase = run.state === "OPEN"
    ? 0
    : run.state === "FINALIZING"
      ? AUTHORITY_PHASE_WIDTH
      : AUTHORITY_PHASE_WIDTH * 2;
  const stateVersion =
    run.creationSequence * RUN_STATE_VERSION_STRIDE +
    phase +
    sequence;
  if (!Number.isSafeInteger(stateVersion)) {
    throw new TypeError("Workbench state version exceeds the safe integer range");
  }
  return stateVersion;
}

function evidenceState(
  envelope: EvidenceEnvelope,
  contradictoryEvidenceIds: ReadonlySet<EvidenceId>,
): EvidenceState {
  return deriveEvidenceState({
    collectionState: envelope.collectionState,
    freshnessState: envelope.freshnessState,
    hasUnresolvedContradiction: contradictoryEvidenceIds.has(envelope.evidenceId),
  });
}

function primitiveText(value: null | boolean | number | string): string {
  if (value === null) return "No value";
  if (typeof value === "number") return Number.isFinite(value) ? String(Number(value.toPrecision(6))) : "Unavailable";
  return requiredWorkbenchText(String(value), 256, "Unavailable");
}

function displayMetric(value: number | null, unit?: string): string {
  if (value === null || !Number.isFinite(value)) return "No value";
  if (unit === "ratio") return `${Number((value * 100).toPrecision(4))}%`;
  return primitiveText(value);
}

function isTechnicalTableColumn(name: string): boolean {
  const tokens = name
    .replace(/([a-z0-9])([A-Z])/gu, "$1 $2")
    .toLowerCase()
    .split(/[^a-z0-9]+/u)
    .filter((token) => token.length > 0);
  return tokens.some((token) => new Set([
    "auth",
    "authorization",
    "commit",
    "cookie",
    "credential",
    "hash",
    "head",
    "index",
    "password",
    "passwd",
    "path",
    "revision",
    "secret",
    "sha",
    "sha1",
    "sha256",
    "sha512",
    "token",
    "tree",
    "uri",
    "url",
    "worktree",
  ]).has(token));
}

function detailValues(envelope: EvidenceEnvelope): WorkbenchEvidenceValue[] {
  const values: WorkbenchEvidenceValue[] = [];
  for (const normalized of envelope.values) {
    if (values.length >= 24) break;
    if (normalized.kind === "SCALAR") {
      const label = safeWorkbenchText(normalized.name, 96);
      if (label === undefined) continue;
      if (typeof normalized.value === "number" || normalized.value === null) {
        const unit = normalized.unit === undefined ? undefined : safeWorkbenchText(normalized.unit, 32);
        values.push({
          kind: "METRIC",
          label,
          value: normalized.value,
          ...(unit === undefined ? {} : { unit }),
          points: [{ at: normalized.observedAt ?? envelope.evaluatedAt, value: normalized.value }],
        });
      } else {
        const value = typeof normalized.value === "string"
          ? safeWorkbenchText(normalized.value, 256)
          : normalized.value;
        if (value !== undefined) values.push({ kind: "FACT", label, value });
      }
      continue;
    }
    if (normalized.kind === "TIMESERIES") {
      const label = safeWorkbenchText(normalized.name, 96);
      if (label === undefined) continue;
      const points = normalized.points.slice(-60);
      const unit = normalized.unit === undefined ? undefined : safeWorkbenchText(normalized.unit, 32);
      values.push({
        kind: "METRIC",
        label,
        value: points.at(-1)?.value ?? null,
        ...(unit === undefined ? {} : { unit }),
        points: points.map((point) => ({ at: point.at, value: point.value })),
      });
      continue;
    }
    if (normalized.kind === "EVENT") {
      const summary = safeWorkbenchText(normalized.summary, 512);
      if (summary !== undefined) values.push({ kind: "EVENT", at: normalized.occurredAt, summary });
      continue;
    }
    for (let rowIndex = 0; rowIndex < normalized.rows.length && values.length < 24; rowIndex += 1) {
      const row = normalized.rows[rowIndex]!;
      for (let columnIndex = 0; columnIndex < normalized.columns.length && values.length < 24; columnIndex += 1) {
        const column = normalized.columns[columnIndex]!;
        if (isTechnicalTableColumn(column.name)) continue;
        const value = row[columnIndex];
        if (value === undefined) continue;
        const label = safeWorkbenchText(`${normalized.name} ${rowIndex + 1} ${column.name}`, 96);
        const safeValue = typeof value === "string" ? safeWorkbenchText(value, 256) : value;
        if (label === undefined || safeValue === undefined) continue;
        values.push({
          kind: "FACT",
          label,
          value: safeValue,
        });
      }
    }
  }
  return values;
}

function detailSummary(envelope: EvidenceEnvelope, state: EvidenceState): string {
  const operation = requiredWorkbenchText(envelope.operationId, 128, "The reviewed operation");
  const provider = requiredWorkbenchText(envelope.source.provider, 64, "the reviewed source");
  if (envelope.error !== undefined) {
    return bounded(
      `${operation} returned ${state.toLowerCase()} evidence (${envelope.error.category}; ${envelope.error.retryable ? "retryable" : "not retryable"}).`,
      1_024,
    );
  }
  const first = envelope.values[0];
  if (first?.kind === "SCALAR") {
    const name = requiredWorkbenchText(first.name, 96, "The normalized value");
    return bounded(
      `${name} is ${displayMetric(typeof first.value === "number" ? first.value : null, first.unit)} from ${provider}.`,
      1_024,
    );
  }
  if (first?.kind === "TIMESERIES") {
    const name = requiredWorkbenchText(first.name, 96, "The normalized metric");
    return bounded(
      `${name} latest value is ${displayMetric(first.points.at(-1)?.value ?? null, first.unit)} from ${provider}.`,
      1_024,
    );
  }
  if (first?.kind === "EVENT") {
    return requiredWorkbenchText(
      first.summary,
      1_024,
      `${operation} returned ${state.toLowerCase()} event evidence.`,
    );
  }
  return bounded(`${operation} returned ${state.toLowerCase()} normalized evidence.`, 1_024);
}

function safeProviderPath(reference: string, provider: "grafana" | "prometheus"): string | undefined {
  const prefix = `${provider}:`;
  if (!reference.startsWith(prefix)) return undefined;
  const path = reference.slice(prefix.length);
  if (
    path.length < 1 ||
    path.length > 1_024 ||
    !path.startsWith("/") ||
    path.startsWith("//") ||
    path.includes("\\") ||
    [...path].some((character) => {
      const code = character.codePointAt(0) ?? 0;
      return code < 0x20 || code === 0x7f;
    })
  ) return undefined;
  return path;
}

function grafanaDeepLinks(envelope: EvidenceEnvelope): string[] {
  const links: string[] = envelope.source.sanitizedReference === undefined
    ? []
    : [envelope.source.sanitizedReference];
  for (const value of envelope.values) {
    if (value.kind === "EVENT") {
      const candidate = value.attributes.deepLink;
      if (typeof candidate === "string") links.push(candidate);
    } else if (value.kind === "TABLE") {
      const index = value.columns.findIndex((column) => column.name === "deepLink");
      if (index >= 0) {
        for (const row of value.rows) {
          const candidate = row[index];
          if (typeof candidate === "string") links.push(candidate);
        }
      }
    }
  }
  return [...new Set(links)].filter((reference) => {
    const path = safeProviderPath(reference, "grafana");
    return path !== undefined && (
      /^\/d\/[A-Za-z0-9_-]{1,128}$/u.test(path) ||
      /^\/d\/[A-Za-z0-9_-]{1,128}\?viewPanel=[1-9][0-9]{0,9}$/u.test(path) ||
      /^\/dashboards\/f\/[A-Za-z0-9_-]{1,128}$/u.test(path) ||
      /^\/alerting\/grafana\/[A-Za-z0-9_-]{1,128}\/view$/u.test(path)
    );
  }).slice(0, 4);
}

function linkCandidates(envelope: EvidenceEnvelope): LinkCandidate[] {
  const reference = envelope.source.sanitizedReference;
  if (envelope.source.provider.toLowerCase() === "grafana") {
    const deepLinks = grafanaDeepLinks(envelope);
    if (deepLinks.length > 0) {
      return deepLinks.map((path, index) => ({
        kind: "GRAFANA_DASHBOARD",
        label: deepLinks.length === 1 ? "Open Grafana evidence" : `Open Grafana evidence ${index + 1}`,
        targetMode: "EXTERNAL",
        path: safeProviderPath(path, "grafana"),
      }));
    }
    return [{ kind: "GRAFANA_DASHBOARD", label: "Open Grafana", targetMode: "EXTERNAL", path: "/" }];
  }
  if (envelope.source.provider.toLowerCase() === "prometheus") {
    return [{ kind: "PROMETHEUS_VIEW", label: "Open Prometheus", targetMode: "EXTERNAL", path: "/graph" }];
  }
  if (reference?.startsWith("git:") === true && /^git:[A-Za-z0-9._:-]{1,512}$/u.test(reference)) {
    return [{ kind: "CODE_REVISION", label: "Open code evidence", targetMode: "CODE" }];
  }
  if (reference === "loki:query-range") {
    return [{ kind: "LOG_VIEW", label: "Log source link unavailable", targetMode: "EXTERNAL" }];
  }
  if (reference === "tempo:search" || reference === "tempo:trace") {
    return [{ kind: "TRACE_VIEW", label: "Trace source link unavailable", targetMode: "EXTERNAL" }];
  }
  return [];
}

function endpointFor(
  operation: OperationSnapshot,
  endpoints: readonly TrustedEndpoint[],
  profileEndpointIds: readonly string[],
): TrustedEndpoint | undefined {
  const active = new Set(profileEndpointIds);
  const candidates = endpoints.filter((endpoint) =>
    active.has(endpoint.endpointId) &&
    endpoint.endpointId === operation.definition.sourceAlias &&
    endpoint.adapterId === operation.definition.adapterPackageId
  );
  return candidates.length === 1 ? candidates[0] : undefined;
}

function resolvedExternalTarget(
  workspaceId: MonitoringWorkspaceId,
  reference: WorkbenchLinkRef,
  label: string,
  endpoint: TrustedEndpoint | undefined,
  path: string | undefined,
): WorkbenchResolvedLinkTarget | undefined {
  if (endpoint === undefined || path === undefined) return undefined;
  let base: URL;
  let target: URL;
  try {
    base = new URL(endpoint.baseUrl);
    target = new URL(path, base);
  } catch {
    return undefined;
  }
  if (target.origin !== base.origin) return undefined;
  const allowed = target.protocol === "https:" || (
    target.protocol === "http:" && new Set(["127.0.0.1", "localhost", "[::1]"]).has(target.hostname)
  );
  if (!allowed || target.username !== "" || target.password !== "") return undefined;
  return {
    schemaVersion: "1.0.0",
    workspaceId,
    linkRef: reference,
    mode: "OPEN_EXTERNAL",
    label,
    url: target.toString(),
  };
}

function evidenceProjection(
  input: WorkbenchProjectionAuthority,
): {
  details: Map<WorkbenchEvidenceRef, WorkbenchEvidenceDetail>;
  links: Map<WorkbenchLinkRef, WorkbenchLinkProjection>;
  refsById: Map<EvidenceId, WorkbenchEvidenceRef>;
  statesById: Map<EvidenceId, EvidenceState>;
} {
  const details = new Map<WorkbenchEvidenceRef, WorkbenchEvidenceDetail>();
  const links = new Map<WorkbenchLinkRef, WorkbenchLinkProjection>();
  const refsById = new Map<EvidenceId, WorkbenchEvidenceRef>();
  const statesById = new Map<EvidenceId, EvidenceState>();
  const operations = new Map(input.operations.map((operation) => [operation.operationId, operation]));
  const contradictory = new Set(
    input.contradictions
      .filter((item) => item.resolutionState === "UNRESOLVED")
      .flatMap((item) => item.claimRefs.map((claim) => claim.evidenceId)),
  );
  for (const envelope of [...input.evidence]
    .sort((left, right) => left.operationId.localeCompare(right.operationId) || left.evidenceId.localeCompare(right.evidenceId))
    .slice(0, MAX_EVIDENCE_CARDS)) {
    const operation = operations.get(envelope.operationId);
    if (operation === undefined) continue;
    const ref = evidenceRef(input.workspaceId, envelope.evidenceId);
    const state = evidenceState(envelope, contradictory);
    const linkRefs: WorkbenchLinkRef[] = [];
    for (const candidate of linkCandidates(envelope)) {
      const candidateRef = linkRef(input.workspaceId, envelope.evidenceId, candidate);
      const target = candidate.targetMode === "CODE"
        ? undefined
        : resolvedExternalTarget(
            input.workspaceId,
            candidateRef,
            candidate.label,
            endpointFor(operation, input.endpoints, input.profileEndpointIds),
            candidate.path,
          );
      const link: WorkbenchEvidenceLink = {
        schemaVersion: "1.0.0",
        workspaceId: input.workspaceId,
        linkRef: candidateRef,
        evidenceRef: ref,
        kind: candidate.kind,
        label: candidate.label,
        availability: target === undefined ? "UNAVAILABLE" : "AVAILABLE",
        ...(target === undefined
          ? { unavailableReason: "No unique reviewed navigation target is available for this evidence." }
          : {}),
      };
      links.set(candidateRef, { link, ...(target === undefined ? {} : { target }) });
      linkRefs.push(candidateRef);
    }
    const summary = detailSummary(envelope, state);
    details.set(ref, {
      schemaVersion: "1.0.0",
      workspaceId: input.workspaceId,
      evidenceRef: ref,
      title: requiredWorkbenchText(envelope.operationId, 160, "Reviewed evidence"),
      domain: operation.definition.domain,
      origin: envelope.origin,
      authority: envelope.authority,
      state,
      source: {
        provider: /^[a-z][a-z0-9._-]{0,63}$/u.test(envelope.source.provider)
          ? envelope.source.provider
          : "unavailable",
        sourceAlias: /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u.test(envelope.source.sourceAlias)
          ? envelope.source.sourceAlias
          : "unavailable",
      },
      evaluatedAt: envelope.evaluatedAt,
      collectedAt: envelope.collectedAt,
      window: structuredClone(envelope.window),
      summary,
      values: detailValues(envelope),
      limitations: uniqueBounded([
        ...envelope.limitations,
        ...envelope.providerWarnings,
        ...(envelope.pagination.complete ? [] : ["The provider result was truncated by a reviewed collection limit."]),
      ], 12, 512),
      linkRefs,
    });
    refsById.set(envelope.evidenceId, ref);
    statesById.set(envelope.evidenceId, state);
  }
  return { details, links, refsById, statesById };
}

function signalCards(
  input: WorkbenchProjectionAuthority,
  refsById: ReadonlyMap<EvidenceId, WorkbenchEvidenceRef>,
  statesById: ReadonlyMap<EvidenceId, EvidenceState>,
): MonitoringWorkspaceSnapshot["signals"] {
  const signals: MonitoringWorkspaceSnapshot["signals"] = [];
  for (const envelope of input.evidence) {
    const ref = refsById.get(envelope.evidenceId);
    if (ref === undefined) continue;
    for (const value of envelope.values) {
      if (signals.length >= 3) return signals;
      if (value.kind !== "SCALAR" && value.kind !== "TIMESERIES") continue;
      const numeric = value.kind === "SCALAR"
        ? typeof value.value === "number" ? value.value : null
        : value.points.at(-1)?.value ?? null;
      const points = value.kind === "SCALAR"
        ? [numeric]
        : value.points.slice(-30).map((point) => point.value);
      const first = points.find((point): point is number => point !== null);
      const last = [...points].reverse().find((point): point is number => point !== null);
      const direction = first === undefined || last === undefined
        ? "UNKNOWN" as const
        : last > first ? "UP" as const : last < first ? "DOWN" as const : "FLAT" as const;
      const state = statesById.get(envelope.evidenceId) ?? "ERROR";
      const title = safeWorkbenchText(value.name, 96);
      if (title === undefined) continue;
      const unit = value.unit === undefined ? undefined : safeWorkbenchText(value.unit, 32);
      signals.push({
        signalRef: `signal.${workspaceDigest({ envelope: envelope.evidenceId, value: value.name }).slice(0, 24)}`,
        title,
        displayValue: displayMetric(numeric, value.unit),
        ...(unit === undefined ? {} : { unit }),
        severity: state === "ERROR" || state === "CONTRADICTORY"
          ? "CRITICAL"
          : state === "STALE" ? "WARNING" : "NEUTRAL",
        direction,
        points,
        evidenceRefs: [ref],
      });
    }
  }
  return signals;
}

function hypothesisCards(
  input: WorkbenchProjectionAuthority,
  refsById: ReadonlyMap<EvidenceId, WorkbenchEvidenceRef>,
): MonitoringWorkspaceSnapshot["hypotheses"] {
  return [...(input.investigation?.hypotheses ?? [])]
    .sort((left, right) => left.rank - right.rank || left.hypothesisId.localeCompare(right.hypothesisId))
    .slice(0, 3)
    .map((hypothesis, index) => ({
      hypothesisRef: hypothesisRefFor(hypothesis.hypothesisId),
      rank: index + 1,
      statement: requiredWorkbenchText(
        hypothesis.statement,
        512,
        "A sensitive technical hypothesis was omitted from the workbench projection.",
      ),
      status: hypothesis.status,
      rationale: requiredWorkbenchText(
        hypothesis.rationale,
        512,
        "Review the sealed incident artifact for the omitted technical rationale.",
      ),
      evidenceRefs: [...new Set([
        ...hypothesis.supportingEvidenceIds,
        ...hypothesis.contradictingEvidenceIds,
      ].map((id) => refsById.get(id)).filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined))].slice(0, 8),
    }));
}

function supportedHypotheses(
  investigation: Readonly<Investigation> | undefined,
): Investigation["hypotheses"] {
  return [...(investigation?.hypotheses ?? [])]
    .filter((hypothesis) => hypothesis.status === "SUPPORTED")
    .sort((left, right) => left.rank - right.rank || left.hypothesisId.localeCompare(right.hypothesisId));
}

function isLocalPatchEvidence(input: WorkbenchProjectionAuthority, envelope: EvidenceEnvelope): boolean {
  const provider = envelope.source.provider.toLowerCase();
  if (provider === "git" && envelope.source.sanitizedReference?.startsWith("git:") === true) return true;
  // The deterministic fixture represents repository evidence only in explicitly simulated runs.
  return envelope.origin === "SIMULATED" && provider === "fixture" && input.run?.origin === "SIMULATED";
}

function independentEvidenceIds(
  evidence: readonly EvidenceEnvelope[],
  ids: readonly EvidenceId[],
): EvidenceId[] {
  const requested = new Set(ids);
  const identities = new Set<string>();
  const independent: EvidenceId[] = [];
  for (const envelope of evidence
    .filter((candidate) => requested.has(candidate.evidenceId))
    .sort((left, right) => left.evidenceId.localeCompare(right.evidenceId))) {
    const identity = evidenceSourceIndependenceKey(envelope);
    if (identities.has(identity)) continue;
    identities.add(identity);
    independent.push(envelope.evidenceId);
  }
  return independent;
}

function patchStatus(
  input: WorkbenchProjectionAuthority,
  refsById: ReadonlyMap<EvidenceId, WorkbenchEvidenceRef>,
  statesById: ReadonlyMap<EvidenceId, EvidenceState>,
): MonitoringWorkspaceSnapshot["patch"] {
  const supportedList = supportedHypotheses(input.investigation);
  const supported = supportedList[0];
  const unresolved = input.contradictions.some((item) => item.resolutionState === "UNRESOLVED");
  const gaps =
    (input.investigation?.missingEvidence.length ?? 0) > 0 ||
    capabilityEvidenceGaps(input, statesById).length > 0;
  const evidenceById = new Map(input.evidence.map((item) => [item.evidenceId, item]));
  const hasLocalSource = supported?.supportingEvidenceIds.some((id) => {
    const envelope = evidenceById.get(id);
    return envelope !== undefined && isLocalPatchEvidence(input, envelope);
  }) ?? false;
  const eligible =
    input.run?.state === "SEALED" &&
    input.capabilityProfile === "prepare_patch" &&
    input.investigation?.status === "COMPLETE" &&
    input.investigation.verificationContract !== undefined &&
    input.coverage?.overall === "COMPLETE" &&
    supportedList.length === 1 &&
    hasLocalSource &&
    !unresolved &&
    !gaps &&
    input.authorityFailure === undefined;
  const evidenceRefs = supported === undefined
    ? []
    : independentEvidenceIds(input.evidence, supported.supportingEvidenceIds)
        .map((id) => refsById.get(id))
        .filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined)
        .slice(0, 16);
  const reason = eligible
    ? "A complete sealed investigation has one supported, uncontested hypothesis with eligible local-source evidence."
    : input.capabilityProfile !== "prepare_patch"
      ? "The active administrator-owned profile does not authorize patch preparation."
      : input.run?.state !== "SEALED"
        ? "Patch handoff requires a sealed investigation."
        : input.investigation?.verificationContract === undefined
          ? "Patch handoff requires a begin-time verification contract."
        : supportedList.length !== 1
          ? "Patch handoff requires exactly one supported hypothesis."
          : !hasLocalSource
            ? "Patch handoff requires eligible local-source evidence; provider telemetry alone is read-only."
          : unresolved
            ? "Unresolved contradictions block patch handoff."
            : gaps
              ? "Named evidence gaps block patch handoff."
              : "The sealed investigation is not complete enough for patch handoff.";
  return {
    schemaVersion: "1.0.0",
    state: eligible ? "ELIGIBLE" : "NOT_ELIGIBLE",
    eligible,
    updatedAt: input.asOf,
    title: eligible ? "Generate a bounded local patch" : "Patch handoff unavailable",
    reason,
    evidenceRefs: [...new Set(evidenceRefs)],
    limitations: ["Patch generation is performed by Codex under the host sandbox; this monitoring runtime remains read-only."],
  };
}

function sameWindow(left: EvidenceEnvelope["window"], right: EvidenceEnvelope["window"]): boolean {
  return left.start === right.start && left.end === right.end;
}

function latestOperationEvidence(
  input: WorkbenchProjectionAuthority,
  operationId: string,
  window: EvidenceEnvelope["window"] | undefined,
): EvidenceEnvelope | undefined {
  return input.evidence
    .filter((envelope) =>
      envelope.operationId === operationId && (window === undefined || sameWindow(envelope.window, window)))
    .sort((left, right) =>
      right.collectedAt.localeCompare(left.collectedAt) || right.evidenceId.localeCompare(left.evidenceId))[0];
}

interface NamedNumericResult {
  value?: number;
  unit?: string;
  error?: "MISSING_OR_AMBIGUOUS_VALUE" | "INCOMPATIBLE_UNIT";
}

function numericResult(
  envelope: EvidenceEnvelope | undefined,
  resultName: string,
  reducer: "SINGLE" | "MAX" | "MIN" = "SINGLE",
  expectedUnit?: string,
): NamedNumericResult {
  if (envelope === undefined) return { error: "MISSING_OR_AMBIGUOUS_VALUE" };
  const candidates: Array<{ value: number; unit?: string }> = [];
  for (const value of envelope.values) {
    if (value.kind === "SCALAR" && value.name === resultName && typeof value.value === "number") {
      candidates.push({ value: value.value, ...(value.unit === undefined ? {} : { unit: value.unit }) });
    }
    if (value.kind === "TIMESERIES" && value.name === resultName) {
      const latest = [...value.points].reverse().find((point) => point.value !== null)?.value;
      if (latest !== undefined && latest !== null) {
        candidates.push({ value: latest, ...(value.unit === undefined ? {} : { unit: value.unit }) });
      }
    }
    if (value.kind === "TABLE") {
      const index = value.columns.findIndex((column) => column.name === resultName);
      if (index >= 0) {
        for (const row of value.rows) {
          const cell = row[index];
          if (typeof cell === "number") candidates.push({ value: cell });
        }
      }
    }
  }
  if (candidates.length === 0 || (reducer === "SINGLE" && candidates.length !== 1)) {
    return { error: "MISSING_OR_AMBIGUOUS_VALUE" };
  }
  const units = new Set(candidates.map((candidate) => candidate.unit ?? ""));
  if (units.size !== 1 || candidates.some((candidate) => candidate.unit !== expectedUnit)) {
    return { error: "INCOMPATIBLE_UNIT" };
  }
  const values = candidates.map((candidate) => candidate.value);
  const selected = reducer === "MAX"
    ? Math.max(...values)
    : reducer === "MIN"
      ? Math.min(...values)
      : values[0]!;
  return { value: selected, ...(expectedUnit === undefined ? {} : { unit: expectedUnit }) };
}

function selectedCapabilityPacks(input: WorkbenchProjectionAuthority): readonly ProviderCapabilityPackV1[] {
  const requestedPackIds = input.request?.requiredCapabilityPacks;
  return input.capabilityPacks.filter((pack) =>
    requestedPackIds === undefined || requestedPackIds.includes(pack.packId));
}

function declaredRuleUnit(
  pack: Readonly<ProviderCapabilityPackV1>,
  operationId: string,
  resultName: string,
): string | undefined {
  return pack.signals.find((signal) =>
    signal.operationId === operationId && signal.resultName === resultName)?.unit;
}

function comparableBaselineWindows(input: WorkbenchProjectionAuthority): boolean {
  const baseline = input.request?.baselineWindow;
  if (baseline === undefined) return true;
  const currentStart = Date.parse(input.run?.window.start ?? input.request!.window.start);
  const currentEnd = Date.parse(input.run?.window.end ?? input.request!.window.end);
  const baselineStart = Date.parse(baseline.start);
  const baselineEnd = Date.parse(baseline.end);
  return [currentStart, currentEnd, baselineStart, baselineEnd].every(Number.isFinite) &&
    baselineEnd <= currentStart &&
    baselineEnd - baselineStart === currentEnd - currentStart;
}

interface CapabilityEvidenceGap {
  key: string;
  title: string;
  summary: string;
  evidence: EvidenceEnvelope[];
}

function capabilityEvidenceGaps(
  input: WorkbenchProjectionAuthority,
  statesById: ReadonlyMap<EvidenceId, EvidenceState>,
): CapabilityEvidenceGap[] {
  if (input.run === undefined) return [];
  const gaps = new Map<string, CapabilityEvidenceGap>();
  const add = (gap: CapabilityEvidenceGap): void => {
    if (!gaps.has(gap.key)) gaps.set(gap.key, gap);
  };
  const packs = selectedCapabilityPacks(input);
  const windows: Array<{ kind: "current" | "baseline"; window: EvidenceEnvelope["window"] }> = [
    { kind: "current", window: input.run.window },
    ...(input.request?.baselineWindow === undefined
      ? []
      : [{ kind: "baseline" as const, window: input.request.baselineWindow }]),
  ];
  for (const pack of packs) {
    for (const operationId of pack.requiredOperationIds) {
      for (const selected of windows) {
        const envelope = latestOperationEvidence(input, operationId, selected.window);
        const state = envelope === undefined ? undefined : statesById.get(envelope.evidenceId);
        if (state === "COMPLETE") continue;
        add({
          key: `${pack.packId}:required:${selected.kind}:${operationId}`,
          title: `Required ${selected.kind} evidence is incomplete`,
          summary: envelope === undefined
            ? `${operationId} did not produce evidence for the sealed ${selected.kind} window.`
            : `${operationId} produced ${state ?? "ERROR"} evidence for the sealed ${selected.kind} window.`,
          evidence: envelope === undefined ? [] : [envelope],
        });
      }
    }
    for (const rule of pack.issueRules) {
      if (rule.comparison !== "THRESHOLD" && rule.comparison !== "BASELINE_DELTA") continue;
      if (rule.resultName === undefined) continue;
      const current = latestOperationEvidence(input, rule.operationId, input.run.window);
      const currentState = current === undefined ? undefined : statesById.get(current.evidenceId);
      if (currentState === "COMPLETE" && current !== undefined) {
        if (!current.pagination.complete) {
          add({
            key: `${pack.packId}:rule:${rule.ruleId}:current-truncated`,
            title: "Signed rule input was truncated",
            summary: `${rule.operationId} reached a reviewed collection limit, so ${rule.ruleId} was not evaluated.`,
            evidence: [current],
          });
        } else {
          const selected = numericResult(
            current,
            rule.resultName,
            rule.reducer,
            declaredRuleUnit(pack, rule.operationId, rule.resultName),
          );
          if (selected.error !== undefined) {
            add({
              key: `${pack.packId}:rule:${rule.ruleId}:current-${selected.error}`,
              title: "Signed rule input is not comparable",
              summary: `${rule.resultName} was missing, ambiguous, or used an incompatible unit, so ${rule.ruleId} was not evaluated.`,
              evidence: [current],
            });
          }
        }
      }
      if (rule.comparison !== "BASELINE_DELTA" || input.request?.baselineWindow === undefined) continue;
      if (!comparableBaselineWindows(input)) {
        add({
          key: `${pack.packId}:rule:${rule.ruleId}:incomparable-windows`,
          title: "Baseline window is not comparable",
          summary: "Signed baseline rules require an earlier, non-overlapping window with the same duration as the current window.",
          evidence: current === undefined ? [] : [current],
        });
        continue;
      }
      const comparisonOperationId = rule.comparisonOperationId ?? rule.operationId;
      const baseline = latestOperationEvidence(input, comparisonOperationId, input.request.baselineWindow);
      const baselineState = baseline === undefined ? undefined : statesById.get(baseline.evidenceId);
      if (baseline === undefined || baselineState !== "COMPLETE") {
        if (!pack.requiredOperationIds.includes(comparisonOperationId)) {
          add({
            key: `${pack.packId}:rule:${rule.ruleId}:baseline-state`,
            title: "Required baseline evidence is incomplete",
            summary: baseline === undefined
              ? `${comparisonOperationId} did not produce evidence for the sealed baseline window.`
              : `${comparisonOperationId} produced ${baselineState ?? "ERROR"} evidence for the sealed baseline window.`,
            evidence: baseline === undefined ? [] : [baseline],
          });
        }
        continue;
      }
      if (!baseline.pagination.complete) {
        add({
          key: `${pack.packId}:rule:${rule.ruleId}:baseline-truncated`,
          title: "Signed baseline input was truncated",
          summary: `${comparisonOperationId} reached a reviewed collection limit, so ${rule.ruleId} was not evaluated.`,
          evidence: [baseline],
        });
        continue;
      }
      const baselineValue = numericResult(
        baseline,
        rule.resultName,
        rule.reducer,
        declaredRuleUnit(pack, comparisonOperationId, rule.resultName),
      );
      if (baselineValue.error !== undefined) {
        add({
          key: `${pack.packId}:rule:${rule.ruleId}:baseline-${baselineValue.error}`,
          title: "Signed baseline input is not comparable",
          summary: `${rule.resultName} was missing, ambiguous, or used an incompatible unit in the baseline, so ${rule.ruleId} was not evaluated.`,
          evidence: [baseline],
        });
      }
    }
  }
  return [...gaps.values()].sort((left, right) => left.key.localeCompare(right.key));
}

function comparisonSatisfied(
  actual: number,
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ",
  expected: number,
): boolean {
  switch (comparator) {
    case "LT": return actual < expected;
    case "LTE": return actual <= expected;
    case "GT": return actual > expected;
    case "GTE": return actual >= expected;
    case "EQ": return actual === expected;
  }
}

function issuePatchStatus(
  input: WorkbenchProjectionAuthority,
  aggregate: MonitoringWorkspaceSnapshot["patch"],
  hypothesisRefs: readonly string[],
  kind: WorkbenchIssueCard["kind"],
  issueEvidenceRefs: readonly WorkbenchEvidenceRef[],
): WorkbenchIssueCard["patch"] {
  const supported = supportedHypotheses(input.investigation);
  const supportedRef = supported.length === 1 ? hypothesisRefFor(supported[0]!.hypothesisId) : undefined;
  const refsById = new Map(input.evidence.map((envelope) => [
    envelope.evidenceId,
    evidenceRef(input.workspaceId, envelope.evidenceId),
  ]));
  const eligibleLocalRefs = new Set(
    (supported[0]?.supportingEvidenceIds ?? [])
      .filter((id) => {
        const envelope = input.evidence.find((candidate) => candidate.evidenceId === id);
        return envelope !== undefined && isLocalPatchEvidence(input, envelope);
      })
      .map((id) => refsById.get(id))
      .filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined),
  );
  const issueLocalRefs = issueEvidenceRefs.filter((ref) => eligibleLocalRefs.has(ref));
  const eligible =
    aggregate.eligible &&
    supportedRef !== undefined &&
    hypothesisRefs.length === 1 &&
    hypothesisRefs[0] === supportedRef &&
    issueLocalRefs.length > 0 &&
    kind !== "CONTRADICTION" &&
    kind !== "EVIDENCE_GAP";
  return {
    schemaVersion: "1.0.0",
    state: eligible ? "ELIGIBLE" : "NOT_ELIGIBLE",
    eligible,
    updatedAt: input.asOf,
    title: eligible ? "Prepare a bounded local patch" : "Read-only issue",
    reason: eligible
      ? "This exact issue is linked to the one supported hypothesis and eligible local-source evidence."
      : "Grafana and provider evidence remain read-only unless this issue is linked to one supported local-source hypothesis.",
    evidenceRefs: eligible ? [...new Set(issueLocalRefs)] : [],
    limitations: ["This status never authorizes provider, Grafana, runtime, deployment, or production mutation."],
  };
}

function issueCards(
  input: WorkbenchProjectionAuthority,
  refsById: ReadonlyMap<EvidenceId, WorkbenchEvidenceRef>,
  statesById: ReadonlyMap<EvidenceId, EvidenceState>,
  aggregatePatch: MonitoringWorkspaceSnapshot["patch"],
): WorkbenchIssueCard[] {
  if (input.run === undefined) return [];
  const issues: Array<Omit<WorkbenchIssueCard, "patch">> = [];
  const packs = selectedCapabilityPacks(input);
  const hypotheses = input.investigation?.hypotheses ?? [];
  const hypothesisRefsFor = (ids: readonly EvidenceId[]): string[] => {
    const cited = new Set(ids);
    return hypotheses
      .filter((hypothesis) =>
        [...hypothesis.supportingEvidenceIds, ...hypothesis.contradictingEvidenceIds]
          .some((id) => cited.has(id)))
      .sort((left, right) => left.rank - right.rank || left.hypothesisId.localeCompare(right.hypothesisId))
      .map((hypothesis) => hypothesisRefFor(hypothesis.hypothesisId))
      .slice(0, 8);
  };
  const refsFor = (envelopes: readonly EvidenceEnvelope[]): WorkbenchEvidenceRef[] =>
    independentEvidenceIds(input.evidence, envelopes.map((envelope) => envelope.evidenceId))
      .map((id) => refsById.get(id))
      .filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined)
      .slice(0, 8);

  for (const gap of capabilityEvidenceGaps(input, statesById)) {
    const evidenceIds = gap.evidence.map((envelope) => envelope.evidenceId);
    issues.push({
      issueRef: issueRefFor(input.workspaceId, { kind: "capability-gap", key: gap.key, evidenceIds }),
      kind: "EVIDENCE_GAP",
      severity: "WARNING",
      status: "BLOCKED",
      classification: "DEVIATION",
      title: gap.title,
      summary: bounded(gap.summary, 512),
      evidenceRefs: refsFor(gap.evidence),
      hypothesisRefs: hypothesisRefsFor(evidenceIds),
    });
  }

  for (const pack of packs) {
    for (const rule of pack.issueRules) {
      const current = latestOperationEvidence(input, rule.operationId, input.run.window);
      const baseline = rule.comparison === "BASELINE_DELTA" && input.request?.baselineWindow !== undefined
        ? latestOperationEvidence(
            input,
            rule.comparisonOperationId ?? rule.operationId,
            input.request.baselineWindow,
          )
        : undefined;
      const currentState = current === undefined ? undefined : statesById.get(current.evidenceId);
      const baselineState = baseline === undefined ? undefined : statesById.get(baseline.evidenceId);
      let triggered = false;
      let summary = "The reviewed rule matched the sealed evidence.";
      if (rule.comparison === "THRESHOLD" && rule.resultName !== undefined && rule.comparator !== undefined && rule.threshold !== undefined) {
        const selected = numericResult(
          current,
          rule.resultName,
          rule.reducer,
          declaredRuleUnit(pack, rule.operationId, rule.resultName),
        );
        triggered = selected.value !== undefined && currentState === "COMPLETE" && current?.pagination.complete === true &&
          comparisonSatisfied(selected.value, rule.comparator, rule.threshold);
        if (selected.value !== undefined) {
          const prefix = rule.reducer === "MAX" ? "maximum " : rule.reducer === "MIN" ? "minimum " : "";
          summary = `${prefix}${rule.resultName} was ${primitiveText(selected.value)}; the signed ${rule.comparator} ${primitiveText(rule.threshold)} rule matched.`;
        }
      } else if (rule.comparison === "BASELINE_DELTA" && rule.resultName !== undefined && rule.comparator !== undefined && rule.delta !== undefined) {
        const actual = numericResult(
          current,
          rule.resultName,
          rule.reducer,
          declaredRuleUnit(pack, rule.operationId, rule.resultName),
        );
        const comparisonOperationId = rule.comparisonOperationId ?? rule.operationId;
        const baselineValue = numericResult(
          baseline,
          rule.resultName,
          rule.reducer,
          declaredRuleUnit(pack, comparisonOperationId, rule.resultName),
        );
        const delta = actual.value === undefined || baselineValue.value === undefined
          ? undefined
          : actual.value - baselineValue.value;
        triggered = delta !== undefined && currentState === "COMPLETE" && baselineState === "COMPLETE" &&
          current?.pagination.complete === true && baseline?.pagination.complete === true &&
          input.request?.baselineWindow !== undefined && comparableBaselineWindows(input) &&
          comparisonSatisfied(delta, rule.comparator, rule.delta);
        if (delta !== undefined) summary = `${rule.resultName} changed by ${primitiveText(delta)} from the sealed baseline; the signed rule matched.`;
      } else if (rule.comparison === "STALE") {
        const evaluatedAt = current === undefined ? Number.NaN : Date.parse(current.evaluatedAt);
        const asOf = Date.parse(input.asOf);
        const ageMs = asOf - evaluatedAt;
        triggered = rule.maxAgeMs !== undefined && Number.isFinite(ageMs) && ageMs >= 0 &&
          ageMs > rule.maxAgeMs && current?.collectionState === "COMPLETE" &&
          current.pagination.complete === true &&
          (currentState === "COMPLETE" || currentState === "STALE");
        summary = `The reviewed signal age exceeded its signed ${primitiveText(rule.maxAgeMs ?? 0)} ms freshness boundary.`;
      } else if (rule.comparison === "EMPTY") {
        triggered = currentState === "EMPTY";
        summary = "The reviewed operation completed with an explicit empty result.";
      } else if (rule.comparison === "ERROR") {
        triggered = currentState === "ERROR";
        summary = "The reviewed operation returned an explicit error result.";
      } else if (rule.comparison === "CONTRADICTION") {
        triggered = currentState === "CONTRADICTORY";
        summary = "The reviewed signal participates in an unresolved contradiction.";
      }
      if (!triggered || current === undefined) continue;
      const cited = baseline === undefined ? [current] : [current, baseline];
      const evidenceIds = cited.map((envelope) => envelope.evidenceId);
      const hypothesisRefs = hypothesisRefsFor(evidenceIds);
      issues.push({
        issueRef: issueRefFor(input.workspaceId, { packId: pack.packId, revision: pack.revision, ruleId: rule.ruleId, evidenceIds }),
        kind: rule.issueKind,
        severity: rule.severity,
        status: hypothesisRefs.some((reference) =>
          supportedHypotheses(input.investigation).some((hypothesis) =>
            hypothesisRefFor(hypothesis.hypothesisId) === reference)) ? "SUPPORTED" : "OPEN",
        classification: rule.signedThreshold ? "SIGNED_RULE" : "DEVIATION",
        title: rule.signedThreshold ? "Reviewed capability rule matched" : "Reviewed evidence deviation",
        summary: bounded(summary, 512),
        evidenceRefs: refsFor(cited),
        hypothesisRefs,
      });
    }
  }

  for (const contradiction of input.contradictions.filter((item) => item.resolutionState === "UNRESOLVED")) {
    const evidenceIds = contradiction.claimRefs.map((claim) => claim.evidenceId);
    issues.push({
      issueRef: issueRefFor(input.workspaceId, { contradictionId: contradiction.contradictionId }),
      kind: "CONTRADICTION",
      severity: "CRITICAL",
      status: "BLOCKED",
      classification: "SIGNED_RULE",
      title: "Unresolved evidence contradiction",
      summary: requiredWorkbenchText(contradiction.summary, 512, "Reviewed evidence contradicts another source."),
      evidenceRefs: evidenceIds.map((id) => refsById.get(id)).filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined).slice(0, 8),
      hypothesisRefs: hypothesisRefsFor(evidenceIds),
    });
  }

  for (const [index, gap] of (input.investigation?.missingEvidence ?? []).slice(0, 8).entries()) {
    issues.push({
      issueRef: issueRefFor(input.workspaceId, { kind: "investigation-gap", index, gap }),
      kind: "EVIDENCE_GAP",
      severity: "WARNING",
      status: "BLOCKED",
      classification: "DEVIATION",
      title: "Named evidence gap",
      summary: requiredWorkbenchText(gap, 512, "The sealed investigation names an unresolved evidence gap."),
      evidenceRefs: [],
      hypothesisRefs: [],
    });
  }

  for (const hypothesis of supportedHypotheses(input.investigation)) {
    const reference = hypothesisRefFor(hypothesis.hypothesisId);
    const ids = independentEvidenceIds(input.evidence, hypothesis.supportingEvidenceIds);
    const localIds = ids.filter((id) => {
      const envelope = input.evidence.find((candidate) => candidate.evidenceId === id);
      return envelope !== undefined && isLocalPatchEvidence(input, envelope);
    });
    const localRefs = new Set(localIds
      .map((id) => refsById.get(id))
      .filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined));
    const hasLocalIssue = issues.some((issue) =>
      issue.hypothesisRefs.includes(reference) && issue.evidenceRefs.some((ref) => localRefs.has(ref)));
    if (localIds.length > 0 && !hasLocalIssue) {
      issues.push({
        issueRef: issueRefFor(input.workspaceId, { kind: "supported-local-hypothesis", hypothesisId: hypothesis.hypothesisId }),
        kind: "REGRESSION",
        severity: "WARNING",
        status: "SUPPORTED",
        classification: "DEVIATION",
        title: "Local source evidence-linked regression",
        summary: requiredWorkbenchText(hypothesis.statement, 512, "A supported local-source deviation was found."),
        evidenceRefs: localIds.map((id) => refsById.get(id)).filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined).slice(0, 8),
        hypothesisRefs: [reference],
      });
      continue;
    }
    if (issues.some((issue) => issue.hypothesisRefs.includes(reference))) continue;
    issues.push({
      issueRef: issueRefFor(input.workspaceId, { kind: "supported-hypothesis", hypothesisId: hypothesis.hypothesisId }),
      kind: "REGRESSION",
      severity: "WARNING",
      status: "SUPPORTED",
      classification: "DEVIATION",
      title: "Evidence-linked regression",
      summary: requiredWorkbenchText(hypothesis.statement, 512, "A supported evidence-linked deviation was found."),
      evidenceRefs: ids.map((id) => refsById.get(id)).filter((ref): ref is WorkbenchEvidenceRef => ref !== undefined).slice(0, 8),
      hypothesisRefs: [reference],
    });
  }

  const severityRank: Record<WorkbenchIssueCard["severity"], number> = { CRITICAL: 0, WARNING: 1, INFO: 2 };
  return issues
    .map((issue) => ({
      ...issue,
      patch: issuePatchStatus(input, aggregatePatch, issue.hypothesisRefs, issue.kind, issue.evidenceRefs),
    }))
    .sort((left, right) =>
      Number(right.patch.eligible) - Number(left.patch.eligible) ||
      severityRank[left.severity] - severityRank[right.severity] ||
      left.issueRef.localeCompare(right.issueRef))
    .slice(0, 24);
}

function lifecycle(input: WorkbenchProjectionAuthority): MonitoringWorkspaceSnapshot["lifecycle"] {
  if (input.run === undefined) return "IDLE";
  if (input.authorityFailure !== undefined) return "BLOCKED";
  if (input.run.state === "ABORTED") return "CANCELLED";
  if (input.run.state === "EXPIRED") return "BLOCKED";
  if (input.run.state === "OPEN" || input.run.state === "FINALIZING") return "RUNNING";
  if (input.investigation?.status === "COMPLETE") return "SEALED";
  if (input.investigation?.status === "PARTIAL") return "PARTIAL";
  return "BLOCKED";
}

function phase(input: WorkbenchProjectionAuthority): MonitoringWorkspaceSnapshot["phase"] {
  if (input.run === undefined) return "READINESS";
  if (input.run.workflow === "verify") return "VERIFYING";
  if (input.run.state === "FINALIZING" || input.run.state === "SEALED") return "FINALIZING";
  if (input.evidence.length === 0) return "SCOPING";
  if (
    input.run.baselineWindow !== undefined &&
    input.evidence.some((item) => sha256Canonical(item.window) === sha256Canonical(input.run!.baselineWindow))
  ) return "COMPARING";
  return "COLLECTING";
}

function recoveryStatus(investigation: Readonly<Investigation> | undefined): MonitoringWorkspaceSnapshot["status"]["recovery"] {
  const value = investigation?.recoveryState;
  return value === undefined || value === "NONE" ? "NOT_ASSESSED" : value;
}

function auditStatus(input: WorkbenchProjectionAuthority): MonitoringWorkspaceSnapshot["status"]["audit"] {
  if (input.run === undefined) return "INITIALIZING";
  if (input.run.audit.state === "HEALTHY") return "HEALTHY";
  if (input.run.audit.state === "FAILED") return "ERROR";
  return "DEGRADED";
}

function collectionStatus(
  input: WorkbenchProjectionAuthority,
  states: readonly EvidenceState[],
): MonitoringWorkspaceSnapshot["status"]["collection"] {
  if (input.authorityFailure !== undefined) return "ERROR";
  if (input.run === undefined || (input.evidence.length === 0 && input.run.state === "OPEN")) return "NOT_STARTED";
  if (input.run.state === "OPEN" || input.run.state === "FINALIZING") {
    if (states.includes("ERROR")) return "ERROR";
    const required = input.request?.requiredOperations?.length ?? input.operations.length;
    return new Set(input.evidence.map((item) => item.operationId)).size >= required
      ? states.some((state) => state === "STALE" || state === "CONTRADICTORY") ? "PARTIAL" : "COMPLETE"
      : "IN_PROGRESS";
  }
  if (input.coverage?.overall === "COMPLETE") return "COMPLETE";
  if (input.coverage?.overall === "PARTIAL") return "PARTIAL";
  return states.includes("ERROR") ? "ERROR" : input.evidence.length > 0 ? "PARTIAL" : "NOT_STARTED";
}

function causalityStatus(input: WorkbenchProjectionAuthority): MonitoringWorkspaceSnapshot["status"]["causality"] {
  const hypotheses = input.investigation?.hypotheses ?? [];
  if (hypotheses.length === 0) return "NOT_ASSESSED";
  if (hypotheses.some((item) => item.status === "SUPPORTED")) return "SUPPORTED";
  if (hypotheses.some((item) => item.status === "OPEN")) return "OPEN";
  return "INCONCLUSIVE";
}

function activityItems(
  input: WorkbenchProjectionAuthority,
  details: ReadonlyMap<WorkbenchEvidenceRef, WorkbenchEvidenceDetail>,
  patch: MonitoringWorkspaceSnapshot["patch"],
): MonitoringWorkspaceSnapshot["activity"] {
  if (input.run === undefined) {
    return [{
      activityRef: "readiness.waiting",
      at: input.asOf,
      kind: "READINESS",
      state: "PENDING",
      title: "Ready for a bounded monitoring run",
    }];
  }
  const activity: MonitoringWorkspaceSnapshot["activity"] = [{
    activityRef: `scope.${workspaceDigest(input.run.runId).slice(0, 24)}`,
    at: input.run.createdAt,
    kind: "SCOPE",
    state: "COMPLETE",
    title: "Incident scope sealed",
    detail: requiredWorkbenchText(
      `${input.run.scope.service ?? "Service"} · ${input.run.scope.environment}`,
      512,
      "Reviewed incident scope",
    ),
  }];
  for (const detail of details.values()) {
    activity.push({
      activityRef: `evidence.${detail.evidenceRef.slice(-24)}`,
      at: detail.collectedAt,
      kind: "EVIDENCE",
      state: detail.state === "COMPLETE" || detail.state === "EMPTY" ? "COMPLETE" : detail.state === "ERROR" ? "ERROR" : "PARTIAL",
      title: bounded(detail.title, 128),
      detail: bounded(detail.summary, 512),
    });
  }
  if (input.investigation !== undefined) {
    activity.push({
      activityRef: `analysis.${workspaceDigest(input.run.runId).slice(0, 24)}`,
      at: input.run.finalizedAt ?? input.asOf,
      kind: "ANALYSIS",
      state: input.investigation.status === "COMPLETE" ? "COMPLETE" : input.investigation.status === "PARTIAL" ? "PARTIAL" : "ERROR",
      title: "Evidence-linked analysis sealed",
      detail: requiredWorkbenchText(
        input.investigation.smallestSafeNextStep,
        512,
        "Review the sealed incident artifact for the next bounded step.",
      ),
    });
  }
  if (patch.eligible) {
    activity.push({
      activityRef: `patch.${workspaceDigest(input.run.runId).slice(0, 24)}`,
      at: patch.updatedAt,
      kind: "PATCH",
      state: "PENDING",
      title: "Bounded patch handoff is available",
    });
  }
  if (input.run.workflow === "verify" && input.investigation !== undefined) {
    activity.push({
      activityRef: `recovery.${workspaceDigest(input.run.runId).slice(0, 24)}`,
      at: input.run.finalizedAt ?? input.asOf,
      kind: "RECOVERY",
      state: input.investigation.recoveryState === "RECOVERED" ? "COMPLETE" : "PARTIAL",
      title: input.investigation.recoveryState === "RECOVERED" ? "Recovery criteria passed" : "Recovery is not proven",
    });
  }
  if (input.authorityFailure !== undefined) {
    activity.push({
      activityRef: `system.${workspaceDigest(input.run.runId).slice(0, 24)}`,
      at: input.asOf,
      kind: "SYSTEM",
      state: "ERROR",
      title: "Authoritative workbench state is unavailable",
    });
  }
  return activity
    .sort((left, right) => left.at.localeCompare(right.at) || left.activityRef.localeCompare(right.activityRef))
    .slice(-MAX_ACTIVITY);
}

function authorityLimitations(input: WorkbenchProjectionAuthority): string[] {
  const failures: Record<NonNullable<WorkbenchProjectionAuthority["authorityFailure"]>, string> = {
    CHECKPOINT_UNAVAILABLE: "The active run has no recoverable runtime checkpoint; progress is partial.",
    CHECKPOINT_INVALID: "The active runtime checkpoint failed integrity validation.",
    ARTIFACT_UNAVAILABLE: "The sealed run has no immutable incident bundle.",
    ARTIFACT_INVALID: "The immutable incident bundle failed validation.",
  };
  return uniqueBounded([
    ...(input.authorityFailure === undefined ? [] : [failures[input.authorityFailure]]),
    ...(input.run?.state === "EXPIRED" ? ["The run expired before it reached a sealed terminal artifact."] : []),
    ...(input.run?.state === "ABORTED" ? ["The run was cancelled; retained evidence is shown without a causal conclusion."] : []),
    ...(input.inventoryOmittedCount > 0
      ? [`${input.inventoryOmittedCount} older owned run${input.inventoryOmittedCount === 1 ? " was" : "s were"} omitted by the bounded inventory.`]
      : []),
    ...(input.investigation?.missingEvidence ?? []),
    ...(input.investigation?.remainingUncertainty ?? []),
  ], 16, 512);
}

function nextAction(
  input: WorkbenchProjectionAuthority,
  collection: MonitoringWorkspaceSnapshot["status"]["collection"],
  patch: MonitoringWorkspaceSnapshot["patch"],
): MonitoringWorkspaceSnapshot["nextAction"] {
  if (patch.eligible) return { action: "GENERATE_PATCH", enabled: true, label: "Generate patch" };
  if (input.run === undefined) {
    return { action: "NONE", enabled: false, label: "Start an investigation in chat" };
  }
  if (input.run.state === "OPEN" && collection === "NOT_STARTED") {
    return { action: "COLLECT_EVIDENCE", enabled: true, label: "Collect bounded evidence" };
  }
  if (collection === "PARTIAL" || collection === "ERROR" || input.run.state === "EXPIRED") {
    return {
      action: "RETRY_COLLECTION",
      enabled: true,
      label: "Retry in a fresh run",
      reason: "Terminal or failed evidence is never rewritten in place.",
    };
  }
  if (
    input.run.workflow !== "verify" &&
    input.investigation?.verificationContract !== undefined &&
    input.run.state === "SEALED"
  ) {
    return { action: "VERIFY_RECOVERY", enabled: true, label: "Verify recovery" };
  }
  return { action: "NONE", enabled: false, label: "No safe action is currently available" };
}

export function buildWorkbenchProjection(input: WorkbenchProjectionAuthority): WorkbenchProjection {
  const projected = evidenceProjection(input);
  const states = [...projected.statesById.values()];
  const patch = patchStatus(input, projected.refsById, projected.statesById);
  const issues = issueCards(input, projected.refsById, projected.statesById, patch);
  const collection = collectionStatus(input, states);
  const lifecycleState = lifecycle(input);
  const evidence = [...projected.details.values()].map((detail) => ({
    evidenceRef: detail.evidenceRef,
    title: bounded(detail.title, 128),
    domain: detail.domain,
    state: detail.state,
    authority: detail.authority,
    sourceLabel: bounded(`${detail.source.provider} · ${detail.source.sourceAlias}`, 96),
    summary: bounded(detail.summary, 512),
    observedAt: detail.evaluatedAt,
    linkRefs: detail.linkRefs.slice(0, 4),
  }));
  const sourceStates = states.reduce<Record<string, number>>((counts, state) => {
    counts[state] = (counts[state] ?? 0) + 1;
    return counts;
  }, {});
  const completedOperations = new Set(
    input.evidence
      .filter((item) => projected.statesById.get(item.evidenceId) === "COMPLETE")
      .map((item) => item.operationId),
  ).size;
  const snapshot: MonitoringWorkspaceSnapshot = {
    schemaVersion: "1.1.0",
    workspaceId: input.workspaceId,
    stateVersion: authorityStateVersion(input.run, input.checkpointRevision),
    asOf: input.asOf,
    lifecycle: lifecycleState,
    phase: phase(input),
    ...(input.run === undefined ? {} : {
      origin: input.run.origin,
      scope: {
        ...(input.run.scope.service === undefined || safeWorkbenchText(input.run.scope.service, 128) === undefined
          ? {}
          : { service: safeWorkbenchText(input.run.scope.service, 128)! }),
        environment: requiredWorkbenchText(input.run.scope.environment, 128, "unavailable"),
        window: structuredClone(input.run.window),
      },
    }),
    status: {
      service: input.investigation?.recoveryState === "RECOVERED"
        ? "HEALTHY"
        : input.investigation?.recoveryState === "NOT_RECOVERED"
          ? "DEGRADED"
          : input.run?.workflow === "verify" && lifecycleState === "RUNNING" ? "RECOVERING" : "UNKNOWN",
      collection,
      causality: causalityStatus(input),
      recovery: recoveryStatus(input.investigation),
      audit: auditStatus(input),
    },
    progress: {
      completedOperations,
      requiredOperations: Math.min(1_024, input.operations.length),
      sourceStates,
    },
    signals: signalCards(input, projected.refsById, projected.statesById),
    hypotheses: hypothesisCards(input, projected.refsById),
    issues,
    evidence,
    activity: [],
    patch,
    nextAction: nextAction(input, collection, patch),
    limitations: authorityLimitations(input),
  };
  snapshot.activity = activityItems(input, projected.details, patch);
  return { snapshot, evidence: projected.details, links: projected.links };
}

export function patchContextForProjection(
  input: WorkbenchProjectionAuthority,
  projection: WorkbenchProjection,
  issueRef: WorkbenchIssueRef,
  hypothesisRef: string,
): WorkbenchPatchContext {
  if (!projection.snapshot.patch.eligible || input.investigation === undefined || input.run === undefined) {
    throw new TypeError("This workbench is not eligible for patch handoff");
  }
  const verificationContract = input.investigation.verificationContract;
  if (verificationContract === undefined) {
    throw new TypeError("This workbench has no begin-time verification contract");
  }
  const issue = projection.snapshot.issues?.find((candidate) => candidate.issueRef === issueRef);
  if (issue === undefined || !issue.patch.eligible) {
    throw new TypeError("This issue is not eligible for patch handoff");
  }
  if (!issue.hypothesisRefs.includes(hypothesisRef)) {
    throw new TypeError("This issue is not linked to the requested hypothesis");
  }
  const hypothesis = supportedHypotheses(input.investigation).find(
    (candidate) => hypothesisRefFor(candidate.hypothesisId) === hypothesisRef,
  );
  if (hypothesis === undefined || supportedHypotheses(input.investigation).length !== 1) {
    throw new TypeError("This workbench does not have exactly one matching supported hypothesis");
  }
  const evidenceFor = (ids: readonly EvidenceId[]): Array<{ evidenceRef: WorkbenchEvidenceRef; title: string; summary: string }> =>
    ids.map((id) => evidenceRef(input.workspaceId, id))
      .map((ref) => projection.evidence.get(ref))
      .filter((detail): detail is WorkbenchEvidenceDetail => detail !== undefined)
      .slice(0, 8)
      .map((detail) => ({ evidenceRef: detail.evidenceRef, title: detail.title, summary: detail.summary }));
  return {
    schemaVersion: "1.1.0",
    workspaceId: input.workspaceId,
    issueRef,
    hypothesisRef,
    issue: {
      kind: issue.kind,
      severity: issue.severity,
      title: issue.title,
      summary: issue.summary,
    },
    origin: input.run.origin,
    scope: {
      ...(input.run.scope.service === undefined || safeWorkbenchText(input.run.scope.service, 128) === undefined
        ? {}
        : { service: safeWorkbenchText(input.run.scope.service, 128)! }),
      environment: requiredWorkbenchText(input.run.scope.environment, 128, "unavailable"),
      window: structuredClone(input.run.window),
    },
    profileAlias: requiredWorkbenchText(input.profileAlias, 128, "unavailable"),
    hypothesis: {
      statement: requiredWorkbenchText(
        hypothesis.statement,
        512,
        "A sensitive technical hypothesis was omitted from the patch handoff.",
      ),
      rationale: requiredWorkbenchText(
        hypothesis.rationale,
        512,
        "Review the sealed incident artifact for the omitted technical rationale.",
      ),
      supportingEvidence: evidenceFor(hypothesis.supportingEvidenceIds),
      counterEvidence: evidenceFor(hypothesis.contradictingEvidenceIds),
    },
    verification: {
      policyAlias: requiredWorkbenchText(verificationContract.policyAlias, 128, "unavailable"),
      windowStrategy: verificationContract.windowStrategy,
      windowDurationSeconds: verificationContract.windowDurationSeconds,
      requiredSamples: verificationContract.requiredSamples,
      passCount: verificationContract.passCount,
      criteria: verificationContract.criteria
        .slice(0, MAX_PATCH_VERIFICATION_CRITERIA)
        .map((criterion) => ({
          criterionId: requiredWorkbenchText(criterion.criterionId, 128, "unavailable"),
          operationId: requiredWorkbenchText(criterion.operationId, 128, "unavailable"),
          signalName: requiredWorkbenchText(criterion.valueSelector.name, 128, "unavailable"),
          signalKind: criterion.valueSelector.kind,
          reducer: criterion.valueSelector.reducer,
          comparator: criterion.comparator,
          expected: typeof criterion.expected === "string"
            ? requiredWorkbenchText(
                criterion.expected,
                128,
                "A sensitive expected value was omitted from the patch handoff.",
              )
            : criterion.expected,
          ...(criterion.unit === undefined || safeWorkbenchText(criterion.unit, 64) === undefined
            ? {}
            : { unit: safeWorkbenchText(criterion.unit, 64)! }),
          maxEvidenceAgeMs: criterion.maxEvidenceAgeMs,
          ...(criterion.requiredDurationSeconds === undefined
            ? {}
            : { requiredDurationSeconds: criterion.requiredDurationSeconds }),
        })),
      omittedCriteria: Math.max(0, verificationContract.criteria.length - MAX_PATCH_VERIFICATION_CRITERIA),
    },
    nextSafeStep: requiredWorkbenchText(
      input.investigation.smallestSafeNextStep,
      512,
      "Review the sealed incident artifact before preparing a bounded local patch.",
    ),
    limitations: uniqueBounded([
      ...input.investigation.remainingUncertainty,
      ...(verificationContract.criteria.length <= MAX_PATCH_VERIFICATION_CRITERIA
        ? []
        : [`${verificationContract.criteria.length - MAX_PATCH_VERIFICATION_CRITERIA} additional verification criteria remain available only in the sealed incident artifact.`]),
      "This context authorizes local patch preparation only; it does not authorize apply, merge, push, deploy, restart, rollback, or recovery claims.",
    ], 12, 512),
  };
}

export const WORKBENCH_RUN_INVENTORY_LIMIT = MAX_WORKBENCH_RUNS;
