import {
  FIXTURE_ADAPTER_PACKAGE_ID,
  FIXTURE_SCENARIOS,
  createFixtureOperationSnapshot,
  fixtureAdapter,
  fixtureAdapterPackage,
} from "@codex-production-monitoring/adapter-fixture";
import { builtinRegistration, type AdapterRegistration } from "@codex-production-monitoring/adapter-host";
import {
  computeIntegrity,
  sha256Canonical,
  type EvidenceOrigin,
  type OperationId,
  type Sha256,
  type TrustBundle,
  type TrustedEndpoint,
  type TrustedProfile,
} from "@codex-production-monitoring/contracts";
import { computeTrustedProfileConfigHash } from "@codex-production-monitoring/config";

const FIXED_CAPTURE_TIME = "2026-01-01T00:00:00.000Z";

export interface FixtureRuntimeDefinition {
  bundle: TrustBundle;
  registrations: AdapterRegistration[];
}

/**
 * Build the credential-free, deterministic profile shipped with the plugin.
 * The profile is SIMULATED/REPLAY only and cannot be confused with LIVE data.
 */
export function createFixtureRuntimeDefinition(): FixtureRuntimeDefinition {
  const operations = FIXTURE_SCENARIOS.map((scenario) =>
    createFixtureOperationSnapshot(scenario, {
      operationId: `fixture.${scenario}` as OperationId,
      capturedAt: FIXED_CAPTURE_TIME,
      // Supported Node runtimes may spend meaningful time in the durable audit
      // and checkpoint boundary surrounding an otherwise immediate fixture
      // operation. Keep the deliberate timeout scenario short, but give every
      // other deterministic scenario the profile's full bounded second.
      limits: { timeoutMs: scenario === "timeout" ? 25 : 1_000 },
    }),
  );
  const endpoint: TrustedEndpoint = {
    endpointId: "fixture-checkout",
    adapterId: FIXTURE_ADAPTER_PACKAGE_ID,
    baseUrl: "http://127.0.0.1/",
    authentication: { mode: "NONE" },
    tls: { minimumVersion: "TLSv1.2" },
    network: {
      followRedirects: false,
      allowLoopbackHttp: true,
      allowedHosts: ["127.0.0.1"],
      networkClass: "loopback",
      routeMode: "direct",
    },
  };
  const profileDraft: TrustedProfile = {
    schemaVersion: "1.0.0",
    profileAlias: "fixture",
    capabilityProfile: "investigate",
    allowedOrigins: ["SIMULATED", "REPLAY"] satisfies EvidenceOrigin[],
    compiledAt: FIXED_CAPTURE_TIME,
    configSha256: "0".repeat(64) as Sha256,
    endpointRegistrySha256: sha256Canonical([endpoint]),
    catalogSha256: sha256Canonical(operations),
    scopes: {
      checkout: { environment: "simulation", service: "checkout" },
      worker: { environment: "simulation", service: "worker" },
    },
    endpointIds: [endpoint.endpointId],
    operationIds: operations.map((operation) => operation.operationId),
    verificationPolicies: {
      "checkout-recovery": {
        policyAlias: "checkout-recovery",
        windowStrategy: "REPEATED_CHECKS",
        windowDurationSeconds: 60,
        requiredSamples: 1,
        passCount: 1,
        criteria: [
          {
            criterionId: "checkout-error-rate",
            operationId: "fixture.healthy" as OperationId,
            valueSelector: { kind: "SCALAR", name: "checkout_error_rate", reducer: "SINGLE" },
            comparator: "LTE",
            expected: 1,
            unit: "percent",
            maxEvidenceAgeMs: 60_000,
          },
        ],
      },
    },
    policy: {
      defaultLookback: { mode: "FIXED", durationSeconds: 900 },
      maxEvidenceAge: { mode: "FIXED", durationSeconds: 60 },
      rawEvidenceRetention: { mode: "NONE" },
      auditRequired: true,
      limits: {
        timeoutMs: 1_000,
        maxAgeMs: 60_000,
        maxBytes: 64_000,
        maxRows: 100,
        maxSeries: 10,
        maxPoints: 1_000,
      },
    },
  };
  const profile: TrustedProfile = {
    ...profileDraft,
    configSha256: computeTrustedProfileConfigHash(profileDraft),
  };
  const unsealed: TrustBundle = {
    schemaVersion: "1.0.0",
    createdAt: FIXED_CAPTURE_TIME,
    profile,
    endpoints: [endpoint],
    operations,
    adapters: [fixtureAdapterPackage],
    integrity: {
      hashContractVersion: "sha256-jcs-v1",
      algorithm: "sha256",
      canonicalization: "RFC8785",
      contentSha256: "0".repeat(64) as Sha256,
    },
  };
  return {
    bundle: { ...unsealed, integrity: computeIntegrity(unsealed) },
    registrations: [builtinRegistration(fixtureAdapterPackage, fixtureAdapter)],
  };
}
