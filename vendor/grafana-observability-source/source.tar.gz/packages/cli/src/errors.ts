export type CliNextStep =
  | "CHECK_ACCESS"
  | "CHECK_CONFIGURATION"
  | "CHECK_INPUT"
  | "CONTACT_OPERATOR"
  | "RESUME_OR_CANCEL"
  | "RETRY";

export interface SanitizedCliError {
  code: string;
  message: string;
  retryable: boolean;
  nextStep: CliNextStep;
}

interface ErrorCandidate {
  code?: unknown;
  message?: unknown;
  name?: unknown;
  retryable?: unknown;
  sanitized?: unknown;
}

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function boundedCode(value: unknown): string | undefined {
  if (typeof value !== "string" || value.length === 0) return undefined;
  const normalized = value
    .replaceAll(/([a-z0-9])([A-Z])/gu, "$1_$2")
    .replaceAll(/[^A-Za-z0-9]+/gu, "_")
    .replaceAll(/^_+|_+$/gu, "")
    .toUpperCase();
  return /^[A-Z0-9_]{1,128}$/u.test(normalized) ? normalized : undefined;
}

function boundedMessage(value: unknown): string {
  if (typeof value !== "string") return "Command failed";
  const normalized = value
    .replaceAll(/\p{Cc}+/gu, " ")
    .replaceAll(/\bhttps?:\/\/\S+/giu, "[redacted-url]")
    .replaceAll(/\b(bearer|password|secret|token)\s*[:=]\s*\S+/giu, "$1=[redacted]")
    .replaceAll(/\s{2,}/gu, " ")
    .trim();
  if (normalized.length === 0) return "Command failed";
  return normalized.length <= 512 ? normalized : `${normalized.slice(0, 509)}...`;
}

function inferredRetryable(code: string, explicit: unknown): boolean {
  if (typeof explicit === "boolean") return explicit;
  return /(?:BUSY|DEADLINE|RATE_LIMIT|TEMPORARY|TIMEOUT|UNAVAILABLE)/u.test(code);
}

function nextStep(code: string, retryable: boolean): CliNextStep {
  if (/(?:CANCEL|HANDLE|LEASE|LOCK|RECOVERABLE|RESUME|STATE)/u.test(code)) return "RESUME_OR_CANCEL";
  if (retryable) return "RETRY";
  if (/(?:ACCESS|AUTH|CREDENTIAL|EACCES|EPERM|PERMISSION)/u.test(code)) return "CHECK_ACCESS";
  if (/(?:CONFLICT|ENOENT|EXISTS|INPUT|INVALID|MISSING|SYNTAX|TYPE_ERROR|UNKNOWN|UNSUPPORTED)/u.test(code)) {
    return "CHECK_INPUT";
  }
  if (/(?:CONFIG|ENDPOINT|ENVIRONMENT|PROFILE|PROVIDER|ROOT|TRUST)/u.test(code)) {
    return "CHECK_CONFIGURATION";
  }
  return "CONTACT_OPERATOR";
}

/** Reduce arbitrary thrown values to a bounded, secret-conscious public CLI error. */
export function sanitizeCliError(error: unknown): SanitizedCliError {
  const candidate = record(error) as ErrorCandidate | undefined;
  const nested = record(candidate?.sanitized);
  const code = boundedCode(nested?.code) ?? boundedCode(candidate?.code) ??
    boundedCode(candidate?.name) ?? "CLI_FAILURE";
  const retryable = inferredRetryable(code, nested?.retryable ?? candidate?.retryable);
  return {
    code,
    message: boundedMessage(nested?.message ?? candidate?.message),
    retryable,
    nextStep: nextStep(code, retryable),
  };
}
