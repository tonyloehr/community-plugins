import { executeCli } from "./main.ts";

const controller = new AbortController();
let terminationExitCode: 130 | 143 = 130;
process.once("SIGINT", () => {
  terminationExitCode = 130;
  controller.abort(new Error("Interrupted"));
});
process.once("SIGTERM", () => {
  terminationExitCode = 143;
  controller.abort(new Error("Terminated"));
});

executeCli(process.argv.slice(2), {
  signal: controller.signal,
  get terminationExitCode() {
    return terminationExitCode;
  },
}).then(
  (exitCode) => {
    process.exitCode = exitCode;
  },
  () => {
    console.error(JSON.stringify({ code: "CLI_FAILURE", message: "Command failed" }));
    process.exitCode = 2;
  },
);
