import {
  closeSync,
  constants,
  existsSync,
  fsyncSync,
  lstatSync,
  openSync,
  renameSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import { randomUUID } from "node:crypto";
import { dirname, resolve } from "node:path";

import {
  parseMonitoringProposal,
  type MonitoringProposal,
} from "@codex-production-monitoring/config";
import { canonicalJson, sha256Bytes } from "@codex-production-monitoring/contracts";

const PROPOSAL_NOTICE = "# UNTRUSTED PROPOSAL: aliases only; this file cannot activate monitoring authority.\n";
const ENVIRONMENT_REFERENCE = /^[A-Z_][A-Z0-9_]{0,127}$/u;

export interface SetupInitInput {
  proposalPath: string;
  profileAlias: string;
  requestedCapability?: string;
  requestedOrigins?: readonly string[];
  requestedScopeAliases?: readonly string[];
  requestedEndpointIds?: readonly string[];
  requestedOperationIds?: readonly string[];
  replace?: boolean;
}

export interface SetupDetectInput {
  proposalPath: string;
  proposalText: string;
  environment: NodeJS.ProcessEnv;
  environmentReferences?: readonly string[];
}

function assertReplaceTarget(path: string): void {
  const stat = lstatSync(path);
  if (stat.isSymbolicLink() || !stat.isFile() || stat.nlink !== 1) {
    throw new TypeError("Proposal target must be one regular, non-linked file");
  }
  if ((stat.mode & 0o022) !== 0) {
    throw new TypeError("Proposal target cannot be group- or world-writable");
  }
}

function writeProposal(path: string, content: string, replace: boolean): void {
  const target = resolve(path);
  const parent = dirname(target);
  const existing = existsSync(target);
  if (existing) assertReplaceTarget(target);
  if (existing && !replace) {
    throw new TypeError("Proposal already exists; use --replace to overwrite it explicitly");
  }
  const temporary = resolve(parent, `.proposal-${randomUUID()}.tmp`);
  const writePath = replace ? temporary : target;
  let descriptor: number | undefined;
  try {
    descriptor = openSync(
      writePath,
      constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
      0o600,
    );
    writeFileSync(descriptor, content, "utf8");
    fsyncSync(descriptor);
    closeSync(descriptor);
    descriptor = undefined;
    if (replace) {
      if (existsSync(target)) assertReplaceTarget(target);
      renameSync(temporary, target);
    }
    const directory = openSync(parent, constants.O_RDONLY | constants.O_DIRECTORY);
    try {
      fsyncSync(directory);
    } finally {
      closeSync(directory);
    }
  } finally {
    if (descriptor !== undefined) closeSync(descriptor);
    if (existsSync(temporary)) unlinkSync(temporary);
  }
}

export function initializeSetupProposal(input: SetupInitInput): {
  mode: "INIT";
  proposalPath: string;
  proposalSha256: string;
  untrusted: true;
  activationPerformed: false;
} {
  const proposed: MonitoringProposal = {
    schemaVersion: "1.0.0",
    profileAlias: input.profileAlias,
    ...(input.requestedCapability === undefined
      ? {}
      : { requestedCapability: input.requestedCapability as MonitoringProposal["requestedCapability"] }),
    ...(input.requestedOrigins === undefined
      ? {}
      : { requestedOrigins: input.requestedOrigins as MonitoringProposal["requestedOrigins"] }),
    ...(input.requestedScopeAliases === undefined
      ? {}
      : { requestedScopeAliases: input.requestedScopeAliases }),
    ...(input.requestedEndpointIds === undefined
      ? {}
      : { requestedEndpointIds: input.requestedEndpointIds }),
    ...(input.requestedOperationIds === undefined
      ? {}
      : { requestedOperationIds: input.requestedOperationIds as MonitoringProposal["requestedOperationIds"] }),
  };
  const json = canonicalJson(proposed);
  parseMonitoringProposal(json);
  const content = `${PROPOSAL_NOTICE}${json}\n`;
  const proposalPath = resolve(input.proposalPath);
  writeProposal(proposalPath, content, input.replace ?? false);
  return {
    mode: "INIT",
    proposalPath,
    proposalSha256: sha256Bytes(content),
    untrusted: true,
    activationPerformed: false,
  };
}

export function detectSetupProposal(input: SetupDetectInput): {
  mode: "DETECT";
  proposalPath: string;
  proposalSha256: string;
  profileAlias: string;
  requestedCapability: string | null;
  requestedOrigins: readonly string[];
  requestedScopeAliases: readonly string[];
  requestedEndpointIds: readonly string[];
  requestedOperationIds: readonly string[];
  environmentReferences: Array<{ key: string; present: boolean }>;
  providerIoPerformed: false;
  activationPerformed: false;
} {
  const proposal = parseMonitoringProposal(input.proposalText);
  const references = [...new Set(input.environmentReferences ?? [])].sort();
  if (references.length > 64 || references.some((key) => !ENVIRONMENT_REFERENCE.test(key))) {
    throw new TypeError("Environment references must be at most 64 valid variable names");
  }
  return {
    mode: "DETECT",
    proposalPath: resolve(input.proposalPath),
    proposalSha256: sha256Bytes(input.proposalText),
    profileAlias: proposal.profileAlias,
    requestedCapability: proposal.requestedCapability ?? null,
    requestedOrigins: proposal.requestedOrigins ?? [],
    requestedScopeAliases: proposal.requestedScopeAliases ?? [],
    requestedEndpointIds: proposal.requestedEndpointIds ?? [],
    requestedOperationIds: proposal.requestedOperationIds ?? [],
    environmentReferences: references.map((key) => ({
      key,
      present: typeof input.environment[key] === "string" && input.environment[key]!.length > 0,
    })),
    providerIoPerformed: false,
    activationPerformed: false,
  };
}
