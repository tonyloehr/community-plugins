import { createHash } from "node:crypto";

import { parseMonitoringProposal } from "@codex-production-monitoring/config";

export const CURRENT_MONITORING_PROPOSAL_SCHEMA_VERSION = "1.0.0";
export const PRE_V0_1_CONFIGURATION_COMPATIBILITY_RULE = "pre-v0.1-proposal-compatibility-v1";

export interface ConfigurationCompatibilityDecision {
  readonly schemaVersion: "1.0.0";
  readonly rule: typeof PRE_V0_1_CONFIGURATION_COMPATIBILITY_RULE;
  readonly releaseVersion: "0.3.0";
  readonly inputSchemaVersion: "1.0.0";
  readonly decision: "NO_MIGRATION_REQUIRED";
  readonly reason: "INPUT_ALREADY_USES_CURRENT_SCHEMA";
  readonly inputSha256: string;
  readonly outputSha256: string;
  readonly transformed: false;
  readonly writesPerformed: false;
}

/**
 * The pre-v0.1 compatibility rule remains a bounded no-op in v0.3. A
 * same-schema pre-release input receives an explicit no-op decision; every
 * other version fails closed.
 */
export function evaluatePreV01ConfigurationCompatibility(inputText: string): ConfigurationCompatibilityDecision {
  const proposal = parseMonitoringProposal(inputText);
  const inputSha256 = createHash("sha256").update(inputText).digest("hex");
  return {
    schemaVersion: "1.0.0",
    rule: PRE_V0_1_CONFIGURATION_COMPATIBILITY_RULE,
    releaseVersion: "0.3.0",
    inputSchemaVersion: proposal.schemaVersion,
    decision: "NO_MIGRATION_REQUIRED",
    reason: "INPUT_ALREADY_USES_CURRENT_SCHEMA",
    inputSha256,
    outputSha256: inputSha256,
    transformed: false,
    writesPerformed: false,
  };
}
