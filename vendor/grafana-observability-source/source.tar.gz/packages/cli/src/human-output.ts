import { resolve } from "node:path";

import type {
  EvidenceOrigin,
  Workflow,
  WorkflowEvent,
} from "@codex-production-monitoring/contracts";

export interface WorkflowTextContext {
  origin: EvidenceOrigin;
  workflow: Workflow;
  outputRoot: string;
}

function prefix(context: Readonly<WorkflowTextContext>): string {
  return `${context.origin} · ${context.workflow.toUpperCase()}`;
}

function evidenceCounts(event: Extract<WorkflowEvent, { event: "workflow_result" }>): string {
  const states = event.result.evidenceSummary;
  return [
    `COMPLETE ${states.COMPLETE}`,
    `EMPTY ${states.EMPTY}`,
    `STALE ${states.STALE}`,
    `CONTRADICTORY ${states.CONTRADICTORY}`,
    `ERROR ${states.ERROR}`,
  ].join(" · ");
}

/** Render bounded, non-authoritative operator copy while JSONL remains the automation contract. */
export function formatWorkflowEventText(
  event: Readonly<WorkflowEvent>,
  context: Readonly<WorkflowTextContext>,
): string[] {
  const lead = prefix(context);
  switch (event.event) {
    case "workflow_started":
      return [`${lead} · STARTING`];
    case "run_started":
      return [`${lead} · COLLECTING EVIDENCE`];
    case "run_resumed":
      return [`${lead} · RESUMING`];
    case "evidence_collected":
      return [`${lead} · EVIDENCE COLLECTED · ${event.evidence.length} signal${event.evidence.length === 1 ? "" : "s"}`];
    case "run_sealed":
      return [`${lead} · ARTIFACT SEALED`];
    case "workflow_stopped":
      return [`${lead} · ${event.state} · ${event.code}`];
    case "run_cancelled":
      return [`${lead} · CANCELLED`];
    case "workflow_result": {
      const lines = [
        `${lead} · RESULT · ${event.result.investigationStatus} · ${event.result.terminalState}`,
        `${lead} · EVIDENCE · ${evidenceCounts(event)}`,
        `${lead} · RECOVERY · ${event.result.recoveryState === "NONE" ? "NOT ASSESSED" : event.result.recoveryState}`,
      ];
      const relativePath = event.result.artifact?.relativePath;
      if (relativePath !== undefined) {
        lines.push(`${lead} · REPORT · ${resolve(context.outputRoot, relativePath, "report.md")}`);
      } else {
        lines.push(`${lead} · REPORT · NOT WRITTEN`);
      }
      return lines;
    }
  }
}
