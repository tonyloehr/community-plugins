const FIXTURE_EXAMPLE = [
  "Credential-free SIMULATED fixture:",
  "  node ./plugins/production-monitoring/scripts/pmctl.mjs workflow run --request ./plugins/production-monitoring/examples/requests/fixture-investigate.json --output \"$(mktemp -d)/production-monitoring-output\" --analysis-driver deterministic-fixture --events text",
].join("\n");

export const PRODUCTION_MONITORING_CLI_VERSION = "0.3.0";

export const PUBLIC_CLI_COMMANDS = Object.freeze([
  "admin validate-root",
  "admin activate",
  "setup init",
  "setup detect",
  "setup compatibility",
  "setup dry-run",
  "workflow validate",
  "workflow run",
  "workflow resume",
  "workflow cancel",
  "doctor",
  "preview-access",
  "capabilities",
  "operations",
  "artifacts validate",
] as const);

const MAIN_HELP = [
  "Production Monitoring (pmctl)",
  "Read-only evidence collection, incident investigation, and recovery verification.",
  "",
  "Usage:",
  "  pmctl <command> [options]",
  "  pmctl help [command]",
  "",
  "Workflows:",
  "  workflow validate       Validate a versioned workflow request",
  "  workflow run            Start or safely resume a workflow",
  "  workflow resume         Resume retained owner-controlled state",
  "  workflow cancel         Cancel a retained workflow",
  "",
  "Setup and access:",
  "  setup init|detect|dry-run|compatibility",
  "  doctor                  Check a configured profile",
  "  preview-access          Preview sealed live access without provider I/O",
  "  capabilities            List profile capabilities",
  "  operations              List approved evidence operations",
  "",
  "Administration:",
  "  admin validate-root|activate",
  "  artifacts validate",
  "",
  FIXTURE_EXAMPLE,
  "",
  "Automation defaults to JSONL. Add --events text to workflow run/resume for a human summary.",
  "Run 'pmctl help workflow' for workflow options.",
  "",
].join("\n");

const TOPIC_HELP: Readonly<Record<string, string>> = {
  workflow: [
    "Usage:",
    "  pmctl workflow validate --request <request.json|-> [--json]",
    "  pmctl workflow run --request <request.json|-> --output <absolute-dir> [--state <absolute-dir>] [--analysis-driver codex|deterministic-fixture] [--events jsonl|text]",
    "  pmctl workflow resume (--run-id <public-run-id> | --request <request.json|-> --output <absolute-dir>) [--events jsonl|text]",
    "  pmctl workflow cancel (--run-id <public-run-id> --reason <reason> | --request <request.json|-> --output <absolute-dir>)",
    "",
    "JSONL is the default stable automation contract. Text mode prints phases, final evidence counts, recovery state, and the absolute report path.",
    "",
    FIXTURE_EXAMPLE,
    "",
  ].join("\n"),
  setup: [
    "Usage:",
    "  pmctl setup init --proposal <file> --profile <alias> [--capability <alias>] [--origins <list>] [--scopes <list>] [--endpoints <list>] [--operations <list>] [--replace]",
    "  pmctl setup detect --proposal <file> [--env-refs <list>]",
    "  pmctl setup dry-run --proposal <file> [--json]",
    "  pmctl setup compatibility --input <file> [--json]",
    "",
    "Setup writes only an untrusted proposal until an administrator validates and activates a trust root.",
    "",
  ].join("\n"),
  admin: [
    "Usage:",
    "  pmctl admin validate-root --root <absolute-dir> [--json]",
    "  pmctl admin activate --root <absolute-dir> --receipt <absolute-file> --expected-root-manifest-sha256 <sha256> --expected-trust-bundle-sha256 <sha256> [--replace] [--json]",
    "",
    "Activation is an explicit administrator action and performs no monitoring-provider mutation.",
    "",
  ].join("\n"),
  artifacts: [
    "Usage:",
    "  pmctl artifacts validate --root <absolute-dir> --bundle <bundle-id> [--json]",
    "",
    "Validates the sealed bundle and deterministic report projection.",
    "",
  ].join("\n"),
  doctor: "Usage:\n  pmctl doctor --profile <alias> [--json]\n\n",
  "preview-access": "Usage:\n  pmctl preview-access --profile <alias> [--json]\n\n",
  capabilities: "Usage:\n  pmctl capabilities --profile <alias> [--json]\n\n",
  operations: "Usage:\n  pmctl operations --profile <alias> [--domain <domain>] [--json]\n\n",
};

function topicHelp(topic: string | undefined): string {
  if (topic === undefined) return MAIN_HELP;
  const selected = TOPIC_HELP[topic];
  if (selected === undefined) throw new TypeError("Unknown help topic; use pmctl --help");
  return selected;
}

/** Resolve conventional top-level, group, and command help forms before option parsing. */
export function requestedHelp(argv: readonly string[]): string | undefined {
  const [command, subcommand, detail] = argv;
  if (command === undefined || command === "--help" || command === "-h") return MAIN_HELP;
  if (command === "help") return topicHelp(subcommand);
  if (subcommand === "help" || subcommand === "--help" || subcommand === "-h") {
    return topicHelp(command);
  }
  if (detail === "--help" || detail === "-h") return topicHelp(command);
  return undefined;
}
