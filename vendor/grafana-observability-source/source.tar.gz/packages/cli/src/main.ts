import { lstatSync, readFileSync, realpathSync } from "node:fs";
import { tmpdir } from "node:os";
import { isAbsolute, join, resolve } from "node:path";
import type { Readable } from "node:stream";

import { ArtifactStore, asBundleId } from "@codex-production-monitoring/artifacts";
import {
  activateTrustRoot,
  compileTrustedConfiguration,
  loadActivatedTrustRoot,
  loadTrustedRoot,
  parseMonitoringProposal,
  previewProviderAccess,
  trustedEndpointCredentialReferences,
  validateTrustRootForActivation,
  type LoadedTrustRoot,
} from "@codex-production-monitoring/config";
import {
  sha256Canonical,
  type Sha256,
  type WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import {
  createFixtureRuntimeDefinition,
  createRuntimeFromEnvironment,
  validateWorkflowRequest,
} from "@codex-production-monitoring/evidence-server";
import {
  cancelHeadlessWorkflow,
  createCodexExecAnalysisDriver,
  deterministicEvidenceAnalysisDriver,
  PublicRunControlIndex,
  runHeadlessWorkflow,
  type PublicRunControlPayload,
  type AnalysisDriver,
} from "@codex-production-monitoring/headless";

import { evaluatePreV01ConfigurationCompatibility } from "./config-compatibility.ts";
import { sanitizeCliError } from "./errors.ts";
import { PRODUCTION_MONITORING_CLI_VERSION, requestedHelp } from "./help.ts";
import { formatWorkflowEventText } from "./human-output.ts";
import { detectSetupProposal, initializeSetupProposal } from "./setup.ts";

export interface CliIo {
  stdout(text: string): void;
  stderr(text: string): void;
}

export interface CliExecutionOptions {
  environment?: NodeJS.ProcessEnv;
  io?: CliIo;
  signal?: AbortSignal;
  terminationExitCode?: 130 | 143;
  now?: () => Date;
  stdin?: Readable;
}

const MAXIMUM_INPUT_BYTES = 1_024 * 1_024;
const CANCELLATION_REASONS: ReadonlySet<string> = new Set([
  "USER_REQUEST",
  "INTERRUPTED",
  "BUDGET_EXCEEDED",
  "PROVIDER_UNAVAILABLE",
] as const);
type CliAnalysisDriver = "codex" | "deterministic-fixture";

const defaultIo: CliIo = {
  stdout: (text) => process.stdout.write(text),
  stderr: (text) => process.stderr.write(text),
};

function secureRead(pathInput: string, maximumBytes = MAXIMUM_INPUT_BYTES): string {
  const path = resolve(pathInput);
  const stat = lstatSync(path);
  if (stat.isSymbolicLink() || !stat.isFile() || stat.nlink !== 1) {
    throw new TypeError("Input must be one regular, non-linked file");
  }
  if (stat.size > maximumBytes) throw new TypeError("Input exceeds the size limit");
  return readFileSync(path, "utf8");
}

async function boundedStdin(stream: Readable, maximumBytes = MAXIMUM_INPUT_BYTES): Promise<string> {
  const chunks: Buffer[] = [];
  let bytes = 0;
  for await (const rawChunk of stream) {
    const chunk = typeof rawChunk === "string" ? Buffer.from(rawChunk, "utf8") : Buffer.from(rawChunk);
    bytes += chunk.byteLength;
    if (bytes > maximumBytes) throw new TypeError("Input exceeds the size limit");
    chunks.push(chunk);
  }
  return Buffer.concat(chunks, bytes).toString("utf8");
}

async function jsonInput(path: string, stdin: Readable): Promise<unknown> {
  const text = path === "-" ? await boundedStdin(stdin) : secureRead(path);
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw new TypeError("Request input is not valid JSON");
  }
}

function parseOptions(args: readonly string[]): Map<string, string | true> {
  const parsed = new Map<string, string | true>();
  for (let index = 0; index < args.length; index += 1) {
    const token = args[index]!;
    if (!token.startsWith("--")) throw new TypeError("Unexpected positional argument");
    if (parsed.has(token)) throw new TypeError(`Duplicate option: ${token}`);
    if (token === "--json" || token === "--replace") {
      parsed.set(token, true);
      continue;
    }
    const value = args[index + 1];
    if (value === undefined || value.startsWith("--")) throw new TypeError(`Missing value for ${token}`);
    parsed.set(token, value);
    index += 1;
  }
  return parsed;
}

function required(options: Map<string, string | true>, name: string): string {
  const value = options.get(name);
  if (typeof value !== "string" || value.length === 0) throw new TypeError(`${name} is required`);
  return value;
}

function optional(options: Map<string, string | true>, name: string): string | undefined {
  const value = options.get(name);
  return typeof value === "string" ? value : undefined;
}

function rejectUnknown(options: Map<string, string | true>, allowed: readonly string[]): void {
  const accepted = new Set(allowed);
  for (const key of options.keys()) {
    if (!accepted.has(key)) throw new TypeError(`Unsupported option: ${key}`);
  }
}

function line(io: CliIo, value: unknown): void {
  io.stdout(`${JSON.stringify(value)}\n`);
}

function absoluteOutput(value: string): string {
  return isAbsolute(value) ? resolve(value) : resolve(process.cwd(), value);
}

function commaSeparated(
  options: Map<string, string | true>,
  name: string,
  maximum = 64,
): string[] | undefined {
  const value = optional(options, name);
  if (value === undefined) return undefined;
  const items = value.split(",").map((item) => item.trim());
  if (items.length > maximum || items.some((item) => item.length === 0 || item.length > 256)) {
    throw new TypeError(`${name} must be a comma-separated list of at most ${maximum} bounded identifiers`);
  }
  return [...new Set(items)];
}

function controlIndexRoot(environment: NodeJS.ProcessEnv): string {
  const configured = environment.PRODUCTION_MONITORING_CONTROL_INDEX_ROOT;
  const value = configured ?? join(
    realpathSync.native(tmpdir()),
    `codex-production-monitoring-control-${typeof process.getuid === "function" ? process.getuid() : "local"}`,
  );
  if (!isAbsolute(value)) {
    throw new TypeError("PRODUCTION_MONITORING_CONTROL_INDEX_ROOT must be an absolute path");
  }
  return resolve(value);
}

function cancellationReason(value: string | undefined):
  "USER_REQUEST" | "INTERRUPTED" | "BUDGET_EXCEEDED" | "PROVIDER_UNAVAILABLE" {
  const reason = value ?? "USER_REQUEST";
  if (!CANCELLATION_REASONS.has(reason)) {
    throw new TypeError("--reason must be USER_REQUEST, INTERRUPTED, BUDGET_EXCEEDED, or PROVIDER_UNAVAILABLE");
  }
  return reason as "USER_REQUEST" | "INTERRUPTED" | "BUDGET_EXCEEDED" | "PROVIDER_UNAVAILABLE";
}

function assertPublicPayload(payload: PublicRunControlPayload): WorkflowRequest {
  const request = validateWorkflowRequest(payload.request);
  if (sha256Canonical(request) !== payload.requestSha256) {
    throw new TypeError("Public run control request digest does not match");
  }
  if (payload.idempotencyKey !== request.idempotencyKey) {
    throw new TypeError("Public run control idempotency policy does not match the request");
  }
  return request;
}

function selectedAnalysisDriver(
  request: Readonly<WorkflowRequest>,
  requested: string | undefined,
): CliAnalysisDriver | undefined {
  if (requested !== undefined && requested !== "codex" && requested !== "deterministic-fixture") {
    throw new TypeError("--analysis-driver must be codex or deterministic-fixture when supplied");
  }
  const selected = requested as CliAnalysisDriver | undefined ?? (request.origin === "LIVE" ? "codex" : undefined);
  if (
    selected === "deterministic-fixture" &&
    (request.profileAlias !== "fixture" || !new Set(["SIMULATED", "REPLAY"]).has(request.origin))
  ) {
    throw new TypeError("deterministic-fixture analysis is restricted to fixture SIMULATED or REPLAY requests");
  }
  return selected;
}

function codexTimeoutMs(environment: Readonly<NodeJS.ProcessEnv>): number | undefined {
  const value = environment.PRODUCTION_MONITORING_CODEX_TIMEOUT_MS;
  if (value === undefined) return undefined;
  if (!/^[1-9][0-9]{2,5}$/u.test(value)) {
    throw new TypeError("PRODUCTION_MONITORING_CODEX_TIMEOUT_MS must be a bounded integer");
  }
  const timeoutMs = Number(value);
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1_000 || timeoutMs > 600_000) {
    throw new TypeError("PRODUCTION_MONITORING_CODEX_TIMEOUT_MS must be between 1000 and 600000");
  }
  return timeoutMs;
}

function analysisDriver(
  selected: CliAnalysisDriver | undefined,
  environment: Readonly<NodeJS.ProcessEnv>,
): AnalysisDriver | undefined {
  if (selected === undefined) return undefined;
  if (selected === "deterministic-fixture") return deterministicEvidenceAnalysisDriver;
  return createCodexExecAnalysisDriver({
    executablePath: environment.PRODUCTION_MONITORING_CODEX_EXECUTABLE,
    environment,
    forbiddenWorkspaceRoots: [process.cwd()],
    ...(codexTimeoutMs(environment) === undefined ? {} : { timeoutMs: codexTimeoutMs(environment) }),
  });
}

function fixtureTrustRoot(): LoadedTrustRoot {
  const { bundle } = createFixtureRuntimeDefinition();
  return {
    rootPath: "fixture://built-in",
    rootManifestSha256: bundle.integrity.contentSha256,
    trustBundleSha256: bundle.integrity.contentSha256,
    bundle,
  };
}

function trustRootForDryRun(environment: NodeJS.ProcessEnv): LoadedTrustRoot {
  const mode = environment.PRODUCTION_MONITORING_MODE ?? "fixture";
  if (mode === "fixture") return fixtureTrustRoot();
  if (mode !== "live") throw new TypeError("PRODUCTION_MONITORING_MODE must be fixture or live");
  const rootPath = environment.PRODUCTION_MONITORING_TRUST_ROOT;
  if (rootPath === undefined || !isAbsolute(rootPath)) {
    throw new TypeError("Live dry-run requires an absolute PRODUCTION_MONITORING_TRUST_ROOT");
  }
  return loadTrustedRoot({ rootPath, forbiddenWorkspaceRoots: [process.cwd()] });
}

function activatedLiveRootForPreview(environment: NodeJS.ProcessEnv): Readonly<LoadedTrustRoot> {
  if (environment.PRODUCTION_MONITORING_MODE !== "live") {
    throw new TypeError("preview-access requires PRODUCTION_MONITORING_MODE=live");
  }
  const rootPath = environment.PRODUCTION_MONITORING_TRUST_ROOT;
  const receiptPath = environment.PRODUCTION_MONITORING_ACTIVATION_RECEIPT;
  if (rootPath === undefined || !isAbsolute(rootPath)) {
    throw new TypeError("preview-access requires an absolute PRODUCTION_MONITORING_TRUST_ROOT");
  }
  if (receiptPath === undefined || !isAbsolute(receiptPath)) {
    throw new TypeError("preview-access requires an absolute PRODUCTION_MONITORING_ACTIVATION_RECEIPT");
  }
  return loadActivatedTrustRoot({
    receiptPath,
    trustRootPath: rootPath,
    forbiddenWorkspaceRoots: [process.cwd()],
  });
}

function setupDryRun(
  options: Map<string, string | true>,
  environment: NodeJS.ProcessEnv,
  now: () => Date,
): unknown {
  rejectUnknown(options, ["--proposal", "--json"]);
  const proposal = parseMonitoringProposal(secureRead(required(options, "--proposal")));
  const compiled = compileTrustedConfiguration({
    root: trustRootForDryRun(environment),
    proposal,
    compiledAt: now().toISOString(),
  });
  return {
    mode: "DRY_RUN",
    writesPerformed: false,
    profileAlias: compiled.bundle.profile.profileAlias,
    capabilityProfile: compiled.bundle.profile.capabilityProfile,
    allowedOrigins: compiled.bundle.profile.allowedOrigins,
    scopes: Object.keys(compiled.bundle.profile.scopes).sort(),
    endpointIds: [...compiled.bundle.profile.endpointIds].sort(),
    operationIds: [...compiled.bundle.profile.operationIds].sort(),
    credentialReferences: compiled.bundle.endpoints.flatMap((endpoint) =>
      trustedEndpointCredentialReferences(endpoint).map((reference) => ({
        endpointId: endpoint.endpointId,
        kind: reference.kind,
        key: reference.key,
      }))
    ),
    trustBundleSha256: compiled.bundle.integrity.contentSha256,
  };
}

export async function executeCli(argv: readonly string[], execution: CliExecutionOptions = {}): Promise<number> {
  const environment = execution.environment ?? process.env;
  const io = execution.io ?? defaultIo;
  const now = execution.now ?? (() => new Date());
  const stdin = execution.stdin ?? process.stdin;
  const [command, subcommand, ...rest] = argv;
  try {
    const help = requestedHelp(argv);
    if (help !== undefined) {
      io.stdout(help);
      return 0;
    }
    if (command === "--version" || command === "version") {
      io.stdout(`${PRODUCTION_MONITORING_CLI_VERSION}\n`);
      return 0;
    }
    if (command === "admin" && subcommand === "validate-root") {
      const options = parseOptions(rest);
      rejectUnknown(options, ["--root", "--json"]);
      const root = required(options, "--root");
      if (!isAbsolute(root)) throw new TypeError("--root must be an absolute path");
      line(io, validateTrustRootForActivation(root));
      return 0;
    }
    if (command === "admin" && subcommand === "activate") {
      const options = parseOptions(rest);
      rejectUnknown(options, [
        "--root",
        "--receipt",
        "--expected-root-manifest-sha256",
        "--expected-trust-bundle-sha256",
        "--replace",
        "--json",
      ]);
      const root = required(options, "--root");
      const receipt = required(options, "--receipt");
      if (!isAbsolute(root) || !isAbsolute(receipt)) {
        throw new TypeError("--root and --receipt must be absolute paths");
      }
      const activated = activateTrustRoot({
        trustRootPath: root,
        receiptPath: receipt,
        expectedRootManifestSha256: required(
          options,
          "--expected-root-manifest-sha256",
        ) as Sha256,
        expectedTrustBundleSha256: required(
          options,
          "--expected-trust-bundle-sha256",
        ) as Sha256,
        activatedAt: now().toISOString(),
        replace: options.get("--replace") === true,
      });
      line(io, {
        mode: "ACTIVATED",
        activationPerformed: true,
        activatedAt: activated.activatedAt,
        trustRootPath: activated.trustRootPath,
        rootManifestSha256: activated.rootManifestSha256,
        trustBundleSha256: activated.trustBundleSha256,
        providerRuntimeSha256: activated.providerRuntimeSha256,
        receiptPath: resolve(receipt),
      });
      return 0;
    }
    if (command === "setup" && subcommand === "init") {
      const options = parseOptions(rest);
      rejectUnknown(options, [
        "--proposal",
        "--profile",
        "--capability",
        "--origins",
        "--scopes",
        "--endpoints",
        "--operations",
        "--replace",
        "--json",
      ]);
      line(io, initializeSetupProposal({
        proposalPath: absoluteOutput(required(options, "--proposal")),
        profileAlias: required(options, "--profile"),
        ...(optional(options, "--capability") === undefined
          ? {}
          : { requestedCapability: optional(options, "--capability") }),
        ...(commaSeparated(options, "--origins", 3) === undefined
          ? {}
          : { requestedOrigins: commaSeparated(options, "--origins", 3) }),
        ...(commaSeparated(options, "--scopes") === undefined
          ? {}
          : { requestedScopeAliases: commaSeparated(options, "--scopes") }),
        ...(commaSeparated(options, "--endpoints") === undefined
          ? {}
          : { requestedEndpointIds: commaSeparated(options, "--endpoints") }),
        ...(commaSeparated(options, "--operations", 128) === undefined
          ? {}
          : { requestedOperationIds: commaSeparated(options, "--operations", 128) }),
        replace: options.get("--replace") === true,
      }));
      return 0;
    }
    if (command === "setup" && subcommand === "detect") {
      const options = parseOptions(rest);
      rejectUnknown(options, ["--proposal", "--env-refs", "--json"]);
      const proposalPath = absoluteOutput(required(options, "--proposal"));
      line(io, detectSetupProposal({
        proposalPath,
        proposalText: secureRead(proposalPath),
        environment,
        ...(commaSeparated(options, "--env-refs") === undefined
          ? {}
          : { environmentReferences: commaSeparated(options, "--env-refs") }),
      }));
      return 0;
    }
    if (command === "setup" && (subcommand === "dry-run" || subcommand === "preview")) {
      const options = parseOptions(rest);
      line(io, setupDryRun(options, environment, now));
      return 0;
    }
    if (command === "setup" && subcommand === "compatibility") {
      const options = parseOptions(rest);
      rejectUnknown(options, ["--input", "--json"]);
      const inputPath = absoluteOutput(required(options, "--input"));
      line(io, evaluatePreV01ConfigurationCompatibility(secureRead(inputPath)));
      return 0;
    }
    if (command === "workflow" && subcommand === "validate") {
      const options = parseOptions(rest);
      rejectUnknown(options, ["--request", "--json"]);
      const request = validateWorkflowRequest(await jsonInput(required(options, "--request"), stdin));
      line(io, { valid: true, schemaVersion: request.schemaVersion, requestSha256: sha256Canonical(request) });
      return 0;
    }
    if (command === "workflow" && (subcommand === "run" || subcommand === "resume")) {
      const options = parseOptions(rest);
      rejectUnknown(options, [
        "--request",
        "--output",
        "--state",
        "--events",
        "--fail-on",
        "--idempotency-key",
        "--analysis-driver",
        "--run-id",
      ]);
      const events = optional(options, "--events") ?? "jsonl";
      if (events !== "jsonl" && events !== "text") {
        throw new TypeError("--events must be jsonl or text");
      }
      const publicIndex = new PublicRunControlIndex(controlIndexRoot(environment));
      const publicRunId = optional(options, "--run-id");
      if (subcommand === "run" && publicRunId !== undefined) {
        throw new TypeError("--run-id is supported only by workflow resume");
      }
      let request: WorkflowRequest;
      let output: string;
      let stateRoot: string;
      let idempotencyKey: string;
      let analysisDriverSelection: CliAnalysisDriver | undefined;
      if (publicRunId !== undefined) {
        for (const incompatible of ["--request", "--output", "--state", "--idempotency-key", "--analysis-driver", "--fail-on"]) {
          if (options.has(incompatible)) {
            throw new TypeError(`${incompatible} cannot be combined with --run-id`);
          }
        }
        const payload = publicIndex.get(publicRunId);
        if (payload === undefined) throw new TypeError("No recoverable run exists for this run ID");
        request = assertPublicPayload(payload);
        output = payload.outputRoot;
        stateRoot = payload.stateRoot;
        idempotencyKey = payload.idempotencyKey;
        analysisDriverSelection = payload.analysisDriver ?? undefined;
      } else {
        request = validateWorkflowRequest(await jsonInput(required(options, "--request"), stdin));
        output = absoluteOutput(required(options, "--output"));
        stateRoot = absoluteOutput(optional(options, "--state") ?? `${output}.state`);
        const requestedIdempotencyKey = optional(options, "--idempotency-key");
        if (requestedIdempotencyKey !== undefined && requestedIdempotencyKey !== request.idempotencyKey) {
          throw new TypeError("--idempotency-key conflicts with the canonical workflow request");
        }
        idempotencyKey = request.idempotencyKey;
        analysisDriverSelection = selectedAnalysisDriver(request, optional(options, "--analysis-driver"));
      }
      const requestedFailOn = optional(options, "--fail-on");
      if (requestedFailOn !== undefined && requestedFailOn !== request.failOn) {
        throw new TypeError("--fail-on conflicts with the canonical workflow request");
      }
      const selectedDriver = analysisDriver(analysisDriverSelection, environment);
      const runtime = createRuntimeFromEnvironment({
        ...environment,
        PRODUCTION_MONITORING_ARTIFACT_ROOT: output,
        PRODUCTION_MONITORING_STATE_ROOT: stateRoot,
      });
      const requestHash = sha256Canonical(request);
      const publicPayload: PublicRunControlPayload = {
        schemaVersion: "1.0.0",
        request: structuredClone(request),
        requestSha256: requestHash,
        outputRoot: output,
        stateRoot,
        idempotencyKey,
        analysisDriver: analysisDriverSelection ?? null,
      };
      const outcome = await runHeadlessWorkflow(runtime, request, {
        controlRoot: stateRoot,
        resumeMode: subcommand === "resume" ? "required" : "auto",
        ...(selectedDriver === undefined ? {} : { analysisDriver: selectedDriver }),
        ...(execution.signal === undefined ? {} : { signal: execution.signal }),
        ...(execution.terminationExitCode === undefined ? {} : { terminationExitCode: execution.terminationExitCode }),
        now,
        emit: (event) => {
          if (event.event === "run_started" || event.event === "run_resumed") {
            if (publicRunId !== undefined && event.runId !== publicRunId) {
              throw new TypeError("Public run control resolved to an unexpected run ID");
            }
            publicIndex.put(event.runId, publicPayload);
          }
          if (
            event.event === "run_sealed" ||
            (event.event === "workflow_stopped" && event.state !== "PAUSED")
          ) {
            publicIndex.remove(event.runId);
          }
          if (events === "jsonl") {
            line(io, event);
          } else {
            for (const rendered of formatWorkflowEventText(event, {
              origin: request.origin,
              workflow: request.workflow,
              outputRoot: output,
            })) {
              io.stdout(`${rendered}\n`);
            }
          }
        },
      });
      return outcome.result.exitCode;
    }
    if (command === "workflow" && subcommand === "cancel") {
      const options = parseOptions(rest);
      rejectUnknown(options, ["--request", "--output", "--state", "--idempotency-key", "--run-id", "--reason"]);
      const publicIndex = new PublicRunControlIndex(controlIndexRoot(environment));
      const publicRunId = optional(options, "--run-id");
      if (publicRunId !== undefined && optional(options, "--reason") === undefined) {
        throw new TypeError("--reason is required with --run-id");
      }
      let request: WorkflowRequest;
      let output: string;
      let stateRoot: string;
      let idempotencyKey: string;
      if (publicRunId !== undefined) {
        for (const incompatible of ["--request", "--output", "--state", "--idempotency-key"]) {
          if (options.has(incompatible)) {
            throw new TypeError(`${incompatible} cannot be combined with --run-id`);
          }
        }
        const payload = publicIndex.get(publicRunId);
        if (payload === undefined) throw new TypeError("No recoverable run exists for this run ID");
        request = assertPublicPayload(payload);
        output = payload.outputRoot;
        stateRoot = payload.stateRoot;
        idempotencyKey = payload.idempotencyKey;
      } else {
        request = validateWorkflowRequest(await jsonInput(required(options, "--request"), stdin));
        output = absoluteOutput(required(options, "--output"));
        stateRoot = absoluteOutput(optional(options, "--state") ?? `${output}.state`);
        const requestedIdempotencyKey = optional(options, "--idempotency-key");
        if (requestedIdempotencyKey !== undefined && requestedIdempotencyKey !== request.idempotencyKey) {
          throw new TypeError("--idempotency-key conflicts with the canonical workflow request");
        }
        idempotencyKey = request.idempotencyKey;
      }
      const runtime = createRuntimeFromEnvironment({
        ...environment,
        PRODUCTION_MONITORING_ARTIFACT_ROOT: output,
        PRODUCTION_MONITORING_STATE_ROOT: stateRoot,
      });
      const outcome = await cancelHeadlessWorkflow(runtime, request, {
        idempotencyKey,
        controlRoot: stateRoot,
        reason: cancellationReason(optional(options, "--reason")),
        now,
        emit: (event) => {
          if (event.event !== "run_cancelled") {
            throw new TypeError("Cancellation emitted an unexpected event");
          }
          if (publicRunId !== undefined && event.runId !== publicRunId) {
            throw new TypeError("Public run control resolved to an unexpected run ID");
          }
          publicIndex.remove(event.runId);
          line(io, event);
        },
      });
      if (publicRunId !== undefined && outcome.runId !== publicRunId) {
        throw new TypeError("Public run control resolved to an unexpected run ID");
      }
      publicIndex.remove(outcome.runId);
      return 0;
    }
    if (command === "doctor") {
      const options = parseOptions([...(subcommand === undefined ? [] : [subcommand]), ...rest]);
      rejectUnknown(options, ["--profile", "--json"]);
      const runtime = createRuntimeFromEnvironment(environment);
      const result = await runtime.doctor(required(options, "--profile"));
      line(io, result);
      return result.status === "BLOCKED" ? 2 : 0;
    }
    if (command === "preview-access") {
      const options = parseOptions([...(subcommand === undefined ? [] : [subcommand]), ...rest]);
      rejectUnknown(options, ["--profile", "--json"]);
      const root = activatedLiveRootForPreview(environment);
      line(io, previewProviderAccess(root, required(options, "--profile")));
      return 0;
    }
    if (command === "capabilities") {
      const options = parseOptions([...(subcommand === undefined ? [] : [subcommand]), ...rest]);
      rejectUnknown(options, ["--profile", "--json"]);
      const runtime = createRuntimeFromEnvironment(environment);
      line(io, runtime.listCapabilities(required(options, "--profile")));
      return 0;
    }
    if (command === "operations") {
      const options = parseOptions([...(subcommand === undefined ? [] : [subcommand]), ...rest]);
      rejectUnknown(options, ["--profile", "--domain", "--json"]);
      const runtime = createRuntimeFromEnvironment(environment);
      line(io, runtime.listOperations(required(options, "--profile"), optional(options, "--domain")));
      return 0;
    }
    if (command === "artifacts" && subcommand === "validate") {
      const options = parseOptions(rest);
      rejectUnknown(options, ["--root", "--bundle", "--json"]);
      const store = new ArtifactStore({ root: absoluteOutput(required(options, "--root")) });
      const bundle = store.validateBundle(asBundleId(required(options, "--bundle")));
      line(io, {
        valid: true,
        bundleId: bundle.bundleId,
        runId: bundle.runId,
        manifestSha256: bundle.manifestSha256,
        status: bundle.investigation.status,
      });
      return 0;
    }
    throw new TypeError(
      "Usage: pmctl admin validate-root|admin activate|setup init|setup detect|setup compatibility|setup dry-run|workflow validate|workflow run|workflow resume|workflow cancel|doctor|preview-access|capabilities|operations|artifacts validate",
    );
  } catch (error) {
    io.stderr(`${JSON.stringify(sanitizeCliError(error))}\n`);
    return 2;
  }
}
