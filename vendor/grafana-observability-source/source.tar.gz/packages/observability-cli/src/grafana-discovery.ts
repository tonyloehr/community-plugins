import {
  normalizeGrafanaOrigin,
  type GrafanaNetworkClass,
} from "../../grafana-credential-profile/src/index.ts";
import {
  NodeTrustedHttpClient,
  type RuntimeDnsResolver,
  type TrustedHttpResponse,
} from "../../provider-runtime/src/http-transport.ts";

export type CertifiedGrafanaDatasourceType =
  | "prometheus"
  | "loki"
  | "tempo"
  | "postgres"
  | "grafana-postgresql-datasource";

type CanonicalGrafanaDatasourceType = "prometheus" | "loki" | "tempo" | "postgres";

export interface GrafanaDatasourcePreview {
  name: string;
  type: CertifiedGrafanaDatasourceType;
}

export interface GrafanaPanelCandidatePreview {
  dashboardTitle: string;
  panelTitle: string;
  panelId: number;
  datasourceType: CertifiedGrafanaDatasourceType;
}

export interface GrafanaConnectionPreview {
  schemaVersion: "1.0.0";
  grafanaVersion: string;
  permissionState: "READ_ONLY_CONFIRMED" | "READ_ACCESS_UNVERIFIED";
  datasources: GrafanaDatasourcePreview[];
  proposedCapabilityPackIds: string[];
  panelCandidates: GrafanaPanelCandidatePreview[];
  warnings: string[];
}

export interface GrafanaConnectionDiscovery {
  inspect(input: Readonly<{
    grafanaOrigin: string;
    bearerSecret: Uint8Array;
  }>): Promise<Readonly<GrafanaConnectionPreview>>;
}

export class GrafanaDiscoveryError extends Error {
  readonly code:
    | "AUTHENTICATION_REJECTED"
    | "PERMISSION_REJECTED"
    | "UNSUPPORTED_VERSION"
    | "OVER_PRIVILEGED"
    | "UNAVAILABLE"
    | "INVALID_RESPONSE";

  constructor(code: GrafanaDiscoveryError["code"]) {
    super("Grafana connection discovery failed safely");
    this.name = "GrafanaDiscoveryError";
    this.code = code;
  }
}

const MAX_RESPONSE_BYTES = 1_048_576;
const MAX_DATASOURCES = 128;
const MAX_DASHBOARDS = 20;
const MAX_PANELS = 256;
const MAX_TEXT = 120;
const MAX_PERMISSION_ACTIONS = 512;
const MAX_PERMISSION_SCOPES = 2_048;
const MAX_JSON_NODES = 100_000;
const SAFE_UID = /^[A-Za-z0-9_-]{1,128}$/u;
const SAFE_PERMISSION_ACTION = /^[a-z0-9*_.:-]{1,160}$/u;
const SUPPORTED_VERSION = /^(10|11|12|13)\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})(?:[-+][0-9A-Za-z.-]{1,64})?$/u;
const CERTIFIED_TYPES = new Set<CertifiedGrafanaDatasourceType>([
  "prometheus",
  "loki",
  "tempo",
  "postgres",
  "grafana-postgresql-datasource",
]);
const PACK_ORDER = [
  "grafana.infrastructure",
  "grafana.apm",
  "grafana.logs",
  "grafana.iot-edge",
  "grafana.business-kpis",
] as const;
const DISCOVERY_CREDENTIAL_REFERENCE = Object.freeze({
  kind: "broker" as const,
  key: "grafana-discovery:ephemeral:bearer:v1",
});

export interface GrafanaDiscoveryTransport {
  get(
    pathname: string,
    query: Readonly<Record<string, string>>,
    signal: AbortSignal,
    requestedMaxBytes: number,
  ): Promise<TrustedHttpResponse>;
}

export interface GrafanaDiscoveryTransportFactoryInput {
  grafanaOrigin: string;
  networkClass: GrafanaNetworkClass;
}

export type GrafanaDiscoveryTransportFactory = (
  input: Readonly<GrafanaDiscoveryTransportFactoryInput>,
) => GrafanaDiscoveryTransport;

function object(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function safeText(value: unknown, fallback: string): string {
  if (typeof value !== "string") return fallback;
  const printable = [...value].map((character) => {
    const codePoint = character.codePointAt(0)!;
    return codePoint < 0x20 || codePoint === 0x7f ? " " : character;
  }).join("");
  const normalized = printable.replace(/\s+/gu, " ").trim();
  if (normalized.length === 0) return fallback;
  return normalized.slice(0, MAX_TEXT);
}

function certifiedType(value: unknown): CertifiedGrafanaDatasourceType | undefined {
  return typeof value === "string" && CERTIFIED_TYPES.has(value as CertifiedGrafanaDatasourceType)
    ? value as CertifiedGrafanaDatasourceType
    : undefined;
}

function canonicalDatasourceType(value: CertifiedGrafanaDatasourceType): CanonicalGrafanaDatasourceType {
  return value === "grafana-postgresql-datasource" ? "postgres" : value;
}

function rejectReflectedSecret(value: unknown, secret: string): void {
  const pending: unknown[] = [value];
  let visited = 0;
  while (pending.length > 0) {
    visited += 1;
    if (visited > MAX_JSON_NODES) throw new GrafanaDiscoveryError("INVALID_RESPONSE");
    const candidate = pending.pop();
    if (typeof candidate === "string") {
      if (candidate.includes(secret)) throw new GrafanaDiscoveryError("INVALID_RESPONSE");
      continue;
    }
    if (Array.isArray(candidate)) {
      pending.push(...candidate);
      continue;
    }
    const record = object(candidate);
    if (record === undefined) continue;
    for (const [key, nested] of Object.entries(record)) {
      if (key.includes(secret)) throw new GrafanaDiscoveryError("INVALID_RESPONSE");
      pending.push(nested);
    }
  }
}

export function assertActivatableGrafanaConnectionPreview(
  preview: Readonly<GrafanaConnectionPreview>,
  bearerSecret: Uint8Array,
): void {
  let secret: string;
  try {
    secret = new TextDecoder("ascii", { fatal: true }).decode(bearerSecret);
  } catch {
    throw new GrafanaDiscoveryError("AUTHENTICATION_REJECTED");
  }
  if (secret.length === 0 || preview.permissionState !== "READ_ONLY_CONFIRMED") {
    throw new GrafanaDiscoveryError("PERMISSION_REJECTED");
  }
  rejectReflectedSecret(preview, secret);
}

async function readWithAbort<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) throw new GrafanaDiscoveryError("UNAVAILABLE");
  return new Promise<T>((resolve, reject) => {
    const aborted = (): void => reject(new GrafanaDiscoveryError("UNAVAILABLE"));
    signal.addEventListener("abort", aborted, { once: true });
    promise.then(resolve, reject).finally(() => signal.removeEventListener("abort", aborted)).catch(() => undefined);
  });
}

function boundedJson(response: TrustedHttpResponse, secret: string): unknown {
  try {
    const declared = response.headers["content-length"];
    if (declared !== undefined && (!/^\d+$/u.test(declared) || Number(declared) > MAX_RESPONSE_BYTES)) {
      throw new GrafanaDiscoveryError("INVALID_RESPONSE");
    }
    if (response.body.byteLength > MAX_RESPONSE_BYTES) throw new GrafanaDiscoveryError("INVALID_RESPONSE");
    const parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(response.body)) as unknown;
    rejectReflectedSecret(parsed, secret);
    return parsed;
  } catch {
    throw new GrafanaDiscoveryError("INVALID_RESPONSE");
  } finally {
    response.body.fill(0);
  }
}

// Exact non-mutating Viewer grants verified against Grafana's tagged built-in role
// definitions and golden permission snapshots for v10.4.19, v11.6.11, v12.4.0,
// and v13.2.0. The plugin grant is defined in each tag at
// pkg/services/pluginsintegration/pluginaccesscontrol/accesscontrol.go; alerting
// role source paths vary by major and are intentionally not encoded here.
// Do not generalize these exceptions by suffix; new actions or scopes require tagged-source review.
const VIEWER_SAFE_NON_READ_ACTIONS: Readonly<Record<number, Readonly<Record<string, readonly string[]>>>> =
  Object.freeze({
    10: Object.freeze({
      "plugins.app:access": Object.freeze(["plugins:*"]),
      "alert.notifications.receivers:list": Object.freeze([""]),
    }),
    11: Object.freeze({
      "plugins.app:access": Object.freeze(["plugins:*"]),
      "alert.notifications.receivers:list": Object.freeze([""]),
    }),
    12: Object.freeze({
      "plugins.app:access": Object.freeze(["plugins:*"]),
      "alert.notifications.receivers:list": Object.freeze([""]),
    }),
    13: Object.freeze({
      "plugins.app:access": Object.freeze(["plugins:*"]),
      "alert.notifications.receivers:list": Object.freeze([""]),
      "notifications.alerting.grafana.app/configs:get": Object.freeze(["configs:*"]),
    }),
  });

function viewerSafeNonReadAction(action: string, scopes: readonly string[], major: number): boolean {
  const allowedScopes = VIEWER_SAFE_NON_READ_ACTIONS[major]?.[action];
  return allowedScopes !== undefined && scopes.length > 0 &&
    scopes.every((scope) => allowedScopes.includes(scope));
}

function permissionState(value: unknown, major: number): "READ_ONLY_CONFIRMED" {
  const permissions = object(value);
  if (permissions === undefined || Object.keys(permissions).length > MAX_PERMISSION_ACTIONS) {
    throw new GrafanaDiscoveryError("PERMISSION_REJECTED");
  }
  const active = new Set<string>();
  let scopeCount = 0;
  for (const [action, scopes] of Object.entries(permissions)) {
    const exactVersionedViewerAction = Object.hasOwn(VIEWER_SAFE_NON_READ_ACTIONS[major] ?? {}, action);
    if ((!SAFE_PERMISSION_ACTION.test(action) && !exactVersionedViewerAction) || !Array.isArray(scopes)) {
      throw new GrafanaDiscoveryError("PERMISSION_REJECTED");
    }
    scopeCount += scopes.length;
    if (
      scopeCount > MAX_PERMISSION_SCOPES
      || scopes.some((scope) => typeof scope !== "string" || scope.length > 512)
    ) {
      throw new GrafanaDiscoveryError("PERMISSION_REJECTED");
    }
    if (scopes.length === 0) continue;
    active.add(action);
    const readOnlyAction = action.endsWith(":read")
      || action === "datasources:query"
      || action === "datasources:explore"
      || viewerSafeNonReadAction(action, scopes, major);
    if (!readOnlyAction) throw new GrafanaDiscoveryError("OVER_PRIVILEGED");
  }
  if (!active.has("datasources:read") || !active.has("datasources:query")) {
    throw new GrafanaDiscoveryError("PERMISSION_REJECTED");
  }
  return "READ_ONLY_CONFIRMED";
}

function proposedPacks(types: ReadonlySet<CertifiedGrafanaDatasourceType>): string[] {
  const canonicalTypes = new Set([...types].map(canonicalDatasourceType));
  const selected = new Set<string>();
  if (canonicalTypes.has("prometheus")) {
    selected.add("grafana.infrastructure");
    selected.add("grafana.apm");
  }
  if (canonicalTypes.has("loki")) selected.add("grafana.logs");
  if (canonicalTypes.has("tempo")) selected.add("grafana.apm");
  if (canonicalTypes.has("postgres")) {
    selected.add("grafana.iot-edge");
    selected.add("grafana.business-kpis");
  }
  return PACK_ORDER.filter((packId) => selected.has(packId));
}

function collectPanels(
  value: unknown,
  dashboardTitle: string,
  output: GrafanaPanelCandidatePreview[],
  depth = 0,
): void {
  if (!Array.isArray(value) || depth > 8 || output.length >= MAX_PANELS) return;
  for (const candidate of value) {
    if (output.length >= MAX_PANELS) return;
    const panel = object(candidate);
    if (panel === undefined) continue;
    collectPanels(panel.panels, dashboardTitle, output, depth + 1);
    if (
      !Number.isSafeInteger(panel.id)
      || (panel.id as number) < 1
      || !Array.isArray(panel.targets)
      || panel.targets.length !== 1
      || panel.libraryPanel !== undefined
      || (Array.isArray(panel.transformations) && panel.transformations.length > 0)
    ) continue;
    const target = object(panel.targets[0]);
    const datasource = object(target?.datasource ?? panel.datasource);
    const type = certifiedType(datasource?.type);
    if (target === undefined || target.refId !== "A" || target.hide === true || type === undefined) continue;
    output.push({
      dashboardTitle,
      panelTitle: safeText(panel.title, `Panel ${String(panel.id)}`),
      panelId: panel.id as number,
      datasourceType: type,
    });
  }
}

export class HttpGrafanaConnectionDiscovery implements GrafanaConnectionDiscovery {
  readonly #timeoutMs: number;
  readonly #resolver: RuntimeDnsResolver | undefined;
  readonly #transportFactory: GrafanaDiscoveryTransportFactory | undefined;

  constructor(options: {
    timeoutMs?: number;
    resolver?: RuntimeDnsResolver;
    transportFactory?: GrafanaDiscoveryTransportFactory;
  } = {}) {
    this.#timeoutMs = options.timeoutMs ?? 10_000;
    this.#resolver = options.resolver;
    this.#transportFactory = options.transportFactory;
    if (!Number.isSafeInteger(this.#timeoutMs) || this.#timeoutMs < 1 || this.#timeoutMs > 30_000) {
      throw new GrafanaDiscoveryError("UNAVAILABLE");
    }
  }

  async inspect(input: Readonly<{
    grafanaOrigin: string;
    bearerSecret: Uint8Array;
  }>): Promise<Readonly<GrafanaConnectionPreview>> {
    if (input.bearerSecret.byteLength < 1 || input.bearerSecret.byteLength > 16_384) {
      throw new GrafanaDiscoveryError("AUTHENTICATION_REJECTED");
    }
    let token: string;
    try {
      token = new TextDecoder("ascii", { fatal: true }).decode(input.bearerSecret);
    } catch {
      throw new GrafanaDiscoveryError("AUTHENTICATION_REJECTED");
    }
    if ([...token].some((character) => character.charCodeAt(0) < 0x21 || character.charCodeAt(0) > 0x7e)) {
      throw new GrafanaDiscoveryError("AUTHENTICATION_REJECTED");
    }
    let grafanaOrigin: string;
    let networkClass: GrafanaNetworkClass;
    let hostname: string;
    try {
      const normalized = normalizeGrafanaOrigin(input.grafanaOrigin);
      if (normalized.grafanaOrigin !== input.grafanaOrigin) throw new GrafanaDiscoveryError("UNAVAILABLE");
      grafanaOrigin = normalized.grafanaOrigin;
      networkClass = normalized.networkClass;
      hostname = new URL(grafanaOrigin).hostname;
    } catch {
      throw new GrafanaDiscoveryError("UNAVAILABLE");
    }
    let transport: GrafanaDiscoveryTransport;
    try {
      transport = this.#transportFactory === undefined
        ? new NodeTrustedHttpClient({
            endpoint: {
              endpointId: "grafana-discovery",
              adapterId: "adapter.grafana.v1",
              baseUrl: grafanaOrigin,
              authentication: {
                mode: "BEARER",
                tokenRef: DISCOVERY_CREDENTIAL_REFERENCE,
              },
              tls: { minimumVersion: "TLSv1.2" },
              network: {
                followRedirects: false,
                allowLoopbackHttp: networkClass === "loopback",
                allowedHosts: [hostname],
                networkClass,
                routeMode: "direct",
              },
            },
            metadata: {},
            // Discovery credentials are supplied only by the interactive caller through
            // this exact in-memory broker reference. Ambient environment values are ignored.
            environment: {},
            credentialResolver: {
              resolve(reference) {
                return reference.kind === DISCOVERY_CREDENTIAL_REFERENCE.kind
                  && reference.key === DISCOVERY_CREDENTIAL_REFERENCE.key
                  ? token
                  : undefined;
              },
            },
            timeoutMs: this.#timeoutMs,
            maxResponseBytes: MAX_RESPONSE_BYTES,
            ...(this.#resolver === undefined ? {} : { resolver: this.#resolver }),
          })
        : this.#transportFactory({ grafanaOrigin, networkClass });
    } catch {
      throw new GrafanaDiscoveryError("UNAVAILABLE");
    }
    const request = async (
      path: string,
      accessPolicy: "required" | "optional" | "permission-proof" = "required",
      query: Readonly<Record<string, string>> = {},
    ): Promise<unknown | undefined> => {
      if (!path.startsWith("/api/") || path.includes("?") || path.includes("#")) {
        throw new GrafanaDiscoveryError("INVALID_RESPONSE");
      }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.#timeoutMs);
      try {
        const response = await readWithAbort(
          transport.get(path, query, controller.signal, MAX_RESPONSE_BYTES),
          controller.signal,
        );
        if (response.status === 401) {
          response.body.fill(0);
          throw new GrafanaDiscoveryError("AUTHENTICATION_REJECTED");
        }
        if (accessPolicy === "optional" && [403, 404, 405].includes(response.status)) {
          response.body.fill(0);
          return undefined;
        }
        if (
          response.status === 403
          || (accessPolicy === "permission-proof" && [404, 405].includes(response.status))
        ) {
          response.body.fill(0);
          throw new GrafanaDiscoveryError("PERMISSION_REJECTED");
        }
        if (response.status < 200 || response.status >= 300) {
          response.body.fill(0);
          throw new GrafanaDiscoveryError("UNAVAILABLE");
        }
        return boundedJson(response, token);
      } catch (error) {
        if (error instanceof GrafanaDiscoveryError) throw error;
        throw new GrafanaDiscoveryError("UNAVAILABLE");
      } finally {
        clearTimeout(timer);
      }
    };

    const health = object(await request("/api/health"));
    const version = health?.version;
    if (health?.database !== "ok" || typeof version !== "string" || !SUPPORTED_VERSION.test(version)) {
      throw new GrafanaDiscoveryError("UNSUPPORTED_VERSION");
    }
    const major = Number(version.split(".", 1)[0]);
    const datasourceResponse = await request("/api/datasources");
    if (!Array.isArray(datasourceResponse) || datasourceResponse.length > MAX_DATASOURCES) {
      throw new GrafanaDiscoveryError("INVALID_RESPONSE");
    }
    const datasources = datasourceResponse.flatMap((candidate, index): GrafanaDatasourcePreview[] => {
      const entry = object(candidate);
      const type = certifiedType(entry?.type);
      return type === undefined ? [] : [{ name: safeText(entry?.name, `Datasource ${index + 1}`), type }];
    });
    const types = new Set(datasources.map((datasource) => datasource.type));
    const permissions = await request("/api/access-control/user/permissions", "permission-proof");
    const access = permissionState(permissions, major);
    const warnings: string[] = [];
    if (major === 13) warnings.push("Grafana 13 uses the certified legacy /api query path, which is deprecated for a future major.");
    if ([...types].some((type) => canonicalDatasourceType(type) === "postgres")) {
      warnings.push("PostgreSQL datasources require an independently restricted SELECT-only database identity.");
    }

    const panelCandidates: GrafanaPanelCandidatePreview[] = [];
    const searchResponse = await request("/api/search", "optional", {
      type: "dash-db",
      limit: String(MAX_DASHBOARDS),
    });
    if (Array.isArray(searchResponse)) {
      for (const result of searchResponse.slice(0, MAX_DASHBOARDS)) {
        const dashboardSummary = object(result);
        const uid = dashboardSummary?.uid;
        if (typeof uid !== "string" || !SAFE_UID.test(uid)) continue;
        const exported = object(await request(`/api/dashboards/uid/${encodeURIComponent(uid)}`, "optional"));
        const dashboard = object(exported?.dashboard);
        if (dashboard === undefined) continue;
        const templating = object(dashboard.templating);
        if (Array.isArray(templating?.list) && templating.list.length > 0) continue;
        collectPanels(
          dashboard.panels,
          safeText(dashboard.title ?? dashboardSummary?.title, "Untitled dashboard"),
          panelCandidates,
        );
      }
    }

    const preview = Object.freeze({
      schemaVersion: "1.0.0",
      grafanaVersion: version,
      permissionState: access,
      datasources: datasources.sort((left, right) => left.type.localeCompare(right.type) || left.name.localeCompare(right.name)),
      proposedCapabilityPackIds: proposedPacks(types),
      panelCandidates: panelCandidates
        .sort((left, right) => left.dashboardTitle.localeCompare(right.dashboardTitle) || left.panelId - right.panelId)
        .slice(0, MAX_PANELS),
      warnings,
    });
    assertActivatableGrafanaConnectionPreview(preview, input.bearerSecret);
    return preview;
  }
}
