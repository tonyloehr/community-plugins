export interface SecretTtyInput {
  readonly isTTY?: boolean;
  setRawMode?(mode: boolean): unknown;
  on(event: "data", listener: (chunk: Buffer) => void): unknown;
  once(event: "error" | "end", listener: (error?: Error) => void): unknown;
  removeListener(event: "data" | "error" | "end", listener: (...args: unknown[]) => void): unknown;
  resume(): unknown;
  pause(): unknown;
}

export interface SecretTtyOutput {
  readonly isTTY?: boolean;
  write(value: string): unknown;
}

export class TtySecretError extends Error {
  readonly code: "TTY_REQUIRED" | "TTY_CANCELLED" | "INVALID_SECRET" | "TTY_FAILED";

  constructor(code: TtySecretError["code"]) {
    super("Interactive secret entry failed");
    this.name = "TtySecretError";
    this.code = code;
  }
}

const MAX_SECRET_BYTES = 16_384;

export async function readSecretFromTty(
  input: SecretTtyInput,
  output: SecretTtyOutput,
  prompt = "Grafana bearer token: ",
): Promise<Uint8Array> {
  if (input.isTTY !== true || output.isTTY !== true || typeof input.setRawMode !== "function") {
    throw new TtySecretError("TTY_REQUIRED");
  }
  output.write(prompt);
  const scratch = Buffer.alloc(MAX_SECRET_BYTES);
  let length = 0;
  return new Promise<Uint8Array>((resolve, reject) => {
    let settled = false;
    const cleanup = (): void => {
      input.removeListener("data", onData as (...args: unknown[]) => void);
      input.removeListener("error", onError as (...args: unknown[]) => void);
      input.removeListener("end", onEnd as (...args: unknown[]) => void);
      try {
        input.setRawMode?.(false);
      } catch {
        // The operation has already failed closed; terminal recovery is best effort.
      }
      input.pause();
      output.write("\n");
    };
    const finish = (error?: TtySecretError): void => {
      if (settled) return;
      settled = true;
      cleanup();
      if (error !== undefined) {
        scratch.fill(0);
        reject(error);
        return;
      }
      const result = Uint8Array.from(scratch.subarray(0, length));
      scratch.fill(0);
      resolve(result);
    };
    const onError = (): void => finish(new TtySecretError("TTY_FAILED"));
    const onEnd = (): void => finish(new TtySecretError("TTY_FAILED"));
    const onData = (chunk: Buffer): void => {
      if (!Buffer.isBuffer(chunk)) {
        finish(new TtySecretError("TTY_FAILED"));
        return;
      }
      for (const byte of chunk) {
        if (byte === 0x03) {
          finish(new TtySecretError("TTY_CANCELLED"));
          return;
        }
        if (byte === 0x0a || byte === 0x0d) {
          finish(length === 0 ? new TtySecretError("INVALID_SECRET") : undefined);
          return;
        }
        if (byte === 0x08 || byte === 0x7f) {
          if (length > 0) {
            length -= 1;
            scratch[length] = 0;
          }
          continue;
        }
        if (byte < 0x21 || byte > 0x7e || length >= scratch.byteLength) {
          finish(new TtySecretError("INVALID_SECRET"));
          return;
        }
        scratch[length] = byte;
        length += 1;
      }
    };
    input.on("data", onData);
    input.once("error", onError);
    input.once("end", onEnd);
    try {
      input.setRawMode!(true);
      input.resume();
    } catch {
      finish(new TtySecretError("TTY_FAILED"));
    }
  });
}

export async function confirmSharedProfileDeletion(
  input: SecretTtyInput,
  output: SecretTtyOutput,
): Promise<boolean> {
  const confirmation = await readSecretFromTty(
    input,
    output,
    "This credential may be shared by two plugins. Type DELETE to continue: ",
  );
  try {
    return Buffer.from(confirmation).toString("ascii") === "DELETE";
  } finally {
    confirmation.fill(0);
  }
}

export async function confirmSharedProfileActivation(
  input: SecretTtyInput,
  output: SecretTtyOutput,
): Promise<boolean> {
  const confirmation = await readSecretFromTty(
    input,
    output,
    "Review the non-secret discovery preview above. Type ACTIVATE to connect: ",
  );
  try {
    return Buffer.from(confirmation).toString("ascii") === "ACTIVATE";
  } finally {
    confirmation.fill(0);
  }
}
