export const OBSERVABILITY_CLI_VERSION = "0.1.0";

/** Informational commands must not initialize a platform credential backend. */
export function observabilityCliInformation(argv: readonly string[]): string | undefined {
  if (argv.length === 1 && argv[0] === "--version") return `${OBSERVABILITY_CLI_VERSION}\n`;
  if (argv.length === 0 || (argv.length === 1 && argv[0] === "--help")) return observabilityCliHelp();
  return undefined;
}

export function observabilityCliHelp(): string {
  return `observabilityctl ${OBSERVABILITY_CLI_VERSION}

Usage:
  observabilityctl grafana connect --url <origin> --profile <name> [--json]
  observabilityctl grafana status [--profile <name>] [--json]
  observabilityctl grafana rotate [--profile <name>] [--json]
  observabilityctl grafana delete [--profile <name>] [--json]
  observabilityctl --version

Grafana bearer tokens are accepted only through the interactive terminal prompt.
Token flags, environment variables, files, clipboard input, and piped stdin are not supported.
`;
}
