import { URL, pathToFileURL } from "node:url";

import {
  GrafanaCredentialKeyring,
  HashPinnedMacOsKeychainLoader,
  NativeGrafanaKeyringBackend,
  SharedGrafanaProfileStore,
  type NativeKeyringModuleLoader,
} from "../../grafana-credential-profile/src/index.ts";

import { runObservabilityCli, type ObservabilityCliIo } from "./main.ts";
import { HttpGrafanaConnectionDiscovery } from "./grafana-discovery.ts";
import { observabilityCliInformation } from "./help.ts";

export const BUNDLED_MACOS_KEYCHAIN_ASSETS = Object.freeze({
  arm64: Object.freeze({
    bytes: 491_232,
    sha256: "9627560bd2490b8495504df6b48dafe0153883aab09fd8eee976f826c74a6fff",
  }),
  x64: Object.freeze({
    bytes: 516_004,
    sha256: "3ad3b083cab321be04223e7fa1a22a8258c32c4da0883886683e25dcba9d03cc",
  }),
});

export function createBundledMacOsKeychainLoader(options: {
  platform?: NodeJS.Platform;
  architecture?: NodeJS.Architecture;
} = {}): NativeKeyringModuleLoader {
  const platform = options.platform ?? process.platform;
  const architecture = options.architecture ?? process.arch;
  if (architecture === "arm64") {
    return new HashPinnedMacOsKeychainLoader({
      platform,
      architecture,
      asset: {
        fileUrl: new URL("../native/keyring.darwin-arm64.node", import.meta.url),
        ...BUNDLED_MACOS_KEYCHAIN_ASSETS.arm64,
      },
    });
  }
  if (architecture === "x64") {
    return new HashPinnedMacOsKeychainLoader({
      platform,
      architecture,
      asset: {
        fileUrl: new URL("../native/keyring.darwin-x64.node", import.meta.url),
        ...BUNDLED_MACOS_KEYCHAIN_ASSETS.x64,
      },
    });
  }
  // The loader itself enforces the supported platform and architecture set.
  return new HashPinnedMacOsKeychainLoader({
    platform,
    architecture,
    asset: {
      fileUrl: new URL("../native/keyring.darwin-arm64.node", import.meta.url),
      ...BUNDLED_MACOS_KEYCHAIN_ASSETS.arm64,
    },
  });
}

export async function runObservabilityCliEntrypoint(options: {
  argv?: readonly string[];
  io?: ObservabilityCliIo;
  nativeLoader?: NativeKeyringModuleLoader;
  platform?: NodeJS.Platform;
} = {}): Promise<number> {
  const io = options.io ?? {
    stdin: process.stdin,
    stdout: process.stdout,
    stderr: process.stderr,
  };
  const argv = options.argv ?? process.argv.slice(2);
  const information = observabilityCliInformation(argv);
  if (information !== undefined) {
    io.stdout.write(information);
    return 0;
  }
  const backend = new NativeGrafanaKeyringBackend({
    loader: options.nativeLoader ?? createBundledMacOsKeychainLoader(
      options.platform === undefined ? {} : { platform: options.platform },
    ),
    ...(options.platform === undefined ? {} : { platform: options.platform }),
  });
  return runObservabilityCli(argv, {
    profileStore: new SharedGrafanaProfileStore(
      options.platform === undefined ? {} : { platform: options.platform },
    ),
    credentialStore: new GrafanaCredentialKeyring(backend),
    connectionDiscovery: new HttpGrafanaConnectionDiscovery(),
    io,
  });
}

const directlyExecuted = process.argv[1] !== undefined
  && pathToFileURL(process.argv[1]).href === import.meta.url;

if (directlyExecuted) {
  // Credential commands admit only the code-owned, hash-pinned native asset;
  // informational commands remain usable on unsupported credential platforms.
  void Promise.resolve().then(() => runObservabilityCliEntrypoint()).then((exitCode) => {
    process.exitCode = exitCode;
  }).catch(() => {
    process.stderr.write("The shared Grafana credential store is unavailable.\n");
    process.exitCode = 1;
  });
}
