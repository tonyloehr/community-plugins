import { randomUUID } from "node:crypto";

import {
  addSharedGrafanaProfile,
  committedGrafanaCredentialLifecycleJournal,
  grafanaCredentialLifecycleAuthority,
  createSharedGrafanaProfile,
  findSharedGrafanaProfile,
  grafanaCredentialReference,
  GrafanaKeyringError,
  GrafanaProfileError,
  GrafanaProfileStoreError,
  normalizeGrafanaProfileName,
  removeSharedGrafanaProfile,
  replaceSharedGrafanaProfile,
  type GrafanaCredentialLifecycleJournalV1,
  type GrafanaCredentialStore,
  type GrafanaCredentialReference,
  type SharedGrafanaProfileRegistryTransaction,
  type SharedGrafanaProfileRegistryStore,
  type SharedGrafanaProfileV1,
} from "../../grafana-credential-profile/src/index.ts";

import {
  assertActivatableGrafanaConnectionPreview,
  GrafanaDiscoveryError,
  type GrafanaConnectionDiscovery,
  type GrafanaConnectionPreview,
} from "./grafana-discovery.ts";
import { observabilityCliInformation } from "./help.ts";
import {
  confirmSharedProfileActivation,
  confirmSharedProfileDeletion,
  readSecretFromTty,
  type SecretTtyInput,
  type SecretTtyOutput,
  TtySecretError,
} from "./tty-secret.ts";

export interface ObservabilityCliIo {
  stdin: SecretTtyInput;
  stdout: SecretTtyOutput;
  stderr: Pick<SecretTtyOutput, "write">;
}

export interface ObservabilityCliDependencies {
  profileStore: SharedGrafanaProfileRegistryStore;
  credentialStore: GrafanaCredentialStore;
  io: ObservabilityCliIo;
  createProfileId?: () => string;
  promptSecret?: () => Promise<Uint8Array>;
  connectionDiscovery?: GrafanaConnectionDiscovery;
  confirmActivation?: (preview: Readonly<GrafanaConnectionPreview>) => Promise<boolean>;
  confirmDelete?: () => Promise<boolean>;
}

class CliUsageError extends Error {
  constructor() {
    super("The command arguments are invalid");
    this.name = "CliUsageError";
  }
}

interface ParsedOptions {
  profile?: string;
  url?: string;
  json: boolean;
}

function parseOptions(
  argv: readonly string[],
  allowed: ReadonlySet<"profile" | "url" | "json">,
): ParsedOptions {
  const parsed: ParsedOptions = { json: false };
  const seen = new Set<string>();
  for (let index = 0; index < argv.length; index += 1) {
    const flag = argv[index]!;
    if (!flag.startsWith("--") || /token|password|secret|credential/iu.test(flag)) {
      throw new CliUsageError();
    }
    const name = flag.slice(2);
    if (!allowed.has(name as "profile" | "url" | "json") || seen.has(name) || flag.includes("=")) {
      throw new CliUsageError();
    }
    seen.add(name);
    if (name === "json") {
      parsed.json = true;
      continue;
    }
    const value = argv[index + 1];
    if (value === undefined || value.length === 0 || value.startsWith("--") || value.length > 2_048) {
      throw new CliUsageError();
    }
    index += 1;
    if (name === "profile") parsed.profile = value;
    else parsed.url = value;
  }
  return parsed;
}

function profileProjection(profile: Readonly<SharedGrafanaProfileV1>): Record<string, unknown> {
  return {
    profileId: profile.profileId,
    profileName: profile.profileName,
    grafanaOrigin: profile.grafanaOrigin,
    networkClass: profile.networkClass,
    revision: profile.revision,
  };
}

function writeResult(
  dependencies: ObservabilityCliDependencies,
  options: ParsedOptions,
  result: Record<string, unknown>,
): void {
  if (options.json) {
    dependencies.io.stdout.write(`${JSON.stringify({ schemaVersion: "1.0.0", ...result })}\n`);
    return;
  }
  const profile = result.profile as ReturnType<typeof profileProjection> | undefined;
  const lines = [String(result.message ?? "Grafana credential operation completed.")];
  if (profile !== undefined) {
    lines.push(`Profile: ${String(profile.profileName)}`);
    lines.push(`Grafana: ${String(profile.grafanaOrigin)}`);
    lines.push(`Revision: ${String(profile.revision)}`);
  }
  if (typeof result.credentialStatus === "string") lines.push(`Credential: ${result.credentialStatus}`);
  if (typeof result.credentialReference === "string") lines.push(`Credential reference: ${result.credentialReference}`);
  dependencies.io.stdout.write(`${lines.join("\n")}\n`);
}

function safeError(error: unknown): { message: string; exitCode: number } {
  if (error instanceof CliUsageError) return { message: "Invalid arguments. Use observabilityctl --help.", exitCode: 2 };
  if (error instanceof TtySecretError && error.code === "TTY_REQUIRED") {
    return { message: "An interactive terminal is required for credential entry.", exitCode: 1 };
  }
  if (error instanceof TtySecretError && error.code === "TTY_CANCELLED") {
    return { message: "Credential entry was cancelled.", exitCode: 1 };
  }
  if (error instanceof GrafanaProfileError && error.code === "PROFILE_NOT_FOUND") {
    return { message: "No matching shared Grafana profile is configured.", exitCode: 1 };
  }
  if (error instanceof GrafanaProfileError && error.code === "PROFILE_ALREADY_EXISTS") {
    return { message: "A shared Grafana profile with that name already exists.", exitCode: 1 };
  }
  if (error instanceof GrafanaKeyringError || error instanceof GrafanaProfileStoreError) {
    return { message: "The shared Grafana credential store is unavailable.", exitCode: 1 };
  }
  if (error instanceof GrafanaDiscoveryError) {
    if (error.code === "AUTHENTICATION_REJECTED") {
      return { message: "Grafana rejected the proposed read credential.", exitCode: 1 };
    }
    if (error.code === "UNSUPPORTED_VERSION") {
      return { message: "This Grafana version is outside the certified 10 through 13 range.", exitCode: 1 };
    }
    if (error.code === "OVER_PRIVILEGED") {
      return { message: "The Grafana credential exposes write or administrative authority; use a least-privilege read identity.", exitCode: 1 };
    }
    if (error.code === "PERMISSION_REJECTED") {
      return { message: "Grafana could not prove the required least-privilege datasource read and query permissions.", exitCode: 1 };
    }
    return { message: "Grafana discovery was unavailable or returned an invalid bounded response.", exitCode: 1 };
  }
  return { message: "The Grafana credential operation failed safely.", exitCode: 1 };
}

async function prompt(dependencies: ObservabilityCliDependencies): Promise<Uint8Array> {
  return dependencies.promptSecret === undefined
    ? readSecretFromTty(dependencies.io.stdin, dependencies.io.stdout)
    : dependencies.promptSecret();
}

async function confirmDelete(dependencies: ObservabilityCliDependencies): Promise<boolean> {
  return dependencies.confirmDelete === undefined
    ? confirmSharedProfileDeletion(dependencies.io.stdin, dependencies.io.stdout)
    : dependencies.confirmDelete();
}

function writeConnectionPreview(
  options: ParsedOptions,
  dependencies: ObservabilityCliDependencies,
  preview: Readonly<GrafanaConnectionPreview>,
): void {
  if (options.json) {
    dependencies.io.stdout.write(`${JSON.stringify({ event: "GRAFANA_DISCOVERY_PREVIEW", ...preview })}\n`);
    return;
  }
  const lines = [
    "Grafana discovery preview (no credential values):",
    `Version: ${preview.grafanaVersion}`,
    `Permissions: ${preview.permissionState}`,
    `Certified datasources: ${preview.datasources.length === 0 ? "none" : preview.datasources.map((item) => `${item.name} (${item.type})`).join(", ")}`,
    `Proposed packs: ${preview.proposedCapabilityPackIds.length === 0 ? "none" : preview.proposedCapabilityPackIds.join(", ")}`,
    `Eligible saved-panel candidates: ${preview.panelCandidates.length}`,
    ...preview.warnings.map((warning) => `Warning: ${warning}`),
  ];
  dependencies.io.stdout.write(`${lines.join("\n")}\n`);
}

async function confirmActivation(
  options: ParsedOptions,
  dependencies: ObservabilityCliDependencies,
  preview: Readonly<GrafanaConnectionPreview>,
): Promise<boolean> {
  writeConnectionPreview(options, dependencies, preview);
  return dependencies.confirmActivation === undefined
    ? confirmSharedProfileActivation(dependencies.io.stdin, dependencies.io.stdout)
    : dependencies.confirmActivation(preview);
}

type LifecycleRecovery = "NONE" | "ROLLED_BACK" | "COMMITTED";

function sameCredentialReference(
  left: Readonly<GrafanaCredentialReference>,
  right: Readonly<GrafanaCredentialReference>,
): boolean {
  return left.kind === right.kind && left.key === right.key;
}

async function requireCredential(
  credentialStore: GrafanaCredentialStore,
  reference: Readonly<GrafanaCredentialReference> | null,
): Promise<void> {
  if (reference === null) return;
  const lease = await credentialStore.acquire(reference);
  if (lease === undefined) throw new GrafanaKeyringError("KEYRING_UNAVAILABLE");
  lease.dispose();
}

async function cleanupCredential(
  credentialStore: GrafanaCredentialStore,
  reference: Readonly<GrafanaCredentialReference> | null,
): Promise<void> {
  if (reference !== null) await credentialStore.delete(reference);
}

async function recoverCredentialLifecycle(
  transaction: SharedGrafanaProfileRegistryTransaction,
  credentialStore: GrafanaCredentialStore,
): Promise<LifecycleRecovery> {
  const journal = transaction.readCredentialLifecycleJournal();
  if (journal === undefined) return "NONE";
  const authority = grafanaCredentialLifecycleAuthority(transaction.read(), journal);
  if (authority === "INVALID") throw new GrafanaProfileStoreError("UNSAFE_STATE");

  if (journal.phase === "PREPARED" && authority === "PREVIOUS") {
    await cleanupCredential(credentialStore, journal.nextCredentialRef);
    await requireCredential(credentialStore, journal.previousCredentialRef);
    await transaction.clearCredentialLifecycleJournal();
    return "ROLLED_BACK";
  }
  if (authority !== "NEXT") throw new GrafanaProfileStoreError("UNSAFE_STATE");
  await requireCredential(credentialStore, journal.nextCredentialRef);
  if (journal.phase === "PREPARED") {
    await transaction.writeCredentialLifecycleJournal(
      committedGrafanaCredentialLifecycleJournal(journal),
    );
  }
  await cleanupCredential(credentialStore, journal.previousCredentialRef);
  await transaction.clearCredentialLifecycleJournal();
  return "COMMITTED";
}

async function runPreparedCredentialLifecycle(
  transaction: SharedGrafanaProfileRegistryTransaction,
  credentialStore: GrafanaCredentialStore,
  journal: Readonly<GrafanaCredentialLifecycleJournalV1>,
  stageAndCommitRegistry: () => Promise<void>,
): Promise<void> {
  try {
    await transaction.writeCredentialLifecycleJournal(journal);
    await stageAndCommitRegistry();
    await transaction.writeCredentialLifecycleJournal(
      committedGrafanaCredentialLifecycleJournal(journal),
    );
    await cleanupCredential(credentialStore, journal.previousCredentialRef);
    await transaction.clearCredentialLifecycleJournal();
  } catch (error) {
    const recovery = await recoverCredentialLifecycle(transaction, credentialStore);
    if (recovery !== "COMMITTED") throw error;
  }
}

async function connect(
  options: ParsedOptions,
  dependencies: ObservabilityCliDependencies,
): Promise<void> {
  if (options.url === undefined || options.profile === undefined) throw new CliUsageError();
  const grafanaOrigin = options.url;
  const profileName = normalizeGrafanaProfileName(options.profile);
  await dependencies.profileStore.withExclusiveLifecycle(async (transaction) => {
    await recoverCredentialLifecycle(transaction, dependencies.credentialStore);
    const current = transaction.read();
    if (current.profiles.some((profile) => profile.profileName.toLowerCase() === profileName.toLowerCase())) {
      throw new GrafanaProfileError("PROFILE_ALREADY_EXISTS");
    }
    const profile = createSharedGrafanaProfile({
      profileId: (dependencies.createProfileId ?? randomUUID)(),
      profileName,
      grafanaOrigin,
    });
    if (current.profiles.some((candidate) => candidate.profileId === profile.profileId)) {
      throw new GrafanaProfileError("PROFILE_ALREADY_EXISTS");
    }
    const secret = await prompt(dependencies);
    try {
      if (dependencies.connectionDiscovery === undefined) {
        throw new GrafanaDiscoveryError("UNAVAILABLE");
      }
      const preview = await dependencies.connectionDiscovery.inspect({
        grafanaOrigin: profile.grafanaOrigin,
        bearerSecret: secret,
      });
      assertActivatableGrafanaConnectionPreview(preview, secret);
      if (!await confirmActivation(options, dependencies, preview)) {
        writeResult(dependencies, options, {
          operation: "connect",
          message: "Shared Grafana profile activation cancelled; no credential or profile was stored.",
        });
        return;
      }
      const journal: GrafanaCredentialLifecycleJournalV1 = {
        schemaVersion: "1.0.0",
        operation: "CONNECT",
        phase: "PREPARED",
        profileId: profile.profileId,
        previousRevision: null,
        previousCredentialRef: null,
        nextRevision: profile.revision,
        nextCredentialRef: profile.credentialRef,
      };
      await runPreparedCredentialLifecycle(
        transaction,
        dependencies.credentialStore,
        journal,
        async () => {
          await dependencies.credentialStore.set(profile.credentialRef, secret);
          await transaction.update((registry) => addSharedGrafanaProfile(registry, profile));
        },
      );
      writeResult(dependencies, options, {
        operation: "connect",
        message: "Shared Grafana profile connected.",
        profile: profileProjection(profile),
        credentialStatus: "AVAILABLE",
        credentialReference: profile.credentialRef.key,
      });
    } finally {
      secret.fill(0);
    }
  });
}

async function status(
  options: ParsedOptions,
  dependencies: ObservabilityCliDependencies,
): Promise<void> {
  if (options.url !== undefined) throw new CliUsageError();
  await dependencies.profileStore.withExclusiveLifecycle(async (transaction) => {
    await recoverCredentialLifecycle(transaction, dependencies.credentialStore);
    const profile = findSharedGrafanaProfile(transaction.read(), options.profile);
    const credentialStatus = await dependencies.credentialStore.status(profile.credentialRef);
    writeResult(dependencies, options, {
      operation: "status",
      message: "Shared Grafana profile status.",
      profile: profileProjection(profile),
      credentialStatus,
    });
  });
}

async function rotate(
  options: ParsedOptions,
  dependencies: ObservabilityCliDependencies,
): Promise<void> {
  if (options.url !== undefined) throw new CliUsageError();
  await dependencies.profileStore.withExclusiveLifecycle(async (transaction) => {
    await recoverCredentialLifecycle(transaction, dependencies.credentialStore);
    const profile = findSharedGrafanaProfile(transaction.read(), options.profile);
    if (profile.revision >= Number.MAX_SAFE_INTEGER) throw new GrafanaProfileError("INVALID_PROFILE");
    const secret = await prompt(dependencies);
    try {
      if (dependencies.connectionDiscovery === undefined) {
        throw new GrafanaDiscoveryError("UNAVAILABLE");
      }
      const preview = await dependencies.connectionDiscovery.inspect({
        grafanaOrigin: profile.grafanaOrigin,
        bearerSecret: secret,
      });
      assertActivatableGrafanaConnectionPreview(preview, secret);
      if (!await confirmActivation(options, dependencies, preview)) {
        writeResult(dependencies, options, {
          operation: "rotate",
          message: "Shared Grafana credential rotation cancelled; the existing credential was retained.",
          profile: profileProjection(profile),
        });
        return;
      }
      await requireCredential(dependencies.credentialStore, profile.credentialRef);
      const nextRevision = profile.revision + 1;
      const updated: SharedGrafanaProfileV1 = {
        ...profile,
        credentialRef: grafanaCredentialReference(profile.profileId, nextRevision),
        revision: nextRevision,
      };
      const journal: GrafanaCredentialLifecycleJournalV1 = {
        schemaVersion: "1.0.0",
        operation: "ROTATE",
        phase: "PREPARED",
        profileId: profile.profileId,
        previousRevision: profile.revision,
        previousCredentialRef: profile.credentialRef,
        nextRevision: updated.revision,
        nextCredentialRef: updated.credentialRef,
      };
      await runPreparedCredentialLifecycle(
        transaction,
        dependencies.credentialStore,
        journal,
        async () => {
          await dependencies.credentialStore.set(updated.credentialRef, secret);
          await transaction.update((registry) => {
            const latest = findSharedGrafanaProfile(registry, profile.profileName);
            if (
              latest.profileId !== profile.profileId
              || latest.revision !== profile.revision
              || !sameCredentialReference(latest.credentialRef, profile.credentialRef)
            ) {
              throw new GrafanaProfileError("INVALID_PROFILE");
            }
            return replaceSharedGrafanaProfile(registry, updated);
          });
        },
      );
      writeResult(dependencies, options, {
        operation: "rotate",
        message: "Shared Grafana credential rotated. Restart provider workers to consume it.",
        profile: profileProjection(updated),
        credentialStatus: "AVAILABLE",
      });
    } finally {
      secret.fill(0);
    }
  });
}

async function remove(
  options: ParsedOptions,
  dependencies: ObservabilityCliDependencies,
): Promise<void> {
  if (options.url !== undefined) throw new CliUsageError();
  await dependencies.profileStore.withExclusiveLifecycle(async (transaction) => {
    await recoverCredentialLifecycle(transaction, dependencies.credentialStore);
    const profile = findSharedGrafanaProfile(transaction.read(), options.profile);
    if (!await confirmDelete(dependencies)) {
      writeResult(dependencies, options, { operation: "delete", message: "Shared Grafana profile deletion cancelled." });
      return;
    }
    await requireCredential(dependencies.credentialStore, profile.credentialRef);
    const journal: GrafanaCredentialLifecycleJournalV1 = {
      schemaVersion: "1.0.0",
      operation: "DELETE",
      phase: "PREPARED",
      profileId: profile.profileId,
      previousRevision: profile.revision,
      previousCredentialRef: profile.credentialRef,
      nextRevision: null,
      nextCredentialRef: null,
    };
    await runPreparedCredentialLifecycle(
      transaction,
      dependencies.credentialStore,
      journal,
      async () => {
        await transaction.update((registry) => {
          const latest = findSharedGrafanaProfile(registry, profile.profileName);
          if (
            latest.profileId !== profile.profileId
            || latest.revision !== profile.revision
            || !sameCredentialReference(latest.credentialRef, profile.credentialRef)
          ) {
            throw new GrafanaProfileError("INVALID_PROFILE");
          }
          return removeSharedGrafanaProfile(registry, profile.profileId);
        });
      },
    );
    writeResult(dependencies, options, {
      operation: "delete",
      message: "Shared Grafana profile and keyring credential deleted.",
      profile: profileProjection(profile),
    });
  });
}

export async function runObservabilityCli(
  argv: readonly string[],
  dependencies: ObservabilityCliDependencies,
): Promise<number> {
  const information = observabilityCliInformation(argv);
  if (information !== undefined) {
    dependencies.io.stdout.write(information);
    return 0;
  }
  try {
    if (argv[0] !== "grafana" || argv.length < 2) throw new CliUsageError();
    const command = argv[1];
    const commandArguments = argv.slice(2);
    if (command === "connect") {
      const options = parseOptions(commandArguments, new Set(["profile", "url", "json"]));
      await connect(options, dependencies);
    } else if (command === "status") {
      const options = parseOptions(commandArguments, new Set(["profile", "json"]));
      await status(options, dependencies);
    } else if (command === "rotate") {
      const options = parseOptions(commandArguments, new Set(["profile", "json"]));
      await rotate(options, dependencies);
    } else if (command === "delete") {
      const options = parseOptions(commandArguments, new Set(["profile", "json"]));
      await remove(options, dependencies);
    } else {
      throw new CliUsageError();
    }
    return 0;
  } catch (error) {
    const failure = safeError(error);
    dependencies.io.stderr.write(`${failure.message}\n`);
    return failure.exitCode;
  }
}
