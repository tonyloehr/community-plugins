import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

import { createGrafanaObservabilityRuntimeFromEnvironment } from "./runtime.ts";
import { createGrafanaObservabilityMcpServer } from "./server.ts";

interface AsyncCloseOwner {
  close(): Promise<void>;
}

export function createGrafanaStdioShutdown(
  server: AsyncCloseOwner,
  runtime: AsyncCloseOwner,
): () => Promise<void> {
  let shutdownPromise: Promise<void> | undefined;
  return () => {
    shutdownPromise ??= Promise.resolve().then(async () => {
      try {
        await server.close();
      } finally {
        await runtime.close();
      }
    });
    return shutdownPromise;
  };
}

export async function connectGrafanaStdio(
  connect: () => Promise<void>,
  shutdown: () => Promise<void>,
): Promise<void> {
  try {
    await connect();
  } catch (connectError) {
    try {
      await shutdown();
    } catch (shutdownError) {
      throw new AggregateError(
        [connectError, shutdownError],
        "Grafana observability stdio connection and shutdown both failed",
      );
    }
    throw connectError;
  }
}

function reportFailure(prefix: string, error: unknown): void {
  const candidate = error as { code?: unknown; name?: unknown };
  const name = typeof candidate.name === "string"
    ? candidate.name.replaceAll(/[^A-Za-z0-9]+/gu, "_").slice(0, 64)
    : "Error";
  const code = typeof candidate.code === "string" && /^[A-Z][A-Z0-9_]{0,127}$/u.test(candidate.code)
    ? candidate.code
    : "NO_CODE";
  console.error(`${prefix}: ${name}:${code}`);
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length !== 1 || args[0] !== "--stdio") {
    throw new Error("Usage: server.mjs --stdio");
  }
  const runtime = createGrafanaObservabilityRuntimeFromEnvironment();
  const server = createGrafanaObservabilityMcpServer(runtime);
  const transport = new StdioServerTransport();
  const shutdown = createGrafanaStdioShutdown(server, runtime);
  let terminalExitPromise: Promise<void> | undefined;
  const requestTerminalExit = (): void => {
    terminalExitPromise ??= shutdown().then(
      () => { process.exitCode = 0; },
      (error: unknown) => {
        reportFailure("Grafana observability server shutdown failed", error);
        process.exitCode = 1;
      },
    );
    void terminalExitPromise;
  };
  process.once("SIGINT", requestTerminalExit);
  process.once("SIGTERM", requestTerminalExit);
  process.stdin.once("end", requestTerminalExit);
  await connectGrafanaStdio(() => server.connect(transport), shutdown);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error: unknown) => {
    reportFailure("Grafana observability server failed to start", error);
    process.exitCode = 1;
  });
}
