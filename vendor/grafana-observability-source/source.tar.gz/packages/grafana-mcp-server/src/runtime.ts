import { URL } from "node:url";

import {
  sha256Canonical,
  type EvidenceState,
  type RunHandle,
  type WorkbenchEvidenceDetail,
  type WorkbenchEvidenceRef,
  type WorkbenchLinkRef,
  type WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import { createRuntimeFromEnvironment } from "@codex-production-monitoring/evidence-server";
import {
  HashPinnedMacOsKeychainLoader,
  NativeGrafanaKeyringBackend,
  type GrafanaKeyringBackend,
  type NativeKeyringModuleLoader,
} from "../../grafana-credential-profile/src/index.ts";

import {
  capabilityPackId,
  isGrafanaObservabilityPackId,
  type GrafanaEvidenceDetailResult,
  type GrafanaEvidenceRef,
  type GrafanaLinkRef,
  type GrafanaListPacksResult,
  type GrafanaObservabilityRuntime,
  type GrafanaPackSummary,
  type GrafanaProfileStatusResult,
  type GrafanaReportEvidenceCard,
  type GrafanaReportIssue,
  type GrafanaReportRef,
  type GrafanaReportSignal,
  type GrafanaReportStatus,
  type GrafanaResolvedLinkResult,
  type GrafanaRunPackInput,
  type GrafanaRunPackResult,
  type GrafanaRuntimeInternalReport,
  type MonitoringRuntimePort,
} from "./types.ts";

// The shared workbench authority retains at most twenty owned runs. Keeping the
// same bound prevents a report reference from outliving its authoritative run.
const MAX_REPORTS = 20;
const SAFE_NAME = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u;
const URL_TEXT = /https?:\/\/[^\s<>"']+/giu;
const TRUSTED_GRAFANA_ADAPTER_PACKAGE_ID = "adapter.grafana.v1";
const TRUSTED_GRAFANA_PROVIDER = "grafana";

export const BUNDLED_MCP_MACOS_KEYCHAIN_ASSETS = Object.freeze({
  arm64: Object.freeze({
    bytes: 491_232,
    sha256: "9627560bd2490b8495504df6b48dafe0153883aab09fd8eee976f826c74a6fff",
  }),
  x64: Object.freeze({
    bytes: 516_004,
    sha256: "3ad3b083cab321be04223e7fa1a22a8258c32c4da0883886683e25dcba9d03cc",
  }),
});

export const GRAFANA_OBSERVABILITY_RUNTIME_NAMESPACE = "grafana-observability" as const;

export function createBundledMcpMacOsKeychainLoader(options: {
  platform?: NodeJS.Platform;
  architecture?: NodeJS.Architecture;
} = {}): NativeKeyringModuleLoader {
  const platform = options.platform ?? process.platform;
  const architecture = options.architecture ?? process.arch;
  if (architecture === "arm64") {
    return new HashPinnedMacOsKeychainLoader({
      platform,
      architecture,
      asset: {
        fileUrl: new URL("../native/keyring.darwin-arm64.node", import.meta.url),
        ...BUNDLED_MCP_MACOS_KEYCHAIN_ASSETS.arm64,
      },
    });
  }
  if (architecture === "x64") {
    return new HashPinnedMacOsKeychainLoader({
      platform,
      architecture,
      asset: {
        fileUrl: new URL("../native/keyring.darwin-x64.node", import.meta.url),
        ...BUNDLED_MCP_MACOS_KEYCHAIN_ASSETS.x64,
      },
    });
  }
  return new HashPinnedMacOsKeychainLoader({
    platform,
    architecture,
    asset: {
      fileUrl: new URL("../native/keyring.darwin-arm64.node", import.meta.url),
      ...BUNDLED_MCP_MACOS_KEYCHAIN_ASSETS.arm64,
    },
  });
}

export class GrafanaObservabilityError extends Error {
  readonly code:
    | "INVALID_INPUT"
    | "PROFILE_NOT_ACTIVE"
    | "PACK_NOT_ACTIVE"
    | "IDEMPOTENCY_CONFLICT"
    | "REPORT_NOT_FOUND"
    | "EVIDENCE_NOT_FOUND"
    | "LINK_NOT_FOUND"
    | "NON_GRAFANA_EVIDENCE"
    | "UNSAFE_LINK"
    | "REPORT_REPLAY_UNAVAILABLE";

  constructor(code: GrafanaObservabilityError["code"]) {
    super("The Grafana observability request is invalid or unavailable");
    this.name = "GrafanaObservabilityError";
    this.code = code;
  }
}

function assertSafeName(value: string): void {
  if (!SAFE_NAME.test(value)) throw new GrafanaObservabilityError("INVALID_INPUT");
}

function safeText(value: string, maximum: number, fallback: string): string {
  const withoutControls = [...value].map((character) => {
    const code = character.codePointAt(0) ?? 0;
    return code < 0x20 || code === 0x7f ? " " : character;
  }).join("");
  const sanitized = withoutControls
    .replaceAll(URL_TEXT, "[link omitted]")
    .replaceAll(/\s+/gu, " ")
    .trim()
    .slice(0, maximum);
  return sanitized.length === 0 ? fallback : sanitized;
}

function safeCheckName(value: string): string {
  return SAFE_NAME.test(value) ? value : "provider-check";
}

function packSummary(pack: ReturnType<MonitoringRuntimePort["listCapabilities"]>["capabilityPacks"][number]): GrafanaPackSummary {
  if (!isGrafanaObservabilityPackId(pack.packId) || !Number.isSafeInteger(pack.revision) || pack.revision < 1) {
    throw new GrafanaObservabilityError("PACK_NOT_ACTIVE");
  }
  return {
    packId: pack.packId,
    revision: pack.revision,
    useCase: safeText(pack.useCase, 80, "GRAFANA_OBSERVABILITY"),
    requiredOperationCount: pack.requiredOperationIds.length,
    optionalOperationCount: pack.optionalOperationIds.length,
  };
}

function hasTrustedGrafanaPackRoute(
  pack: ReturnType<MonitoringRuntimePort["listCapabilities"]>["capabilityPacks"][number],
  routes: ReturnType<MonitoringRuntimePort["listCapabilities"]>["capabilities"],
): boolean {
  const operationIds = [...pack.requiredOperationIds, ...pack.optionalOperationIds];
  if (
    pack.requiredOperationIds.length === 0 ||
    new Set(operationIds).size !== operationIds.length
  ) {
    return false;
  }
  for (const operationId of operationIds) {
    const operationRoutes = routes.filter((route) => route.operations.includes(operationId));
    if (
      operationRoutes.length !== 1 ||
      operationRoutes[0]!.provider !== TRUSTED_GRAFANA_PROVIDER ||
      operationRoutes[0]!.packageId !== TRUSTED_GRAFANA_ADAPTER_PACKAGE_ID
    ) {
      return false;
    }
  }
  return true;
}

function assertTrustedGrafanaPackRoute(
  pack: ReturnType<MonitoringRuntimePort["listCapabilities"]>["capabilityPacks"][number],
  routes: ReturnType<MonitoringRuntimePort["listCapabilities"]>["capabilities"],
): void {
  if (!hasTrustedGrafanaPackRoute(pack, routes)) {
    throw new GrafanaObservabilityError("PACK_NOT_ACTIVE");
  }
}

function reportRef(runId: string): GrafanaReportRef {
  return `gfrpt_${sha256Canonical({ domain: "grafana-report-v1", runId })}` as GrafanaReportRef;
}

function evidenceRef(report: GrafanaReportRef, source: WorkbenchEvidenceRef): GrafanaEvidenceRef {
  return `gfev_${sha256Canonical({ domain: "grafana-report-evidence-v1", report, source })}` as GrafanaEvidenceRef;
}

function linkRef(report: GrafanaReportRef, source: WorkbenchLinkRef): GrafanaLinkRef {
  return `gflnk_${sha256Canonical({ domain: "grafana-report-link-v1", report, source })}` as GrafanaLinkRef;
}

function evidenceStatus(state: EvidenceState): Exclude<GrafanaReportStatus, "PARTIAL"> {
  return state;
}

function sameWindow(
  left: WorkbenchEvidenceDetail["window"],
  right: GrafanaRunPackInput["window"],
): boolean {
  return left.start === right.start && left.end === right.end;
}

function metricDirection(
  points: ReadonlyArray<{ value: number | null }>,
): GrafanaReportSignal["direction"] {
  const first = points.find((point): point is { value: number } => point.value !== null)?.value;
  const last = [...points].reverse().find((point): point is { value: number } => point.value !== null)?.value;
  if (first === undefined || last === undefined) return "UNKNOWN";
  return last > first ? "UP" : last < first ? "DOWN" : "FLAT";
}

function metricDisplay(value: number | null, unit: string | undefined): string {
  if (value === null) return "Unavailable";
  const formatted = Number.isInteger(value) ? String(value) : String(Number(value.toPrecision(8)));
  return unit === undefined ? formatted : `${formatted} ${unit}`;
}

function metricSeverity(
  state: EvidenceState,
  value: number | null,
  actualUnit: string | undefined,
  signal: ReturnType<MonitoringRuntimePort["listCapabilities"]>["capabilityPacks"][number]["signals"][number],
): GrafanaReportSignal["severity"] {
  if (state === "ERROR" || state === "CONTRADICTORY") return "CRITICAL";
  if (state === "STALE") return "WARNING";
  if (state !== "COMPLETE" || value === null) return "NEUTRAL";
  if (signal.unit !== undefined && actualUnit !== signal.unit) return "WARNING";
  const thresholds = signal.thresholds;
  if (thresholds === undefined) return "NEUTRAL";
  const matches = (threshold: number | undefined): boolean => {
    if (threshold === undefined) return false;
    if (thresholds.comparator === "LT") return value < threshold;
    if (thresholds.comparator === "LTE") return value <= threshold;
    if (thresholds.comparator === "GT") return value > threshold;
    return value >= threshold;
  };
  if (matches(thresholds.critical)) return "CRITICAL";
  if (matches(thresholds.warning)) return "WARNING";
  return signal.polarity === "NEUTRAL" ? "NEUTRAL" : "GOOD";
}

export function deriveGrafanaReportStatus(input: {
  states: readonly EvidenceState[];
  expectedEvidenceCount: number;
  collectionFailures: number;
}): GrafanaReportStatus {
  const { states, expectedEvidenceCount, collectionFailures } = input;
  if (states.includes("CONTRADICTORY")) return "CONTRADICTORY";
  if (states.length === 0) return collectionFailures > 0 ? "ERROR" : "EMPTY";
  if (states.every((state) => state === "ERROR")) return "ERROR";
  if (
    collectionFailures > 0 ||
    states.length !== expectedEvidenceCount ||
    new Set(states).size > 1
  ) return "PARTIAL";
  if (states.every((state) => state === "EMPTY")) return "EMPTY";
  if (states.every((state) => state === "STALE")) return "STALE";
  if (states.every((state) => state === "COMPLETE")) return "COMPLETE";
  return "PARTIAL";
}

function sanitizedValue(
  value: WorkbenchEvidenceDetail["values"][number],
): GrafanaEvidenceDetailResult["values"][number] {
  if (value.kind === "METRIC") {
    return {
      kind: "METRIC",
      label: safeText(value.label, 96, "metric"),
      value: value.value,
      ...(value.unit === undefined ? {} : { unit: safeText(value.unit, 32, "unit") }),
      points: value.points.slice(-60).map((point) => ({ at: point.at, value: point.value })),
    };
  }
  if (value.kind === "EVENT") {
    return {
      kind: "EVENT",
      at: value.at,
      summary: safeText(value.summary, 512, "Grafana event"),
    };
  }
  return {
    kind: "FACT",
    label: safeText(value.label, 96, "fact"),
    value: typeof value.value === "string"
      ? safeText(value.value, 256, "Unavailable")
      : value.value,
  };
}

function safeExternalLink(target: ReturnType<MonitoringRuntimePort["resolveWorkspaceLink"]>): {
  label: string;
  url: string;
} {
  if (target.mode !== "OPEN_EXTERNAL") throw new GrafanaObservabilityError("UNSAFE_LINK");
  let url: URL;
  try {
    url = new URL(target.url);
  } catch {
    throw new GrafanaObservabilityError("UNSAFE_LINK");
  }
  const loopback = new Set(["127.0.0.1", "localhost", "[::1]"]).has(url.hostname);
  if (
    (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) ||
    url.username !== "" ||
    url.password !== ""
  ) {
    throw new GrafanaObservabilityError("UNSAFE_LINK");
  }
  return { label: safeText(target.label, 128, "Open Grafana evidence"), url: url.toString() };
}

export class MonitoringGrafanaObservabilityRuntime implements GrafanaObservabilityRuntime {
  readonly #runtime: MonitoringRuntimePort;
  readonly #reports = new Map<GrafanaReportRef, GrafanaRuntimeInternalReport>();
  readonly #idempotency = new Map<string, GrafanaReportRef>();

  constructor(runtime: MonitoringRuntimePort) {
    this.#runtime = runtime;
  }

  async profileStatus(profileAlias: string): Promise<GrafanaProfileStatusResult> {
    assertSafeName(profileAlias);
    const doctor = await this.#runtime.doctor(profileAlias);
    const originModes = doctor.originModes.filter(
      (origin): origin is GrafanaProfileStatusResult["originModes"][number] =>
        origin === "LIVE" || origin === "REPLAY" || origin === "SIMULATED",
    );
    return {
      schemaVersion: "1.0.0",
      status: doctor.status === "READY" ? "COMPLETE" : doctor.status === "WARN" ? "PARTIAL" : "ERROR",
      profileAlias,
      readiness: doctor.status,
      originModes,
      checks: doctor.checks.slice(0, 64).map((check) => ({
        name: safeCheckName(check.name),
        status: check.status,
      })),
      limitations: [
        "This status is read-only and does not expose credentials or provider configuration.",
      ],
    };
  }

  listPacks(profileAlias: string): GrafanaListPacksResult {
    assertSafeName(profileAlias);
    const listed = this.#runtime.listCapabilities(profileAlias);
    const packs = listed.capabilityPacks
      .filter((pack) => isGrafanaObservabilityPackId(pack.packId))
      .filter((pack) => hasTrustedGrafanaPackRoute(pack, listed.capabilities))
      .map(packSummary)
      .sort((left, right) => left.packId.localeCompare(right.packId));
    return {
      schemaVersion: "1.0.0",
      status: packs.length === 0 ? "EMPTY" : "COMPLETE",
      profileAlias,
      packs,
      limitations: [
        "Packs contain reviewed frozen operations; provider queries and datasource identities are not returned.",
      ],
    };
  }

  async runPack(input: Readonly<GrafanaRunPackInput>, signal?: AbortSignal): Promise<GrafanaRunPackResult> {
    assertSafeName(input.idempotencyKey);
    assertSafeName(input.profileAlias);
    assertSafeName(input.scopeAlias);
    if (!isGrafanaObservabilityPackId(input.packId)) throw new GrafanaObservabilityError("INVALID_INPUT");
    if (input.profileAlias !== this.#runtime.profileAlias) {
      throw new GrafanaObservabilityError("PROFILE_NOT_ACTIVE");
    }
    const requestSha256 = sha256Canonical(input);
    const idempotencyIdentity = `${input.profileAlias}\u0000${input.idempotencyKey}`;
    const existingRef = this.#idempotency.get(idempotencyIdentity);
    if (existingRef !== undefined) {
      const existing = this.#reports.get(existingRef);
      if (existing === undefined) throw new GrafanaObservabilityError("REPORT_REPLAY_UNAVAILABLE");
      if (existing.requestSha256 !== requestSha256) {
        throw new GrafanaObservabilityError("IDEMPOTENCY_CONFLICT");
      }
      return structuredClone(existing.result);
    }
    const listed = this.#runtime.listCapabilities(input.profileAlias);
    const capability = listed.capabilityPacks
      .find((candidate) => candidate.packId === input.packId);
    if (capability === undefined || !isGrafanaObservabilityPackId(capability.packId)) {
      throw new GrafanaObservabilityError("PACK_NOT_ACTIVE");
    }
    assertTrustedGrafanaPackRoute(capability, listed.capabilities);
    const pack = packSummary(capability);
    const request: WorkflowRequest = {
      schemaVersion: "1.0.0",
      idempotencyKey: input.idempotencyKey,
      workflow: "investigate",
      profileAlias: input.profileAlias,
      scopeAlias: input.scopeAlias,
      origin: input.origin,
      window: structuredClone(input.window),
      ...(input.baselineWindow === undefined
        ? {}
        : { baselineWindow: structuredClone(input.baselineWindow) }),
      requiredCapabilityPacks: [capabilityPackId(input.packId)],
      artifactPolicy: { mode: "required" },
      failOn: "none",
    };
    const begun = this.#runtime.beginRun(request, input.idempotencyKey);
    if (begun.runHandle === undefined) {
      throw new GrafanaObservabilityError("REPORT_REPLAY_UNAVAILABLE");
    }
    const runHandle = begun.runHandle as RunHandle;
    let revision = begun.revision;
    let collectionFailures = 0;
    let sealed = false;
    const snapshot = await (async () => {
      try {
        const current = await this.#runtime.collect(
          runHandle,
          revision,
          capability.requiredOperationIds,
          "CURRENT",
          signal,
        );
        revision = current.revision;
        collectionFailures += current.failures?.length ?? 0;
        if (input.baselineWindow !== undefined) {
          const baseline = await this.#runtime.collect(
            runHandle,
            revision,
            capability.requiredOperationIds,
            "BASELINE",
            signal,
          );
          revision = baseline.revision;
          collectionFailures += baseline.failures?.length ?? 0;
        }
        this.#runtime.finalizeRun(runHandle, revision);
        sealed = true;
        return this.#runtime.openWorkbenchForRun(begun.runId);
      } catch (error) {
        if (!sealed) {
          try {
            this.#runtime.cancelRun(
              runHandle,
              revision,
              signal?.aborted === true ? "INTERRUPTED" : "PROVIDER_UNAVAILABLE",
            );
          } catch {
            // Cancellation is best-effort and must never mask the collection failure.
          }
        }
        throw error;
      }
    })();
    // Evidence-only finalization deliberately produces a verified PARTIAL
    // investigation artifact: it has no model-authored analysis, but its
    // immutable evidence is still the complete authority for this focused
    // read-only pack report.
    if ((snapshot.lifecycle !== "SEALED" && snapshot.lifecycle !== "PARTIAL") || snapshot.scope?.window === undefined) {
      throw new GrafanaObservabilityError("REPORT_NOT_FOUND");
    }
    const reference = reportRef(begun.runId);
    const storedEvidence = new Map<GrafanaEvidenceRef, WorkbenchEvidenceRef>();
    const storedLinks = new Map<GrafanaLinkRef, WorkbenchLinkRef>();
    const rawToOpaqueEvidence = new Map<WorkbenchEvidenceRef, GrafanaEvidenceRef>();
    const detailsByRawRef = new Map<WorkbenchEvidenceRef, WorkbenchEvidenceDetail>();
    const evidence: GrafanaReportEvidenceCard[] = [];
    for (const card of snapshot.evidence) {
      const detail = this.#runtime.workspaceEvidence(snapshot.workspaceId, card.evidenceRef);
      if (detail.source.provider.toLowerCase() !== "grafana") {
        throw new GrafanaObservabilityError("NON_GRAFANA_EVIDENCE");
      }
      const opaqueEvidence = evidenceRef(reference, card.evidenceRef);
      detailsByRawRef.set(card.evidenceRef, detail);
      rawToOpaqueEvidence.set(card.evidenceRef, opaqueEvidence);
      storedEvidence.set(opaqueEvidence, card.evidenceRef);
      const opaqueLinks = card.linkRefs.map((rawLink) => {
        const opaqueLink = linkRef(reference, rawLink);
        storedLinks.set(opaqueLink, rawLink);
        return opaqueLink;
      });
      evidence.push({
        evidenceRef: opaqueEvidence,
        title: safeText(card.title, 160, "Reviewed Grafana evidence"),
        domain: safeText(card.domain, 32, "METRICS"),
        status: evidenceStatus(card.state),
        summary: safeText(card.summary, 512, "Reviewed Grafana evidence is available."),
        ...(card.observedAt === undefined ? {} : { observedAt: card.observedAt }),
        linkRefs: opaqueLinks,
      });
    }
    const remapEvidence = (refs: readonly WorkbenchEvidenceRef[]): GrafanaEvidenceRef[] =>
      refs.map((raw) => rawToOpaqueEvidence.get(raw)).filter((ref): ref is GrafanaEvidenceRef => ref !== undefined);
    const signals: GrafanaReportSignal[] = [];
    for (const signalDefinition of [...capability.signals]
      .sort((left, right) => left.order - right.order || left.signalId.localeCompare(right.signalId))) {
      const operationId = signalDefinition.operationId;
      const rawRef = [...detailsByRawRef.entries()].find(([, detail]) =>
        detail.title === operationId && sameWindow(detail.window, input.window))?.[0];
      if (rawRef === undefined) continue;
      const detail = detailsByRawRef.get(rawRef)!;
      const opaqueEvidence = rawToOpaqueEvidence.get(rawRef);
      if (opaqueEvidence === undefined) continue;
      const value = detail.values.find((candidate) =>
        candidate.kind === "METRIC" && candidate.label === signalDefinition.resultName);
      if (value?.kind !== "METRIC") continue;
      signals.push({
        signalRef: `signal.${sha256Canonical({
          packId: capability.packId,
          signalId: signalDefinition.signalId,
          definitionSha256: capability.definitionSha256,
        }).slice(0, 24)}`,
        title: safeText(signalDefinition.signalId, 128, "Grafana signal"),
        displayValue: safeText(metricDisplay(value.value, value.unit), 128, "Unavailable"),
        ...(value.unit === undefined ? {} : { unit: safeText(value.unit, 32, "unit") }),
        severity: metricSeverity(detail.state, value.value, value.unit, signalDefinition),
        direction: metricDirection(value.points),
        evidenceRefs: [opaqueEvidence],
      });
    }
    const issues: GrafanaReportIssue[] = (snapshot.issues ?? []).slice(0, 64).map((issue) => ({
      kind: issue.kind,
      severity: issue.severity,
      status: issue.status,
      classification: issue.classification,
      title: safeText(issue.title, 128, "Grafana issue"),
      summary: safeText(issue.summary, 512, "Reviewed Grafana issue"),
      evidenceRefs: remapEvidence(issue.evidenceRefs),
    }));
    const states = evidence.map((item) => item.status);
    const expectedEvidenceCount = capability.requiredOperationIds.length * (input.baselineWindow === undefined ? 1 : 2);
    const status = deriveGrafanaReportStatus({ states, expectedEvidenceCount, collectionFailures });
    const evidenceSummary: GrafanaRunPackResult["evidenceSummary"] = {
      COMPLETE: 0,
      EMPTY: 0,
      STALE: 0,
      CONTRADICTORY: 0,
      ERROR: 0,
    };
    for (const state of states) evidenceSummary[state] += 1;
    const result: GrafanaRunPackResult = {
      schemaVersion: "1.0.0",
      status,
      reportRef: reference,
      profileAlias: input.profileAlias,
      pack,
      scopeAlias: input.scopeAlias,
      origin: input.origin,
      window: structuredClone(input.window),
      ...(input.baselineWindow === undefined
        ? {}
        : { baselineWindow: structuredClone(input.baselineWindow) }),
      evidenceSummary,
      collectionFailures,
      evidence,
      signals,
      issues,
      limitations: [
        "Evidence is read-only and cannot authorize a patch or mutate Grafana.",
        "Datasource identities and frozen provider queries are intentionally omitted.",
      ],
    };
    const stored: GrafanaRuntimeInternalReport = {
      reportRef: reference,
      requestSha256,
      workspaceId: snapshot.workspaceId,
      result,
      evidenceRefs: storedEvidence,
      linkRefs: storedLinks,
    };
    this.#reports.set(reference, stored);
    this.#idempotency.set(idempotencyIdentity, reference);
    this.#evictReports();
    return structuredClone(result);
  }

  getEvidence(
    report: GrafanaReportRef,
    evidence: GrafanaEvidenceRef,
  ): GrafanaEvidenceDetailResult {
    const stored = this.#requireReport(report);
    const sourceRef = stored.evidenceRefs.get(evidence);
    if (sourceRef === undefined) throw new GrafanaObservabilityError("EVIDENCE_NOT_FOUND");
    const detail = this.#runtime.workspaceEvidence(stored.workspaceId, sourceRef);
    if (detail.source.provider.toLowerCase() !== "grafana") {
      throw new GrafanaObservabilityError("NON_GRAFANA_EVIDENCE");
    }
    const opaqueLinks = detail.linkRefs.map((rawLink) => {
      for (const [opaque, raw] of stored.linkRefs) if (raw === rawLink) return opaque;
      throw new GrafanaObservabilityError("LINK_NOT_FOUND");
    });
    return {
      schemaVersion: "1.0.0",
      status: evidenceStatus(detail.state),
      reportRef: report,
      evidenceRef: evidence,
      title: safeText(detail.title, 160, "Reviewed Grafana evidence"),
      domain: safeText(detail.domain, 32, "METRICS"),
      origin: detail.origin,
      authority: detail.authority,
      provider: "grafana",
      evaluatedAt: detail.evaluatedAt,
      collectedAt: detail.collectedAt,
      window: structuredClone(detail.window),
      summary: safeText(detail.summary, 512, "Reviewed Grafana evidence is available."),
      values: detail.values.slice(0, 24).map(sanitizedValue),
      limitationCount: detail.limitations.length,
      linkRefs: opaqueLinks,
    };
  }

  resolveLink(report: GrafanaReportRef, link: GrafanaLinkRef): GrafanaResolvedLinkResult {
    const stored = this.#requireReport(report);
    const sourceRef = stored.linkRefs.get(link);
    if (sourceRef === undefined) throw new GrafanaObservabilityError("LINK_NOT_FOUND");
    const target = safeExternalLink(this.#runtime.resolveWorkspaceLink(stored.workspaceId, sourceRef));
    return {
      schemaVersion: "1.0.0",
      status: "COMPLETE",
      reportRef: report,
      linkRef: link,
      mode: "OPEN_EXTERNAL",
      label: target.label,
      url: target.url,
    };
  }

  close(): Promise<void> {
    this.#reports.clear();
    this.#idempotency.clear();
    return this.#runtime.close();
  }

  #requireReport(reference: GrafanaReportRef): GrafanaRuntimeInternalReport {
    const report = this.#reports.get(reference);
    if (report === undefined) throw new GrafanaObservabilityError("REPORT_NOT_FOUND");
    return report;
  }

  #evictReports(): void {
    while (this.#reports.size > MAX_REPORTS) {
      const oldest = this.#reports.keys().next().value as GrafanaReportRef | undefined;
      if (oldest === undefined) return;
      this.#reports.delete(oldest);
      for (const [key, value] of this.#idempotency) {
        if (value === oldest) this.#idempotency.delete(key);
      }
    }
  }
}

export function createGrafanaObservabilityRuntimeFromEnvironment(
  environment: NodeJS.ProcessEnv = process.env,
  dependencies: {
    grafanaKeyringBackend?: GrafanaKeyringBackend;
    platform?: NodeJS.Platform;
    architecture?: NodeJS.Architecture;
  } = {},
): MonitoringGrafanaObservabilityRuntime {
  const platform = dependencies.platform ?? process.platform;
  const architecture = dependencies.architecture ?? process.arch;
  let grafanaKeyringBackend = dependencies.grafanaKeyringBackend;
  if (
    grafanaKeyringBackend === undefined
    && platform === "darwin"
    && (architecture === "arm64" || architecture === "x64")
  ) {
    grafanaKeyringBackend = new NativeGrafanaKeyringBackend({
      platform,
      loader: createBundledMcpMacOsKeychainLoader({ platform, architecture }),
    });
  }
  return new MonitoringGrafanaObservabilityRuntime(createRuntimeFromEnvironment(
    environment,
    {
      ...(grafanaKeyringBackend === undefined ? {} : { grafanaKeyringBackend }),
      runtimeNamespace: GRAFANA_OBSERVABILITY_RUNTIME_NAMESPACE,
      artifactProducer: {
        pluginVersion: "0.1.0",
        contractsVersion: "0.3.0",
        reportProjectionVersion: "1.1.0",
      },
    },
  ));
}
