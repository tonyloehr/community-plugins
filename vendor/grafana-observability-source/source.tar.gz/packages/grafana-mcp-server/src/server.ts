import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import type { CallToolResult, ToolAnnotations } from "@modelcontextprotocol/sdk/types.js";
import * as z from "zod/v4";

import {
  GRAFANA_OBSERVABILITY_PACK_IDS,
  type GrafanaEvidenceRef,
  type GrafanaLinkRef,
  type GrafanaObservabilityRuntime,
  type GrafanaReportRef,
} from "./types.ts";

export const GRAFANA_OBSERVABILITY_MCP_VERSION = "0.1.0";

export const GRAFANA_OBSERVABILITY_TOOL_NAMES = [
  "grafana_profile_status",
  "grafana_list_packs",
  "grafana_run_pack",
  "grafana_get_evidence",
  "grafana_resolve_link",
] as const;

type GrafanaObservabilityToolName = typeof GRAFANA_OBSERVABILITY_TOOL_NAMES[number];

function annotations(readOnly: boolean, openWorld: boolean): Readonly<ToolAnnotations> {
  return Object.freeze({
    readOnlyHint: readOnly,
    openWorldHint: openWorld,
    destructiveHint: false,
    idempotentHint: true,
  });
}

export const GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS: Readonly<
  Record<GrafanaObservabilityToolName, Readonly<ToolAnnotations>>
> = Object.freeze({
  grafana_profile_status: annotations(true, true),
  grafana_list_packs: annotations(true, false),
  grafana_run_pack: annotations(false, true),
  grafana_get_evidence: annotations(true, false),
  grafana_resolve_link: annotations(true, false),
});

const alias = z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u);
const packId = z.enum(GRAFANA_OBSERVABILITY_PACK_IDS);
const reportRef = z.string().regex(/^gfrpt_[A-Za-z0-9_-]{20,128}$/u);
const evidenceRef = z.string().regex(/^gfev_[A-Za-z0-9_-]{20,128}$/u);
const linkRef = z.string().regex(/^gflnk_[A-Za-z0-9_-]{20,128}$/u);
const MAX_WINDOW_MS = 7 * 24 * 60 * 60 * 1_000;

const timeWindow = z.strictObject({
  start: z.iso.datetime({ offset: true }),
  end: z.iso.datetime({ offset: true }),
}).superRefine((window, context) => {
  const start = Date.parse(window.start);
  const end = Date.parse(window.end);
  if (end <= start) {
    context.addIssue({ code: "custom", message: "window end must follow start", path: ["end"] });
  } else if (end - start > MAX_WINDOW_MS) {
    context.addIssue({ code: "custom", message: "window exceeds the seven-day bound", path: ["end"] });
  }
});

const runPackInput = z.strictObject({
  idempotencyKey: alias,
  profileAlias: alias,
  packId,
  scopeAlias: alias,
  origin: z.enum(["LIVE", "REPLAY", "SIMULATED"]),
  window: timeWindow,
  baselineWindow: timeWindow.optional(),
}).superRefine((input, context) => {
  if (
    input.baselineWindow !== undefined &&
    Date.parse(input.baselineWindow.end) > Date.parse(input.window.start)
  ) {
    context.addIssue({
      code: "custom",
      message: "baseline window must end before the current window starts",
      path: ["baselineWindow", "end"],
    });
  }
  if (input.baselineWindow !== undefined) {
    const currentDuration = Date.parse(input.window.end) - Date.parse(input.window.start);
    const baselineDuration = Date.parse(input.baselineWindow.end) - Date.parse(input.baselineWindow.start);
    if (currentDuration !== baselineDuration) {
      context.addIssue({
        code: "custom",
        message: "baseline and current windows must have equal durations",
        path: ["baselineWindow"],
      });
    }
  }
});

function jsonResult(value: unknown): CallToolResult {
  const safe = JSON.parse(JSON.stringify(value)) as Record<string, unknown>;
  return {
    content: [{ type: "text", text: JSON.stringify(safe) }],
    structuredContent: safe,
  };
}

function errorCode(error: unknown): string {
  const candidate = error as { code?: unknown; name?: unknown };
  if (typeof candidate.code === "string" && /^[A-Z][A-Z0-9_]{0,127}$/u.test(candidate.code)) {
    return candidate.code;
  }
  if (typeof candidate.name === "string") {
    const normalized = candidate.name.replaceAll(/[^A-Za-z0-9]+/gu, "_").toUpperCase();
    if (/^[A-Z][A-Z0-9_]{0,127}$/u.test(normalized)) return normalized;
  }
  return "GRAFANA_OBSERVABILITY_ERROR";
}

function sanitizedError(error: unknown): CallToolResult {
  const safe = {
    schemaVersion: "1.0.0",
    status: "ERROR",
    error: {
      code: errorCode(error),
      message: "The Grafana observability request was rejected",
    },
  };
  return {
    isError: true,
    content: [{ type: "text", text: JSON.stringify(safe) }],
    structuredContent: safe,
  };
}

function guarded(callback: () => unknown | Promise<unknown>): Promise<CallToolResult> {
  return Promise.resolve().then(callback).then(jsonResult, sanitizedError);
}

export function createGrafanaObservabilityMcpServer(runtime: GrafanaObservabilityRuntime): McpServer {
  const server = new McpServer({
    name: "grafana-observability",
    version: GRAFANA_OBSERVABILITY_MCP_VERSION,
  });

  server.registerTool("grafana_profile_status", {
    title: "Check Grafana Observability Profile",
    description: "Check one active Grafana profile without returning its origin URL, credential, datasource identity, or query catalog.",
    inputSchema: z.strictObject({ profileAlias: alias }),
    annotations: GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS.grafana_profile_status,
  }, ({ profileAlias }) => guarded(() => runtime.profileStatus(profileAlias)));

  server.registerTool("grafana_list_packs", {
    title: "List Grafana Observability Packs",
    description: "List activated reviewed Grafana capability packs; frozen datasource targets and queries remain server-side.",
    inputSchema: z.strictObject({ profileAlias: alias }),
    annotations: GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS.grafana_list_packs,
  }, ({ profileAlias }) => guarded(() => runtime.listPacks(profileAlias)));

  server.registerTool("grafana_run_pack", {
    title: "Run Grafana Observability Pack",
    description: "Collect one activated provider-read-only Grafana pack and write only plugin-owned local run, audit, checkpoint, and sealed evidence artifact state.",
    inputSchema: runPackInput,
    annotations: GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS.grafana_run_pack,
  }, (input, extra) => guarded(() => runtime.runPack(input, extra.signal)));

  server.registerTool("grafana_get_evidence", {
    title: "Read Grafana Observability Evidence",
    description: "Read bounded normalized evidence owned by one opaque report; provider configuration is never returned.",
    inputSchema: z.strictObject({ reportRef, evidenceRef }),
    annotations: GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS.grafana_get_evidence,
  }, ({ reportRef: report, evidenceRef: evidence }) => guarded(
    () => runtime.getEvidence(report as GrafanaReportRef, evidence as GrafanaEvidenceRef),
  ));

  server.registerTool("grafana_resolve_link", {
    title: "Resolve Grafana Observability Link",
    description: "Resolve one ownership-checked opaque report link; URLs are never accepted as tool input.",
    inputSchema: z.strictObject({ reportRef, linkRef }),
    annotations: GRAFANA_OBSERVABILITY_TOOL_ANNOTATIONS.grafana_resolve_link,
  }, ({ reportRef: report, linkRef: link }) => guarded(
    () => runtime.resolveLink(report as GrafanaReportRef, link as GrafanaLinkRef),
  ));

  return server;
}
