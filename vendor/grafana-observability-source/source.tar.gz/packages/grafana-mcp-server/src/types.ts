import type {
  CapabilityPackId,
  CapabilityPackSignalV1,
  EvidenceId,
  EvidenceOrigin,
  MonitoringWorkspaceId,
  MonitoringWorkspaceSnapshot,
  RunHandle,
  RunId,
  TimeWindow,
  WorkbenchEvidenceDetail,
  WorkbenchEvidenceRef,
  WorkbenchLinkRef,
  WorkbenchResolvedLinkTarget,
  WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import type {
  BeginRunOutput,
  CollectOutput,
  FinalizeOutput,
  RuntimeCapability,
} from "@codex-production-monitoring/evidence-server";

export const GRAFANA_OBSERVABILITY_PACK_IDS = [
  "grafana.infrastructure",
  "grafana.apm",
  "grafana.logs",
  "grafana.iot-edge",
  "grafana.business-kpis",
] as const;

export type GrafanaObservabilityPackId = typeof GRAFANA_OBSERVABILITY_PACK_IDS[number];

const GRAFANA_OBSERVABILITY_PACK_ID_SET = new Set<string>(GRAFANA_OBSERVABILITY_PACK_IDS);

export function isGrafanaObservabilityPackId(value: string): value is GrafanaObservabilityPackId {
  return GRAFANA_OBSERVABILITY_PACK_ID_SET.has(value);
}

export type GrafanaReportStatus =
  | "COMPLETE"
  | "EMPTY"
  | "STALE"
  | "PARTIAL"
  | "CONTRADICTORY"
  | "ERROR";

export type GrafanaReportRef = string & { readonly __brand: "GrafanaReportRef" };
export type GrafanaEvidenceRef = string & { readonly __brand: "GrafanaEvidenceRef" };
export type GrafanaLinkRef = string & { readonly __brand: "GrafanaLinkRef" };

export interface GrafanaProfileStatusResult {
  schemaVersion: "1.0.0";
  status: Extract<GrafanaReportStatus, "COMPLETE" | "PARTIAL" | "ERROR">;
  profileAlias: string;
  readiness: "READY" | "WARN" | "BLOCKED";
  originModes: EvidenceOrigin[];
  checks: Array<{ name: string; status: "PASS" | "WARN" | "FAIL" }>;
  limitations: string[];
}

export interface GrafanaPackSummary {
  packId: GrafanaObservabilityPackId;
  revision: number;
  useCase: string;
  requiredOperationCount: number;
  optionalOperationCount: number;
}

export interface GrafanaListPacksResult {
  schemaVersion: "1.0.0";
  status: Extract<GrafanaReportStatus, "COMPLETE" | "EMPTY">;
  profileAlias: string;
  packs: GrafanaPackSummary[];
  limitations: string[];
}

export interface GrafanaReportEvidenceCard {
  evidenceRef: GrafanaEvidenceRef;
  title: string;
  domain: string;
  status: Exclude<GrafanaReportStatus, "PARTIAL">;
  summary: string;
  observedAt?: string;
  linkRefs: GrafanaLinkRef[];
}

export interface GrafanaReportIssue {
  kind: "ALERT" | "REGRESSION" | "ANOMALY" | "CONTRADICTION" | "EVIDENCE_GAP";
  severity: "INFO" | "WARNING" | "CRITICAL";
  status: "OPEN" | "SUPPORTED" | "RESOLVED" | "BLOCKED";
  classification: "SIGNED_RULE" | "DEVIATION";
  title: string;
  summary: string;
  evidenceRefs: GrafanaEvidenceRef[];
}

export interface GrafanaReportSignal {
  signalRef: string;
  title: string;
  displayValue: string;
  unit?: string;
  severity: "NEUTRAL" | "GOOD" | "WARNING" | "CRITICAL";
  direction: "UP" | "DOWN" | "FLAT" | "UNKNOWN";
  evidenceRefs: GrafanaEvidenceRef[];
}

export interface GrafanaRunPackInput {
  idempotencyKey: string;
  profileAlias: string;
  packId: GrafanaObservabilityPackId;
  scopeAlias: string;
  origin: EvidenceOrigin;
  window: TimeWindow;
  baselineWindow?: TimeWindow;
}

export interface GrafanaRunPackResult {
  schemaVersion: "1.0.0";
  status: GrafanaReportStatus;
  reportRef: GrafanaReportRef;
  profileAlias: string;
  pack: GrafanaPackSummary;
  scopeAlias: string;
  origin: EvidenceOrigin;
  window: TimeWindow;
  baselineWindow?: TimeWindow;
  evidenceSummary: Record<Exclude<GrafanaReportStatus, "PARTIAL">, number>;
  collectionFailures: number;
  evidence: GrafanaReportEvidenceCard[];
  signals: GrafanaReportSignal[];
  issues: GrafanaReportIssue[];
  limitations: string[];
}

export interface GrafanaEvidenceDetailResult {
  schemaVersion: "1.0.0";
  status: Exclude<GrafanaReportStatus, "PARTIAL">;
  reportRef: GrafanaReportRef;
  evidenceRef: GrafanaEvidenceRef;
  title: string;
  domain: string;
  origin: EvidenceOrigin;
  authority: "AUTHORITATIVE" | "CORROBORATING";
  provider: "grafana";
  evaluatedAt: string;
  collectedAt: string;
  window: TimeWindow;
  summary: string;
  values: Array<
    | {
        kind: "METRIC";
        label: string;
        value: number | null;
        unit?: string;
        points: Array<{ at: string; value: number | null }>;
      }
    | { kind: "FACT"; label: string; value: null | boolean | number | string }
    | { kind: "EVENT"; at: string; summary: string }
  >;
  limitationCount: number;
  linkRefs: GrafanaLinkRef[];
}

export interface GrafanaResolvedLinkResult {
  schemaVersion: "1.0.0";
  status: "COMPLETE";
  reportRef: GrafanaReportRef;
  linkRef: GrafanaLinkRef;
  mode: "OPEN_EXTERNAL";
  label: string;
  url: string;
}

export interface GrafanaObservabilityRuntime {
  profileStatus(profileAlias: string): Promise<GrafanaProfileStatusResult>;
  listPacks(profileAlias: string): GrafanaListPacksResult | Promise<GrafanaListPacksResult>;
  runPack(input: Readonly<GrafanaRunPackInput>, signal?: AbortSignal): Promise<GrafanaRunPackResult>;
  getEvidence(
    reportRef: GrafanaReportRef,
    evidenceRef: GrafanaEvidenceRef,
  ): GrafanaEvidenceDetailResult | Promise<GrafanaEvidenceDetailResult>;
  resolveLink(
    reportRef: GrafanaReportRef,
    linkRef: GrafanaLinkRef,
  ): GrafanaResolvedLinkResult | Promise<GrafanaResolvedLinkResult>;
  close(): Promise<void>;
}

export interface MonitoringRuntimePort {
  readonly profileAlias: string;
  doctor(profileAlias: string): Promise<{
    status: "READY" | "WARN" | "BLOCKED";
    profileAlias: string;
    surface: string;
    originModes: string[];
    checks: Array<{ name: string; status: "PASS" | "WARN" | "FAIL"; message: string }>;
  }>;
  listCapabilities(profileAlias: string): {
    profileAlias: string;
    surface: string;
    route: string;
    privateNetworkReachability: string;
    capabilities: RuntimeCapability[];
    capabilityPacks: Array<{
      packId: string;
      revision: number;
      useCase: string;
      requiredOperationIds: string[];
      optionalOperationIds: string[];
      signals: CapabilityPackSignalV1[];
      definitionSha256: string;
    }>;
    limitations: string[];
  };
  beginRun(request: WorkflowRequest, idempotencyKey: string): BeginRunOutput;
  collect(
    runHandle: RunHandle,
    expectedRevision: number,
    operationIds: readonly string[],
    window: "CURRENT" | "BASELINE",
    signal?: AbortSignal,
  ): Promise<CollectOutput>;
  finalizeRun(runHandle: RunHandle, expectedRevision: number): FinalizeOutput;
  cancelRun(
    runHandle: RunHandle,
    expectedRevision: number,
    reason: "INTERRUPTED" | "PROVIDER_UNAVAILABLE",
  ): { runId: RunId; revision: number; state: "ABORTED"; retainedEvidenceIds: EvidenceId[] };
  openWorkbenchForRun(runId: RunId): MonitoringWorkspaceSnapshot;
  workspaceEvidence(
    workspaceId: MonitoringWorkspaceId,
    evidenceRef: WorkbenchEvidenceRef,
  ): WorkbenchEvidenceDetail;
  resolveWorkspaceLink(
    workspaceId: MonitoringWorkspaceId,
    linkRef: WorkbenchLinkRef,
  ): WorkbenchResolvedLinkTarget;
  close(): Promise<void>;
}

export interface GrafanaRuntimeInternalReport {
  reportRef: GrafanaReportRef;
  requestSha256: string;
  workspaceId: MonitoringWorkspaceId;
  result: GrafanaRunPackResult;
  evidenceRefs: ReadonlyMap<GrafanaEvidenceRef, WorkbenchEvidenceRef>;
  linkRefs: ReadonlyMap<GrafanaLinkRef, WorkbenchLinkRef>;
}

export function capabilityPackId(value: GrafanaObservabilityPackId): CapabilityPackId {
  return value as CapabilityPackId;
}
