import { verifyWorkerArtifact, verifyWorkerAdmission } from "../../adapter-sdk/src/index.ts";
import {
  credentialReferenceIdentity,
  decodeCredentialBootstrapFrame,
  readCredentialBootstrapFrameFromFd,
  type DecodedWorkerCredentials,
} from "../../adapter-host/src/index.ts";
import { runAdapterWorker } from "../../adapter-runner/src/index.ts";
import { loadTrustedRoot, providerBindingCredentialReferences } from "../../config/src/index.ts";
import type { AdapterPackageId, Sha256 } from "../../contracts/src/index.ts";

import { instantiateProviderAdapter } from "./worker-runtime.ts";

interface WorkerArguments {
  trustRoot: string;
  rootManifestSha256: Sha256;
  trustBundleSha256: Sha256;
  runtimeSha256: Sha256;
  packageId: AdapterPackageId;
  validateOnly: boolean;
}

const SHA256 = /^[a-f0-9]{64}$/u;
const PACKAGE_ID = /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u;

function parseArguments(argv: readonly string[]): WorkerArguments {
  const expectedFlags = [
    "--trust-root",
    "--root-manifest-sha256",
    "--trust-bundle-sha256",
    "--runtime-sha256",
    "--package-id",
  ];
  const validateOnly = argv.at(-1) === "--validate-only";
  const fixedArguments = validateOnly ? argv.slice(0, -1) : argv;
  if (fixedArguments.length !== expectedFlags.length * 2) throw new Error("Invalid fixed worker bootstrap");
  const values = new Map<string, string>();
  for (let index = 0; index < expectedFlags.length; index += 1) {
    const flag = fixedArguments[index * 2];
    const value = fixedArguments[index * 2 + 1];
    if (flag !== expectedFlags[index] || value === undefined || value.length === 0 || value.includes("\0")) {
      throw new Error("Invalid fixed worker bootstrap");
    }
    values.set(flag, value);
  }
  const trustRoot = values.get("--trust-root")!;
  const rootManifestSha256 = values.get("--root-manifest-sha256")!;
  const trustBundleSha256 = values.get("--trust-bundle-sha256")!;
  const runtimeSha256 = values.get("--runtime-sha256")!;
  const packageId = values.get("--package-id")!;
  if (!trustRoot.startsWith("/") || !SHA256.test(rootManifestSha256) || !SHA256.test(trustBundleSha256) || !SHA256.test(runtimeSha256) || !PACKAGE_ID.test(packageId)) {
    throw new Error("Invalid fixed worker bootstrap");
  }
  return {
    trustRoot,
    rootManifestSha256: rootManifestSha256 as Sha256,
    trustBundleSha256: trustBundleSha256 as Sha256,
    runtimeSha256: runtimeSha256 as Sha256,
    packageId: packageId as AdapterPackageId,
    validateOnly,
  };
}

export async function runProviderWorker(argv: readonly string[] = process.argv.slice(2)): Promise<void> {
  const args = parseArguments(argv);
  const root = loadTrustedRoot({ rootPath: args.trustRoot });
  if (
    root.rootManifestSha256 !== args.rootManifestSha256 ||
    root.trustBundleSha256 !== args.trustBundleSha256 ||
    root.providerRuntime?.sourceSha256 !== args.runtimeSha256
  ) {
    throw new Error("Trusted worker bootstrap changed");
  }
  const binding = root.providerRuntime.configuration.adapters.find((candidate) => candidate.packageId === args.packageId);
  const adapterPackage = root.bundle.adapters.find((candidate) => candidate.packageId === args.packageId);
  if (binding === undefined || adapterPackage === undefined || adapterPackage.entrypoint.kind !== "SIGNED_WORKER") {
    throw new Error("Worker package is not admitted");
  }
  const configuredEnvironment = new Set(binding.credentialEnv);
  const platformAmbient = (key: string, value: string | undefined): boolean =>
    key === "__CF_USER_TEXT_ENCODING" && value !== undefined && /^[A-Fa-f0-9x:]{1,64}$/u.test(value);
  if (Object.entries(process.env).some(([key, value]) => !configuredEnvironment.has(key) && !platformAmbient(key, value))) {
    throw new Error("Worker received an unapproved environment entry");
  }
  const admission = root.providerRuntime.configuration.workerAdmission;
  verifyWorkerAdmission(adapterPackage, {
    trustedSigningKeys: new Map(root.providerRuntime.signingKeys.map((key) => [key.keyId, key.publicKeyPem])),
    allowedPackageIds: new Set([adapterPackage.packageId]),
    allowedArtifactHashes: new Set([adapterPackage.entrypoint.artifactSha256]),
    revokedPackageIds: new Set(admission.revocations.packageIds),
    revokedArtifactHashes: new Set(admission.revocations.artifactSha256s),
    revokedArtifactPaths: new Set(admission.revocations.artifactPaths),
    revokedSigningKeyIds: new Set(admission.revocations.signingKeyIds),
  });
  await verifyWorkerArtifact({
    artifactPath: process.argv[1]!,
    artifactSha256: adapterPackage.entrypoint.artifactSha256,
  });
  if (args.validateOnly) return;
  const expectedCredentials = [...new Map(
    providerBindingCredentialReferences(binding, root.bundle)
      .filter((reference) => reference.kind !== "env")
      .map((reference) => [credentialReferenceIdentity(reference), reference]),
  ).values()];
  let frame: Buffer | undefined;
  let credentials: DecodedWorkerCredentials | undefined;
  let adapter: ReturnType<typeof instantiateProviderAdapter>;
  try {
    if (expectedCredentials.length > 0) {
      frame = readCredentialBootstrapFrameFromFd(3);
      credentials = decodeCredentialBootstrapFrame(frame, expectedCredentials);
    }
    adapter = instantiateProviderAdapter(root, binding, {
      environment: process.env,
      ...(credentials === undefined
        ? {}
        : { credentialResolver: { resolve: (reference) => credentials?.resolve(reference) } }),
    });
  } finally {
    frame?.fill(0);
    credentials?.dispose();
  }
  await runAdapterWorker(adapter);
}

void runProviderWorker().catch(() => {
  process.exitCode = 1;
});
