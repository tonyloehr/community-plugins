import {
  AlertmanagerAdapter,
  type AlertmanagerCatalogBinding,
  type AlertmanagerTransport,
} from "../../../adapters/alertmanager/src/index.ts";
import { fixtureAdapter } from "../../../adapters/fixture/src/index.ts";
import {
  GitAdapter,
  type GitCatalogBinding,
  type GitWorkspaceBinding,
} from "../../../adapters/git/src/index.ts";
import {
  GrafanaAdapter,
  GrafanaTransportError,
  type GrafanaHttpRequest,
  type GrafanaTransport,
  type GrafanaTrustedCatalog,
} from "../../../adapters/grafana/src/index.ts";
import {
  KubernetesAdapter,
  KubernetesTransportError,
  type KubernetesReadRequest,
  type KubernetesTransport,
  type KubernetesTrustedCatalog,
} from "../../../adapters/kubernetes/src/index.ts";
import {
  LokiAdapter,
  LokiTransportError,
  type LokiHttpRequest,
  type LokiTransport,
  type LokiTrustedCatalog,
} from "../../../adapters/loki/src/index.ts";
import {
  PrometheusAdapter,
  PrometheusTransportError,
  type PrometheusHttpRequest,
  type PrometheusTransport,
  type PrometheusTrustedCatalog,
} from "../../../adapters/prometheus/src/index.ts";
import {
  TempoAdapter,
  TempoTransportError,
  type TempoHttpRequest,
  type TempoTransport,
  type TempoTrustedCatalog,
} from "../../../adapters/tempo/src/index.ts";
import type {
  AdapterDoctorResult,
  EvidenceAdapter,
} from "../../adapter-sdk/src/index.ts";
import {
  requiredProviderScopesForBinding,
  type LoadedTrustRoot,
  type ProviderRuntimeBinding,
} from "../../config/src/index.ts";
import type { TrustedEndpoint } from "../../contracts/src/index.ts";

import {
  NodeTrustedHttpClient,
  RuntimeTransportError,
  bufferedBody,
  type RuntimeCredentialResolver,
  type RuntimeDnsResolver,
} from "./http-transport.ts";

export interface WorkerRuntimeOptions {
  environment?: Readonly<NodeJS.ProcessEnv>;
  resolver?: RuntimeDnsResolver;
  credentialResolver?: RuntimeCredentialResolver;
}

const HEALTH_PATH = {
  prometheus: "/api/v1/status/runtimeinfo",
  grafana: "/api/health",
  alertmanager: "/-/ready",
  loki: "/ready",
  tempo: "/ready",
  kubernetes: "/version",
} as const;

function scopeAdmissionCheck(
  root: Readonly<LoadedTrustRoot>,
  binding: Readonly<ProviderRuntimeBinding>,
): AdapterDoctorResult["checks"][number] {
  const required = [...requiredProviderScopesForBinding(binding, root.bundle)];
  const effective = [...binding.access.effectiveProviderScopes].sort();
  if (JSON.stringify(required) !== JSON.stringify(effective)) {
    return {
      name: `provider-scope-admission:${binding.kind}`,
      status: "FAIL",
      message: "Manifest-sealed provider authority does not exactly match active operation requirements",
    };
  }
  return {
    name: `provider-scope-admission:${binding.kind}`,
    status: "PASS",
    message: "Manifest-sealed effective provider scopes exactly match active operation requirements; provider IAM was not introspected",
  };
}

function withSealedScopeAdmission(
  adapter: EvidenceAdapter,
  root: Readonly<LoadedTrustRoot>,
  binding: Readonly<ProviderRuntimeBinding>,
): EvidenceAdapter {
  return {
    descriptor: adapter.descriptor,
    async doctor(context) {
      const configured = await adapter.doctor(context);
      const scopeAdmission = scopeAdmissionCheck(root, binding);
      return {
        status: scopeAdmission.status === "FAIL" ? "BLOCKED" : configured.status,
        checks: [...configured.checks, scopeAdmission],
      };
    },
    compile: (operation, context) => adapter.compile(operation, context),
    execute: (context, operation) => adapter.execute(context, operation),
  };
}

function validStructuredHealthBody(
  kind: Exclude<ProviderRuntimeBinding["kind"], "git" | "fixture">,
  body: Uint8Array,
): boolean {
  if (kind !== "prometheus" && kind !== "grafana" && kind !== "kubernetes") return true;
  try {
    const value = JSON.parse(Buffer.from(body).toString("utf8")) as unknown;
    if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
    const object = value as Record<string, unknown>;
    if (kind === "prometheus") {
      return object.status === "success" && object.data !== null && typeof object.data === "object" && !Array.isArray(object.data);
    }
    if (kind === "grafana") return object.database === "ok" && typeof object.version === "string";
    return typeof object.major === "string" && typeof object.minor === "string";
  } catch {
    return false;
  }
}

type HttpProviderKind = Exclude<ProviderRuntimeBinding["kind"], "git" | "fixture">;

function providerClockCheck(
  kind: HttpProviderKind,
  warning: boolean,
  unavailable = false,
): AdapterDoctorResult["checks"][number] {
  return warning
    ? {
        name: `provider-clock:${kind}`,
        status: "WARN",
        message: unavailable
          ? "Provider clock could not be evaluated because the fixed health route was unreachable"
          : "Provider clock could not be verified within the allowed skew",
      }
    : {
        name: `provider-clock:${kind}`,
        status: "PASS",
        message: "Provider clock is within the allowed skew",
      };
}

function blockedConnectivity(
  kind: HttpProviderKind,
  checks: AdapterDoctorResult["checks"],
  message: string,
  clockWarning: boolean,
  clockUnavailable = false,
): AdapterDoctorResult {
  return {
    status: "BLOCKED",
    checks: [
      ...checks,
      { name: `provider-connectivity:${kind}`, status: "FAIL", message },
      providerClockCheck(kind, clockWarning, clockUnavailable),
    ],
  };
}

function withProviderConnectivity(
  adapter: EvidenceAdapter,
  root: Readonly<LoadedTrustRoot>,
  binding: Exclude<ProviderRuntimeBinding, { kind: "git" | "fixture" }>,
  clients: readonly NodeTrustedHttpClient[],
): EvidenceAdapter {
  const kind = binding.kind;
  return {
    descriptor: adapter.descriptor,
    async doctor(context) {
      const configured = await adapter.doctor(context);
      const scopeAdmission = scopeAdmissionCheck(root, binding);
      const checks = [...configured.checks, scopeAdmission];
      if (configured.status === "BLOCKED" || scopeAdmission.status === "FAIL") {
        return {
          status: "BLOCKED",
          checks: [
            ...checks,
            {
              name: `provider-connectivity:${kind}`,
              status: "WARN",
              message: "Provider connectivity was not evaluated because adapter or scope admission was blocked",
            },
            {
              name: `provider-clock:${kind}`,
              status: "WARN",
              message: "Provider clock was not evaluated because adapter or scope admission was blocked",
            },
          ],
        };
      }
      let clockWarning = false;
      try {
        for (const http of clients) {
          context.signal.throwIfAborted();
          const response = await http.get(HEALTH_PATH[kind], {}, context.signal, 4_096);
          const providerDate = response.headers.date;
          if (providerDate === undefined || !Number.isFinite(Date.parse(providerDate))) {
            clockWarning = true;
          } else if (Math.abs(Date.parse(providerDate) - context.clock.now().getTime()) > 5 * 60_000) {
            clockWarning = true;
          }
          if (response.status === 401) {
            return blockedConnectivity(
              kind,
              checks,
              "Provider rejected the configured read credential",
              clockWarning,
            );
          }
          if (response.status === 403) {
            return blockedConnectivity(
              kind,
              checks,
              "Provider denied access to the fixed health route",
              clockWarning,
            );
          }
          if (response.status < 200 || response.status >= 300) {
            return blockedConnectivity(
              kind,
              checks,
              "Provider fixed health route was unavailable",
              clockWarning,
            );
          }
          if (!validStructuredHealthBody(kind, response.body)) {
            return blockedConnectivity(
              kind,
              checks,
              "Provider fixed health route returned an invalid bounded response",
              clockWarning,
            );
          }
        }
      } catch (error) {
        if (context.signal.aborted) throw error;
        if (error instanceof RuntimeTransportError && error.kind === "TIMEOUT") {
          return blockedConnectivity(
            kind,
            checks,
            "Provider fixed health route timed out",
            true,
            true,
          );
        }
        return blockedConnectivity(
          kind,
          checks,
          "Provider fixed health route was unreachable",
          true,
          true,
        );
      }
      checks.push({
        name: `provider-connectivity:${kind}`,
        status: "PASS",
        message: "Fixed bounded health route passed the configured transport policy",
      });
      checks.push(providerClockCheck(kind, clockWarning));
      checks.push({
        name: `provider-read-authorization:${kind}`,
        status: "WARN",
        message: "Health connectivity does not prove that the configured identity can execute a catalog read",
      });
      return {
        status: "WARN",
        checks,
      };
    },
    compile: (operation, context) => adapter.compile(operation, context),
    execute: (context, operation) => adapter.execute(context, operation),
  };
}

function endpoint(root: LoadedTrustRoot, endpointId: string): Readonly<TrustedEndpoint> {
  const value = root.bundle.endpoints.find((candidate) => candidate.endpointId === endpointId);
  if (value === undefined) throw new RuntimeTransportError("ENDPOINT_NOT_ADMITTED", "POLICY");
  return value;
}

function client(
  root: LoadedTrustRoot,
  binding: Exclude<ProviderRuntimeBinding, { kind: "git" | "fixture" }>,
  endpointId: string,
  options: WorkerRuntimeOptions,
): NodeTrustedHttpClient {
  return new NodeTrustedHttpClient({
    endpoint: endpoint(root, endpointId),
    metadata: root.providerRuntime!.configuration.metadata,
    environment: options.environment ?? process.env,
    timeoutMs: binding.bootstrap.transport.timeoutMs,
    maxResponseBytes: binding.bootstrap.transport.maxResponseBytes,
    ...(options.resolver === undefined ? {} : { resolver: options.resolver }),
    ...(options.credentialResolver === undefined
      ? {}
      : { credentialResolver: options.credentialResolver }),
  });
}

function transportError(error: unknown, create: (kind: "TIMEOUT" | "UNAVAILABLE") => Error): never {
  if (error instanceof RuntimeTransportError) {
    throw create(error.kind === "TIMEOUT" ? "TIMEOUT" : "UNAVAILABLE");
  }
  throw error;
}

function prometheusTransport(http: NodeTrustedHttpClient): PrometheusTransport {
  return {
    async request(request: Readonly<PrometheusHttpRequest>) {
      try {
        const response = await http.get(request.path, request.query, request.signal, request.maxResponseBytes);
        return { status: response.status, body: bufferedBody(response.body) };
      } catch (error) {
        transportError(error, (kind) => new PrometheusTransportError(kind));
      }
    },
  };
}

function grafanaTransport(http: NodeTrustedHttpClient): GrafanaTransport {
  return {
    async request(request: Readonly<GrafanaHttpRequest>) {
      try {
        const response = request.method === "POST"
          ? await http.postJson(request.path, request.body, request.signal, request.maxResponseBytes)
          : await http.get(request.path, request.query, request.signal, request.maxResponseBytes);
        return { status: response.status, body: bufferedBody(response.body) };
      } catch (error) {
        transportError(error, (kind) => new GrafanaTransportError(kind));
      }
    },
  };
}

function lokiTransport(http: NodeTrustedHttpClient): LokiTransport {
  return {
    async request(request: Readonly<LokiHttpRequest>) {
      try {
        const response = await http.get(
          "/loki/api/v1/query_range",
          {
            query: request.expression,
            start: request.start,
            end: request.end,
            direction: request.direction,
            limit: String(request.limit),
          },
          request.signal,
          request.maxResponseBytes,
        );
        return { status: response.status, body: bufferedBody(response.body) };
      } catch (error) {
        transportError(error, (kind) => new LokiTransportError(kind));
      }
    },
  };
}

function tempoTransport(http: NodeTrustedHttpClient): TempoTransport {
  return {
    async request(request: Readonly<TempoHttpRequest>) {
      try {
        const response = request.route === "SEARCH"
          ? await http.get(
              "/api/search",
              { q: request.query, start: request.start, end: request.end, limit: String(request.limit) },
              request.signal,
              request.maxResponseBytes,
            )
          : await http.get(
              `/api/traces/${encodeURIComponent(request.traceId)}`,
              {},
              request.signal,
              request.maxResponseBytes,
            );
        return { status: response.status, body: bufferedBody(response.body) };
      } catch (error) {
        transportError(error, (kind) => new TempoTransportError(kind));
      }
    },
  };
}

function kubernetesPath(request: Readonly<KubernetesReadRequest>): string {
  const prefix = request.resource === "pods" ? "/api/v1" : "/apis/apps/v1";
  const base = `${prefix}/namespaces/${encodeURIComponent(request.namespace)}/${request.resource}`;
  return request.mode === "GET" ? `${base}/${encodeURIComponent(request.name!)}` : base;
}

function kubernetesTransport(http: NodeTrustedHttpClient): KubernetesTransport {
  return {
    async request(request: Readonly<KubernetesReadRequest>) {
      try {
        const query: Record<string, string> = { limit: String(request.limit) };
        if (request.selector !== undefined) query.labelSelector = `${request.selector.key}=${request.selector.value}`;
        const response = await http.get(kubernetesPath(request), query, request.signal, request.maxResponseBytes);
        return { status: response.status, body: bufferedBody(response.body) };
      } catch (error) {
        transportError(error, (kind) => new KubernetesTransportError(kind));
      }
    },
  };
}

/** Instantiate one fixed binding after the worker has independently reloaded its trusted root. */
export function instantiateProviderAdapter(
  root: LoadedTrustRoot,
  binding: ProviderRuntimeBinding,
  options: WorkerRuntimeOptions = {},
): EvidenceAdapter {
  if (binding.kind === "fixture") return withSealedScopeAdmission(fixtureAdapter, root, binding);
  if (binding.kind === "git") {
    return withSealedScopeAdmission(new GitAdapter({
      gitExecutable: binding.bootstrap.gitExecutable,
      workspaces: binding.bootstrap.workspaces as unknown as GitWorkspaceBinding[],
      catalog: binding.bootstrap.catalog as unknown as GitCatalogBinding[],
    }), root, binding);
  }
  if (binding.kind === "alertmanager") {
    const clients = new Map(
      binding.bootstrap.endpointIds.map((endpointId) => [endpointId, client(root, binding, endpointId, options)]),
    );
    const transport: AlertmanagerTransport = {
      async request(request) {
        const http = clients.get(request.endpointId);
        if (http === undefined) throw new RuntimeTransportError("ENDPOINT_NOT_ADMITTED", "POLICY");
        const response = await http.getAbsolute(request.url, request.signal, request.maxBytes);
        return { status: response.status, headers: response.headers, body: response.body };
      },
    };
    const adapter = new AlertmanagerAdapter({
      endpoints: binding.bootstrap.endpointIds.map((endpointId) => ({
        endpointId,
        baseUrl: endpoint(root, endpointId).baseUrl,
      })),
      catalog: binding.bootstrap.catalog as unknown as AlertmanagerCatalogBinding[],
      transport,
    });
    return withProviderConnectivity(adapter, root, binding, [...clients.values()]);
  }
  const http = client(root, binding, binding.bootstrap.endpointId, options);
  if (binding.kind === "prometheus") {
    return withProviderConnectivity(new PrometheusAdapter({
      transport: prometheusTransport(http),
      catalog: binding.bootstrap.catalog as unknown as PrometheusTrustedCatalog,
    }), root, binding, [http]);
  }
  if (binding.kind === "grafana") {
    return withProviderConnectivity(new GrafanaAdapter({
      transport: grafanaTransport(http),
      catalog: binding.bootstrap.catalog as unknown as GrafanaTrustedCatalog,
    }), root, binding, [http]);
  }
  if (binding.kind === "loki") {
    return withProviderConnectivity(new LokiAdapter({
      transport: lokiTransport(http),
      catalog: binding.bootstrap.catalog as unknown as LokiTrustedCatalog,
    }), root, binding, [http]);
  }
  if (binding.kind === "tempo") {
    return withProviderConnectivity(new TempoAdapter({
      transport: tempoTransport(http),
      catalog: binding.bootstrap.catalog as unknown as TempoTrustedCatalog,
    }), root, binding, [http]);
  }
  return withProviderConnectivity(new KubernetesAdapter({
    transport: kubernetesTransport(http),
    catalog: binding.bootstrap.catalog as unknown as KubernetesTrustedCatalog,
  }), root, binding, [http]);
}
