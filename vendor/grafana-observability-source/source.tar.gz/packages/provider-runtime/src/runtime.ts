import { isAbsolute } from "node:path";
import { URL, fileURLToPath } from "node:url";

import {
  AdapterAdmissionError,
  AdapterExecutionError,
  createWorkerBackedAdapter,
  StaticWorkerRegistry,
  verifyWorkerAdmission,
  type AdapterCompileContext,
  type AdapterDescriptor,
  type AdapterDoctorContext,
  type AdapterDoctorResult,
  type AdapterExecutionContext,
  type CompiledAdapterOperation,
  type EvidenceAdapter,
  type ProviderResult,
  type WorkerTransport,
  type WorkerFactory,
} from "../../adapter-sdk/src/index.ts";
import {
  credentialReferenceIdentity,
  createStdioWorkerFactory,
  StdioWorkerTransport,
  type AdapterRegistration,
  type WorkerCredentialSource,
} from "../../adapter-host/src/index.ts";
import {
  V0_1_CODE_OWNED_PACKAGE_BY_KIND,
  PROVIDER_WORKER_ARTIFACT_PATH,
  providerBindingCredentialReferences,
  type LoadedTrustRoot,
  type ProviderRuntimeBinding,
} from "../../config/src/index.ts";
import type { AdapterPackage, CredentialReference, OperationSnapshot, Sha256 } from "../../contracts/src/index.ts";

export interface ProviderRuntimeIssue {
  packageId?: string;
  code: string;
  message: string;
}

export interface CodeOwnedWorkerArtifact {
  /** Portable signed path; the only config-originating portion of this mapping. */
  packageArtifactPath: string;
  /** Absolute launcher path selected by release code, never by a proposal or MCP request. */
  artifactPath: string;
  /** Release-pinned digest independently matched against signed package metadata. */
  artifactSha256: Sha256;
}

export interface ProviderRuntimeResult {
  registrations: AdapterRegistration[];
  issues: ProviderRuntimeIssue[];
  runtimeConfigurationSha256?: string;
  close(): Promise<void>;
}

export interface ProviderRuntimeOptions {
  environment?: Readonly<NodeJS.ProcessEnv>;
  /** Code-owned release mapping. Tests may inject an equally exact temporary build output. */
  releaseArtifacts?: readonly Readonly<CodeOwnedWorkerArtifact>[];
  /** Absolute Node-compatible runtime selected by the trusted launcher. */
  runtimePath?: string;
  /** Host-managed exact-reference credential source for non-environment secrets. */
  credentialSource?: WorkerCredentialSource;
  defaultRequestTimeoutMs?: number;
  shutdownGraceMs?: number;
}

class UnsupportedWorkerBoundaryError extends AdapterAdmissionError {
  constructor() {
    super("The current pre-1.0 runtime admits only release-code-owned first-party and fixture workers");
    this.name = "UnsupportedWorkerBoundaryError";
  }
}

function assertV01CodeOwnedWorker(
  binding: Readonly<ProviderRuntimeBinding>,
  adapterPackage: Readonly<AdapterPackage>,
): void {
  if (
    binding.packageId !== V0_1_CODE_OWNED_PACKAGE_BY_KIND[binding.kind] ||
    adapterPackage.packageId !== binding.packageId ||
    adapterPackage.entrypoint.kind !== "SIGNED_WORKER" ||
    adapterPackage.entrypoint.artifactPath !== PROVIDER_WORKER_ARTIFACT_PATH
  ) {
    throw new UnsupportedWorkerBoundaryError();
  }
}

function defaultReleaseArtifact(adapterPackage: AdapterPackage): CodeOwnedWorkerArtifact | undefined {
  if (
    adapterPackage.entrypoint.kind !== "SIGNED_WORKER" ||
    adapterPackage.entrypoint.artifactPath !== PROVIDER_WORKER_ARTIFACT_PATH
  ) {
    return undefined;
  }
  return {
    packageArtifactPath: PROVIDER_WORKER_ARTIFACT_PATH,
    artifactPath: fileURLToPath(new URL("../workers/provider-worker.mjs", import.meta.url)),
    artifactSha256: adapterPackage.entrypoint.artifactSha256,
  };
}

function descriptor(adapterPackage: AdapterPackage): AdapterDescriptor {
  return {
    packageId: adapterPackage.packageId,
    name: adapterPackage.name,
    version: adapterPackage.version,
    provider: adapterPackage.providerCompatibility[0]?.provider ?? "unknown",
    domains: [...adapterPackage.domains],
    operations: [...adapterPackage.capabilities],
    resultSchemaVersions: [...adapterPackage.supportedContractVersions],
  };
}

class CodeOwnedChildWorkerAdapter implements EvidenceAdapter {
  readonly descriptor: AdapterDescriptor;
  readonly #adapterPackage: AdapterPackage;
  readonly #registry: StaticWorkerRegistry;
  #lifecycle: "OPEN" | "CLOSING" | "CLOSED" = "OPEN";
  #opening: Promise<EvidenceAdapter> | undefined;
  #transport: WorkerTransport | undefined;
  #closePromise: Promise<void> | undefined;

  constructor(adapterPackage: AdapterPackage, registry: StaticWorkerRegistry) {
    this.#adapterPackage = adapterPackage;
    this.#registry = registry;
    this.descriptor = descriptor(adapterPackage);
  }

  #closedError(): AdapterExecutionError {
    return new AdapterExecutionError({
      code: "ADAPTER_WORKER_CLOSED",
      category: "INTERNAL",
      message: "Adapter worker is closed",
      retryable: false,
    });
  }

  #closedDoctor(): AdapterDoctorResult {
    return {
      status: "BLOCKED",
      checks: [{
        name: `signed-worker:${this.#adapterPackage.packageId}`,
        status: "FAIL",
        message: "Signed out-of-process worker runtime is closed",
      }],
    };
  }

  async #adapter(): Promise<EvidenceAdapter> {
    if (this.#lifecycle !== "OPEN") throw this.#closedError();
    this.#opening ??= (async () => {
      const transport = await this.#registry.create(this.#adapterPackage);
      this.#transport = transport;
      if (this.#lifecycle !== "OPEN") {
        await transport.close().catch(() => undefined);
        throw this.#closedError();
      }
      await new Promise<void>((resolve) => setImmediate(resolve));
      if (this.#lifecycle !== "OPEN") {
        await transport.close().catch(() => undefined);
        throw this.#closedError();
      }
      if (transport instanceof StdioWorkerTransport && transport.closed) {
        throw new AdapterAdmissionError("Signed worker exited during bootstrap");
      }
      return createWorkerBackedAdapter(this.#adapterPackage, transport);
    })();
    return this.#opening;
  }

  async #resetAfterWorkerFailure(error: unknown): Promise<void> {
    if (
      error instanceof AdapterExecutionError &&
      new Set([
        "ADAPTER_WORKER_CANCELLED",
        "ADAPTER_WORKER_CLOSED",
        "ADAPTER_WORKER_CRASH",
        "ADAPTER_WORKER_PROTOCOL",
        "ADAPTER_WORKER_OVERSIZE",
        "ADAPTER_WORKER_DEADLINE_EXCEEDED",
      ]).has(error.sanitized.code)
      && this.#lifecycle === "OPEN"
    ) {
      const failedTransport = this.#transport;
      this.#opening = undefined;
      this.#transport = undefined;
      await failedTransport?.close().catch(() => undefined);
    }
  }

  async doctor(context: AdapterDoctorContext): Promise<AdapterDoctorResult> {
    if (this.#lifecycle !== "OPEN") return this.#closedDoctor();
    if (context.signal.aborted) {
      return {
        status: "BLOCKED",
        checks: [{ name: `signed-worker:${this.#adapterPackage.packageId}`, status: "FAIL", message: "Signed worker admission was cancelled" }],
      };
    }
    try {
      const adapter = await this.#adapter();
      if (this.#lifecycle !== "OPEN") return this.#closedDoctor();
      const result = await adapter.doctor(context);
      return {
        status: result.status,
        checks: [
          {
            name: `signed-worker:${this.#adapterPackage.packageId}`,
            status: "PASS",
            message: "Release-code-owned signed child worker admitted; this process boundary is not an OS sandbox",
          },
          ...result.checks,
        ],
      };
    } catch (error) {
      await this.#resetAfterWorkerFailure(error);
      return {
        status: "BLOCKED",
        checks: [{ name: `signed-worker:${this.#adapterPackage.packageId}`, status: "FAIL", message: "Signed out-of-process worker admission failed" }],
      };
    }
  }

  async compile(operation: Readonly<OperationSnapshot>, context: AdapterCompileContext): Promise<CompiledAdapterOperation> {
    try {
      const adapter = await this.#adapter();
      if (this.#lifecycle !== "OPEN") throw this.#closedError();
      return await adapter.compile(operation, context);
    } catch (error) {
      await this.#resetAfterWorkerFailure(error);
      throw error;
    }
  }

  async execute(
    context: AdapterExecutionContext,
    operation: Readonly<CompiledAdapterOperation>,
  ): Promise<ProviderResult> {
    try {
      const adapter = await this.#adapter();
      if (this.#lifecycle !== "OPEN") throw this.#closedError();
      return await adapter.execute(context, operation);
    } catch (error) {
      await this.#resetAfterWorkerFailure(error);
      throw error;
    }
  }

  close(): Promise<void> {
    if (this.#closePromise !== undefined) return this.#closePromise;
    this.#lifecycle = "CLOSING";
    const opening = this.#opening;
    this.#closePromise = (async () => {
      try {
        await opening?.catch(() => undefined);
        const transport = this.#transport;
        this.#opening = undefined;
        this.#transport = undefined;
        await transport?.close();
      } finally {
        this.#lifecycle = "CLOSED";
      }
    })();
    return this.#closePromise;
  }
}

function concurrentSafeRuntimeClose(
  adapters: readonly CodeOwnedChildWorkerAdapter[] = [],
): () => Promise<void> {
  let closePromise: Promise<void> | undefined;
  return () => {
    closePromise ??= Promise.allSettled(adapters.map((adapter) => adapter.close())).then(() => undefined);
    return closePromise;
  };
}

function safeCredentialEnvironment(
  binding: Readonly<ProviderRuntimeBinding>,
  environment: Readonly<NodeJS.ProcessEnv>,
): Readonly<Record<string, string>> {
  const selected: Record<string, string> = Object.create(null) as Record<string, string>;
  for (const key of binding.credentialEnv) {
    const value = environment[key];
    if (value === undefined || value.length === 0 || value.length > 1_048_576 || value.includes("\0")) {
      throw new AdapterAdmissionError("A required credential environment reference is unavailable");
    }
    selected[key] = value;
  }
  return Object.freeze(selected);
}

function fixedWorkerArguments(root: LoadedTrustRoot, packageId: string): string[] {
  return [
    "--trust-root",
    root.rootPath,
    "--root-manifest-sha256",
    root.rootManifestSha256,
    "--trust-bundle-sha256",
    root.trustBundleSha256,
    "--runtime-sha256",
    root.providerRuntime!.sourceSha256,
    "--package-id",
    packageId,
  ];
}

function validatingWorkerFactory(options: {
  runtimePath: string;
  artifactArguments: readonly string[];
  environment: Readonly<Record<string, string>>;
  credentialReferences: readonly Readonly<CredentialReference>[];
  credentialSource?: WorkerCredentialSource;
  defaultRequestTimeoutMs?: number;
  shutdownGraceMs?: number;
}): WorkerFactory {
  if (!isAbsolute(options.runtimePath)) {
    throw new AdapterAdmissionError("Worker runtime path must be absolute");
  }
  return createStdioWorkerFactory({
    runtimePath: options.runtimePath,
    artifactArguments: options.artifactArguments,
    validationArtifactArguments: [...options.artifactArguments, "--validate-only"],
    environment: options.environment,
    credentialReferences: options.credentialReferences,
    ...(options.credentialSource === undefined ? {} : { credentialSource: options.credentialSource }),
    ...(options.defaultRequestTimeoutMs === undefined ? {} : { defaultRequestTimeoutMs: options.defaultRequestTimeoutMs }),
    ...(options.shutdownGraceMs === undefined ? {} : { shutdownGraceMs: options.shutdownGraceMs }),
  });
}

/**
 * Construct exclusively release-code-owned first-party or fixture child-worker
 * registrations. There is intentionally no BUILTIN, in-process, or third-party
 * fallback on this v0.1 production path. The child is a protocol/crash boundary,
 * not an OS filesystem, network, CPU, or memory sandbox.
 */
export function createProviderRuntime(
  root: LoadedTrustRoot,
  options: ProviderRuntimeOptions = {},
): ProviderRuntimeResult {
  if (root.providerRuntime === undefined) {
    return {
      registrations: [],
      issues: [{ code: "PROVIDER_RUNTIME_NOT_CONFIGURED", message: "No manifest-hashed provider runtime configuration is active" }],
      close: concurrentSafeRuntimeClose(),
    };
  }

  const configuration = root.providerRuntime.configuration;
  const environment = options.environment ?? process.env;
  const trustedSigningKeys = new Map(root.providerRuntime.signingKeys.map((key) => [key.keyId, key.publicKeyPem]));
  const adapterPackages = new Map(root.bundle.adapters.map((adapterPackage) => [adapterPackage.packageId, adapterPackage]));
  const admissionPolicy = {
    trustedSigningKeys,
    allowedPackageIds: new Set(configuration.adapters.map((binding) => binding.packageId)),
    allowedArtifactHashes: new Set(
      configuration.adapters.flatMap((binding) => {
        const entrypoint = adapterPackages.get(binding.packageId)?.entrypoint;
        return entrypoint?.kind === "SIGNED_WORKER" ? [entrypoint.artifactSha256] : [];
      }),
    ),
    revokedPackageIds: new Set(configuration.workerAdmission.revocations.packageIds),
    revokedArtifactHashes: new Set(configuration.workerAdmission.revocations.artifactSha256s),
    revokedArtifactPaths: new Set(configuration.workerAdmission.revocations.artifactPaths),
    revokedSigningKeyIds: new Set(configuration.workerAdmission.revocations.signingKeyIds),
  };
  const suppliedArtifacts = options.releaseArtifacts;
  const staticRegistrations = [];
  const admittedPackages: AdapterPackage[] = [];
  const issues: ProviderRuntimeIssue[] = [];

  for (const binding of configuration.adapters) {
    const adapterPackage = adapterPackages.get(binding.packageId);
    try {
      if (adapterPackage === undefined || adapterPackage.entrypoint.kind !== "SIGNED_WORKER") {
        throw new AdapterAdmissionError("Configured adapter is not a signed worker");
      }
      assertV01CodeOwnedWorker(binding, adapterPackage);
      const nonEnvironmentReferences = [...new Map(
        providerBindingCredentialReferences(binding, root.bundle)
          .filter((reference) => reference.kind !== "env")
          .map((reference) => [credentialReferenceIdentity(reference), reference]),
      ).values()];
      if (nonEnvironmentReferences.length > 0 && options.credentialSource === undefined) {
        throw new AdapterAdmissionError("An explicit credential resolver is required but not configured");
      }
      verifyWorkerAdmission(adapterPackage, admissionPolicy);
      const workerEntrypoint = adapterPackage.entrypoint;
      const credentialEnvironment = safeCredentialEnvironment(binding, environment);
      const candidateArtifacts = suppliedArtifacts ?? [defaultReleaseArtifact(adapterPackage)].filter(
        (value): value is CodeOwnedWorkerArtifact => value !== undefined,
      );
      const releaseArtifact = candidateArtifacts.find((candidate) =>
        candidate.packageArtifactPath === workerEntrypoint.artifactPath &&
        candidate.artifactSha256 === workerEntrypoint.artifactSha256
      );
      if (releaseArtifact === undefined) {
        throw new AdapterAdmissionError("No exact code-owned release artifact mapping exists");
      }
      staticRegistrations.push({
        packageId: adapterPackage.packageId,
        packageArtifactPath: releaseArtifact.packageArtifactPath,
        artifactPath: releaseArtifact.artifactPath,
        artifactSha256: releaseArtifact.artifactSha256,
        factory: validatingWorkerFactory({
          runtimePath: options.runtimePath ?? process.execPath,
          artifactArguments: fixedWorkerArguments(root, adapterPackage.packageId),
          environment: credentialEnvironment,
          credentialReferences: nonEnvironmentReferences,
          ...(options.credentialSource === undefined ? {} : { credentialSource: options.credentialSource }),
          ...(options.defaultRequestTimeoutMs === undefined ? {} : { defaultRequestTimeoutMs: options.defaultRequestTimeoutMs }),
          ...(options.shutdownGraceMs === undefined ? {} : { shutdownGraceMs: options.shutdownGraceMs }),
        }),
      });
      admittedPackages.push(adapterPackage);
    } catch (error) {
      issues.push({
        packageId: binding.packageId,
        code: error instanceof UnsupportedWorkerBoundaryError
          ? "THIRD_PARTY_ADAPTER_NOT_SUPPORTED"
          : error instanceof AdapterAdmissionError && /resolver/u.test(error.message)
          ? "CREDENTIAL_RESOLVER_NOT_CONFIGURED"
          : error instanceof AdapterAdmissionError && /credential/u.test(error.message)
            ? "CREDENTIAL_UNAVAILABLE"
            : "SIGNED_WORKER_ADMISSION_FAILED",
        message: `Configured adapter ${binding.packageId} is unavailable`,
      });
    }
  }

  let registry: StaticWorkerRegistry;
  try {
    registry = new StaticWorkerRegistry(staticRegistrations, admissionPolicy);
  } catch {
    return {
      registrations: [],
      issues: [...issues, { code: "WORKER_REGISTRY_INVALID", message: "The signed worker registry failed closed" }],
      runtimeConfigurationSha256: root.providerRuntime.sourceSha256,
      close: concurrentSafeRuntimeClose(),
    };
  }
  const childWorkerAdapters = admittedPackages.map(
    (adapterPackage) => new CodeOwnedChildWorkerAdapter(adapterPackage, registry),
  );
  const close = concurrentSafeRuntimeClose(childWorkerAdapters);
  return {
    registrations: childWorkerAdapters.map((adapter, index) => ({ adapterPackage: admittedPackages[index]!, adapter })),
    issues,
    runtimeConfigurationSha256: root.providerRuntime.sourceSha256,
    close,
  };
}
