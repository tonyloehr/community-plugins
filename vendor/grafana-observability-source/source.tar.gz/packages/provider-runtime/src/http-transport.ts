import { lookup as dnsLookup } from "node:dns/promises";
import { request as httpRequest } from "node:http";
import type { ClientRequest, IncomingHttpHeaders } from "node:http";
import { request as httpsRequest, type RequestOptions } from "node:https";
import { BlockList, isIP } from "node:net";

import {
  canonicalJson,
  type CredentialReference,
  type JsonObject,
  type NetworkPolicy,
  type TrustedEndpoint,
} from "../../contracts/src/index.ts";

const MAX_JSON_REQUEST_BYTES = 262_144;

export interface ResolvedAddress {
  address: string;
  family: 4 | 6;
}

export interface RuntimeDnsResolver {
  lookup(hostname: string): Promise<readonly ResolvedAddress[]>;
}

export interface RuntimeCredentialResolver {
  /** Return only the value for this exact trusted reference. Never log it. */
  resolve(reference: Readonly<CredentialReference>): string | undefined;
}

export interface TrustedHttpClientOptions {
  endpoint: Readonly<TrustedEndpoint>;
  metadata: Readonly<Record<string, string>>;
  environment: Readonly<NodeJS.ProcessEnv>;
  timeoutMs: number;
  maxResponseBytes: number;
  resolver?: RuntimeDnsResolver;
  credentialResolver?: RuntimeCredentialResolver;
}

export interface TrustedHttpResponse {
  status: number;
  headers: Readonly<Record<string, string>>;
  body: Uint8Array;
}

export class RuntimeTransportError extends Error {
  readonly code: string;
  readonly kind: "POLICY" | "TIMEOUT" | "UNAVAILABLE" | "RESPONSE_TOO_LARGE";

  constructor(
    code: string,
    kind: "POLICY" | "TIMEOUT" | "UNAVAILABLE" | "RESPONSE_TOO_LARGE",
  ) {
    super(`Trusted provider transport failed (${code})`);
    this.name = "RuntimeTransportError";
    this.code = code;
    this.kind = kind;
  }
}

const defaultResolver: RuntimeDnsResolver = {
  async lookup(hostname) {
    const literal = normalizeAddress(hostname);
    const family = isIP(literal);
    if (family === 4 || family === 6) return [{ address: literal, family }];
    const results = await dnsLookup(hostname, { all: true, verbatim: true });
    return results
      .filter((entry): entry is { address: string; family: 4 | 6 } => entry.family === 4 || entry.family === 6)
      .map((entry) => ({ address: normalizeAddress(entry.address), family: entry.family }));
  },
};

const loopbackAddresses = new BlockList();
loopbackAddresses.addSubnet("127.0.0.0", 8, "ipv4");
loopbackAddresses.addAddress("::1", "ipv6");

const privateAddresses = new BlockList();
privateAddresses.addSubnet("10.0.0.0", 8, "ipv4");
privateAddresses.addSubnet("172.16.0.0", 12, "ipv4");
privateAddresses.addSubnet("192.168.0.0", 16, "ipv4");
privateAddresses.addSubnet("fc00::", 7, "ipv6");

const nonPublicAddresses = new BlockList();
for (const [address, prefix] of [
  ["0.0.0.0", 8],
  ["10.0.0.0", 8],
  ["100.64.0.0", 10],
  ["127.0.0.0", 8],
  ["169.254.0.0", 16],
  ["172.16.0.0", 12],
  ["192.0.0.0", 24],
  ["192.0.2.0", 24],
  ["192.168.0.0", 16],
  ["198.18.0.0", 15],
  ["198.51.100.0", 24],
  ["203.0.113.0", 24],
  ["224.0.0.0", 4],
  ["240.0.0.0", 4],
] as const) {
  nonPublicAddresses.addSubnet(address, prefix, "ipv4");
}
for (const [address, prefix] of [
  ["::", 128],
  ["::1", 128],
  ["fc00::", 7],
  ["fe80::", 10],
  ["ff00::", 8],
  ["2001:db8::", 32],
  ["64:ff9b::", 96],
  ["64:ff9b:1::", 48],
  ["2001::", 32],
  ["2002::", 16],
] as const) {
  nonPublicAddresses.addSubnet(address, prefix, "ipv6");
}

function normalizeAddress(value: string): string {
  const unwrapped = value.startsWith("[") && value.endsWith("]") ? value.slice(1, -1) : value;
  return unwrapped.toLowerCase().startsWith("::ffff:") ? unwrapped.slice(7) : unwrapped.toLowerCase();
}

export type RuntimeNetworkClass = NetworkPolicy["networkClass"] | "forbidden";

export function classifyNetworkAddress(value: string): RuntimeNetworkClass {
  const address = normalizeAddress(value);
  const family = isIP(address);
  if (family !== 4 && family !== 6) return "forbidden";
  const type = family === 4 ? "ipv4" : "ipv6";
  if (loopbackAddresses.check(address, type)) return "loopback";
  if (privateAddresses.check(address, type)) return "private";
  if (nonPublicAddresses.check(address, type)) return "forbidden";
  return "public";
}

function normalizeHost(value: string): string {
  return value.trim().toLowerCase().replace(/\.$/u, "").replace(/^\[(.*)\]$/u, "$1");
}

function isLoopback(hostname: string): boolean {
  const host = normalizeHost(hostname);
  if (host === "localhost" || host === "::1") return true;
  const match = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/u.exec(host);
  if (match === null) return false;
  const octets = match.slice(1).map(Number);
  return octets.every((octet) => octet >= 0 && octet <= 255) && octets[0] === 127;
}

function hasUnsafeHeaderMaterial(value: string): boolean {
  return /[\r\n\0]/u.test(value);
}

function resolveCredential(
  reference: Readonly<CredentialReference>,
  options: Pick<TrustedHttpClientOptions, "environment" | "credentialResolver">,
): string {
  let value: string | undefined;
  if (reference.kind === "env") {
    value = options.environment[reference.key];
  } else {
    if (options.credentialResolver === undefined) {
      throw new RuntimeTransportError("CREDENTIAL_RESOLVER_NOT_CONFIGURED", "POLICY");
    }
    try {
      value = options.credentialResolver.resolve(reference);
    } catch {
      throw new RuntimeTransportError("CREDENTIAL_RESOLUTION_FAILED", "POLICY");
    }
  }
  if (value === undefined || value.length === 0 || value.length > 1_048_576 || value.includes("\0")) {
    throw new RuntimeTransportError("CREDENTIAL_UNAVAILABLE", "POLICY");
  }
  return value;
}

function responseHeaders(headers: IncomingHttpHeaders): Readonly<Record<string, string>> {
  const output: Record<string, string> = {};
  for (const [name, value] of Object.entries(headers)) {
    if (typeof value === "string") output[name.toLowerCase()] = value;
    else if (Array.isArray(value)) output[name.toLowerCase()] = value.join(", ");
  }
  return Object.freeze(output);
}

function safePathSegments(pathname: string): void {
  if (!pathname.startsWith("/") || pathname.startsWith("//") || pathname.includes("\\") || pathname.includes("\0")) {
    throw new RuntimeTransportError("UNSAFE_PATH", "POLICY");
  }
  for (const segment of pathname.split("/")) {
    let decoded: string;
    try {
      decoded = decodeURIComponent(segment);
    } catch {
      throw new RuntimeTransportError("INVALID_PATH_ENCODING", "POLICY");
    }
    if (decoded === "." || decoded === ".." || decoded.includes("/") || decoded.includes("\\")) {
      throw new RuntimeTransportError("PATH_TRAVERSAL", "POLICY");
    }
  }
}

function asyncBody(body: Uint8Array): AsyncIterable<Uint8Array> {
  return {
    async *[Symbol.asyncIterator]() {
      yield body;
    },
  };
}

async function boundedLookup(
  resolver: RuntimeDnsResolver,
  hostname: string,
  signal: AbortSignal,
  timeoutMs: number,
): Promise<readonly ResolvedAddress[]> {
  return new Promise<readonly ResolvedAddress[]>((resolvePromise, rejectPromise) => {
    let settled = false;
    const finish = (result: { addresses: readonly ResolvedAddress[] } | { error: unknown }) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal.removeEventListener("abort", onAbort);
      if ("error" in result) rejectPromise(result.error);
      else resolvePromise(result.addresses);
    };
    const onAbort = () => finish({ error: signal.reason ?? new RuntimeTransportError("CANCELLED", "UNAVAILABLE") });
    const timer = setTimeout(
      () => finish({ error: new RuntimeTransportError("DEADLINE_EXCEEDED", "TIMEOUT") }),
      timeoutMs,
    );
    timer.unref();
    signal.addEventListener("abort", onAbort, { once: true });
    if (signal.aborted) {
      onAbort();
      return;
    }
    void resolver.lookup(hostname).then(
      (addresses) => finish({ addresses }),
      () => finish({ error: new RuntimeTransportError("DNS_UNAVAILABLE", "UNAVAILABLE") }),
    );
  });
}

export function bufferedBody(body: Uint8Array): AsyncIterable<Uint8Array> {
  return asyncBody(body);
}

/**
 * One endpoint-bound Node transport. It never accepts a destination URL from model input,
 * never follows redirects, and pins each connection to the DNS answer it subsequently rechecks.
 */
export class NodeTrustedHttpClient {
  readonly #endpoint: Readonly<TrustedEndpoint>;
  readonly #base: URL;
  readonly #headers: Readonly<Record<string, string>>;
  readonly #tls: Readonly<{
    minimumVersion: "TLSv1.2" | "TLSv1.3";
    ca?: string;
    certificate?: string;
    privateKey?: string;
    serverName?: string;
  }>;
  readonly #timeoutMs: number;
  readonly #maxResponseBytes: number;
  readonly #resolver: RuntimeDnsResolver;

  constructor(options: TrustedHttpClientOptions) {
    this.#endpoint = options.endpoint;
    this.#base = new URL(options.endpoint.baseUrl);
    if (
      this.#base.username !== "" ||
      this.#base.password !== "" ||
      this.#base.search !== "" ||
      this.#base.hash !== ""
    ) {
      throw new RuntimeTransportError("UNSAFE_ENDPOINT_MATERIAL", "POLICY");
    }
    const hostname = normalizeHost(this.#base.hostname);
    const allowedHosts = options.endpoint.network.allowedHosts.map(normalizeHost);
    if (!allowedHosts.includes(hostname)) throw new RuntimeTransportError("HOST_NOT_ALLOWED", "POLICY");
    if (options.endpoint.network.followRedirects !== false) {
      throw new RuntimeTransportError("REDIRECTS_MUST_BE_DISABLED", "POLICY");
    }
    if (options.endpoint.network.routeMode === "application_proxy") {
      throw new RuntimeTransportError("APPLICATION_PROXY_NOT_IMPLEMENTED", "POLICY");
    }
    if (
      options.endpoint.network.routeMode === "host_vpn" &&
      options.endpoint.network.networkClass !== "private"
    ) {
      throw new RuntimeTransportError("HOST_VPN_REQUIRES_PRIVATE_NETWORK", "POLICY");
    }
    if (this.#base.protocol !== "https:") {
      if (this.#base.protocol !== "http:" || !options.endpoint.network.allowLoopbackHttp || !isLoopback(hostname)) {
        throw new RuntimeTransportError("INSECURE_ENDPOINT", "POLICY");
      }
      if (
        options.endpoint.authentication.mode === "MTLS" ||
        options.endpoint.tls.caRef !== undefined ||
        options.endpoint.tls.serverName !== undefined
      ) {
        throw new RuntimeTransportError("TLS_POLICY_REQUIRES_HTTPS", "POLICY");
      }
    }
    if (!Number.isSafeInteger(options.timeoutMs) || options.timeoutMs < 1 || options.timeoutMs > 120_000) {
      throw new RuntimeTransportError("INVALID_TIMEOUT", "POLICY");
    }
    if (!Number.isSafeInteger(options.maxResponseBytes) || options.maxResponseBytes < 1 || options.maxResponseBytes > 1_073_741_824) {
      throw new RuntimeTransportError("INVALID_BYTE_LIMIT", "POLICY");
    }
    const headers: Record<string, string> = { Accept: "application/json" };
    const authentication = options.endpoint.authentication;
    if (authentication.mode === "BEARER") {
      const token = resolveCredential(authentication.tokenRef, options);
      if (hasUnsafeHeaderMaterial(token)) throw new RuntimeTransportError("CREDENTIAL_UNAVAILABLE", "POLICY");
      headers.Authorization = `Bearer ${token}`;
    } else if (authentication.mode === "BASIC") {
      const username = resolveCredential(authentication.usernameRef, options);
      const password = resolveCredential(authentication.passwordRef, options);
      if (
        username.includes(":") ||
        hasUnsafeHeaderMaterial(username) ||
        hasUnsafeHeaderMaterial(password)
      ) {
        throw new RuntimeTransportError("CREDENTIAL_UNAVAILABLE", "POLICY");
      }
      headers.Authorization = `Basic ${Buffer.from(`${username}:${password}`, "utf8").toString("base64")}`;
    }
    if (options.endpoint.tenantBinding !== undefined) {
      const key = options.endpoint.tenantBinding.valueRef.slice("metadata:".length);
      const tenantValue = options.metadata[key];
      if (tenantValue === undefined || tenantValue.length === 0 || hasUnsafeHeaderMaterial(tenantValue)) {
        throw new RuntimeTransportError("TENANT_BINDING_UNAVAILABLE", "POLICY");
      }
      headers[options.endpoint.tenantBinding.headerName] = tenantValue;
    }
    this.#headers = Object.freeze(headers);
    const ca = options.endpoint.tls.caRef === undefined
      ? undefined
      : resolveCredential(options.endpoint.tls.caRef, options);
    const clientIdentity = authentication.mode === "MTLS"
      ? {
          certificate: resolveCredential(authentication.certificateRef, options),
          privateKey: resolveCredential(authentication.privateKeyRef, options),
        }
      : {};
    this.#tls = Object.freeze({
      minimumVersion: options.endpoint.tls.minimumVersion,
      ...(ca === undefined ? {} : { ca }),
      ...clientIdentity,
      ...(options.endpoint.tls.serverName === undefined
        ? {}
        : { serverName: options.endpoint.tls.serverName }),
    });
    this.#timeoutMs = options.timeoutMs;
    this.#maxResponseBytes = options.maxResponseBytes;
    this.#resolver = options.resolver ?? defaultResolver;
  }

  async get(
    pathname: string,
    query: Readonly<Record<string, string>> | URLSearchParams,
    signal: AbortSignal,
    requestedMaxBytes: number,
  ): Promise<TrustedHttpResponse> {
    safePathSegments(pathname);
    const url = new URL(this.#base.toString());
    const basePath = this.#base.pathname.endsWith("/") ? this.#base.pathname : `${this.#base.pathname}/`;
    url.pathname = `${basePath}${pathname.replace(/^\/+/, "")}`;
    url.search = "";
    const entries = query instanceof URLSearchParams ? query.entries() : Object.entries(query);
    for (const [name, value] of entries) {
      if (name.length === 0 || name.length > 128 || hasUnsafeHeaderMaterial(name) || hasUnsafeHeaderMaterial(value)) {
        throw new RuntimeTransportError("INVALID_QUERY", "POLICY");
      }
      url.searchParams.append(name, value);
    }
    return this.#request(url, signal, requestedMaxBytes, "GET");
  }

  async postJson(
    pathname: string,
    body: Readonly<JsonObject>,
    signal: AbortSignal,
    requestedMaxBytes: number,
  ): Promise<TrustedHttpResponse> {
    safePathSegments(pathname);
    const url = new URL(this.#base.toString());
    const basePath = this.#base.pathname.endsWith("/") ? this.#base.pathname : `${this.#base.pathname}/`;
    url.pathname = `${basePath}${pathname.replace(/^\/+/, "")}`;
    url.search = "";
    let encoded: Buffer;
    try {
      encoded = Buffer.from(canonicalJson(body), "utf8");
    } catch {
      throw new RuntimeTransportError("INVALID_JSON_BODY", "POLICY");
    }
    if (encoded.byteLength < 2 || encoded.byteLength > MAX_JSON_REQUEST_BYTES) {
      throw new RuntimeTransportError("REQUEST_TOO_LARGE", "POLICY");
    }
    return this.#request(url, signal, requestedMaxBytes, "POST", encoded);
  }

  async getAbsolute(
    absoluteUrl: string,
    signal: AbortSignal,
    requestedMaxBytes: number,
  ): Promise<TrustedHttpResponse> {
    let url: URL;
    try {
      url = new URL(absoluteUrl);
    } catch {
      throw new RuntimeTransportError("INVALID_ABSOLUTE_URL", "POLICY");
    }
    if (
      url.origin !== this.#base.origin ||
      url.username !== "" ||
      url.password !== "" ||
      url.hash !== "" ||
      !url.pathname.startsWith(this.#base.pathname)
    ) {
      throw new RuntimeTransportError("ENDPOINT_ESCAPE", "POLICY");
    }
    safePathSegments(url.pathname);
    for (const [name, value] of url.searchParams.entries()) {
      if (name.length === 0 || name.length > 128 || hasUnsafeHeaderMaterial(name) || hasUnsafeHeaderMaterial(value)) {
        throw new RuntimeTransportError("INVALID_QUERY", "POLICY");
      }
    }
    return this.#request(url, signal, requestedMaxBytes, "GET");
  }

  async #request(
    url: URL,
    signal: AbortSignal,
    requestedMaxBytes: number,
    method: "GET" | "POST",
    body?: Buffer,
  ): Promise<TrustedHttpResponse> {
    if (signal.aborted) throw signal.reason ?? new RuntimeTransportError("CANCELLED", "UNAVAILABLE");
    if ((method === "POST" && body === undefined) || (method === "GET" && body !== undefined)) {
      throw new RuntimeTransportError("INVALID_REQUEST_BODY", "POLICY");
    }
    const requestHeaders: Record<string, string> = { ...this.#headers };
    if (body !== undefined) {
      requestHeaders["Content-Type"] = "application/json";
      requestHeaders["Content-Length"] = String(body.byteLength);
    }
    const deadline = Date.now() + this.#timeoutMs;
    const maximum = Math.min(this.#maxResponseBytes, requestedMaxBytes);
    if (!Number.isSafeInteger(maximum) || maximum < 1) {
      throw new RuntimeTransportError("INVALID_BYTE_LIMIT", "POLICY");
    }
    const hostname = normalizeHost(url.hostname);
    const allowedHosts = this.#endpoint.network.allowedHosts.map(normalizeHost);
    if (!allowedHosts.includes(hostname)) throw new RuntimeTransportError("HOST_NOT_ALLOWED", "POLICY");
    const addresses = await boundedLookup(this.#resolver, hostname, signal, this.#timeoutMs);
    if (signal.aborted) throw signal.reason ?? new RuntimeTransportError("CANCELLED", "UNAVAILABLE");
    const candidates = addresses.filter((entry) =>
      (entry.family === 4 || entry.family === 6) && isIP(normalizeAddress(entry.address)) === entry.family,
    );
    if (candidates.length === 0) throw new RuntimeTransportError("DNS_EMPTY", "UNAVAILABLE");
    if (candidates.some((entry) =>
      classifyNetworkAddress(entry.address) !== this.#endpoint.network.networkClass
    )) {
      throw new RuntimeTransportError("DNS_NETWORK_CLASS_MISMATCH", "POLICY");
    }
    const selected = candidates[0]!;
    const selectedAddress = normalizeAddress(selected.address);
    const remainingMs = deadline - Date.now();
    if (remainingMs < 1) throw new RuntimeTransportError("DEADLINE_EXCEEDED", "TIMEOUT");

    return new Promise<TrustedHttpResponse>((resolvePromise, rejectPromise) => {
      let settled = false;
      let request: ClientRequest | undefined;
      const cleanup: { timer?: NodeJS.Timeout; onAbort?: () => void } = {};
      const fail = (error: unknown) => {
        if (settled) return;
        settled = true;
        if (cleanup.timer !== undefined) clearTimeout(cleanup.timer);
        if (cleanup.onAbort !== undefined) signal.removeEventListener("abort", cleanup.onAbort);
        rejectPromise(error instanceof RuntimeTransportError ? error : new RuntimeTransportError("NETWORK_UNAVAILABLE", "UNAVAILABLE"));
      };
      const succeed = (response: TrustedHttpResponse) => {
        if (settled) return;
        settled = true;
        if (cleanup.timer !== undefined) clearTimeout(cleanup.timer);
        if (cleanup.onAbort !== undefined) signal.removeEventListener("abort", cleanup.onAbort);
        resolvePromise(response);
      };
      const requestOptions: RequestOptions = {
        method,
        headers: requestHeaders,
        agent: false,
        ...(url.protocol === "https:"
          ? {
              rejectUnauthorized: true,
              minVersion: this.#tls.minimumVersion,
              ...(this.#tls.ca === undefined ? {} : { ca: this.#tls.ca }),
              ...(this.#tls.certificate === undefined ? {} : { cert: this.#tls.certificate }),
              ...(this.#tls.privateKey === undefined ? {} : { key: this.#tls.privateKey }),
              ...(this.#tls.serverName === undefined
                ? (isIP(hostname) === 0 ? { servername: hostname } : {})
                : { servername: this.#tls.serverName }),
            }
          : {}),
        lookup: (_lookupHostname, lookupOptions, callback) => {
          if (typeof lookupOptions === "object" && lookupOptions.all === true) {
            (callback as (error: null, addresses: Array<{ address: string; family: 4 | 6 }>) => void)(
              null,
              [{ address: selectedAddress, family: selected.family }],
            );
          } else {
            (callback as (error: null, address: string, family: 4 | 6) => void)(
              null,
              selectedAddress,
              selected.family,
            );
          }
        },
      };
      try {
        request = (url.protocol === "https:" ? httpsRequest : httpRequest)(url, requestOptions, (response) => {
          const peer = normalizeAddress(response.socket.remoteAddress ?? "");
          if (peer !== selectedAddress) {
            response.destroy();
            fail(new RuntimeTransportError("CONNECTED_PEER_MISMATCH", "POLICY"));
            return;
          }
          if (classifyNetworkAddress(peer) !== this.#endpoint.network.networkClass) {
            response.destroy();
            fail(new RuntimeTransportError("CONNECTED_PEER_NETWORK_CLASS_MISMATCH", "POLICY"));
            return;
          }
          const chunks: Buffer[] = [];
          let bytes = 0;
          response.on("data", (chunk: Buffer | string) => {
            const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
            bytes += buffer.byteLength;
            if (bytes > maximum) {
              response.destroy();
              fail(new RuntimeTransportError("RESPONSE_TOO_LARGE", "RESPONSE_TOO_LARGE"));
              return;
            }
            chunks.push(buffer);
          });
          response.once("end", () => {
            succeed({
              status: response.statusCode ?? 0,
              headers: responseHeaders(response.headers),
              body: Buffer.concat(chunks, bytes),
            });
          });
          response.once("error", fail);
        });
      } catch {
        fail(new RuntimeTransportError("NETWORK_UNAVAILABLE", "UNAVAILABLE"));
        return;
      }
      cleanup.onAbort = () => {
        request?.destroy();
        fail(signal.reason ?? new RuntimeTransportError("CANCELLED", "UNAVAILABLE"));
      };
      signal.addEventListener("abort", cleanup.onAbort, { once: true });
      cleanup.timer = setTimeout(() => {
        request?.destroy();
        fail(new RuntimeTransportError("DEADLINE_EXCEEDED", "TIMEOUT"));
      }, remainingMs);
      cleanup.timer.unref();
      request.once("error", fail);
      if (body !== undefined) request.write(body);
      request.end();
    });
  }
}
