import {
  computeIntegrity,
  sha256Canonical,
} from "@codex-production-monitoring/contracts";
import type {
  CapabilityProfile,
  CapabilityPackId,
  EvidenceOrigin,
  OperationId,
  TrustBundle,
  TrustedProfile,
} from "@codex-production-monitoring/contracts";

import type { MonitoringProposal } from "./proposal.ts";
import { computeTrustedProfileConfigHash, type LoadedTrustRoot } from "./trust-root.ts";
import { ConfigurationError, deepFreeze } from "./validation.ts";

const CAPABILITY_RANK: Record<CapabilityProfile, number> = {
  observe: 0,
  investigate: 1,
  prepare_patch: 2,
};

export interface CompileProfileOptions {
  root: LoadedTrustRoot;
  proposal: MonitoringProposal;
  compiledAt: string;
}

export interface CompiledConfiguration {
  readonly rootManifestSha256: LoadedTrustRoot["rootManifestSha256"];
  readonly sourceTrustBundleSha256: LoadedTrustRoot["trustBundleSha256"];
  readonly bundle: Readonly<TrustBundle>;
}

function selectSubset<T extends string>(
  requested: readonly T[] | undefined,
  allowed: readonly T[],
  label: string,
): T[] {
  if (requested === undefined) return [...allowed];
  if (requested.length === 0) {
    throw new ConfigurationError("EMPTY_SELECTION", `${label} cannot be empty`);
  }
  const allowlist = new Set(allowed);
  for (const item of requested) {
    if (!allowlist.has(item)) {
      throw new ConfigurationError("PROPOSAL_WIDENING", `${label} requests an unapproved value: ${item}`);
    }
  }
  return [...requested];
}

export function compileTrustedConfiguration(
  options: CompileProfileOptions,
): Readonly<CompiledConfiguration> {
  const timestamp = Date.parse(options.compiledAt);
  if (!Number.isFinite(timestamp)) {
    throw new ConfigurationError("INVALID_TIME", "compiledAt must be an RFC 3339 timestamp");
  }
  const base = options.root.bundle.profile;
  if (options.proposal.profileAlias !== base.profileAlias) {
    throw new ConfigurationError("PROFILE_NOT_APPROVED", "The proposed profile is not active in this trust root");
  }

  const capability = options.proposal.requestedCapability ?? base.capabilityProfile;
  if (CAPABILITY_RANK[capability] > CAPABILITY_RANK[base.capabilityProfile]) {
    throw new ConfigurationError("PROPOSAL_WIDENING", "The proposal widens the approved capability profile");
  }
  const origins = selectSubset<EvidenceOrigin>(
    options.proposal.requestedOrigins,
    base.allowedOrigins,
    "evidence origins",
  );
  const scopeAliases = selectSubset(
    options.proposal.requestedScopeAliases,
    Object.keys(base.scopes),
    "scope aliases",
  );
  const endpointIds = selectSubset(
    options.proposal.requestedEndpointIds,
    base.endpointIds,
    "endpoint IDs",
  );
  const operationIds = selectSubset<OperationId>(
    options.proposal.requestedOperationIds,
    base.operationIds,
    "operation IDs",
  );
  const capabilityPackIds = selectSubset<CapabilityPackId>(
    options.proposal.requestedCapabilityPackIds,
    base.capabilityPackIds ?? [],
    "capability pack IDs",
  );

  const endpoints = options.root.bundle.endpoints.filter((endpoint) => endpointIds.includes(endpoint.endpointId));
  const endpointSet = new Set(endpoints.map((endpoint) => endpoint.endpointId));
  const operations = options.root.bundle.operations.filter((operation) =>
    operationIds.includes(operation.operationId),
  );
  const capabilityPacks = (options.root.bundle.capabilityPacks ?? []).filter((pack) =>
    capabilityPackIds.includes(pack.packId),
  );
  if (capabilityPacks.length !== capabilityPackIds.length) {
    throw new ConfigurationError("UNKNOWN_CAPABILITY_PACK", "The selected profile references an unavailable capability pack");
  }
  const selectedOperationIds = new Set(operationIds);
  for (const pack of capabilityPacks) {
    for (const operationId of pack.requiredOperationIds) {
      if (!selectedOperationIds.has(operationId)) {
        throw new ConfigurationError(
          "INCOMPLETE_PROPOSAL",
          `Capability pack ${pack.packId} requires operation ${operationId}`,
        );
      }
    }
  }
  for (const operation of operations) {
    if (!endpointSet.has(operation.definition.sourceAlias)) {
      throw new ConfigurationError(
        "INCOMPLETE_PROPOSAL",
        `Operation ${operation.operationId} requires endpoint ${operation.definition.sourceAlias}`,
      );
    }
  }

  const adapterIds = new Set([
    ...endpoints.map((endpoint) => endpoint.adapterId),
    ...operations.map((operation) => operation.definition.adapterPackageId),
  ]);
  const adapters = options.root.bundle.adapters.filter((adapter) => adapterIds.has(adapter.packageId));
  if (adapters.length !== adapterIds.size) {
    throw new ConfigurationError("UNKNOWN_ADAPTER", "The selected profile references an unadmitted adapter");
  }

  const scopes = Object.fromEntries(scopeAliases.map((alias) => [alias, base.scopes[alias]!]));
  const {
    verificationPolicies: baseVerificationPolicies,
    defaultVerificationPolicyAlias: baseDefaultVerificationPolicyAlias,
    capabilityPackIds: _baseCapabilityPackIds,
    capabilityPackCatalogSha256: _baseCapabilityPackCatalogSha256,
    ...baseWithoutVerificationPolicies
  } = base;
  // These authority fields are intentionally replaced by the proposal's
  // narrowed, re-hashed capability-pack selection below.
  void _baseCapabilityPackIds;
  void _baseCapabilityPackCatalogSha256;
  const verificationPolicies = Object.fromEntries(
    Object.entries(baseVerificationPolicies ?? {}).filter(([, policy]) =>
      policy.criteria.every((criterion) => operationIds.includes(criterion.operationId))
    ),
  );
  const defaultVerificationPolicyAlias = baseDefaultVerificationPolicyAlias !== undefined &&
    verificationPolicies[baseDefaultVerificationPolicyAlias] !== undefined
    ? baseDefaultVerificationPolicyAlias
    : undefined;
  const profileWithoutConfigHash = {
    ...baseWithoutVerificationPolicies,
    capabilityProfile: capability,
    allowedOrigins: origins,
    compiledAt: new Date(timestamp).toISOString(),
    scopes,
    endpointIds,
    operationIds,
    ...(capabilityPacks.length === 0
      ? {}
      : {
          capabilityPackIds,
          capabilityPackCatalogSha256: sha256Canonical(capabilityPacks),
        }),
    ...(Object.keys(verificationPolicies).length === 0 ? {} : { verificationPolicies }),
    ...(defaultVerificationPolicyAlias === undefined ? {} : { defaultVerificationPolicyAlias }),
    endpointRegistrySha256: sha256Canonical(endpoints),
    catalogSha256: sha256Canonical(operations),
  };
  const provisional = { ...profileWithoutConfigHash, configSha256: base.configSha256 } as TrustedProfile;
  const profile: TrustedProfile = {
    ...provisional,
    configSha256: computeTrustedProfileConfigHash(provisional),
  };
  const unsealed: TrustBundle = {
    schemaVersion: "1.0.0",
    createdAt: profile.compiledAt,
    profile,
    endpoints,
    operations,
    ...(capabilityPacks.length === 0 ? {} : { capabilityPacks }),
    adapters,
    integrity: options.root.bundle.integrity,
  };
  const bundle: TrustBundle = { ...unsealed, integrity: computeIntegrity(unsealed) };
  return deepFreeze({
    rootManifestSha256: options.root.rootManifestSha256,
    sourceTrustBundleSha256: options.root.trustBundleSha256,
    bundle,
  });
}
