import {
  closeSync,
  constants,
  existsSync,
  fstatSync,
  fsyncSync,
  lstatSync,
  openSync,
  readFileSync,
  realpathSync,
  renameSync,
  unlinkSync,
  writeFileSync,
  type Stats,
} from "node:fs";
import { randomUUID } from "node:crypto";
import { basename, dirname, isAbsolute, relative, resolve, sep } from "node:path";

import {
  canonicalJson,
  computeIntegrity,
  verifyIntegrity,
  type Integrity,
  type Sha256,
} from "@codex-production-monitoring/contracts";

import { ConfigurationError } from "./validation.ts";
import {
  loadTrustedRoot,
  type LoadedTrustRoot,
  type LoadTrustRootOptions,
} from "./trust-root.ts";
import { trustedEndpointEnvironmentReferences } from "./endpoint.ts";

const RECEIPT_KIND = "production-monitoring-activation-v1" as const;
const RECEIPT_MAXIMUM_BYTES = 64 * 1_024;
const SAFE_RECEIPT_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,180}$/u;
const SHA256 = /^[a-f0-9]{64}$/u;

export interface ActivationReceipt {
  schemaVersion: "1.0.0";
  kind: typeof RECEIPT_KIND;
  activatedAt: string;
  trustRootPath: string;
  rootManifestSha256: Sha256;
  trustBundleSha256: Sha256;
  providerRuntimeSha256: Sha256 | null;
  integrity: Integrity;
}

export interface ActivationSummary {
  schemaVersion: "1.0.0";
  valid: true;
  trustRootPath: string;
  rootManifestSha256: Sha256;
  trustBundleSha256: Sha256;
  providerRuntimeSha256: Sha256 | null;
  profileAlias: string;
  adapterPackageIds: string[];
  credentialEnvironmentReferences: string[];
}

export interface ActivationPathOptions {
  forbiddenWorkspaceRoots?: readonly string[];
  expectedOwnerUid?: number;
}

export interface ActivateTrustRootOptions extends ActivationPathOptions {
  trustRootPath: string;
  receiptPath: string;
  expectedRootManifestSha256: Sha256;
  expectedTrustBundleSha256: Sha256;
  activatedAt?: string;
  replace?: boolean;
}

export interface LoadActivatedTrustRootOptions extends ActivationPathOptions {
  receiptPath: string;
  trustRootPath?: string;
}

function expectedUid(options: ActivationPathOptions): number | undefined {
  if (options.expectedOwnerUid !== undefined) return options.expectedOwnerUid;
  return typeof process.geteuid === "function" ? process.geteuid() : undefined;
}

function modeBits(mode: number): number {
  return mode & 0o777;
}

function assertOwner(stat: Stats, uid: number | undefined, label: string): void {
  if (uid !== undefined && stat.uid !== uid) {
    throw new ConfigurationError("UNTRUSTED_OWNER", `${label} is not owned by the trusted launcher user`);
  }
}

function isWithin(path: string, parent: string): boolean {
  const relation = relative(parent, path);
  return relation === "" || (!relation.startsWith(`..${sep}`) && relation !== ".." && !isAbsolute(relation));
}

function workspaceRoots(options: ActivationPathOptions): string[] {
  return (options.forbiddenWorkspaceRoots ?? [process.cwd()]).map((root) => realpathSync(resolve(root)));
}

function assertOutsideWorkspaces(path: string, options: ActivationPathOptions, label: string): void {
  for (const workspace of workspaceRoots(options)) {
    if (isWithin(path, workspace)) {
      throw new ConfigurationError("ACTIVATION_IN_WORKSPACE", `${label} cannot live in an inspected workspace`);
    }
  }
}

function assertPrivateDirectory(path: string, uid: number | undefined, label: string): string {
  const requested = resolve(path);
  const stat = lstatSync(requested);
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    throw new ConfigurationError("UNSAFE_ACTIVATION_PATH", `${label} must be a real directory`);
  }
  assertOwner(stat, uid, label);
  if ((modeBits(stat.mode) & 0o077) !== 0 || (modeBits(stat.mode) & 0o700) !== 0o700) {
    throw new ConfigurationError("UNSAFE_MODE", `${label} must be owner-only and owner-readable/writable/searchable`);
  }
  const canonical = realpathSync(requested);
  if (canonical !== requested) {
    throw new ConfigurationError("UNSAFE_ACTIVATION_PATH", `${label} cannot use symlinked ancestor aliases`);
  }
  return canonical;
}

function receiptTarget(pathInput: string, options: ActivationPathOptions): { path: string; parent: string } {
  if (!isAbsolute(pathInput)) {
    throw new ConfigurationError("RELATIVE_ACTIVATION_RECEIPT", "Activation receipt path must be absolute");
  }
  const requested = resolve(pathInput);
  if (!SAFE_RECEIPT_NAME.test(basename(requested))) {
    throw new ConfigurationError("UNSAFE_ACTIVATION_PATH", "Activation receipt filename is invalid");
  }
  const parent = assertPrivateDirectory(dirname(requested), expectedUid(options), "Activation receipt directory");
  const path = resolve(parent, basename(requested));
  assertOutsideWorkspaces(path, options, "Activation receipt");
  return { path, parent };
}

function assertReceiptFile(path: string, uid: number | undefined): Stats {
  const stat = lstatSync(path);
  if (stat.isSymbolicLink() || !stat.isFile() || stat.nlink !== 1) {
    throw new ConfigurationError("UNSAFE_ACTIVATION_RECEIPT", "Activation receipt must be one regular, non-linked file");
  }
  assertOwner(stat, uid, "Activation receipt");
  if ((modeBits(stat.mode) & 0o077) !== 0 || (modeBits(stat.mode) & 0o400) === 0) {
    throw new ConfigurationError("UNSAFE_MODE", "Activation receipt must be owner-readable and owner-only");
  }
  if (stat.size < 1 || stat.size > RECEIPT_MAXIMUM_BYTES) {
    throw new ConfigurationError("ACTIVATION_RECEIPT_SIZE", "Activation receipt is outside its byte limit");
  }
  return stat;
}

function secureReadReceipt(path: string, uid: number | undefined): Buffer {
  const before = assertReceiptFile(path, uid);
  const noFollow = typeof constants.O_NOFOLLOW === "number" ? constants.O_NOFOLLOW : 0;
  let descriptor: number | undefined;
  try {
    descriptor = openSync(path, constants.O_RDONLY | noFollow);
    const opened = fstatSync(descriptor);
    if (!opened.isFile() || opened.nlink !== 1 || opened.dev !== before.dev || opened.ino !== before.ino) {
      throw new ConfigurationError("ACTIVATION_RECEIPT_CHANGED", "Activation receipt changed while opening");
    }
    const content = readFileSync(descriptor);
    const after = fstatSync(descriptor);
    if (
      after.dev !== opened.dev ||
      after.ino !== opened.ino ||
      after.size !== opened.size ||
      after.mtimeMs !== opened.mtimeMs
    ) {
      throw new ConfigurationError("ACTIVATION_RECEIPT_CHANGED", "Activation receipt changed while reading");
    }
    return content;
  } finally {
    if (descriptor !== undefined) closeSync(descriptor);
  }
}

function parseReceipt(bytes: Buffer): ActivationReceipt {
  let value: unknown;
  try {
    value = JSON.parse(bytes.toString("utf8")) as unknown;
  } catch {
    throw new ConfigurationError("ACTIVATION_RECEIPT_INVALID", "Activation receipt is not valid JSON");
  }
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new ConfigurationError("ACTIVATION_RECEIPT_INVALID", "Activation receipt has an invalid shape");
  }
  const object = value as Record<string, unknown>;
  const expected = new Set([
    "schemaVersion",
    "kind",
    "activatedAt",
    "trustRootPath",
    "rootManifestSha256",
    "trustBundleSha256",
    "providerRuntimeSha256",
    "integrity",
  ]);
  if (Object.keys(object).length !== expected.size || Object.keys(object).some((key) => !expected.has(key))) {
    throw new ConfigurationError("ACTIVATION_RECEIPT_INVALID", "Activation receipt contains unknown or missing fields");
  }
  if (
    object.schemaVersion !== "1.0.0" ||
    object.kind !== RECEIPT_KIND ||
    typeof object.activatedAt !== "string" ||
    !Number.isFinite(Date.parse(object.activatedAt)) ||
    new Date(object.activatedAt).toISOString() !== object.activatedAt ||
    typeof object.trustRootPath !== "string" ||
    !isAbsolute(object.trustRootPath) ||
    typeof object.rootManifestSha256 !== "string" ||
    !SHA256.test(object.rootManifestSha256) ||
    typeof object.trustBundleSha256 !== "string" ||
    !SHA256.test(object.trustBundleSha256) ||
    !(object.providerRuntimeSha256 === null ||
      (typeof object.providerRuntimeSha256 === "string" && SHA256.test(object.providerRuntimeSha256))) ||
    !verifyIntegrity(value as ActivationReceipt)
  ) {
    throw new ConfigurationError("ACTIVATION_RECEIPT_INVALID", "Activation receipt failed validation");
  }
  return value as ActivationReceipt;
}

function loadForActivation(
  trustRootPath: string,
  options: ActivationPathOptions,
): Readonly<LoadedTrustRoot> {
  const roots = workspaceRoots(options);
  const loaded = loadTrustedRoot({
    rootPath: trustRootPath,
    forbiddenWorkspaceRoots: roots,
    ...(options.expectedOwnerUid === undefined ? {} : { expectedOwnerUid: options.expectedOwnerUid }),
  } satisfies LoadTrustRootOptions);
  if (resolve(trustRootPath) !== loaded.rootPath) {
    throw new ConfigurationError(
      "UNSAFE_TRUST_ROOT",
      "Trust-root path cannot use symlinked ancestor aliases",
    );
  }
  assertOutsideWorkspaces(loaded.rootPath, options, "Trust root");
  return loaded;
}

export function activationSummary(root: Readonly<LoadedTrustRoot>): ActivationSummary {
  const credentialEnvironmentReferences = root.bundle.endpoints.flatMap((endpoint) =>
    trustedEndpointEnvironmentReferences(endpoint)
  );
  return {
    schemaVersion: "1.0.0",
    valid: true,
    trustRootPath: root.rootPath,
    rootManifestSha256: root.rootManifestSourceSha256 ?? root.rootManifestSha256,
    trustBundleSha256: root.trustBundleSourceSha256 ?? root.trustBundleSha256,
    providerRuntimeSha256: root.providerRuntime?.sourceSha256 ?? null,
    profileAlias: root.bundle.profile.profileAlias,
    adapterPackageIds: [...new Set(root.bundle.adapters.map((adapter) => adapter.packageId))].sort(),
    credentialEnvironmentReferences: [...new Set(credentialEnvironmentReferences)].sort(),
  };
}

export function validateTrustRootForActivation(
  trustRootPath: string,
  options: ActivationPathOptions = {},
): ActivationSummary {
  return activationSummary(loadForActivation(trustRootPath, options));
}

function writeReceipt(
  path: string,
  parent: string,
  content: string,
  replace: boolean,
  uid: number | undefined,
): void {
  const existing = existsSync(path) ? assertReceiptFile(path, uid) : undefined;
  if (existing !== undefined && !replace) {
    throw new ConfigurationError("ACTIVATION_RECEIPT_EXISTS", "Activation receipt already exists; explicit replacement is required");
  }
  const noFollow = typeof constants.O_NOFOLLOW === "number" ? constants.O_NOFOLLOW : 0;
  const temporary = resolve(parent, `.activation-${randomUUID()}.tmp`);
  let descriptor: number | undefined;
  try {
    descriptor = openSync(
      replace ? temporary : path,
      constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | noFollow,
      0o600,
    );
    writeFileSync(descriptor, content, { encoding: "utf8" });
    fsyncSync(descriptor);
    closeSync(descriptor);
    descriptor = undefined;
    assertReceiptFile(replace ? temporary : path, uid);
    if (replace) {
      if (existing !== undefined) {
        const current = assertReceiptFile(path, uid);
        if (current.dev !== existing.dev || current.ino !== existing.ino) {
          throw new ConfigurationError("ACTIVATION_RECEIPT_CHANGED", "Activation receipt changed before replacement");
        }
      }
      renameSync(temporary, path);
    }
    const directory = openSync(parent, constants.O_RDONLY | constants.O_DIRECTORY);
    try {
      fsyncSync(directory);
    } finally {
      closeSync(directory);
    }
  } finally {
    if (descriptor !== undefined) closeSync(descriptor);
    if (existsSync(temporary)) unlinkSync(temporary);
  }
}

export function activateTrustRoot(options: ActivateTrustRootOptions): ActivationReceipt {
  const loaded = loadForActivation(options.trustRootPath, options);
  const rootManifestSha256 = loaded.rootManifestSourceSha256 ?? loaded.rootManifestSha256;
  const trustBundleSha256 = loaded.trustBundleSourceSha256 ?? loaded.trustBundleSha256;
  if (
    !SHA256.test(options.expectedRootManifestSha256) ||
    !SHA256.test(options.expectedTrustBundleSha256) ||
    options.expectedRootManifestSha256 !== rootManifestSha256 ||
    options.expectedTrustBundleSha256 !== trustBundleSha256
  ) {
    throw new ConfigurationError(
      "ACTIVATION_REVIEW_MISMATCH",
      "Trust-root digests do not match the operator-reviewed validation result",
    );
  }
  const target = receiptTarget(options.receiptPath, options);
  if (isWithin(target.path, loaded.rootPath)) {
    throw new ConfigurationError("ACTIVATION_RECEIPT_IN_ROOT", "Activation receipt must remain separate from the trust root");
  }
  const activatedAt = options.activatedAt ?? new Date().toISOString();
  if (!Number.isFinite(Date.parse(activatedAt)) || new Date(activatedAt).toISOString() !== activatedAt) {
    throw new ConfigurationError("INVALID_TIME", "Activation time must be a canonical ISO UTC timestamp");
  }
  const unsigned = {
    schemaVersion: "1.0.0" as const,
    kind: RECEIPT_KIND,
    activatedAt,
    trustRootPath: loaded.rootPath,
    rootManifestSha256,
    trustBundleSha256,
    providerRuntimeSha256: loaded.providerRuntime?.sourceSha256 ?? null,
  };
  const receipt: ActivationReceipt = { ...unsigned, integrity: computeIntegrity(unsigned) };
  writeReceipt(
    target.path,
    target.parent,
    `${canonicalJson(receipt)}\n`,
    options.replace ?? false,
    expectedUid(options),
  );
  return receipt;
}

export function loadActivatedTrustRoot(
  options: LoadActivatedTrustRootOptions,
): Readonly<LoadedTrustRoot> {
  const target = receiptTarget(options.receiptPath, options);
  const receipt = parseReceipt(secureReadReceipt(target.path, expectedUid(options)));
  const requestedRoot = options.trustRootPath === undefined ? undefined : resolve(options.trustRootPath);
  if (requestedRoot !== undefined && requestedRoot !== receipt.trustRootPath) {
    throw new ConfigurationError("ACTIVATION_ROOT_MISMATCH", "Requested trust root does not match the activation receipt");
  }
  const loaded = loadForActivation(receipt.trustRootPath, options);
  if (
    loaded.rootPath !== receipt.trustRootPath ||
    (loaded.rootManifestSourceSha256 ?? loaded.rootManifestSha256) !== receipt.rootManifestSha256 ||
    (loaded.trustBundleSourceSha256 ?? loaded.trustBundleSha256) !== receipt.trustBundleSha256 ||
    (loaded.providerRuntime?.sourceSha256 ?? null) !== receipt.providerRuntimeSha256
  ) {
    throw new ConfigurationError("ACTIVATION_DIGEST_MISMATCH", "Active trust-root material changed after activation");
  }
  return loaded;
}
