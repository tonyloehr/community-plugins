import type { CredentialReference } from "@codex-production-monitoring/contracts";

import {
  providerBindingCredentialReferences,
  providerBindingEndpointIds,
  requiredProviderScopesForBinding,
} from "./provider-runtime.ts";
import type { LoadedTrustRoot } from "./trust-root.ts";
import { ConfigurationError, deepFreeze } from "./validation.ts";

export interface ProviderAccessPreview {
  schemaVersion: "1.0.0";
  mode: "LIVE_ACCESS_PREVIEW";
  activated: true;
  profileAlias: string;
  providerIoPerformed: false;
  secretValuesIncluded: false;
  rootManifestSha256: string;
  trustBundleSha256: string;
  providerRuntimeSha256: string;
  credentialEnvironmentReferences: string[];
  adapters: Array<{
    kind: string;
    packageId: string;
    endpointIds: string[];
    endpoints: Array<{
      endpointId: string;
      origin: string;
      authenticationMode: "NONE" | "BEARER" | "BASIC" | "MTLS";
      minimumTlsVersion: "TLSv1.2" | "TLSv1.3";
      customCertificateAuthority: boolean;
      networkClass: "loopback" | "private" | "public";
      routeMode: "direct" | "host_vpn" | "application_proxy";
      routeImplementation: "DIRECT_SOCKET" | "NOT_IMPLEMENTED";
      redirects: "DISABLED";
    }>;
    credentialReferences: Array<Readonly<CredentialReference>>;
    credentialResolution: "ENVIRONMENT_OR_NONE" | "EXPLICIT_RESOLVER_REQUIRED";
    runtimeAdmission:
      | "ADMISSIBLE_NO_CREDENTIAL"
      | "CREDENTIAL_AVAILABILITY_NOT_CHECKED"
      | "BLOCKED_CREDENTIAL_RESOLVER_REQUIRED";
    accessAttestation: {
      approvalId: string;
      reviewedAt: string;
      effectiveProviderScopes: string[];
      requiredProviderScopes: string[];
      scopeAdmission: "SEALED_EXACT";
    };
  }>;
}

/**
 * Describe only manifest-sealed access metadata. This function never resolves a
 * credential, constructs a provider runtime, performs DNS, or opens a socket.
 */
export function previewProviderAccess(
  root: Readonly<LoadedTrustRoot>,
  profileAlias: string,
): Readonly<ProviderAccessPreview> {
  if (root.bundle.profile.profileAlias !== profileAlias) {
    throw new ConfigurationError("PROFILE_NOT_ACTIVE", "The requested profile is not the activated live profile");
  }
  const runtime = root.providerRuntime;
  if (runtime === undefined) {
    throw new ConfigurationError(
      "PROVIDER_RUNTIME_NOT_CONFIGURED",
      "The activated live root does not contain a manifest-hashed provider runtime",
    );
  }
  const adapters = runtime.configuration.adapters.map((binding) => {
    const endpointIds = [...providerBindingEndpointIds(binding)];
    const credentialReferences = providerBindingCredentialReferences(binding, root.bundle)
      .map((reference) => ({ ...reference }));
    const requiredProviderScopes = [...requiredProviderScopesForBinding(binding, root.bundle)];
    const effectiveProviderScopes = [...binding.access.effectiveProviderScopes].sort();
    if (JSON.stringify(requiredProviderScopes) !== JSON.stringify(effectiveProviderScopes)) {
      throw new ConfigurationError(
        "SCOPE_ATTESTATION_MISMATCH",
        "The manifest-sealed provider access attestation no longer matches active operation requirements",
      );
    }
    const requiresResolver = credentialReferences.some((reference) => reference.kind !== "env");
    return {
      kind: binding.kind,
      packageId: binding.packageId,
      endpointIds,
      endpoints: endpointIds.map((endpointId) => {
        const endpoint = root.bundle.endpoints.find((candidate) => candidate.endpointId === endpointId);
        if (endpoint === undefined) {
          throw new ConfigurationError("UNKNOWN_ENDPOINT", "A provider binding references an unavailable endpoint");
        }
        const url = new URL(endpoint.baseUrl);
        return {
          endpointId,
          origin: url.origin,
          authenticationMode: endpoint.authentication.mode,
          minimumTlsVersion: endpoint.tls.minimumVersion,
          customCertificateAuthority: endpoint.tls.caRef !== undefined,
          networkClass: endpoint.network.networkClass,
          routeMode: endpoint.network.routeMode,
          routeImplementation: endpoint.network.routeMode === "application_proxy"
            ? "NOT_IMPLEMENTED" as const
            : "DIRECT_SOCKET" as const,
          redirects: "DISABLED" as const,
        };
      }),
      credentialReferences,
      credentialResolution: requiresResolver
        ? "EXPLICIT_RESOLVER_REQUIRED" as const
        : "ENVIRONMENT_OR_NONE" as const,
      runtimeAdmission: requiresResolver
        ? "BLOCKED_CREDENTIAL_RESOLVER_REQUIRED" as const
        : credentialReferences.length === 0
          ? "ADMISSIBLE_NO_CREDENTIAL" as const
          : "CREDENTIAL_AVAILABILITY_NOT_CHECKED" as const,
      accessAttestation: {
        approvalId: binding.access.approvalId,
        reviewedAt: binding.access.reviewedAt,
        effectiveProviderScopes,
        requiredProviderScopes,
        scopeAdmission: "SEALED_EXACT" as const,
      },
    };
  });
  const credentialEnvironmentReferences = adapters
    .flatMap((adapter) => adapter.credentialReferences)
    .filter((reference) => reference.kind === "env")
    .map((reference) => reference.key);
  return deepFreeze({
    schemaVersion: "1.0.0",
    mode: "LIVE_ACCESS_PREVIEW",
    activated: true,
    profileAlias,
    providerIoPerformed: false,
    secretValuesIncluded: false,
    rootManifestSha256: root.rootManifestSourceSha256 ?? root.rootManifestSha256,
    trustBundleSha256: root.trustBundleSourceSha256 ?? root.trustBundleSha256,
    providerRuntimeSha256: runtime.sourceSha256,
    credentialEnvironmentReferences: [...new Set(credentialEnvironmentReferences)].sort(),
    adapters,
  });
}
