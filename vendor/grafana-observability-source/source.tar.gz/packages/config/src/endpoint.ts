import { isIP } from "node:net";

import type {
  CredentialReference,
  TrustedEndpoint,
} from "@codex-production-monitoring/contracts";

import { ConfigurationError, deepFreeze } from "./validation.ts";

const FORBIDDEN_TENANT_HEADERS = new Set([
  "authorization",
  "cookie",
  "host",
  "proxy-authorization",
  "proxy-authenticate",
  "set-cookie",
]);
const ENVIRONMENT_KEY = /^[A-Z_][A-Z0-9_]{0,127}$/u;
const CREDENTIAL_KEY = /^[A-Za-z][A-Za-z0-9_.:-]{0,255}$/u;

function normalizeHost(host: string): string {
  const value = host.trim().toLowerCase().replace(/\.$/u, "");
  if (value.length === 0 || value.includes("*") || value.includes("/") || value.includes("@")) {
    throw new ConfigurationError("INVALID_HOST", `Unsafe endpoint host allowlist entry: ${host}`);
  }
  try {
    return new URL(`https://${value}`).hostname.toLowerCase().replace(/\.$/u, "");
  } catch {
    throw new ConfigurationError("INVALID_HOST", `Invalid endpoint host allowlist entry: ${host}`);
  }
}

function isLoopback(hostname: string): boolean {
  if (hostname === "localhost" || hostname === "::1" || hostname === "[::1]") return true;
  const match = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/u.exec(hostname);
  if (match === null) return false;
  const octets = match.slice(1).map(Number);
  return octets.every((octet) => octet >= 0 && octet <= 255) && octets[0] === 127;
}

export function trustedEndpointCredentialReferences(
  endpoint: Readonly<TrustedEndpoint>,
): readonly Readonly<CredentialReference>[] {
  const authentication = endpoint.authentication;
  const references = authentication.mode === "NONE"
    ? []
    : authentication.mode === "BEARER"
      ? [authentication.tokenRef]
      : authentication.mode === "BASIC"
        ? [authentication.usernameRef, authentication.passwordRef]
        : [authentication.certificateRef, authentication.privateKeyRef];
  if (endpoint.tls.caRef !== undefined) references.push(endpoint.tls.caRef);
  return references.map((reference) => ({ ...reference }));
}

export function trustedEndpointEnvironmentReferences(
  endpoint: Readonly<TrustedEndpoint>,
): readonly string[] {
  return trustedEndpointCredentialReferences(endpoint)
    .filter((reference) => reference.kind === "env")
    .map((reference) => reference.key);
}

function assertCredentialReference(reference: Readonly<CredentialReference>, endpointId: string): void {
  if (!CREDENTIAL_KEY.test(reference.key)) {
    throw new ConfigurationError(
      "INVALID_CREDENTIAL_REFERENCE",
      `Endpoint ${endpointId} has an invalid credential reference`,
    );
  }
  if (reference.kind === "env" && !ENVIRONMENT_KEY.test(reference.key)) {
    throw new ConfigurationError(
      "INVALID_ENVIRONMENT_REFERENCE",
      `Endpoint ${endpointId} environment references must use canonical environment keys`,
    );
  }
}

export function normalizeTrustedEndpoint(endpoint: TrustedEndpoint): Readonly<TrustedEndpoint> {
  let url: URL;
  try {
    url = new URL(endpoint.baseUrl);
  } catch {
    throw new ConfigurationError("INVALID_ENDPOINT", `Endpoint ${endpoint.endpointId} has an invalid URL`);
  }
  if (url.username !== "" || url.password !== "" || url.search !== "" || url.hash !== "") {
    throw new ConfigurationError(
      "UNSAFE_ENDPOINT",
      `Endpoint ${endpoint.endpointId} must not contain userinfo, query, or fragment material`,
    );
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") {
    throw new ConfigurationError("UNSAFE_SCHEME", `Endpoint ${endpoint.endpointId} must use HTTPS`);
  }

  const hostname = normalizeHost(url.hostname);
  const allowedHosts = endpoint.network.allowedHosts.map(normalizeHost);
  if (new Set(allowedHosts).size !== allowedHosts.length) {
    throw new ConfigurationError("DUPLICATE_HOST", `Endpoint ${endpoint.endpointId} repeats an allowed host`);
  }
  if (!allowedHosts.includes(hostname)) {
    throw new ConfigurationError(
      "HOST_NOT_ALLOWED",
      `Endpoint ${endpoint.endpointId} host is not present in its allowlist`,
    );
  }
  if (url.protocol === "http:" && (!endpoint.network.allowLoopbackHttp || !isLoopback(hostname))) {
    throw new ConfigurationError(
      "INSECURE_ENDPOINT",
      `Endpoint ${endpoint.endpointId} permits HTTP only for explicitly approved loopback hosts`,
    );
  }
  if (endpoint.network.networkClass === "loopback") {
    if (!isLoopback(hostname) || endpoint.network.routeMode !== "direct") {
      throw new ConfigurationError(
        "NETWORK_CLASS_MISMATCH",
        `Endpoint ${endpoint.endpointId} loopback class requires a loopback host and direct route`,
      );
    }
  } else if (isLoopback(hostname) || endpoint.network.allowLoopbackHttp) {
    throw new ConfigurationError(
      "NETWORK_CLASS_MISMATCH",
      `Endpoint ${endpoint.endpointId} ${endpoint.network.networkClass} class cannot admit loopback transport`,
    );
  }
  if (endpoint.network.routeMode === "application_proxy") {
    throw new ConfigurationError(
      "APPLICATION_PROXY_NOT_IMPLEMENTED",
      `Endpoint ${endpoint.endpointId} application-proxy routing is NOT_IMPLEMENTED`,
    );
  }
  if (endpoint.network.routeMode === "host_vpn" && endpoint.network.networkClass !== "private") {
    throw new ConfigurationError(
      "NETWORK_CLASS_MISMATCH",
      `Endpoint ${endpoint.endpointId} host-VPN routing is restricted to private network destinations`,
    );
  }
  if (endpoint.network.followRedirects !== false) {
    throw new ConfigurationError("REDIRECTS_FORBIDDEN", `Endpoint ${endpoint.endpointId} must disable redirects`);
  }
  if (endpoint.authentication.mode === "MTLS" && url.protocol !== "https:") {
    throw new ConfigurationError("MTLS_REQUIRES_TLS", `Endpoint ${endpoint.endpointId} mTLS requires HTTPS`);
  }
  if (url.protocol !== "https:" && (endpoint.tls.caRef !== undefined || endpoint.tls.serverName !== undefined)) {
    throw new ConfigurationError(
      "TLS_POLICY_ON_HTTP",
      `Endpoint ${endpoint.endpointId} cannot apply CA or server-name policy to HTTP`,
    );
  }
  if (
    endpoint.authentication.mode === "BASIC" &&
    endpoint.authentication.usernameRef.kind === endpoint.authentication.passwordRef.kind &&
    endpoint.authentication.usernameRef.key === endpoint.authentication.passwordRef.key
  ) {
    throw new ConfigurationError(
      "DUPLICATE_CREDENTIAL_REFERENCE",
      `Endpoint ${endpoint.endpointId} basic username and password references must be distinct`,
    );
  }
  const references = trustedEndpointCredentialReferences(endpoint);
  for (const reference of references) assertCredentialReference(reference, endpoint.endpointId);
  if (new Set(references.map((reference) => `${reference.kind}:${reference.key}`)).size !== references.length) {
    throw new ConfigurationError(
      "DUPLICATE_CREDENTIAL_REFERENCE",
      `Endpoint ${endpoint.endpointId} repeats a credential reference`,
    );
  }
  if (endpoint.tenantBinding !== undefined) {
    const header = endpoint.tenantBinding.headerName.toLowerCase();
    if (FORBIDDEN_TENANT_HEADERS.has(header)) {
      throw new ConfigurationError(
        "FORBIDDEN_TENANT_HEADER",
        `Endpoint ${endpoint.endpointId} uses a forbidden tenant header`,
      );
    }
    if (!endpoint.tenantBinding.valueRef.startsWith("metadata:")) {
      throw new ConfigurationError(
        "INVALID_TENANT_BINDING",
        `Endpoint ${endpoint.endpointId} tenant values must come from trusted metadata`,
      );
    }
  }

  url.hostname = hostname;
  if ((url.protocol === "https:" && url.port === "443") || (url.protocol === "http:" && url.port === "80")) {
    url.port = "";
  }
  url.pathname = url.pathname.replace(/\/{2,}/gu, "/");
  if (!url.pathname.endsWith("/")) url.pathname += "/";

  const tls = {
    ...endpoint.tls,
    ...(endpoint.tls.caRef === undefined ? {} : { caRef: { ...endpoint.tls.caRef } }),
    ...(endpoint.tls.serverName === undefined
      ? {}
      : { serverName: normalizeHost(endpoint.tls.serverName) }),
  };
  if (tls.serverName !== undefined && isIP(tls.serverName) !== 0) {
    throw new ConfigurationError(
      "INVALID_TLS_SERVER_NAME",
      `Endpoint ${endpoint.endpointId} TLS server name must be a DNS hostname`,
    );
  }

  return deepFreeze({
    ...endpoint,
    baseUrl: url.toString(),
    network: { ...endpoint.network, allowedHosts },
    authentication: structuredClone(endpoint.authentication),
    tls,
    ...(endpoint.tenantBinding === undefined
      ? {}
      : { tenantBinding: { ...endpoint.tenantBinding } }),
  });
}
