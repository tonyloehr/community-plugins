import { parseDocument } from "yaml";

export class ConfigurationError extends Error {
  readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = "ConfigurationError";
    this.code = code;
  }
}

export function parseStrictYaml(text: string, source: string): unknown {
  if (Buffer.byteLength(text, "utf8") > 1024 * 1024) {
    throw new ConfigurationError("YAML_TOO_LARGE", `${source} exceeds the 1 MiB limit`);
  }
  const document = parseDocument(text, {
    merge: false,
    prettyErrors: false,
    schema: "core",
    strict: true,
    stringKeys: true,
    uniqueKeys: true,
  });
  if (document.errors.length > 0) {
    throw new ConfigurationError(
      "INVALID_YAML",
      `${source}: ${document.errors.map((error) => error.message).join("; ")}`,
    );
  }
  try {
    return document.toJS({ maxAliasCount: 0 });
  } catch (error) {
    throw new ConfigurationError(
      "UNSAFE_YAML",
      `${source}: ${error instanceof Error ? error.message : "unsafe YAML"}`,
    );
  }
}

export function requireObject(value: unknown, path: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new ConfigurationError("INVALID_SHAPE", `${path} must be an object`);
  }
  return value as Record<string, unknown>;
}

export function requireExactKeys(
  value: Record<string, unknown>,
  allowed: readonly string[],
  required: readonly string[],
  path: string,
): void {
  const allowedSet = new Set(allowed);
  for (const key of Object.keys(value)) {
    if (!allowedSet.has(key)) {
      throw new ConfigurationError("UNKNOWN_FIELD", `${path}.${key} is not allowed`);
    }
  }
  for (const key of required) {
    if (!Object.hasOwn(value, key)) {
      throw new ConfigurationError("MISSING_FIELD", `${path}.${key} is required`);
    }
  }
}

export function requireString(value: unknown, path: string): string {
  if (typeof value !== "string" || value.length === 0) {
    throw new ConfigurationError("INVALID_STRING", `${path} must be a non-empty string`);
  }
  return value;
}

export function requireAlias(value: unknown, path: string): string {
  const alias = requireString(value, path);
  if (!/^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u.test(alias)) {
    throw new ConfigurationError("INVALID_ALIAS", `${path} is not a valid alias`);
  }
  return alias;
}

export function requireStringArray(value: unknown, path: string, maximum = 128): string[] {
  if (!Array.isArray(value) || value.length > maximum) {
    throw new ConfigurationError("INVALID_ARRAY", `${path} must be an array of at most ${maximum} items`);
  }
  const output = value.map((item, index) => requireString(item, `${path}[${index}]`));
  if (new Set(output).size !== output.length) {
    throw new ConfigurationError("DUPLICATE_VALUE", `${path} contains duplicate values`);
  }
  return output;
}

export function deepFreeze<T>(value: T, seen = new Set<object>()): Readonly<T> {
  if (value === null || typeof value !== "object" || seen.has(value)) return value;
  seen.add(value);
  for (const child of Object.values(value as Record<string, unknown>)) deepFreeze(child, seen);
  return Object.freeze(value);
}
