import { createPublicKey } from "node:crypto";
import {
  closeSync,
  constants,
  fstatSync,
  lstatSync,
  openSync,
  readFileSync,
  readdirSync,
  realpathSync,
} from "node:fs";
import type { Stats } from "node:fs";
import { isAbsolute, relative, resolve, sep } from "node:path";

import {
  computeOperationDefinitionHash,
  loadSchemaRegistry,
  SCHEMA_IDS,
  sha256Bytes,
  sha256Canonical,
  verifyIntegrity,
  validateCapabilityPack,
} from "@codex-production-monitoring/contracts";
import type {
  AdapterPackage,
  OperationId,
  Sha256,
  TrustBundle,
  TrustedProfile,
} from "@codex-production-monitoring/contracts";
import { Ajv2020 } from "ajv/dist/2020.js";
import type { ValidateFunction } from "ajv";
import addFormatsImport from "ajv-formats";

import { normalizeTrustedEndpoint } from "./endpoint.ts";
import {
  parseProviderRuntimeConfiguration,
  type LoadedProviderRuntimeConfiguration,
  type LoadedWorkerSigningKey,
  type ProviderRuntimeConfiguration,
} from "./provider-runtime.ts";
import {
  ConfigurationError,
  deepFreeze,
  parseStrictYaml,
  requireExactKeys,
  requireObject,
  requireString,
} from "./validation.ts";

interface TrustRootManifestEntry {
  role: "TRUST_BUNDLE" | "PROVIDER_RUNTIME" | "SIGNING_KEY";
  path: string;
  bytes: number;
  sha256: Sha256;
}

interface TrustRootManifest {
  schemaVersion: "1.0.0";
  rootId: string;
  createdAt: string;
  files: TrustRootManifestEntry[];
}

export interface LoadTrustRootOptions {
  rootPath: string;
  forbiddenWorkspaceRoots?: readonly string[];
  expectedOwnerUid?: number;
}

export interface LoadedTrustRoot {
  readonly rootPath: string;
  /** Exact SHA-256 of the manifest.yaml source bytes. */
  readonly rootManifestSourceSha256?: Sha256;
  /** Exact SHA-256 of the manifest-selected trust-bundle source bytes. */
  readonly trustBundleSourceSha256?: Sha256;
  readonly rootManifestSha256: Sha256;
  readonly trustBundleSha256: Sha256;
  readonly bundle: Readonly<TrustBundle>;
  readonly providerRuntime?: Readonly<LoadedProviderRuntimeConfiguration>;
}

const ajv = new Ajv2020({ allErrors: true, allowUnionTypes: true, strict: true });
const addFormats = addFormatsImport as unknown as (instance: Ajv2020) => Ajv2020;
addFormats(ajv);
for (const schema of loadSchemaRegistry().values()) ajv.addSchema(schema);
const resolvedTrustBundleValidator = ajv.getSchema(SCHEMA_IDS.trustBundle);
if (resolvedTrustBundleValidator === undefined) throw new Error("Trust bundle schema is not registered");
const validateTrustBundle: ValidateFunction = resolvedTrustBundleValidator;

function modeBits(mode: number): number {
  return mode & 0o777;
}

function expectedUid(options: LoadTrustRootOptions): number | undefined {
  if (options.expectedOwnerUid !== undefined) return options.expectedOwnerUid;
  return typeof process.geteuid === "function" ? process.geteuid() : undefined;
}

function assertOwner(stat: Stats, uid: number | undefined, path: string): void {
  if (uid !== undefined && stat.uid !== uid) {
    throw new ConfigurationError("UNTRUSTED_OWNER", `${path} is not owned by the trusted launcher user`);
  }
}

function assertPrivateDirectory(path: string, uid: number | undefined): void {
  const stat = lstatSync(path);
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    throw new ConfigurationError("UNSAFE_TRUST_ROOT", `${path} must be a real directory`);
  }
  assertOwner(stat, uid, path);
  const mode = modeBits(stat.mode);
  if ((mode & 0o500) !== 0o500 || (mode & 0o077) !== 0) {
    throw new ConfigurationError("UNSAFE_MODE", `${path} must be owner-only and owner-readable/searchable`);
  }
}

function assertSafeRelativePath(path: string): void {
  if (
    path.length === 0 ||
    isAbsolute(path) ||
    path.includes("\\") ||
    path.split("/").some((segment) => segment === "" || segment === "." || segment === "..")
  ) {
    throw new ConfigurationError("UNSAFE_PATH", `Unsafe trust-root manifest path: ${path}`);
  }
}

function securelyReadPrivateFile(path: string, uid: number | undefined): Buffer {
  const before = lstatSync(path);
  if (before.isSymbolicLink() || !before.isFile() || before.nlink !== 1) {
    throw new ConfigurationError("UNSAFE_FILE", `${path} must be one regular, unlinked file`);
  }
  assertOwner(before, uid, path);
  const mode = modeBits(before.mode);
  if ((mode & 0o400) === 0 || (mode & 0o077) !== 0) {
    throw new ConfigurationError("UNSAFE_MODE", `${path} must be owner-readable and owner-only`);
  }

  const noFollow = typeof constants.O_NOFOLLOW === "number" ? constants.O_NOFOLLOW : 0;
  let descriptor: number | undefined;
  try {
    descriptor = openSync(path, constants.O_RDONLY | noFollow);
    const opened = fstatSync(descriptor);
    if (
      !opened.isFile() ||
      opened.nlink !== 1 ||
      opened.dev !== before.dev ||
      opened.ino !== before.ino
    ) {
      throw new ConfigurationError("FILE_IDENTITY_CHANGED", `${path} changed while opening`);
    }
    const content = readFileSync(descriptor);
    const after = fstatSync(descriptor);
    if (
      after.dev !== opened.dev ||
      after.ino !== opened.ino ||
      after.size !== opened.size ||
      after.mtimeMs !== opened.mtimeMs
    ) {
      throw new ConfigurationError("FILE_IDENTITY_CHANGED", `${path} changed while reading`);
    }
    return content;
  } finally {
    if (descriptor !== undefined) closeSync(descriptor);
  }
}

function parseManifest(text: string): TrustRootManifest {
  const object = requireObject(parseStrictYaml(text, "trust-root manifest"), "manifest");
  requireExactKeys(
    object,
    ["schemaVersion", "rootId", "createdAt", "files"],
    ["schemaVersion", "rootId", "createdAt", "files"],
    "manifest",
  );
  if (object.schemaVersion !== "1.0.0") {
    throw new ConfigurationError("UNSUPPORTED_VERSION", "manifest.schemaVersion must be 1.0.0");
  }
  const rootId = requireString(object.rootId, "manifest.rootId");
  const createdAt = requireString(object.createdAt, "manifest.createdAt");
  if (!Number.isFinite(Date.parse(createdAt))) {
    throw new ConfigurationError("INVALID_TIME", "manifest.createdAt must be an RFC 3339 timestamp");
  }
  if (!Array.isArray(object.files) || object.files.length < 1 || object.files.length > 66) {
    throw new ConfigurationError("INVALID_MANIFEST", "manifest must contain one trust bundle, at most one provider runtime, and at most 64 signing keys");
  }
  const files = object.files.map((rawEntry, index): TrustRootManifestEntry => {
    const entryPath = `manifest.files[${index}]`;
    const entryObject = requireObject(rawEntry, entryPath);
    requireExactKeys(entryObject, ["role", "path", "bytes", "sha256"], ["role", "path", "bytes", "sha256"], entryPath);
    if (
      entryObject.role !== "TRUST_BUNDLE" &&
      entryObject.role !== "PROVIDER_RUNTIME" &&
      entryObject.role !== "SIGNING_KEY"
    ) {
      throw new ConfigurationError("INVALID_ROLE", `${entryPath}.role is not supported`);
    }
    const path = requireString(entryObject.path, `${entryPath}.path`);
    assertSafeRelativePath(path);
    if (!Number.isSafeInteger(entryObject.bytes) || (entryObject.bytes as number) < 1) {
      throw new ConfigurationError("INVALID_SIZE", `${entryPath}.bytes must be a positive safe integer`);
    }
    const sha256 = requireString(entryObject.sha256, `${entryPath}.sha256`);
    if (!/^[a-f0-9]{64}$/u.test(sha256)) {
      throw new ConfigurationError("INVALID_DIGEST", `${entryPath}.sha256 must be lowercase SHA-256`);
    }
    return {
      role: entryObject.role,
      path,
      bytes: entryObject.bytes as number,
      sha256: sha256 as Sha256,
    };
  });
  if (files.filter((entry) => entry.role === "TRUST_BUNDLE").length !== 1) {
    throw new ConfigurationError("INVALID_MANIFEST", "manifest must contain exactly one trust bundle");
  }
  if (files.filter((entry) => entry.role === "PROVIDER_RUNTIME").length > 1) {
    throw new ConfigurationError("INVALID_MANIFEST", "manifest may contain at most one provider runtime file");
  }
  if (files.filter((entry) => entry.role === "SIGNING_KEY").length > 64) {
    throw new ConfigurationError("INVALID_MANIFEST", "manifest may contain at most 64 signing keys");
  }
  if (new Set(files.map((entry) => entry.path)).size !== files.length) {
    throw new ConfigurationError("DUPLICATE_PATH", "manifest paths must be unique");
  }
  return {
    schemaVersion: "1.0.0",
    rootId,
    createdAt,
    files,
  };
}

function isWithin(path: string, parent: string): boolean {
  const relation = relative(parent, path);
  return relation === "" || (!relation.startsWith(`..${sep}`) && relation !== ".." && !isAbsolute(relation));
}

function loadWorkerSigningKeys(
  configuration: Readonly<ProviderRuntimeConfiguration>,
  manifest: Readonly<TrustRootManifest>,
  rootPath: string,
  uid: number | undefined,
): readonly Readonly<LoadedWorkerSigningKey>[] {
  const signingEntries = manifest.files.filter((entry) => entry.role === "SIGNING_KEY");
  const configuredPaths = new Set(
    configuration.workerAdmission.trustedSigningKeys.map((reference) => reference.manifestPath),
  );
  if (signingEntries.length !== configuredPaths.size) {
    throw new ConfigurationError(
      "SIGNING_KEY_MANIFEST_MISMATCH",
      "Every signing key manifest entry must be referenced exactly once by the provider runtime",
    );
  }
  const entriesByPath = new Map(signingEntries.map((entry) => [entry.path, entry]));
  return configuration.workerAdmission.trustedSigningKeys.map((reference) => {
    const entry = entriesByPath.get(reference.manifestPath);
    if (entry === undefined || !configuredPaths.has(entry.path)) {
      throw new ConfigurationError(
        "SIGNING_KEY_NOT_MANIFESTED",
        `Signing key ${reference.keyId} is not a manifest-hashed file`,
      );
    }
    const path = resolve(rootPath, entry.path);
    if (!isWithin(path, rootPath)) {
      throw new ConfigurationError("UNSAFE_PATH", "A signing key file escapes the active root");
    }
    const bytes = securelyReadPrivateFile(path, uid);
    if (bytes.byteLength !== entry.bytes) {
      throw new ConfigurationError("SIZE_MISMATCH", `Signing key ${reference.keyId} byte length does not match its manifest`);
    }
    if (sha256Bytes(bytes) !== entry.sha256) {
      throw new ConfigurationError("DIGEST_MISMATCH", `Signing key ${reference.keyId} digest does not match its manifest`);
    }
    if (bytes.byteLength > 16_384 || bytes.includes(0)) {
      throw new ConfigurationError("INVALID_SIGNING_KEY", `Signing key ${reference.keyId} is not a bounded PEM public key`);
    }
    const pem = bytes.toString("utf8");
    if (/PRIVATE KEY/u.test(pem)) {
      throw new ConfigurationError("PRIVATE_KEY_FORBIDDEN", "Private signing keys must never be placed in the trust root");
    }
    try {
      const key = createPublicKey(pem);
      if (key.type !== "public" || key.asymmetricKeyType !== "ed25519") {
        throw new Error("not Ed25519");
      }
    } catch {
      throw new ConfigurationError("INVALID_SIGNING_KEY", `Signing key ${reference.keyId} is not an Ed25519 public key`);
    }
    return Object.freeze({
      keyId: reference.keyId,
      sourcePath: reference.manifestPath,
      sourceSha256: entry.sha256,
      publicKeyPem: pem,
    });
  });
}

export function computeTrustedProfileConfigHash(profile: TrustedProfile): Sha256 {
  return sha256Canonical({
    schemaVersion: profile.schemaVersion,
    profileAlias: profile.profileAlias,
    capabilityProfile: profile.capabilityProfile,
    allowedOrigins: profile.allowedOrigins,
    scopes: profile.scopes,
    endpointIds: profile.endpointIds,
    operationIds: profile.operationIds,
    ...(profile.capabilityPackIds === undefined
      ? {}
      : { capabilityPackIds: profile.capabilityPackIds }),
    ...(profile.capabilityPackCatalogSha256 === undefined
      ? {}
      : { capabilityPackCatalogSha256: profile.capabilityPackCatalogSha256 }),
    ...(profile.defaultVerificationPolicyAlias === undefined
      ? {}
      : { defaultVerificationPolicyAlias: profile.defaultVerificationPolicyAlias }),
    ...(profile.verificationPolicies === undefined
      ? {}
      : { verificationPolicies: profile.verificationPolicies }),
    policy: profile.policy,
  });
}

function assertBundleBindings(bundle: TrustBundle): void {
  const endpointIds = new Set<string>();
  for (const endpoint of bundle.endpoints) {
    if (endpointIds.has(endpoint.endpointId)) {
      throw new ConfigurationError("DUPLICATE_ENDPOINT", `Duplicate endpoint: ${endpoint.endpointId}`);
    }
    endpointIds.add(endpoint.endpointId);
    const normalized = normalizeTrustedEndpoint(endpoint);
    if (normalized.baseUrl !== endpoint.baseUrl) {
      throw new ConfigurationError(
        "NON_CANONICAL_ENDPOINT",
        `Endpoint ${endpoint.endpointId} must be stored in canonical form: ${normalized.baseUrl}`,
      );
    }
  }

  const adapters = new Set<string>();
  for (const adapter of bundle.adapters) {
    if (adapters.has(adapter.packageId)) {
      throw new ConfigurationError("DUPLICATE_ADAPTER", `Duplicate adapter: ${adapter.packageId}`);
    }
    adapters.add(adapter.packageId);
  }
  for (const endpoint of bundle.endpoints) {
    if (!adapters.has(endpoint.adapterId)) {
      throw new ConfigurationError(
        "UNKNOWN_ADAPTER",
        `Endpoint ${endpoint.endpointId} references an unadmitted adapter`,
      );
    }
  }

  const operations = new Map<string, Sha256>();
  for (const operation of bundle.operations) {
    if (operations.has(operation.operationId)) {
      throw new ConfigurationError("DUPLICATE_OPERATION", `Duplicate operation: ${operation.operationId}`);
    }
    if (computeOperationDefinitionHash(operation) !== operation.definitionSha256) {
      throw new ConfigurationError(
        "OPERATION_DIGEST_MISMATCH",
        `Operation ${operation.operationId} definition digest does not match`,
      );
    }
    if (!adapters.has(operation.definition.adapterPackageId)) {
      throw new ConfigurationError(
        "UNKNOWN_ADAPTER",
        `Operation ${operation.operationId} references an unadmitted adapter`,
      );
    }
    if (!endpointIds.has(operation.definition.sourceAlias)) {
      throw new ConfigurationError(
        "UNKNOWN_ENDPOINT",
        `Operation ${operation.operationId} references an unknown source alias`,
      );
    }
    const source = bundle.endpoints.find(
      (endpoint) => endpoint.endpointId === operation.definition.sourceAlias,
    );
    if (source?.adapterId !== operation.definition.adapterPackageId) {
      throw new ConfigurationError(
        "ADAPTER_ENDPOINT_MISMATCH",
        `Operation ${operation.operationId} adapter does not match its endpoint`,
      );
    }
    operations.set(operation.operationId, operation.definitionSha256);
  }

  for (const endpointId of bundle.profile.endpointIds) {
    if (!endpointIds.has(endpointId)) {
      throw new ConfigurationError("UNKNOWN_ENDPOINT", `Profile references unknown endpoint ${endpointId}`);
    }
  }
  for (const operationId of bundle.profile.operationIds) {
    if (!operations.has(operationId)) {
      throw new ConfigurationError("UNKNOWN_OPERATION", `Profile references unknown operation ${operationId}`);
    }
  }
  const capabilityPacks = bundle.capabilityPacks ?? [];
  const capabilityPackIds = new Set<string>();
  for (const pack of capabilityPacks) {
    if (capabilityPackIds.has(pack.packId)) {
      throw new ConfigurationError("DUPLICATE_CAPABILITY_PACK", `Duplicate capability pack: ${pack.packId}`);
    }
    try {
      validateCapabilityPack(pack);
    } catch {
      throw new ConfigurationError(
        "CAPABILITY_PACK_DIGEST_MISMATCH",
        `Capability pack ${pack.packId} is not a valid reviewed pack`,
      );
    }
    for (const operationId of pack.requiredOperationIds) {
      if (!bundle.profile.operationIds.includes(operationId) || !operations.has(operationId)) {
        throw new ConfigurationError(
          "CAPABILITY_PACK_OPERATION_MISSING",
          `Capability pack ${pack.packId} requires unavailable operation ${operationId}`,
        );
      }
    }
    capabilityPackIds.add(pack.packId);
  }
  const profileCapabilityPackIds = bundle.profile.capabilityPackIds ?? [];
  if (
    profileCapabilityPackIds.length !== capabilityPackIds.size ||
    profileCapabilityPackIds.some((packId) => !capabilityPackIds.has(packId))
  ) {
    throw new ConfigurationError(
      "CAPABILITY_PACK_CATALOG_MISMATCH",
      "Profile capability pack IDs do not match the activated pack catalog",
    );
  }
  if (capabilityPacks.length === 0) {
    if (bundle.profile.capabilityPackCatalogSha256 !== undefined) {
      throw new ConfigurationError(
        "CAPABILITY_PACK_CATALOG_MISMATCH",
        "An empty capability pack catalog cannot carry a digest",
      );
    }
  } else if (bundle.profile.capabilityPackCatalogSha256 !== sha256Canonical(capabilityPacks)) {
    throw new ConfigurationError(
      "CAPABILITY_PACK_CATALOG_MISMATCH",
      "Capability pack catalog digest does not match",
    );
  }
  const verificationPolicies = bundle.profile.verificationPolicies ?? {};
  if (
    bundle.profile.defaultVerificationPolicyAlias !== undefined &&
    verificationPolicies[bundle.profile.defaultVerificationPolicyAlias] === undefined
  ) {
    throw new ConfigurationError("UNKNOWN_VERIFICATION_POLICY", "Default verification policy alias is not defined");
  }
  for (const [alias, policy] of Object.entries(verificationPolicies)) {
    if (policy.policyAlias !== alias || policy.passCount > policy.requiredSamples) {
      throw new ConfigurationError("INVALID_VERIFICATION_POLICY", `Verification policy ${alias} is internally inconsistent`);
    }
    const criterionIds = new Set<string>();
    for (const criterion of policy.criteria) {
      if (criterionIds.has(criterion.criterionId)) {
        throw new ConfigurationError("INVALID_VERIFICATION_POLICY", `Verification policy ${alias} repeats a criterion ID`);
      }
      criterionIds.add(criterion.criterionId);
      if (!bundle.profile.operationIds.includes(criterion.operationId)) {
        throw new ConfigurationError("UNKNOWN_OPERATION", `Verification policy ${alias} references an unapproved operation`);
      }
      const operation = bundle.operations.find((candidate) => candidate.operationId === criterion.operationId)!;
      const numericExpectedInvalid =
        new Set(["LT", "LTE", "GT", "GTE"]).has(criterion.comparator) &&
        (typeof criterion.expected !== "number" || !Number.isFinite(criterion.expected));
      const activityExpectedInvalid =
        new Set(["ACTIVE", "INACTIVE"]).has(criterion.comparator) &&
        criterion.expected !== true;
      if (
        criterion.maxEvidenceAgeMs > operation.definition.limits.maxAgeMs ||
        criterion.valueSelector.kind !== operation.definition.normalization.resultKind ||
        numericExpectedInvalid ||
        activityExpectedInvalid ||
        (criterion.valueSelector.reducer === "ALL" && criterion.valueSelector.kind !== "TIMESERIES") ||
        (policy.requiredSamples > 1 && criterion.valueSelector.kind === "SCALAR") ||
        (criterion.requiredDurationSeconds !== undefined && criterion.requiredDurationSeconds > policy.windowDurationSeconds) ||
        (operation.definition.normalization.targetUnit !== undefined && criterion.unit !== operation.definition.normalization.targetUnit)
      ) {
        throw new ConfigurationError("INVALID_VERIFICATION_POLICY", `Verification policy ${alias} conflicts with its operation contract`);
      }
    }
  }
  if (bundle.profile.configSha256 !== computeTrustedProfileConfigHash(bundle.profile)) {
    throw new ConfigurationError("PROFILE_DIGEST_MISMATCH", "Profile configuration digest does not match");
  }
  if (bundle.profile.endpointRegistrySha256 !== sha256Canonical(bundle.endpoints)) {
    throw new ConfigurationError("ENDPOINT_DIGEST_MISMATCH", "Endpoint registry digest does not match");
  }
  if (bundle.profile.catalogSha256 !== sha256Canonical(bundle.operations)) {
    throw new ConfigurationError("CATALOG_DIGEST_MISMATCH", "Operation catalog digest does not match");
  }
}

export function loadTrustedRoot(options: LoadTrustRootOptions): Readonly<LoadedTrustRoot> {
  if (!isAbsolute(options.rootPath)) {
    throw new ConfigurationError("RELATIVE_TRUST_ROOT", "The trust-root path must be absolute");
  }
  const requestedRoot = resolve(options.rootPath);
  assertPrivateDirectory(requestedRoot, expectedUid(options));
  const rootPath = realpathSync(requestedRoot);
  for (const forbiddenRoot of options.forbiddenWorkspaceRoots ?? []) {
    const workspace = realpathSync(resolve(forbiddenRoot));
    if (isWithin(rootPath, workspace)) {
      throw new ConfigurationError("TRUST_ROOT_IN_WORKSPACE", "The active trust root cannot live in an inspected workspace");
    }
  }

  const uid = expectedUid(options);
  const manifestPath = resolve(rootPath, "manifest.yaml");
  const manifestBytes = securelyReadPrivateFile(manifestPath, uid);
  const manifest = parseManifest(manifestBytes.toString("utf8"));
  const listed = new Set(["manifest.yaml", ...manifest.files.map((entry) => entry.path)]);
  for (const entry of readdirSync(rootPath, { withFileTypes: true })) {
    if (!listed.has(entry.name)) {
      throw new ConfigurationError(
        entry.name === ".env" ? "DOTENV_FORBIDDEN" : "UNMANIFESTED_ENTRY",
        `The active trust root contains an unmanifested entry: ${entry.name}`,
      );
    }
    if (!entry.isFile()) {
      throw new ConfigurationError("UNSAFE_FILE", `The active trust root entry is not a regular file: ${entry.name}`);
    }
  }

  const bundleEntry = manifest.files.find((entry) => entry.role === "TRUST_BUNDLE")!;
  const bundlePath = resolve(rootPath, bundleEntry.path);
  if (!isWithin(bundlePath, rootPath)) {
    throw new ConfigurationError("UNSAFE_PATH", "The trust bundle escapes the active root");
  }
  const bundleBytes = securelyReadPrivateFile(bundlePath, uid);
  if (bundleBytes.byteLength !== bundleEntry.bytes) {
    throw new ConfigurationError("SIZE_MISMATCH", "The trust bundle byte length does not match its manifest");
  }
  if (sha256Bytes(bundleBytes) !== bundleEntry.sha256) {
    throw new ConfigurationError("DIGEST_MISMATCH", "The trust bundle digest does not match its manifest");
  }

  const bundleValue = parseStrictYaml(bundleBytes.toString("utf8"), bundleEntry.path);
  if (!validateTrustBundle(bundleValue)) {
    throw new ConfigurationError(
      "INVALID_TRUST_BUNDLE",
      `Trust bundle does not satisfy its contract: ${ajv.errorsText(validateTrustBundle.errors)}`,
    );
  }
  const bundle = bundleValue as TrustBundle;
  if (!verifyIntegrity(bundle)) {
    throw new ConfigurationError("TRUST_BUNDLE_INTEGRITY", "Trust bundle integrity does not match");
  }
  assertBundleBindings(bundle);

  const runtimeEntry = manifest.files.find((entry) => entry.role === "PROVIDER_RUNTIME");
  let providerRuntime: LoadedProviderRuntimeConfiguration | undefined;
  if (runtimeEntry !== undefined) {
    const runtimePath = resolve(rootPath, runtimeEntry.path);
    if (!isWithin(runtimePath, rootPath)) {
      throw new ConfigurationError("UNSAFE_PATH", "The provider runtime file escapes the active root");
    }
    const runtimeBytes = securelyReadPrivateFile(runtimePath, uid);
    if (runtimeBytes.byteLength !== runtimeEntry.bytes) {
      throw new ConfigurationError("SIZE_MISMATCH", "The provider runtime byte length does not match its manifest");
    }
    if (sha256Bytes(runtimeBytes) !== runtimeEntry.sha256) {
      throw new ConfigurationError("DIGEST_MISMATCH", "The provider runtime digest does not match its manifest");
    }
    const configuration = parseProviderRuntimeConfiguration(runtimeBytes.toString("utf8"), bundle);
    providerRuntime = {
      sourcePath: runtimeEntry.path,
      sourceSha256: runtimeEntry.sha256,
      configuration,
      signingKeys: loadWorkerSigningKeys(configuration, manifest, rootPath, uid),
    };
  } else if (manifest.files.some((entry) => entry.role === "SIGNING_KEY")) {
    throw new ConfigurationError(
      "ORPHANED_SIGNING_KEY",
      "Signing key files require a manifest-hashed provider runtime configuration",
    );
  }

  return deepFreeze({
    rootPath,
    rootManifestSourceSha256: sha256Bytes(manifestBytes),
    trustBundleSourceSha256: bundleEntry.sha256,
    rootManifestSha256: sha256Canonical(manifest),
    trustBundleSha256: bundle.integrity.contentSha256,
    bundle,
    ...(providerRuntime === undefined ? {} : { providerRuntime }),
  });
}

export function admittedAdapterPackages(root: LoadedTrustRoot): ReadonlyMap<string, AdapterPackage> {
  return new Map(root.bundle.adapters.map((adapter) => [adapter.packageId, adapter]));
}

export function operationDefinitionHashes(root: LoadedTrustRoot): ReadonlyMap<OperationId, Sha256> {
  return new Map(root.bundle.operations.map((operation) => [operation.operationId, operation.definitionSha256]));
}
