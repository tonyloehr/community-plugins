import { isAbsolute, posix } from "node:path";

import type {
  AdapterPackageId,
  CredentialReference,
  JsonObject,
  JsonValue,
  Sha256,
  TrustBundle,
} from "@codex-production-monitoring/contracts";

import { trustedEndpointCredentialReferences } from "./endpoint.ts";

import {
  ConfigurationError,
  deepFreeze,
  parseStrictYaml,
  requireAlias,
  requireExactKeys,
  requireObject,
  requireString,
  requireStringArray,
} from "./validation.ts";

export const PROVIDER_WORKER_ARTIFACT_PATH = "workers/provider-worker.mjs";

export type ProviderKind =
  | "prometheus"
  | "grafana"
  | "alertmanager"
  | "loki"
  | "tempo"
  | "kubernetes"
  | "git"
  | "fixture";

export type FirstPartyProviderKind = Exclude<ProviderKind, "fixture">;

export interface TrustedHttpRuntimePolicy {
  timeoutMs: number;
  maxResponseBytes: number;
}

export interface WorkerSigningKeyReference {
  keyId: string;
  manifestPath: string;
}

export interface WorkerRevocations {
  packageIds: AdapterPackageId[];
  artifactSha256s: Sha256[];
  artifactPaths: string[];
  signingKeyIds: string[];
}

export interface WorkerAdmissionConfiguration {
  trustedSigningKeys: WorkerSigningKeyReference[];
  revocations: WorkerRevocations;
}

interface ProviderRuntimeBindingBase {
  kind: ProviderKind;
  packageId: AdapterPackageId;
  /** Exact secret environment references copied into this worker; never inherited. */
  credentialEnv: string[];
  /** Administrator-reviewed effective provider authority, sealed by the runtime manifest. */
  access: ProviderAccessApproval;
}

export interface ProviderAccessApproval {
  approvalId: string;
  reviewedAt: string;
  effectiveProviderScopes: string[];
}

export interface SingleEndpointRuntimeBootstrap {
  endpointId: string;
  catalog: JsonObject;
  transport: TrustedHttpRuntimePolicy;
}

export interface SingleEndpointRuntimeBinding extends ProviderRuntimeBindingBase {
  kind: "prometheus" | "grafana" | "loki" | "tempo" | "kubernetes";
  bootstrap: SingleEndpointRuntimeBootstrap;
}

export interface AlertmanagerRuntimeBootstrap {
  endpointIds: string[];
  catalog: JsonObject[];
  transport: TrustedHttpRuntimePolicy;
}

export interface AlertmanagerRuntimeBinding extends ProviderRuntimeBindingBase {
  kind: "alertmanager";
  bootstrap: AlertmanagerRuntimeBootstrap;
}

export interface GitRuntimeBootstrap {
  gitExecutable: string;
  workspaces: JsonObject[];
  catalog: JsonObject[];
}

export interface GitRuntimeBinding extends ProviderRuntimeBindingBase {
  kind: "git";
  bootstrap: GitRuntimeBootstrap;
}

export interface FixtureRuntimeBinding extends ProviderRuntimeBindingBase {
  kind: "fixture";
  bootstrap: JsonObject;
}

export type ProviderRuntimeBinding =
  | SingleEndpointRuntimeBinding
  | AlertmanagerRuntimeBinding
  | GitRuntimeBinding
  | FixtureRuntimeBinding;

export interface ProviderRuntimeConfiguration {
  schemaVersion: "1.0.0";
  metadata: Record<string, string>;
  workerAdmission: WorkerAdmissionConfiguration;
  adapters: ProviderRuntimeBinding[];
}

export interface LoadedWorkerSigningKey {
  readonly keyId: string;
  readonly sourcePath: string;
  readonly sourceSha256: Sha256;
  readonly publicKeyPem: string;
}

export interface LoadedProviderRuntimeConfiguration {
  readonly sourcePath: string;
  readonly sourceSha256: Sha256;
  readonly configuration: Readonly<ProviderRuntimeConfiguration>;
  readonly signingKeys: readonly Readonly<LoadedWorkerSigningKey>[];
}

/**
 * The complete pre-1.0 production-admission set. These identifiers are coupled to
 * implementations compiled into the release-owned provider worker; they are
 * not an extension namespace. Public adapter SDK/conformance packages remain
 * usable for authoring and testing, but this runtime does not execute
 * third-party adapter code.
 */
export const V0_1_CODE_OWNED_PACKAGE_BY_KIND = {
  prometheus: "adapter.prometheus.v1",
  grafana: "adapter.grafana.v1",
  alertmanager: "adapter.alertmanager.v1",
  loki: "adapter.loki.v1",
  tempo: "adapter.tempo.v1",
  kubernetes: "adapter.kubernetes.v1",
  git: "adapter.git.v1",
  fixture: "adapter.fixture.v1",
} as const satisfies Record<ProviderKind, string>;

/** @deprecated Prefer the boundary-explicit v0.1 name. */
export const PACKAGE_BY_KIND = V0_1_CODE_OWNED_PACKAGE_BY_KIND;

const PROVIDER_KINDS = new Set<string>(Object.keys(V0_1_CODE_OWNED_PACKAGE_BY_KIND));
const SAFE_METADATA_KEY = /^[A-Za-z][A-Za-z0-9_.-]{0,127}$/u;
const ENVIRONMENT_KEY = /^[A-Z_][A-Z0-9_]{0,127}$/u;
const SHA256_PATTERN = /^[a-f0-9]{64}$/u;

function requirePositiveInteger(value: unknown, path: string, maximum: number): number {
  if (!Number.isSafeInteger(value) || (value as number) < 1 || (value as number) > maximum) {
    throw new ConfigurationError("INVALID_BOUND", `${path} must be a positive integer no larger than ${maximum}`);
  }
  return value as number;
}

function requireJsonValue(value: unknown, path: string, state = { nodes: 0, depth: 0 }): JsonValue {
  state.nodes += 1;
  if (state.nodes > 100_000) {
    throw new ConfigurationError("RUNTIME_CONFIG_TOO_LARGE", `${path} contains too many values`);
  }
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new ConfigurationError("INVALID_JSON_VALUE", `${path} is not finite`);
    return value;
  }
  if (state.depth >= 32) throw new ConfigurationError("RUNTIME_CONFIG_TOO_DEEP", `${path} is too deeply nested`);
  const childState = { nodes: state.nodes, depth: state.depth + 1 };
  if (Array.isArray(value)) {
    const output = value.map((item, index) => {
      const parsed = requireJsonValue(item, `${path}[${index}]`, childState);
      state.nodes = childState.nodes;
      return parsed;
    });
    return output;
  }
  const object = requireObject(value, path);
  const output: Record<string, JsonValue> = {};
  for (const [key, child] of Object.entries(object)) {
    if (key.length === 0 || key.length > 256) {
      throw new ConfigurationError("INVALID_JSON_KEY", `${path} contains an invalid key`);
    }
    output[key] = requireJsonValue(child, `${path}.${key}`, childState);
    state.nodes = childState.nodes;
  }
  return output;
}

function requireJsonObject(value: unknown, path: string): JsonObject {
  const parsed = requireJsonValue(value, path);
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new ConfigurationError("INVALID_SHAPE", `${path} must be an object`);
  }
  return parsed;
}

function requireJsonObjectArray(value: unknown, path: string, maximum = 1_024): JsonObject[] {
  if (!Array.isArray(value) || value.length === 0 || value.length > maximum) {
    throw new ConfigurationError("INVALID_ARRAY", `${path} must contain one to ${maximum} objects`);
  }
  return value.map((item, index) => requireJsonObject(item, `${path}[${index}]`));
}

function parseTransport(value: unknown, path: string): TrustedHttpRuntimePolicy {
  const object = requireObject(value, path);
  requireExactKeys(object, ["timeoutMs", "maxResponseBytes"], ["timeoutMs", "maxResponseBytes"], path);
  return {
    timeoutMs: requirePositiveInteger(object.timeoutMs, `${path}.timeoutMs`, 120_000),
    maxResponseBytes: requirePositiveInteger(object.maxResponseBytes, `${path}.maxResponseBytes`, 1_073_741_824),
  };
}

function parseCatalog(value: unknown, path: string): JsonObject {
  const catalog = requireJsonObject(value, path);
  requireExactKeys(catalog, ["entries"], ["entries"], path);
  if (!Array.isArray(catalog.entries) || catalog.entries.length === 0 || catalog.entries.length > 1_024) {
    throw new ConfigurationError("INVALID_CATALOG", `${path}.entries must contain one to 1024 reviewed entries`);
  }
  for (const [index, entry] of catalog.entries.entries()) {
    if (entry === null || typeof entry !== "object" || Array.isArray(entry)) {
      throw new ConfigurationError("INVALID_CATALOG", `${path}.entries[${index}] must be an object`);
    }
  }
  return catalog;
}

function parseMetadata(value: unknown): Record<string, string> {
  const object = requireObject(value, "provider-runtime.metadata");
  if (Object.keys(object).length > 64) {
    throw new ConfigurationError("TOO_MUCH_METADATA", "provider-runtime.metadata exceeds 64 fixed values");
  }
  const output: Record<string, string> = {};
  for (const [key, rawValue] of Object.entries(object)) {
    if (!SAFE_METADATA_KEY.test(key)) {
      throw new ConfigurationError("INVALID_METADATA_KEY", `Invalid provider runtime metadata key: ${key}`);
    }
    const value = requireString(rawValue, `provider-runtime.metadata.${key}`);
    if (value.length > 1_024 || /[\r\n\0]/u.test(value)) {
      throw new ConfigurationError("INVALID_METADATA_VALUE", `Unsafe provider runtime metadata value: ${key}`);
    }
    output[key] = value;
  }
  return output;
}

function requirePortablePath(value: unknown, path: string): string {
  const result = requireString(value, path);
  if (
    result.length > 1_024 ||
    isAbsolute(result) ||
    result.includes("\\") ||
    result.includes("\0") ||
    posix.normalize(result) !== result ||
    result.split("/").some((segment) => segment === "" || segment === "." || segment === "..")
  ) {
    throw new ConfigurationError("UNSAFE_PATH", `${path} must be a portable relative path`);
  }
  return result;
}

function parseSha256Array(value: unknown, path: string): Sha256[] {
  return requireStringArray(value, path, 1_024).map((item, index) => {
    if (!SHA256_PATTERN.test(item)) throw new ConfigurationError("INVALID_DIGEST", `${path}[${index}] is not SHA-256`);
    return item as Sha256;
  });
}

function parseWorkerAdmission(value: unknown): WorkerAdmissionConfiguration {
  const path = "provider-runtime.workerAdmission";
  const object = requireObject(value, path);
  requireExactKeys(object, ["trustedSigningKeys", "revocations"], ["trustedSigningKeys", "revocations"], path);
  if (!Array.isArray(object.trustedSigningKeys) || object.trustedSigningKeys.length < 1 || object.trustedSigningKeys.length > 64) {
    throw new ConfigurationError("INVALID_ARRAY", `${path}.trustedSigningKeys must contain one to 64 keys`);
  }
  const trustedSigningKeys = object.trustedSigningKeys.map((value, index) => {
    const keyPath = `${path}.trustedSigningKeys[${index}]`;
    const key = requireObject(value, keyPath);
    requireExactKeys(key, ["keyId", "manifestPath"], ["keyId", "manifestPath"], keyPath);
    const manifestPath = requirePortablePath(key.manifestPath, `${keyPath}.manifestPath`);
    if (manifestPath.includes("/")) {
      throw new ConfigurationError("UNSAFE_PATH", `${keyPath}.manifestPath must name a top-level manifest file`);
    }
    return {
      keyId: requireAlias(key.keyId, `${keyPath}.keyId`),
      manifestPath,
    };
  });
  if (new Set(trustedSigningKeys.map((key) => key.keyId)).size !== trustedSigningKeys.length) {
    throw new ConfigurationError("DUPLICATE_SIGNING_KEY", `${path}.trustedSigningKeys contains a duplicate key ID`);
  }
  if (new Set(trustedSigningKeys.map((key) => key.manifestPath)).size !== trustedSigningKeys.length) {
    throw new ConfigurationError("DUPLICATE_PATH", `${path}.trustedSigningKeys contains a duplicate manifest path`);
  }
  const rawRevocations = requireObject(object.revocations, `${path}.revocations`);
  requireExactKeys(
    rawRevocations,
    ["packageIds", "artifactSha256s", "artifactPaths", "signingKeyIds"],
    ["packageIds", "artifactSha256s", "artifactPaths", "signingKeyIds"],
    `${path}.revocations`,
  );
  return {
    trustedSigningKeys,
    revocations: {
      packageIds: requireStringArray(rawRevocations.packageIds, `${path}.revocations.packageIds`, 1_024)
        .map((id) => requireAlias(id, `${path}.revocations.packageIds`) as AdapterPackageId),
      artifactSha256s: parseSha256Array(rawRevocations.artifactSha256s, `${path}.revocations.artifactSha256s`),
      artifactPaths: requireStringArray(rawRevocations.artifactPaths, `${path}.revocations.artifactPaths`, 1_024)
        .map((item, index) => requirePortablePath(item, `${path}.revocations.artifactPaths[${index}]`)),
      signingKeyIds: requireStringArray(rawRevocations.signingKeyIds, `${path}.revocations.signingKeyIds`, 1_024)
        .map((id) => requireAlias(id, `${path}.revocations.signingKeyIds`)),
    },
  };
}

function endpointFor(bundle: Readonly<TrustBundle>, endpointId: string, path: string) {
  if (!bundle.profile.endpointIds.includes(endpointId)) {
    throw new ConfigurationError("ENDPOINT_NOT_ACTIVE", `${path} is not active in the trusted profile`);
  }
  const endpoint = bundle.endpoints.find((candidate) => candidate.endpointId === endpointId);
  if (endpoint === undefined) throw new ConfigurationError("UNKNOWN_ENDPOINT", `${path} is unknown`);
  return endpoint;
}

function assertPackageAdmission(
  binding: ProviderRuntimeBinding,
  bundle: Readonly<TrustBundle>,
  admission: Readonly<WorkerAdmissionConfiguration>,
  index: number,
): void {
  const expectedPackageId = V0_1_CODE_OWNED_PACKAGE_BY_KIND[binding.kind];
  if (binding.packageId !== expectedPackageId) {
    throw new ConfigurationError(
      "THIRD_PARTY_ADAPTER_NOT_SUPPORTED",
      `provider-runtime.adapters[${index}] must use the pre-1.0 code-owned package ${expectedPackageId} for ${binding.kind}; third-party worker activation requires a separately implemented deployment-enforced containment boundary`,
    );
  }
  const admitted = bundle.adapters.find((adapter) => adapter.packageId === binding.packageId);
  if (admitted === undefined || admitted.entrypoint.kind !== "SIGNED_WORKER") {
    throw new ConfigurationError("ADAPTER_NOT_ADMITTED", `${binding.packageId} is not an admitted signed worker adapter`);
  }
  if (admitted.entrypoint.artifactPath !== PROVIDER_WORKER_ARTIFACT_PATH) {
    throw new ConfigurationError("WORKER_PATH_MISMATCH", `${binding.packageId} does not use the fixed provider worker artifact`);
  }
  const signingKeyId = admitted.entrypoint.signingKeyId;
  if (!admission.trustedSigningKeys.some((key) => key.keyId === signingKeyId)) {
    throw new ConfigurationError("SIGNING_KEY_NOT_CONFIGURED", `${binding.packageId} does not use a configured signing key`);
  }
}

function assertEndpointAdmission(
  endpointId: string,
  packageId: string,
  bundle: Readonly<TrustBundle>,
  path: string,
): void {
  const endpoint = endpointFor(bundle, endpointId, path);
  if (endpoint.adapterId !== packageId) {
    throw new ConfigurationError("ENDPOINT_ADAPTER_MISMATCH", `${path} is not bound to ${packageId}`);
  }
}

function parseCredentialEnvironment(value: unknown, path: string): string[] {
  return requireStringArray(value, path, 64).map((key, index) => {
    if (!ENVIRONMENT_KEY.test(key)) {
      throw new ConfigurationError("INVALID_ENVIRONMENT_REFERENCE", `${path}[${index}] is not an environment key`);
    }
    return key;
  });
}

function parseAccessApproval(value: unknown, path: string): ProviderAccessApproval {
  const object = requireObject(value, path);
  requireExactKeys(
    object,
    ["approvalId", "reviewedAt", "effectiveProviderScopes"],
    ["approvalId", "reviewedAt", "effectiveProviderScopes"],
    path,
  );
  const reviewedAt = requireString(object.reviewedAt, `${path}.reviewedAt`);
  if (!Number.isFinite(Date.parse(reviewedAt)) || new Date(reviewedAt).toISOString() !== reviewedAt) {
    throw new ConfigurationError("INVALID_TIME", `${path}.reviewedAt must be a canonical UTC timestamp`);
  }
  const effectiveProviderScopes = requireStringArray(
    object.effectiveProviderScopes,
    `${path}.effectiveProviderScopes`,
    128,
  ).map((scope, index) => {
    if (scope.length > 256 || /[\r\n\0]/u.test(scope)) {
      throw new ConfigurationError("INVALID_PROVIDER_SCOPE", `${path}.effectiveProviderScopes[${index}] is invalid`);
    }
    return scope;
  });
  if (new Set(effectiveProviderScopes).size !== effectiveProviderScopes.length) {
    throw new ConfigurationError("DUPLICATE_PROVIDER_SCOPE", `${path}.effectiveProviderScopes contains duplicates`);
  }
  return {
    approvalId: requireAlias(object.approvalId, `${path}.approvalId`),
    reviewedAt,
    effectiveProviderScopes: [...effectiveProviderScopes].sort(),
  };
}

export function endpointCredentialReferences(
  bundle: Readonly<TrustBundle>,
  endpointId: string,
): readonly Readonly<CredentialReference>[] {
  const endpoint = endpointFor(bundle, endpointId, endpointId);
  return trustedEndpointCredentialReferences(endpoint);
}

export function providerBindingEndpointIds(binding: Readonly<ProviderRuntimeBinding>): readonly string[] {
  return binding.kind === "alertmanager"
    ? binding.bootstrap.endpointIds
    : binding.kind === "git" || binding.kind === "fixture"
      ? []
      : [binding.bootstrap.endpointId];
}

export function providerBindingCredentialReferences(
  binding: Readonly<ProviderRuntimeBinding>,
  bundle: Readonly<TrustBundle>,
): readonly Readonly<CredentialReference>[] {
  return providerBindingEndpointIds(binding)
    .flatMap((endpointId) => endpointCredentialReferences(bundle, endpointId));
}

function expectedCredentialEnvironment(binding: ProviderRuntimeBinding, bundle: Readonly<TrustBundle>): string[] {
  const keys = providerBindingCredentialReferences(binding, bundle)
    .filter((reference) => reference.kind === "env")
    .map((reference) => reference.key);
  return [...new Set(keys)].sort();
}

export function requiredProviderScopesForBinding(
  binding: Readonly<ProviderRuntimeBinding>,
  bundle: Readonly<TrustBundle>,
): readonly string[] {
  const scopes = bundle.operations
    .filter((operation) =>
      bundle.profile.operationIds.includes(operation.operationId) &&
      operation.definition.adapterPackageId === binding.packageId)
    .flatMap((operation) => operation.definition.requiredProviderScopes);
  return [...new Set(scopes)].sort();
}

function activeOperationsForBinding(
  binding: Readonly<ProviderRuntimeBinding>,
  bundle: Readonly<TrustBundle>,
): Readonly<TrustBundle>["operations"] {
  return bundle.operations.filter((operation) =>
    bundle.profile.operationIds.includes(operation.operationId) &&
    operation.definition.adapterPackageId === binding.packageId);
}

function assertOperationSourceBinding(
  binding: Readonly<ProviderRuntimeBinding>,
  bundle: Readonly<TrustBundle>,
  path: string,
): void {
  const operations = activeOperationsForBinding(binding, bundle);
  if (binding.kind === "git" || binding.kind === "fixture") return;
  if (binding.kind !== "alertmanager") {
    const mismatched = operations.find(
      (operation) => operation.definition.sourceAlias !== binding.bootstrap.endpointId,
    );
    if (mismatched !== undefined) {
      throw new ConfigurationError(
        "OPERATION_SOURCE_MISMATCH",
        `${path} cannot serve active operation ${mismatched.operationId} from a different endpoint`,
      );
    }
    return;
  }

  const endpointIds = new Set(binding.bootstrap.endpointIds);
  if (endpointIds.size !== binding.bootstrap.endpointIds.length) {
    throw new ConfigurationError(
      "DUPLICATE_ENDPOINT_SELECTION",
      `${path}.bootstrap.endpointIds contains a duplicate endpoint`,
    );
  }
  const catalog = new Map<string, { endpointId: string; operation: string }>();
  for (const [index, rawBinding] of binding.bootstrap.catalog.entries()) {
    const bindingId = rawBinding.bindingId;
    const endpointId = rawBinding.endpointId;
    const operation = rawBinding.operation;
    if (typeof bindingId !== "string" || typeof endpointId !== "string" || typeof operation !== "string") {
      throw new ConfigurationError(
        "INVALID_CATALOG_BINDING",
        `${path}.bootstrap.catalog[${index}] must bind an operation and endpoint`,
      );
    }
    if (!endpointIds.has(endpointId)) {
      throw new ConfigurationError(
        "CATALOG_ENDPOINT_NOT_SELECTED",
        `${path}.bootstrap.catalog[${index}] targets an endpoint outside the binding`,
      );
    }
    if (catalog.has(bindingId)) {
      throw new ConfigurationError(
        "DUPLICATE_CATALOG_BINDING",
        `${path}.bootstrap.catalog contains duplicate bindingId ${bindingId}`,
      );
    }
    catalog.set(bindingId, { endpointId, operation });
  }
  for (const activeOperation of operations) {
    if (!endpointIds.has(activeOperation.definition.sourceAlias)) {
      throw new ConfigurationError(
        "OPERATION_SOURCE_MISMATCH",
        `${path} does not select the endpoint for active operation ${activeOperation.operationId}`,
      );
    }
    const providerDefinition = activeOperation.definition.sanitizedProviderDefinition;
    const bindingId = Object.keys(providerDefinition).length === 1
      ? providerDefinition.bindingId
      : undefined;
    const catalogBinding = typeof bindingId === "string" ? catalog.get(bindingId) : undefined;
    if (
      catalogBinding === undefined ||
      catalogBinding.endpointId !== activeOperation.definition.sourceAlias ||
      catalogBinding.operation !== activeOperation.definition.adapterOperation
    ) {
      throw new ConfigurationError(
        "OPERATION_CATALOG_BINDING_MISMATCH",
        `${path} cannot prove the catalog endpoint selected by active operation ${activeOperation.operationId}`,
      );
    }
  }
}

function parseBinding(
  value: unknown,
  index: number,
  bundle: Readonly<TrustBundle>,
  admission: Readonly<WorkerAdmissionConfiguration>,
): ProviderRuntimeBinding {
  const path = `provider-runtime.adapters[${index}]`;
  const object = requireObject(value, path);
  requireExactKeys(
    object,
    ["kind", "packageId", "credentialEnv", "access", "bootstrap"],
    ["kind", "packageId", "credentialEnv", "access", "bootstrap"],
    path,
  );
  const kindValue = requireString(object.kind, `${path}.kind`);
  if (!PROVIDER_KINDS.has(kindValue)) {
    throw new ConfigurationError("UNSUPPORTED_PROVIDER", `${path}.kind is not a supported provider`);
  }
  const kind = kindValue as ProviderKind;
  const packageId = requireAlias(object.packageId, `${path}.packageId`) as AdapterPackageId;
  const credentialEnv = parseCredentialEnvironment(object.credentialEnv, `${path}.credentialEnv`);
  const access = parseAccessApproval(object.access, `${path}.access`);
  const bootstrapPath = `${path}.bootstrap`;
  const bootstrap = requireObject(object.bootstrap, bootstrapPath);
  let binding: ProviderRuntimeBinding;
  if (kind === "git") {
    requireExactKeys(bootstrap, ["gitExecutable", "workspaces", "catalog"], ["gitExecutable", "workspaces", "catalog"], bootstrapPath);
    const gitExecutable = requireString(bootstrap.gitExecutable, `${bootstrapPath}.gitExecutable`);
    if (!isAbsolute(gitExecutable)) {
      throw new ConfigurationError("RELATIVE_GIT_EXECUTABLE", `${bootstrapPath}.gitExecutable must be administrator-pinned and absolute`);
    }
    binding = {
      kind,
      packageId,
      credentialEnv,
      access,
      bootstrap: {
        gitExecutable,
        workspaces: requireJsonObjectArray(bootstrap.workspaces, `${bootstrapPath}.workspaces`, 64),
        catalog: requireJsonObjectArray(bootstrap.catalog, `${bootstrapPath}.catalog`),
      },
    };
  } else if (kind === "alertmanager") {
    requireExactKeys(bootstrap, ["endpointIds", "catalog", "transport"], ["endpointIds", "catalog", "transport"], bootstrapPath);
    const endpointIds = requireStringArray(bootstrap.endpointIds, `${bootstrapPath}.endpointIds`, 16);
    if (endpointIds.length === 0) throw new ConfigurationError("EMPTY_SELECTION", `${bootstrapPath}.endpointIds cannot be empty`);
    binding = {
      kind,
      packageId,
      credentialEnv,
      access,
      bootstrap: {
        endpointIds,
        catalog: requireJsonObjectArray(bootstrap.catalog, `${bootstrapPath}.catalog`),
        transport: parseTransport(bootstrap.transport, `${bootstrapPath}.transport`),
      },
    };
  } else if (kind === "fixture") {
    requireExactKeys(bootstrap, [], [], bootstrapPath);
    binding = { kind, packageId, credentialEnv, access, bootstrap: {} };
  } else {
    requireExactKeys(bootstrap, ["endpointId", "catalog", "transport"], ["endpointId", "catalog", "transport"], bootstrapPath);
    binding = {
      kind,
      packageId,
      credentialEnv,
      access,
      bootstrap: {
        endpointId: requireAlias(bootstrap.endpointId, `${bootstrapPath}.endpointId`),
        catalog: parseCatalog(bootstrap.catalog, `${bootstrapPath}.catalog`),
        transport: parseTransport(bootstrap.transport, `${bootstrapPath}.transport`),
      },
    };
  }
  assertPackageAdmission(binding, bundle, admission, index);
  if (binding.kind === "alertmanager") {
    for (const [endpointIndex, endpointId] of binding.bootstrap.endpointIds.entries()) {
      assertEndpointAdmission(endpointId, binding.packageId, bundle, `${bootstrapPath}.endpointIds[${endpointIndex}]`);
    }
  } else if (binding.kind !== "git" && binding.kind !== "fixture") {
    assertEndpointAdmission(binding.bootstrap.endpointId, binding.packageId, bundle, `${bootstrapPath}.endpointId`);
  }
  assertOperationSourceBinding(binding, bundle, path);
  const expectedCredentials = expectedCredentialEnvironment(binding, bundle);
  const configuredCredentials = [...binding.credentialEnv].sort();
  if (JSON.stringify(configuredCredentials) !== JSON.stringify(expectedCredentials)) {
    throw new ConfigurationError(
      "CREDENTIAL_ENV_NOT_MINIMAL",
      `${path}.credentialEnv must exactly match credential references of kind env for this binding`,
    );
  }
  const requiredScopes = requiredProviderScopesForBinding(binding, bundle);
  const approvedScopes = [...binding.access.effectiveProviderScopes].sort();
  if (requiredScopes.some((scope) => !approvedScopes.includes(scope))) {
    throw new ConfigurationError(
      "SCOPE_APPROVAL_INCOMPLETE",
      `${path}.access is missing a required provider scope`,
    );
  }
  if (approvedScopes.some((scope) => !requiredScopes.includes(scope))) {
    throw new ConfigurationError(
      "OVER_SCOPED_IDENTITY",
      `${path}.access declares provider authority beyond the active operation ledger`,
    );
  }
  return binding;
}

/** Parse only administrator-owned runtime material read from a manifest-hashed trust root. */
export function parseProviderRuntimeConfiguration(
  text: string,
  bundle: Readonly<TrustBundle>,
): Readonly<ProviderRuntimeConfiguration> {
  const object = requireObject(parseStrictYaml(text, "provider runtime configuration"), "provider-runtime");
  requireExactKeys(
    object,
    ["schemaVersion", "metadata", "workerAdmission", "adapters"],
    ["schemaVersion", "metadata", "workerAdmission", "adapters"],
    "provider-runtime",
  );
  if (object.schemaVersion !== "1.0.0") {
    throw new ConfigurationError("UNSUPPORTED_VERSION", "provider-runtime.schemaVersion must be 1.0.0");
  }
  if (!Array.isArray(object.adapters) || object.adapters.length === 0 || object.adapters.length > 64) {
    throw new ConfigurationError("INVALID_ARRAY", "provider-runtime.adapters must contain one to 64 bindings");
  }
  const workerAdmission = parseWorkerAdmission(object.workerAdmission);
  const adapters = object.adapters.map((binding, index) => parseBinding(binding, index, bundle, workerAdmission));
  if (new Set(adapters.map((binding) => binding.packageId)).size !== adapters.length) {
    throw new ConfigurationError("DUPLICATE_ADAPTER", "provider-runtime.adapters contains a duplicate package binding");
  }
  return deepFreeze({
    schemaVersion: "1.0.0",
    metadata: parseMetadata(object.metadata),
    workerAdmission,
    adapters,
  });
}
