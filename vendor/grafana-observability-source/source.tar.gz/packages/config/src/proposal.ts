import type {
  CapabilityProfile,
  CapabilityPackId,
  EvidenceOrigin,
  OperationId,
} from "@codex-production-monitoring/contracts";

import {
  ConfigurationError,
  deepFreeze,
  parseStrictYaml,
  requireAlias,
  requireExactKeys,
  requireObject,
  requireStringArray,
} from "./validation.ts";

export interface MonitoringProposal {
  readonly schemaVersion: "1.0.0";
  readonly profileAlias: string;
  readonly requestedCapability?: CapabilityProfile;
  readonly requestedOrigins?: readonly EvidenceOrigin[];
  readonly requestedScopeAliases?: readonly string[];
  readonly requestedEndpointIds?: readonly string[];
  readonly requestedOperationIds?: readonly OperationId[];
  readonly requestedCapabilityPackIds?: readonly CapabilityPackId[];
}

const CAPABILITIES = new Set<CapabilityProfile>(["observe", "investigate", "prepare_patch"]);
const ORIGINS = new Set<EvidenceOrigin>(["LIVE", "REPLAY", "SIMULATED"]);

export function parseMonitoringProposal(text: string): Readonly<MonitoringProposal> {
  const object = requireObject(parseStrictYaml(text, "monitoring proposal"), "proposal");
  requireExactKeys(
    object,
    [
      "schemaVersion",
      "profileAlias",
      "requestedCapability",
      "requestedOrigins",
      "requestedScopeAliases",
      "requestedEndpointIds",
      "requestedOperationIds",
      "requestedCapabilityPackIds",
    ],
    ["schemaVersion", "profileAlias"],
    "proposal",
  );
  if (object.schemaVersion !== "1.0.0") {
    throw new ConfigurationError("UNSUPPORTED_VERSION", "proposal.schemaVersion must be 1.0.0");
  }

  const requestedCapability = object.requestedCapability;
  if (requestedCapability !== undefined && !CAPABILITIES.has(requestedCapability as CapabilityProfile)) {
    throw new ConfigurationError("INVALID_CAPABILITY", "proposal.requestedCapability is not supported");
  }

  const requestedOrigins = object.requestedOrigins === undefined
    ? undefined
    : requireStringArray(object.requestedOrigins, "proposal.requestedOrigins", 3).map((origin) => {
        if (!ORIGINS.has(origin as EvidenceOrigin)) {
          throw new ConfigurationError("INVALID_ORIGIN", `Unsupported evidence origin: ${origin}`);
        }
        return origin as EvidenceOrigin;
      });

  const proposal: MonitoringProposal = {
    schemaVersion: "1.0.0",
    profileAlias: requireAlias(object.profileAlias, "proposal.profileAlias"),
    ...(requestedCapability === undefined
      ? {}
      : { requestedCapability: requestedCapability as CapabilityProfile }),
    ...(requestedOrigins === undefined ? {} : { requestedOrigins }),
    ...(object.requestedScopeAliases === undefined
      ? {}
      : {
          requestedScopeAliases: requireStringArray(
            object.requestedScopeAliases,
            "proposal.requestedScopeAliases",
          ).map((alias, index) => requireAlias(alias, `proposal.requestedScopeAliases[${index}]`)),
        }),
    ...(object.requestedEndpointIds === undefined
      ? {}
      : {
          requestedEndpointIds: requireStringArray(
            object.requestedEndpointIds,
            "proposal.requestedEndpointIds",
          ).map((alias, index) => requireAlias(alias, `proposal.requestedEndpointIds[${index}]`)),
        }),
    ...(object.requestedOperationIds === undefined
      ? {}
      : {
          requestedOperationIds: requireStringArray(
            object.requestedOperationIds,
            "proposal.requestedOperationIds",
          ) as OperationId[],
        }),
    ...(object.requestedCapabilityPackIds === undefined
      ? {}
      : {
          requestedCapabilityPackIds: requireStringArray(
            object.requestedCapabilityPackIds,
            "proposal.requestedCapabilityPackIds",
            32,
          ) as CapabilityPackId[],
        }),
  };
  return deepFreeze(proposal);
}
