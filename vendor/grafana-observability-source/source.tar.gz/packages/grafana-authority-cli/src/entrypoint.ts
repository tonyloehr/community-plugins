import { executeGrafanaAuthorityCli } from "./main.ts";

executeGrafanaAuthorityCli(process.argv.slice(2)).then(
  (exitCode) => {
    process.exitCode = exitCode;
  },
  () => {
    process.stderr.write('{"schemaVersion":"1.0.0","status":"ERROR","code":"AUTHORITY_OPERATION_REJECTED"}\n');
    process.exitCode = 1;
  },
);
