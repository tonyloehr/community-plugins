export const GRAFANA_AUTHORITY_CLI_VERSION = "0.1.0" as const;

export const grafanaAuthorityCliHelp = `Grafana Observability authority administration

Usage:
  grafana-authorityctl trust-root validate --root <absolute-dir>
  grafana-authorityctl trust-root activate --root <absolute-dir> --receipt <absolute-file> --expected-root-manifest-sha256 <sha256> --expected-trust-bundle-sha256 <sha256> [--replace]
  grafana-authorityctl saved-panel enroll --input <absolute-json-file> --output <absolute-json-file>

The saved-panel command reads one bounded regular JSON file, compiles exactly one target A into a
hash-pinned catalog entry, and writes a no-clobber review proposal. It never contacts Grafana and
never activates the proposal. This CLI does not accept credentials, URLs, headers, or provider calls.
`;
