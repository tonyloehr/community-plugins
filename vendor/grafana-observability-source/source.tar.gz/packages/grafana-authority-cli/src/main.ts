import {
  closeSync,
  constants,
  fstatSync,
  fsyncSync,
  lstatSync,
  openSync,
  readSync,
  realpathSync,
  unlinkSync,
  writeFileSync,
  type Stats,
} from "node:fs";
import { basename, dirname, isAbsolute, resolve } from "node:path";

import {
  CompiledGrafanaCatalog,
  compileGrafanaSavedPanel,
  grafanaCatalogEntryHash,
  type GrafanaDatasourceQueryCatalogEntry,
  type GrafanaSavedPanelEnrollmentInput,
} from "@codex-production-monitoring/adapter-grafana";
import {
  activateTrustRoot,
  validateTrustRootForActivation,
  type ActivateTrustRootOptions,
  type ActivationReceipt,
  type ActivationSummary,
} from "@codex-production-monitoring/config";
import { canonicalJson, type Sha256 } from "@codex-production-monitoring/contracts";

import { GRAFANA_AUTHORITY_CLI_VERSION, grafanaAuthorityCliHelp } from "./help.ts";

const MAXIMUM_ENROLLMENT_BYTES = 1_310_720;
const SAFE_OUTPUT_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,180}$/u;
const SHA256 = /^[a-f0-9]{64}$/u;
const ENROLLMENT_KIND = "grafana-saved-panel-enrollment-v1" as const;
const PROPOSAL_KIND = "grafana-frozen-catalog-entry-v1" as const;

const REQUIRED_ENROLLMENT_KEYS = [
  "schemaVersion",
  "kind",
  "dashboard",
  "panelId",
  "id",
  "outputName",
  "datasourceIdentitySha256",
  "frame",
  "minIntervalMs",
  "scope",
  "scopeMappings",
] as const;
const OPTIONAL_ENROLLMENT_KEYS = ["postgresMaxRows", "postgresReadOnlyIdentity"] as const;

export interface GrafanaAuthorityCliIo {
  stdout(text: string): void;
  stderr(text: string): void;
}

export interface GrafanaAuthorityCliDependencies {
  io?: GrafanaAuthorityCliIo;
  now?: () => Date;
  validateRoot?: (rootPath: string) => ActivationSummary;
  activateRoot?: (options: ActivateTrustRootOptions) => ActivationReceipt;
  compileSavedPanel?: (
    input: Readonly<GrafanaSavedPanelEnrollmentInput>,
  ) => GrafanaDatasourceQueryCatalogEntry;
}

interface ParsedOptions {
  readonly values: ReadonlyMap<string, string>;
  readonly replace: boolean;
}

interface FrozenCatalogEntryProposal {
  schemaVersion: "1.0.0";
  kind: typeof PROPOSAL_KIND;
  activationPerformed: false;
  catalogEntrySha256: Sha256;
  catalogEntry: GrafanaDatasourceQueryCatalogEntry;
}

class CliUsageError extends Error {
  constructor() {
    super("Invalid arguments");
    this.name = "CliUsageError";
  }
}

const defaultIo: GrafanaAuthorityCliIo = {
  stdout: (text) => process.stdout.write(text),
  stderr: (text) => process.stderr.write(text),
};

function parseOptions(
  argv: readonly string[],
  allowedValues: ReadonlySet<string>,
  allowReplace = false,
): ParsedOptions {
  const values = new Map<string, string>();
  let replace = false;
  for (let index = 0; index < argv.length; index += 1) {
    const flag = argv[index]!;
    if (
      !flag.startsWith("--") ||
      flag.includes("=") ||
      /token|password|secret|credential|header|url/iu.test(flag)
    ) {
      throw new CliUsageError();
    }
    if (flag === "--replace") {
      if (!allowReplace || replace) throw new CliUsageError();
      replace = true;
      continue;
    }
    if (!allowedValues.has(flag) || values.has(flag)) throw new CliUsageError();
    const value = argv[index + 1];
    if (
      value === undefined ||
      value.length === 0 ||
      value.length > 4_096 ||
      value.startsWith("--") ||
      value.includes("\0")
    ) {
      throw new CliUsageError();
    }
    values.set(flag, value);
    index += 1;
  }
  return { values, replace };
}

function required(options: ParsedOptions, name: string): string {
  const value = options.values.get(name);
  if (value === undefined) throw new CliUsageError();
  return value;
}

function exactOptions(options: ParsedOptions, expectedCount: number): void {
  if (options.values.size !== expectedCount) throw new CliUsageError();
}

function absolutePath(value: string): string {
  if (!isAbsolute(value)) throw new CliUsageError();
  return resolve(value);
}

function reviewedSha256(value: string): Sha256 {
  if (!SHA256.test(value)) throw new CliUsageError();
  return value as Sha256;
}

function sameOpenedFile(before: Stats, opened: Stats): boolean {
  return opened.isFile() && opened.nlink === 1 && opened.dev === before.dev && opened.ino === before.ino;
}

function readBoundedRegularJson(pathInput: string): unknown {
  const path = absolutePath(pathInput);
  const before = lstatSync(path);
  if (
    before.isSymbolicLink() ||
    !before.isFile() ||
    before.nlink !== 1 ||
    before.size < 1 ||
    before.size > MAXIMUM_ENROLLMENT_BYTES ||
    realpathSync(path) !== path
  ) {
    throw new Error("Enrollment input rejected");
  }
  const noFollow = typeof constants.O_NOFOLLOW === "number" ? constants.O_NOFOLLOW : 0;
  let descriptor: number | undefined;
  try {
    descriptor = openSync(path, constants.O_RDONLY | noFollow);
    const opened = fstatSync(descriptor);
    if (!sameOpenedFile(before, opened)) throw new Error("Enrollment input rejected");
    const buffer = Buffer.allocUnsafe(MAXIMUM_ENROLLMENT_BYTES + 1);
    let length = 0;
    for (;;) {
      const read = readSync(descriptor, buffer, length, buffer.length - length, null);
      length += read;
      if (length > MAXIMUM_ENROLLMENT_BYTES) throw new Error("Enrollment input rejected");
      if (read === 0) break;
    }
    const after = fstatSync(descriptor);
    if (
      !sameOpenedFile(opened, after) ||
      after.size !== opened.size ||
      after.mtimeMs !== opened.mtimeMs ||
      length !== after.size
    ) {
      throw new Error("Enrollment input rejected");
    }
    try {
      return JSON.parse(buffer.subarray(0, length).toString("utf8")) as unknown;
    } catch {
      throw new Error("Enrollment input rejected");
    }
  } finally {
    if (descriptor !== undefined) closeSync(descriptor);
  }
}

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function enrollmentInput(value: unknown): GrafanaSavedPanelEnrollmentInput {
  if (!isObject(value)) throw new Error("Enrollment input rejected");
  const allowed = new Set<string>([...REQUIRED_ENROLLMENT_KEYS, ...OPTIONAL_ENROLLMENT_KEYS]);
  const keys = Object.keys(value);
  if (
    keys.some((key) => !allowed.has(key)) ||
    REQUIRED_ENROLLMENT_KEYS.some((key) => !Object.hasOwn(value, key)) ||
    value.schemaVersion !== "1.0.0" ||
    value.kind !== ENROLLMENT_KIND
  ) {
    throw new Error("Enrollment input rejected");
  }
  const input = { ...value };
  delete input.schemaVersion;
  delete input.kind;
  return input as unknown as GrafanaSavedPanelEnrollmentInput;
}

function safeOutputTarget(pathInput: string): string {
  const path = absolutePath(pathInput);
  if (!SAFE_OUTPUT_NAME.test(basename(path))) throw new CliUsageError();
  const parent = dirname(path);
  const stat = lstatSync(parent);
  if (stat.isSymbolicLink() || !stat.isDirectory() || realpathSync(parent) !== parent) {
    throw new Error("Enrollment output rejected");
  }
  return path;
}

function writeNoClobber(pathInput: string, value: unknown): string {
  const path = safeOutputTarget(pathInput);
  const content = `${canonicalJson(value)}\n`;
  const noFollow = typeof constants.O_NOFOLLOW === "number" ? constants.O_NOFOLLOW : 0;
  let descriptor: number | undefined;
  let created = false;
  let createdIdentity: Pick<Stats, "dev" | "ino"> | undefined;
  try {
    descriptor = openSync(
      path,
      constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | noFollow,
      0o600,
    );
    created = true;
    const opened = fstatSync(descriptor);
    if (!opened.isFile() || opened.nlink !== 1) throw new Error("Enrollment output rejected");
    createdIdentity = { dev: opened.dev, ino: opened.ino };
    writeFileSync(descriptor, content, { encoding: "utf8" });
    fsyncSync(descriptor);
    const stat = fstatSync(descriptor);
    if (!stat.isFile() || stat.nlink !== 1 || (stat.mode & 0o077) !== 0) {
      throw new Error("Enrollment output rejected");
    }
    closeSync(descriptor);
    descriptor = undefined;
    return path;
  } catch (error) {
    if (descriptor !== undefined) {
      closeSync(descriptor);
      descriptor = undefined;
    }
    if (created && createdIdentity !== undefined) {
      const current = lstatSync(path);
      if (current.dev === createdIdentity.dev && current.ino === createdIdentity.ino) unlinkSync(path);
    }
    throw error;
  }
}

function line(io: GrafanaAuthorityCliIo, value: unknown): void {
  io.stdout(`${canonicalJson(value)}\n`);
}

function safeErrorCode(error: unknown): string {
  if (error instanceof CliUsageError) return "INVALID_ARGUMENTS";
  return "AUTHORITY_OPERATION_REJECTED";
}

export async function executeGrafanaAuthorityCli(
  argv: readonly string[],
  dependencies: GrafanaAuthorityCliDependencies = {},
): Promise<number> {
  const io = dependencies.io ?? defaultIo;
  const now = dependencies.now ?? (() => new Date());
  const validateRoot = dependencies.validateRoot ?? validateTrustRootForActivation;
  const activateRoot = dependencies.activateRoot ?? activateTrustRoot;
  const compileSavedPanel = dependencies.compileSavedPanel ?? compileGrafanaSavedPanel;
  try {
    if (argv.length === 1 && (argv[0] === "--help" || argv[0] === "help")) {
      io.stdout(grafanaAuthorityCliHelp);
      return 0;
    }
    if (argv.length === 1 && (argv[0] === "--version" || argv[0] === "version")) {
      io.stdout(`${GRAFANA_AUTHORITY_CLI_VERSION}\n`);
      return 0;
    }
    const [command, subcommand, ...rest] = argv;
    if (command === "trust-root" && subcommand === "validate") {
      const options = parseOptions(rest, new Set(["--root"]));
      exactOptions(options, 1);
      const result = validateRoot(absolutePath(required(options, "--root")));
      line(io, { ...result, activationPerformed: false });
      return 0;
    }
    if (command === "trust-root" && subcommand === "activate") {
      const options = parseOptions(rest, new Set([
        "--root",
        "--receipt",
        "--expected-root-manifest-sha256",
        "--expected-trust-bundle-sha256",
      ]), true);
      exactOptions(options, 4);
      const receiptPath = absolutePath(required(options, "--receipt"));
      const result = activateRoot({
        trustRootPath: absolutePath(required(options, "--root")),
        receiptPath,
        expectedRootManifestSha256: reviewedSha256(required(options, "--expected-root-manifest-sha256")),
        expectedTrustBundleSha256: reviewedSha256(required(options, "--expected-trust-bundle-sha256")),
        activatedAt: now().toISOString(),
        replace: options.replace,
      });
      line(io, {
        schemaVersion: result.schemaVersion,
        mode: "ACTIVATED",
        activationPerformed: true,
        activatedAt: result.activatedAt,
        trustRootPath: result.trustRootPath,
        rootManifestSha256: result.rootManifestSha256,
        trustBundleSha256: result.trustBundleSha256,
        providerRuntimeSha256: result.providerRuntimeSha256,
        receiptPath,
      });
      return 0;
    }
    if (command === "saved-panel" && subcommand === "enroll") {
      const options = parseOptions(rest, new Set(["--input", "--output"]));
      exactOptions(options, 2);
      const inputPath = absolutePath(required(options, "--input"));
      const outputPath = absolutePath(required(options, "--output"));
      if (inputPath === outputPath) throw new CliUsageError();
      const entry = compileSavedPanel(enrollmentInput(readBoundedRegularJson(inputPath)));
      const catalogEntrySha256 = grafanaCatalogEntryHash(entry);
      const catalog = new CompiledGrafanaCatalog({ entries: [entry] });
      const frozenEntry = catalog.resolve(entry.id, catalogEntrySha256) as GrafanaDatasourceQueryCatalogEntry;
      const proposal: FrozenCatalogEntryProposal = {
        schemaVersion: "1.0.0",
        kind: PROPOSAL_KIND,
        activationPerformed: false,
        catalogEntrySha256,
        catalogEntry: frozenEntry,
      };
      const writtenPath = writeNoClobber(outputPath, proposal);
      line(io, {
        schemaVersion: "1.0.0",
        mode: "ENROLLMENT_PROPOSAL_WRITTEN",
        activationPerformed: false,
        catalogEntryId: frozenEntry.id,
        catalogEntrySha256,
        outputPath: writtenPath,
      });
      return 0;
    }
    throw new CliUsageError();
  } catch (error) {
    line({ stdout: io.stderr, stderr: io.stderr }, {
      schemaVersion: "1.0.0",
      status: "ERROR",
      code: safeErrorCode(error),
    });
    return error instanceof CliUsageError ? 2 : 1;
  }
}
