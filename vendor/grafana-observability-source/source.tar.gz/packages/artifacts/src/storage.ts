import { randomUUID } from "node:crypto";
import {
  chmodSync,
  closeSync,
  constants,
  existsSync,
  fsyncSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmdirSync,
  statSync,
  unlinkSync,
  writeFileSync,
  type Stats,
} from "node:fs";
import {
  basename,
  dirname,
  isAbsolute,
  relative,
  resolve,
  sep,
} from "node:path";

import {
  canonicalJson,
  computeBundleHash,
  sha256Bytes,
  verifyBundleHash,
  verifyIntegrity,
  type BundleId,
  type BundleManifest,
  type ContradictionRecord,
  type Coverage,
  type EvidenceEnvelope,
  type Investigation,
  type JsonValue,
  type ManifestEntry,
  type OperationSnapshot,
  type RunId,
  type Sha256,
  type TrustedProfile,
  type WorkflowRequest,
} from "../../contracts/src/index.ts";

import {
  asBundleId,
  asRunId,
  assertManifestIdentity,
  assertParentVerificationContract,
  prepareArtifacts,
  validatePreparedArtifacts,
  type PreparedArtifacts,
} from "./model.ts";
import { assertSchema } from "./schema.ts";
import type {
  ArtifactProducer,
  ArtifactRootDeletionReceipt,
  ArtifactStoreOptions,
  FinalizationResult,
  FinalizeBundleInput,
  InvestigationDraft,
  ValidatedBundle,
} from "./types.ts";

const ROOT_MARKER = ".production-monitoring-owned.json";
const STAGE_MARKER = ".production-monitoring-stage.json";
const SEAL_LOCK = ".seal.lock";
const BUNDLES_DIRECTORY = "bundles";
const MANIFEST_PATH = "manifest.json";
const MANIFEST_DIGEST_PATH = "manifest.sha256";
const MAX_JSON_BYTES = 64 * 1024 * 1024;
const ROOT_MAGIC = "codex-production-monitoring-artifact-root";
const STAGE_MAGIC = "codex-production-monitoring-artifact-stage";
const STAGE_RECEIPT_MAGIC = "codex-production-monitoring-artifact-stage-receipt";
const SEAL_LOCK_MAGIC = "codex-production-monitoring-artifact-seal-lock";
const INTERNAL_RECEIPT_BYTES = 16 * 1024;
const UUID_PATTERN = /^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/u;
const INTERNAL_INTEGER_PATTERN = /^(?:0|[1-9][0-9]{0,39})$/u;
const STAGE_NAME_PATTERN = /^(?:\.stage-)(pmbundle_[A-Za-z0-9_-]{20,128})-([a-f0-9-]{36})$/u;
const STAGE_RECEIPT_NAME_PATTERN = /^\.stage-receipt-([a-f0-9-]{36})\.json$/u;
const TEST_CRASH_ENV = "PM_ARTIFACT_TEST_CRASH_POINT";
const TEST_CRASH_TOKEN_ENV = "PM_ARTIFACT_TEST_CRASH_TOKEN";
const TEST_CRASH_TOKEN = "artifact-crash-recovery-v1";

interface RootMarker {
  magic: typeof ROOT_MAGIC;
  version: 1;
  rootId: string;
  rootPath: string;
}

interface StageMarker {
  magic: typeof STAGE_MAGIC;
  version: 1;
  rootId: string;
  rootPath: string;
  bundlesDevice: string;
  bundlesInode: string;
  lockNonce: string;
  stageNonce: string;
  stageName: string;
  receiptName: string;
  bundleId: BundleId;
  runId: RunId;
  createdAt: string;
}

interface StageReceipt {
  magic: typeof STAGE_RECEIPT_MAGIC;
  version: 1;
  rootId: string;
  rootPath: string;
  bundlesDevice: string;
  bundlesInode: string;
  lockNonce: string;
  stageNonce: string;
  stageName: string;
  receiptName: string;
  bundleId: BundleId;
  runId: RunId;
  createdAt: string;
}

interface SealLockReceipt {
  magic: typeof SEAL_LOCK_MAGIC;
  version: 1;
  rootId: string;
  rootPath: string;
  bundlesDevice: string;
  bundlesInode: string;
  pid: number;
  nonce: string;
  acquiredAt: string;
}

interface RootContext {
  path: string;
  device: bigint;
  marker: RootMarker;
}

interface OwnedPathIdentity {
  path: string;
  kind: "file" | "directory";
  device: bigint;
  inode: bigint;
}

interface ArtifactRootDeletionInventory {
  marker: OwnedPathIdentity;
  bundles: OwnedPathIdentity;
  bundleFiles: OwnedPathIdentity[];
  bundleDirectories: OwnedPathIdentity[];
}

interface FileSpec {
  path: string;
  role: ManifestEntry["role"];
  mediaType: string;
  content: string;
}

interface ValidationOptions {
  expectedBundleId?: BundleId;
  allowStageMarker?: boolean;
}

interface OwnedReceipt<T> {
  value: T;
  content: string;
  identity: OwnedPathIdentity;
}

interface StageInventory {
  root: OwnedPathIdentity;
  files: OwnedPathIdentity[];
  directories: OwnedPathIdentity[];
}

interface AcquiredSealLock {
  path: string;
  receipt: SealLockReceipt;
  identity: OwnedPathIdentity;
}

const DEFAULT_PRODUCER: ArtifactProducer = {
  pluginVersion: "0.3.0",
  contractsVersion: "0.3.0",
  reportProjectionVersion: "1.1.0",
};

function currentUid(): number | undefined {
  return typeof process.getuid === "function" ? process.getuid() : undefined;
}

function statDevice(stat: Stats): bigint {
  return BigInt(stat.dev);
}

function assertOwned(stat: Stats, label: string): void {
  const uid = currentUid();
  if (uid !== undefined && stat.uid !== uid) throw new Error(`${label} is not owned by this user`);
}

function assertPrivateMode(stat: Stats, label: string): void {
  if ((stat.mode & 0o077) !== 0) throw new Error(`${label} grants group or other permissions`);
}

function assertDirectory(stat: Stats, label: string): void {
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error(`${label} is not a real directory`);
}

function assertRegularFile(stat: Stats, label: string): void {
  if (!stat.isFile() || stat.isSymbolicLink()) throw new Error(`${label} is not a regular file`);
  if (stat.nlink !== 1) throw new Error(`${label} has multiple hard links`);
}

function ensureContained(root: string, candidate: string): void {
  const pathFromRoot = relative(root, candidate);
  if (pathFromRoot === ".." || pathFromRoot.startsWith(`..${sep}`) || isAbsolute(pathFromRoot)) {
    throw new Error(`Path escapes the artifact root: ${candidate}`);
  }
}

function assertPortablePath(path: string): void {
  if (
    path.length === 0 ||
    path.length > 1024 ||
    path.startsWith("/") ||
    path.includes("\\") ||
    path.split("/").includes("..") ||
    !/^[A-Za-z0-9._/-]+$/u.test(path)
  ) {
    throw new Error(`Unsafe artifact path: ${path}`);
  }
}

function writeExclusive(path: string, content: string, mode = 0o600): void {
  const noFollow = constants.O_NOFOLLOW ?? 0;
  const descriptor = openSync(
    path,
    constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | noFollow,
    mode,
  );
  try {
    writeFileSync(descriptor, content, "utf8");
    fsyncSync(descriptor);
  } finally {
    closeSync(descriptor);
  }
  const stat = lstatSync(path, { bigint: false });
  assertRegularFile(stat, path);
  assertOwned(stat, path);
  assertPrivateMode(stat, path);
}

function canonicalDocument(value: unknown): string {
  return canonicalJson(value);
}

function parseJson<T>(content: string, label: string): T {
  try {
    return JSON.parse(content) as T;
  } catch (error) {
    throw new TypeError(`${label} is not valid JSON: ${String(error)}`);
  }
}

function readSecureFile(path: string, device: bigint, maxBytes = MAX_JSON_BYTES): string {
  const stat = lstatSync(path, { bigint: false });
  assertRegularFile(stat, path);
  assertOwned(stat, path);
  assertPrivateMode(stat, path);
  if (statDevice(stat) !== device) throw new Error(`${path} crosses a filesystem device boundary`);
  if (stat.size > maxBytes) throw new Error(`${path} exceeds the artifact size limit`);
  return readFileSync(path, "utf8");
}

function readCanonicalJson<T>(path: string, device: bigint): T {
  const content = readSecureFile(path, device);
  const value = parseJson<T>(content, path);
  if (content !== canonicalDocument(value)) throw new Error(`${path} is not canonical RFC 8785 JSON`);
  return value;
}

function createDirectory(path: string, device: bigint): void {
  mkdirSync(path, { mode: 0o700 });
  const stat = lstatSync(path, { bigint: false });
  assertDirectory(stat, path);
  assertOwned(stat, path);
  assertPrivateMode(stat, path);
  if (statDevice(stat) !== device) throw new Error(`${path} crosses a filesystem device boundary`);
}

function validateRootMarker(rootPath: string, device: bigint): RootMarker {
  const markerPath = resolve(rootPath, ROOT_MARKER);
  const marker = readCanonicalJson<RootMarker>(markerPath, device);
  if (
    marker.magic !== ROOT_MAGIC ||
    marker.version !== 1 ||
    typeof marker.rootId !== "string" ||
    !/^[a-f0-9-]{36}$/u.test(marker.rootId) ||
    marker.rootPath !== rootPath
  ) {
    throw new Error("Artifact root ownership marker is invalid or belongs elsewhere");
  }
  return marker;
}

function openOrCreateRoot(requestedRoot: string): RootContext {
  if (!isAbsolute(requestedRoot)) throw new Error("Artifact root must be an absolute path");
  const requestedPath = resolve(requestedRoot);
  const existed = existsSync(requestedPath);
  if (!existed) {
    const parent = dirname(requestedPath);
    const parentStat = lstatSync(parent, { bigint: false });
    assertDirectory(parentStat, "Artifact root parent");
    mkdirSync(requestedPath, { mode: 0o700 });
  }

  const rootStat = lstatSync(requestedPath, { bigint: false });
  assertDirectory(rootStat, "Artifact root");
  assertOwned(rootStat, "Artifact root");
  assertPrivateMode(rootStat, "Artifact root");
  // Canonicalize trusted ancestor aliases (for example macOS /var -> /private/var)
  // after proving that the root entry itself is not a symlink.
  const rootPath = realpathSync.native(requestedPath);
  const device = statDevice(rootStat);

  let marker: RootMarker;
  if (existed) {
    if (!existsSync(resolve(rootPath, ROOT_MARKER))) {
      throw new Error("Refusing to claim an existing unmarked artifact root");
    }
    marker = validateRootMarker(rootPath, device);
  } else {
    marker = {
      magic: ROOT_MAGIC,
      version: 1,
      rootId: randomUUID(),
      rootPath,
    };
    writeExclusive(resolve(rootPath, ROOT_MARKER), canonicalDocument(marker));
  }

  const bundlesPath = resolve(rootPath, BUNDLES_DIRECTORY);
  if (!existsSync(bundlesPath)) createDirectory(bundlesPath, device);
  const bundlesStat = lstatSync(bundlesPath, { bigint: false });
  assertDirectory(bundlesStat, "Artifact bundles directory");
  assertOwned(bundlesStat, "Artifact bundles directory");
  assertPrivateMode(bundlesStat, "Artifact bundles directory");
  if (statDevice(bundlesStat) !== device) throw new Error("Bundles directory crosses devices");
  return { path: rootPath, device, marker };
}

function assertSecureTree(root: string, device: bigint): void {
  ensureContained(root, root);
  const rootStat = lstatSync(root, { bigint: false });
  assertDirectory(rootStat, root);
  assertOwned(rootStat, root);
  assertPrivateMode(rootStat, root);
  if (statDevice(rootStat) !== device) throw new Error(`${root} crosses a filesystem device boundary`);
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    const path = resolve(root, entry.name);
    ensureContained(root, path);
    const stat = lstatSync(path, { bigint: false });
    if (stat.isSymbolicLink()) throw new Error(`${path} is a symbolic link`);
    assertOwned(stat, path);
    assertPrivateMode(stat, path);
    if (statDevice(stat) !== device) throw new Error(`${path} crosses a filesystem device boundary`);
    if (stat.isDirectory()) assertSecureTree(path, device);
    else assertRegularFile(stat, path);
  }
}

function ownedPathIdentity(path: string, kind: OwnedPathIdentity["kind"], device: bigint): OwnedPathIdentity {
  const stat = lstatSync(path, { bigint: false });
  if (kind === "directory") assertDirectory(stat, path);
  else assertRegularFile(stat, path);
  assertOwned(stat, path);
  assertPrivateMode(stat, path);
  if (statDevice(stat) !== device) throw new Error(`${path} crosses a filesystem device boundary`);
  return { path, kind, device, inode: BigInt(stat.ino) };
}

function assertSameOwnedPath(identity: OwnedPathIdentity): void {
  const current = ownedPathIdentity(identity.path, identity.kind, identity.device);
  if (current.inode !== identity.inode) {
    throw new Error(`Refusing to delete a replaced artifact path: ${identity.path}`);
  }
}

function isErrnoException(error: unknown, code: string): boolean {
  return error instanceof Error && "code" in error && error.code === code;
}

function assertExactKeys(value: object, expected: readonly string[], label: string): void {
  const actual = Object.keys(value).sort();
  if (canonicalJson(actual) !== canonicalJson([...expected].sort())) {
    throw new Error(`${label} contains unknown or missing fields`);
  }
}

function assertCanonicalTimestamp(value: unknown, label: string): asserts value is string {
  if (
    typeof value !== "string" ||
    value.length < 20 ||
    value.length > 32 ||
    Number.isNaN(Date.parse(value)) ||
    new Date(value).toISOString() !== value
  ) {
    throw new Error(`${label} is not a bounded canonical timestamp`);
  }
}

function assertUuid(value: unknown, label: string): asserts value is string {
  if (typeof value !== "string" || !UUID_PATTERN.test(value)) {
    throw new Error(`${label} is not a canonical UUID`);
  }
}

function assertInternalInteger(value: unknown, label: string): asserts value is string {
  if (typeof value !== "string" || !INTERNAL_INTEGER_PATTERN.test(value)) {
    throw new Error(`${label} is not a bounded filesystem identity`);
  }
}

function fsyncDirectory(path: string): void {
  const descriptor = openSync(path, constants.O_RDONLY);
  try {
    fsyncSync(descriptor);
  } finally {
    closeSync(descriptor);
  }
}

function readCanonicalOwnedReceipt<T>(
  path: string,
  device: bigint,
  label: string,
): OwnedReceipt<T> {
  const identity = ownedPathIdentity(path, "file", device);
  const content = readSecureFile(path, device, INTERNAL_RECEIPT_BYTES);
  assertSameOwnedPath(identity);
  const value = parseJson<T>(content, label);
  if (content !== canonicalDocument(value)) throw new Error(`${label} is not canonical RFC 8785 JSON`);
  return { value, content, identity };
}

function bundlesIdentity(root: RootContext): OwnedPathIdentity {
  return ownedPathIdentity(resolve(root.path, BUNDLES_DIRECTORY), "directory", root.device);
}

function rootIdentityFields(root: RootContext): {
  rootId: string;
  rootPath: string;
  bundlesDevice: string;
  bundlesInode: string;
} {
  const bundles = bundlesIdentity(root);
  return {
    rootId: root.marker.rootId,
    rootPath: root.path,
    bundlesDevice: bundles.device.toString(),
    bundlesInode: bundles.inode.toString(),
  };
}

function assertReceiptRootIdentity(
  value: {
    rootId?: unknown;
    rootPath?: unknown;
    bundlesDevice?: unknown;
    bundlesInode?: unknown;
  },
  root: RootContext,
  label: string,
): void {
  assertInternalInteger(value.bundlesDevice, `${label} bundlesDevice`);
  assertInternalInteger(value.bundlesInode, `${label} bundlesInode`);
  const expected = rootIdentityFields(root);
  if (
    value.rootId !== expected.rootId ||
    value.rootPath !== expected.rootPath ||
    value.bundlesDevice !== expected.bundlesDevice ||
    value.bundlesInode !== expected.bundlesInode
  ) {
    throw new Error(`${label} belongs to a different artifact root`);
  }
}

function stageCoordinates(stageName: string): { bundleId: BundleId; stageNonce: string } {
  const match = STAGE_NAME_PATTERN.exec(stageName);
  if (match === null) throw new Error(`Invalid internal staging directory name: ${stageName}`);
  const bundleId = asBundleId(match[1]!);
  const stageNonce = match[2]!;
  assertUuid(stageNonce, "Stage name nonce");
  return { bundleId, stageNonce };
}

function receiptNonce(receiptName: string): string {
  const match = STAGE_RECEIPT_NAME_PATTERN.exec(receiptName);
  if (match === null) throw new Error(`Invalid internal staging receipt name: ${receiptName}`);
  const nonce = match[1]!;
  assertUuid(nonce, "Stage receipt name nonce");
  return nonce;
}

function assertStageOwnership(
  value: StageMarker | StageReceipt,
  root: RootContext,
  lock: SealLockReceipt,
  label: string,
): void {
  assertReceiptRootIdentity(value, root, label);
  assertUuid(value.lockNonce, `${label} lock nonce`);
  assertUuid(value.stageNonce, `${label} stage nonce`);
  assertCanonicalTimestamp(value.createdAt, `${label} createdAt`);
  const coordinates = stageCoordinates(value.stageName);
  const receiptStageNonce = receiptNonce(value.receiptName);
  const bundleId = asBundleId(value.bundleId);
  const runId = asRunId(value.runId);
  if (
    value.lockNonce !== lock.nonce ||
    coordinates.bundleId !== bundleId ||
    coordinates.stageNonce !== value.stageNonce ||
    receiptStageNonce !== value.stageNonce ||
    runId !== value.runId
  ) {
    throw new Error(`${label} identity fields do not agree`);
  }
}

function readSealLock(path: string, root: RootContext): OwnedReceipt<SealLockReceipt> {
  const receipt = readCanonicalOwnedReceipt<SealLockReceipt>(path, root.device, "Artifact seal lock");
  assertExactKeys(receipt.value, [
    "magic",
    "version",
    "rootId",
    "rootPath",
    "bundlesDevice",
    "bundlesInode",
    "pid",
    "nonce",
    "acquiredAt",
  ], "Artifact seal lock");
  if (receipt.value.magic !== SEAL_LOCK_MAGIC || receipt.value.version !== 1) {
    throw new Error("Artifact seal lock has an unsupported identity");
  }
  assertReceiptRootIdentity(receipt.value, root, "Artifact seal lock");
  if (
    !Number.isSafeInteger(receipt.value.pid) ||
    receipt.value.pid <= 0 ||
    receipt.value.pid > 0x7fffffff
  ) {
    throw new Error("Artifact seal lock PID is invalid");
  }
  assertUuid(receipt.value.nonce, "Artifact seal lock nonce");
  assertCanonicalTimestamp(receipt.value.acquiredAt, "Artifact seal lock acquiredAt");
  return receipt;
}

function readStageReceipt(
  path: string,
  root: RootContext,
  lock: SealLockReceipt,
): OwnedReceipt<StageReceipt> {
  const receipt = readCanonicalOwnedReceipt<StageReceipt>(path, root.device, "Artifact stage receipt");
  assertExactKeys(receipt.value, [
    "magic",
    "version",
    "rootId",
    "rootPath",
    "bundlesDevice",
    "bundlesInode",
    "lockNonce",
    "stageNonce",
    "stageName",
    "receiptName",
    "bundleId",
    "runId",
    "createdAt",
  ], "Artifact stage receipt");
  if (receipt.value.magic !== STAGE_RECEIPT_MAGIC || receipt.value.version !== 1) {
    throw new Error("Artifact stage receipt has an unsupported identity");
  }
  assertStageOwnership(receipt.value, root, lock, "Artifact stage receipt");
  if (basename(path) !== receipt.value.receiptName) {
    throw new Error("Artifact stage receipt path does not match its identity");
  }
  return receipt;
}

function readStageMarker(
  path: string,
  root: RootContext,
  lock: SealLockReceipt,
): OwnedReceipt<StageMarker> {
  const marker = readCanonicalOwnedReceipt<StageMarker>(path, root.device, "Artifact stage marker");
  assertExactKeys(marker.value, [
    "magic",
    "version",
    "rootId",
    "rootPath",
    "bundlesDevice",
    "bundlesInode",
    "lockNonce",
    "stageNonce",
    "stageName",
    "receiptName",
    "bundleId",
    "runId",
    "createdAt",
  ], "Artifact stage marker");
  if (marker.value.magic !== STAGE_MAGIC || marker.value.version !== 1) {
    throw new Error("Artifact stage marker has an unsupported identity");
  }
  assertStageOwnership(marker.value, root, lock, "Artifact stage marker");
  if (dirname(path) === path || basename(dirname(path)) !== marker.value.stageName) {
    throw new Error("Artifact stage marker path does not match its identity");
  }
  return marker;
}

function stageOwnershipFields(value: StageMarker | StageReceipt): object {
  return {
    version: value.version,
    rootId: value.rootId,
    rootPath: value.rootPath,
    bundlesDevice: value.bundlesDevice,
    bundlesInode: value.bundlesInode,
    lockNonce: value.lockNonce,
    stageNonce: value.stageNonce,
    stageName: value.stageName,
    receiptName: value.receiptName,
    bundleId: value.bundleId,
    runId: value.runId,
    createdAt: value.createdAt,
  };
}

function maybeCrashForTest(
  point: "LOCK_ONLY" | "MARKED_STAGE" | "PRE_RENAME" | "POST_RENAME",
): void {
  if (
    process.env.NODE_ENV === "test" &&
    basename(process.argv[1] ?? "") === "crash-seal-child.ts" &&
    process.env[TEST_CRASH_TOKEN_ENV] === TEST_CRASH_TOKEN &&
    process.env[TEST_CRASH_ENV] === point
  ) {
    process.kill(process.pid, "SIGKILL");
    throw new Error(`Test crash failpoint did not terminate at ${point}`);
  }
}

function collectRelativeTree(root: string): { files: string[]; directories: string[] } {
  const files: string[] = [];
  const directories: string[] = [];
  const visit = (directory: string): void => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = resolve(directory, entry.name);
      const relativePath = relative(root, path).split(sep).join("/");
      if (entry.isDirectory()) {
        directories.push(relativePath);
        visit(path);
      } else {
        files.push(relativePath);
      }
    }
  };
  visit(root);
  return { files: files.sort(), directories: directories.sort() };
}

function immutableTree(root: string): void {
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    const path = resolve(root, entry.name);
    if (entry.isDirectory()) immutableTree(path);
    else chmodSync(path, 0o400);
  }
  chmodSync(root, 0o500);
}

function semanticFileSpecs(prepared: PreparedArtifacts): FileSpec[] {
  const specs: FileSpec[] = [
    {
      path: "request.json",
      role: "RUN",
      mediaType: "application/json",
      content: canonicalDocument(prepared.request),
    },
    {
      path: "profile.json",
      role: "PROFILE",
      mediaType: "application/json",
      content: canonicalDocument(prepared.profile),
    },
    {
      path: "operations.json",
      role: "OPERATIONS",
      mediaType: "application/json",
      content: canonicalDocument(prepared.operations),
    },
    {
      path: "investigation.json",
      role: "INVESTIGATION",
      mediaType: "application/json",
      content: canonicalDocument(prepared.investigation),
    },
    {
      path: "coverage.json",
      role: "COVERAGE",
      mediaType: "application/json",
      content: canonicalDocument(prepared.coverage),
    },
  ];
  for (const evidence of prepared.evidence) {
    specs.push({
      path: `evidence/${evidence.evidenceId}.json`,
      role: "EVIDENCE",
      mediaType: "application/json",
      content: canonicalDocument(evidence),
    });
  }
  for (const contradiction of prepared.contradictions) {
    specs.push({
      path: `contradictions/${contradiction.contradictionId}.json`,
      role: "CONTRADICTIONS",
      mediaType: "application/json",
      content: canonicalDocument(contradiction),
    });
  }
  return specs.sort((left, right) => left.path.localeCompare(right.path));
}

function artifactRootDeletionInventory(root: RootContext): ArtifactRootDeletionInventory {
  const rootEntries = readdirSync(root.path, { withFileTypes: true });
  const expectedRootEntries = [BUNDLES_DIRECTORY, ROOT_MARKER].sort();
  const actualRootEntries = rootEntries.map((entry) => entry.name).sort();
  if (canonicalJson(actualRootEntries) !== canonicalJson(expectedRootEntries)) {
    const unknown = actualRootEntries.find((entry) => !expectedRootEntries.includes(entry));
    throw new Error(`Artifact root contains unknown or unreceipted entry: ${unknown ?? "missing owned entry"}`);
  }

  const marker = ownedPathIdentity(resolve(root.path, ROOT_MARKER), "file", root.device);
  const bundlesPath = resolve(root.path, BUNDLES_DIRECTORY);
  const bundles = ownedPathIdentity(bundlesPath, "directory", root.device);
  const bundleFiles: OwnedPathIdentity[] = [];
  const bundleDirectories: OwnedPathIdentity[] = [];

  for (const entry of readdirSync(bundlesPath, { withFileTypes: true })) {
    if (entry.name === ".seal.lock") {
      throw new Error("Refusing to delete an artifact root while a seal is active");
    }
    if (!entry.isDirectory()) {
      throw new Error(`Artifact bundles directory contains unknown or unreceipted entry: ${entry.name}`);
    }

    let bundleId: BundleId;
    try {
      bundleId = asBundleId(entry.name);
    } catch {
      throw new Error(`Artifact bundles directory contains unknown or unreceipted entry: ${entry.name}`);
    }
    const bundlePath = resolve(bundlesPath, entry.name);
    validateBundleDeletionReceipt(bundlePath, root, bundleId);
    const tree = collectRelativeTree(bundlePath);
    for (const file of tree.files) {
      bundleFiles.push(ownedPathIdentity(resolve(bundlePath, file), "file", root.device));
    }
    for (const directory of tree.directories) {
      bundleDirectories.push(ownedPathIdentity(resolve(bundlePath, directory), "directory", root.device));
    }
    bundleDirectories.push(ownedPathIdentity(bundlePath, "directory", root.device));
  }

  return { marker, bundles, bundleFiles, bundleDirectories };
}

function pathDepth(path: string): number {
  return path.split(sep).length;
}

function deleteEnumeratedArtifactRoot(root: RootContext, inventory: ArtifactRootDeletionInventory): void {
  const directories = [...inventory.bundleDirectories].sort((left, right) =>
    pathDepth(left.path) - pathDepth(right.path) || left.path.localeCompare(right.path)
  );
  for (const directory of directories) {
    assertSameOwnedPath(directory);
    chmodSync(directory.path, 0o700);
  }

  // Re-inventory after making sealed directories writable. Private permission
  // changes preserve identity, while an added or replaced path aborts before
  // any artifact file is removed.
  const confirmed = artifactRootDeletionInventory(root);
  const expectedIdentities = [
    inventory.marker,
    inventory.bundles,
    ...inventory.bundleFiles,
    ...inventory.bundleDirectories,
  ].map((entry) => `${entry.kind}:${entry.path}:${entry.device}:${entry.inode}`).sort();
  const confirmedIdentities = [
    confirmed.marker,
    confirmed.bundles,
    ...confirmed.bundleFiles,
    ...confirmed.bundleDirectories,
  ].map((entry) => `${entry.kind}:${entry.path}:${entry.device}:${entry.inode}`).sort();
  if (canonicalJson(confirmedIdentities) !== canonicalJson(expectedIdentities)) {
    throw new Error("Refusing to delete an artifact tree that changed during validation");
  }

  for (const file of confirmed.bundleFiles) {
    assertSameOwnedPath(file);
    unlinkSync(file.path);
  }
  for (const directory of [...confirmed.bundleDirectories].sort((left, right) =>
    pathDepth(right.path) - pathDepth(left.path) || right.path.localeCompare(left.path)
  )) {
    assertSameOwnedPath(directory);
    rmdirSync(directory.path);
  }

  assertSameOwnedPath(confirmed.bundles);
  rmdirSync(confirmed.bundles.path);
  const remaining = readdirSync(root.path).sort();
  if (canonicalJson(remaining) !== canonicalJson([ROOT_MARKER])) {
    throw new Error("Refusing to remove an artifact root that gained an unknown entry");
  }
  assertSameOwnedPath(confirmed.marker);
  unlinkSync(confirmed.marker.path);
  rmdirSync(root.path);
}

function writePreparedFiles(stagePath: string, device: bigint, prepared: PreparedArtifacts): ManifestEntry[] {
  createDirectory(resolve(stagePath, "evidence"), device);
  createDirectory(resolve(stagePath, "contradictions"), device);
  const entries: ManifestEntry[] = [];
  for (const spec of semanticFileSpecs(prepared)) {
    assertPortablePath(spec.path);
    const destination = resolve(stagePath, spec.path);
    ensureContained(stagePath, destination);
    writeExclusive(destination, spec.content);
    entries.push({
      path: spec.path,
      role: spec.role,
      mediaType: spec.mediaType,
      bytes: Buffer.byteLength(spec.content),
      sha256: sha256Bytes(spec.content),
    });
  }
  return entries;
}

function expectedRole(path: string): ManifestEntry["role"] | undefined {
  const fixed: Record<string, ManifestEntry["role"]> = {
    "request.json": "RUN",
    "profile.json": "PROFILE",
    "operations.json": "OPERATIONS",
    "investigation.json": "INVESTIGATION",
    "coverage.json": "COVERAGE",
  };
  if (fixed[path] !== undefined) return fixed[path];
  if (/^evidence\/pmev_[A-Za-z0-9_-]{20,128}\.json$/u.test(path)) return "EVIDENCE";
  if (/^contradictions\/pmcon_[A-Za-z0-9_-]{20,128}\.json$/u.test(path)) {
    return "CONTRADICTIONS";
  }
  return undefined;
}

function investigationDraft(investigation: Investigation): InvestigationDraft {
  const draft = { ...investigation } as Record<string, unknown>;
  delete draft.schemaVersion;
  delete draft.runId;
  // analysisState is persisted so validation can reproduce whether analysis was submitted.
  delete draft.status;
  delete draft.contradictionIds;
  delete draft.integrity;
  return draft as unknown as InvestigationDraft;
}

function validateBundleDeletionReceipt(
  bundlePath: string,
  root: RootContext,
  expectedBundleId: BundleId,
): void {
  ensureContained(resolve(root.path, BUNDLES_DIRECTORY), bundlePath);
  assertSecureTree(bundlePath, root.device);
  const tree = collectRelativeTree(bundlePath);
  const expectedDirectories = ["contradictions", "evidence"];
  if (canonicalJson(tree.directories) !== canonicalJson(expectedDirectories)) {
    throw new Error("Bundle contains missing or unreceipted directories");
  }

  const manifestContent = readSecureFile(resolve(bundlePath, MANIFEST_PATH), root.device, 4 * 1024 * 1024);
  const manifest = parseJson<BundleManifest>(manifestContent, MANIFEST_PATH);
  if (manifestContent !== canonicalDocument(manifest)) throw new Error("Manifest is not canonical");
  assertSchema("manifest", manifest);
  if (!verifyBundleHash(manifest)) throw new Error("Manifest bundle hash is invalid");
  const sortedEntries = [...manifest.entries].sort((left, right) => left.path.localeCompare(right.path));
  if (canonicalJson(sortedEntries) !== canonicalJson(manifest.entries)) {
    throw new Error("Manifest entries are not sorted by path");
  }
  if (manifest.bundleId !== expectedBundleId || basename(bundlePath) !== manifest.bundleId) {
    throw new Error("Bundle directory does not match manifest bundleId");
  }

  const manifestSha256 = sha256Bytes(manifestContent);
  const digestContent = readSecureFile(resolve(bundlePath, MANIFEST_DIGEST_PATH), root.device, 1024);
  if (digestContent !== `${manifestSha256}  ${MANIFEST_PATH}\n`) {
    throw new Error("Detached manifest digest is invalid");
  }

  const expectedFiles = new Set([
    MANIFEST_PATH,
    MANIFEST_DIGEST_PATH,
    "report.md",
    ...manifest.entries.map((entry) => entry.path),
  ]);
  if (canonicalJson([...expectedFiles].sort()) !== canonicalJson(tree.files)) {
    throw new Error("Bundle contains missing or unreceipted files");
  }
  for (const entry of manifest.entries) {
    assertPortablePath(entry.path);
    if (expectedRole(entry.path) !== entry.role || entry.mediaType !== "application/json") {
      throw new Error(`Manifest receipt does not authorize artifact path: ${entry.path}`);
    }
  }
}

function validateBundleDirectory(
  bundlePath: string,
  root: RootContext,
  options: ValidationOptions = {},
): ValidatedBundle {
  ensureContained(resolve(root.path, BUNDLES_DIRECTORY), bundlePath);
  assertSecureTree(bundlePath, root.device);
  const tree = collectRelativeTree(bundlePath);
  const allowedDirectories = new Set(["contradictions", "evidence"]);
  for (const directory of tree.directories) {
    if (!allowedDirectories.has(directory)) throw new Error(`Unexpected bundle directory: ${directory}`);
  }

  const manifestFile = resolve(bundlePath, MANIFEST_PATH);
  const digestFile = resolve(bundlePath, MANIFEST_DIGEST_PATH);
  const manifestContent = readSecureFile(manifestFile, root.device, 4 * 1024 * 1024);
  const manifest = parseJson<BundleManifest>(manifestContent, MANIFEST_PATH);
  if (manifestContent !== canonicalDocument(manifest)) throw new Error("Manifest is not canonical");
  assertSchema("manifest", manifest);
  if (!verifyBundleHash(manifest)) throw new Error("Manifest bundle hash is invalid");
  const sortedEntries = [...manifest.entries].sort((left, right) => left.path.localeCompare(right.path));
  if (canonicalJson(sortedEntries) !== canonicalJson(manifest.entries)) {
    throw new Error("Manifest entries are not sorted by path");
  }
  if (options.expectedBundleId !== undefined && manifest.bundleId !== options.expectedBundleId) {
    throw new Error("Bundle directory does not match manifest bundleId");
  }
  if (!options.allowStageMarker && basename(bundlePath) !== manifest.bundleId) {
    throw new Error("Bundle directory name does not match manifest bundleId");
  }

  const manifestSha256 = sha256Bytes(manifestContent);
  const digestContent = readSecureFile(digestFile, root.device, 1024);
  if (digestContent !== `${manifestSha256}  ${MANIFEST_PATH}\n`) {
    throw new Error("Detached manifest digest is invalid");
  }

  const expectedFiles = new Set([
    MANIFEST_PATH,
    MANIFEST_DIGEST_PATH,
    "report.md",
    ...manifest.entries.map((entry) => entry.path),
  ]);
  if (options.allowStageMarker) expectedFiles.add(STAGE_MARKER);
  if (
    canonicalJson([...expectedFiles].sort()) !== canonicalJson(tree.files)
  ) {
    throw new Error("Bundle contains missing or unreceipted files");
  }
  if (options.allowStageMarker) {
    const stageMarker = readCanonicalJson<StageMarker>(
      resolve(bundlePath, STAGE_MARKER),
      root.device,
    );
    if (
      stageMarker.magic !== STAGE_MAGIC ||
      stageMarker.version !== 1 ||
      stageMarker.rootId !== root.marker.rootId ||
      stageMarker.stageName !== basename(bundlePath) ||
      stageMarker.bundleId !== manifest.bundleId ||
      stageMarker.runId !== manifest.runId
    ) {
      throw new Error("Staging ownership marker does not match the bundle");
    }
  }

  for (const entry of manifest.entries) {
    assertPortablePath(entry.path);
    const role = expectedRole(entry.path);
    if (role === undefined || role !== entry.role) {
      throw new Error(`Manifest role does not match path: ${entry.path}`);
    }
    if (entry.mediaType !== "application/json") {
      throw new Error(`Manifest media type does not match path: ${entry.path}`);
    }
    const path = resolve(bundlePath, entry.path);
    ensureContained(bundlePath, path);
    const content = readSecureFile(path, root.device);
    if (Buffer.byteLength(content) !== entry.bytes || sha256Bytes(content) !== entry.sha256) {
      throw new Error(`Artifact receipt mismatch: ${entry.path}`);
    }
  }

  const request = readCanonicalJson<WorkflowRequest>(resolve(bundlePath, "request.json"), root.device);
  const profile = readCanonicalJson<TrustedProfile>(resolve(bundlePath, "profile.json"), root.device);
  const operations = readCanonicalJson<OperationSnapshot[]>(
    resolve(bundlePath, "operations.json"),
    root.device,
  );
  const investigation = readCanonicalJson<Investigation>(
    resolve(bundlePath, "investigation.json"),
    root.device,
  );
  const coverage = readCanonicalJson<Coverage>(resolve(bundlePath, "coverage.json"), root.device);
  assertSchema("investigation", investigation);
  assertSchema("coverage", coverage);
  if (!verifyIntegrity(investigation) || !verifyIntegrity(coverage)) {
    throw new Error("Derived artifact integrity is invalid");
  }

  const evidence = manifest.entries
    .filter((entry) => entry.role === "EVIDENCE")
    .map((entry) =>
      readCanonicalJson<EvidenceEnvelope>(resolve(bundlePath, entry.path), root.device),
    );
  const contradictions = manifest.entries
    .filter((entry) => entry.role === "CONTRADICTIONS")
    .map((entry) =>
      readCanonicalJson<ContradictionRecord>(resolve(bundlePath, entry.path), root.device),
    );
  const report = readSecureFile(resolve(bundlePath, "report.md"), root.device);

  const reconstructed: FinalizeBundleInput = {
    bundleId: manifest.bundleId,
    runId: manifest.runId,
    createdAt: manifest.createdAt,
    request,
    profile,
    operations,
    evidence,
    contradictions,
    investigation: investigationDraft(investigation),
  };
  assertManifestIdentity(
    manifest,
    reconstructed.bundleId,
    reconstructed.runId,
    request.parentRunId,
  );
  if (manifest.origin !== request.origin) throw new Error("Manifest origin does not match request");
  const actual: PreparedArtifacts = {
    request,
    profile,
    operations,
    evidence,
    contradictions,
    investigation,
    coverage,
    report,
  };
  validatePreparedArtifacts(reconstructed, actual);

  return {
    bundleId: manifest.bundleId,
    runId: manifest.runId,
    path: bundlePath,
    manifest,
    manifestSha256,
    request,
    profile,
    operations,
    evidence,
    contradictions,
    investigation,
    coverage,
    report,
  };
}

function isAllowedStageFile(path: string): boolean {
  if (
    path === STAGE_MARKER ||
    path === "request.json" ||
    path === "profile.json" ||
    path === "operations.json" ||
    path === "investigation.json" ||
    path === "coverage.json" ||
    path === MANIFEST_PATH ||
    path === MANIFEST_DIGEST_PATH ||
    path === "report.md"
  ) {
    return true;
  }
  return (
    /^evidence\/pmev_[A-Za-z0-9_-]{20,128}\.json$/u.test(path) ||
    /^contradictions\/pmcon_[A-Za-z0-9_-]{20,128}\.json$/u.test(path)
  );
}

function stageInventory(
  stagePath: string,
  receipt: StageReceipt,
  root: RootContext,
  lock: SealLockReceipt,
): StageInventory {
  const bundlesPath = resolve(root.path, BUNDLES_DIRECTORY);
  ensureContained(bundlesPath, stagePath);
  if (basename(stagePath) !== receipt.stageName) {
    throw new Error("Staging directory path does not match its parent receipt");
  }
  const coordinates = stageCoordinates(basename(stagePath));
  if (coordinates.bundleId !== receipt.bundleId || coordinates.stageNonce !== receipt.stageNonce) {
    throw new Error("Staging directory name does not match its parent receipt");
  }

  const stageRoot = ownedPathIdentity(stagePath, "directory", root.device);
  assertSecureTree(stagePath, root.device);
  const tree = collectRelativeTree(stagePath);
  for (const directory of tree.directories) {
    if (directory !== "evidence" && directory !== "contradictions") {
      throw new Error(`Staging directory contains an unknown directory: ${directory}`);
    }
  }
  for (const file of tree.files) {
    if (!isAllowedStageFile(file)) {
      throw new Error(`Staging directory contains an unknown file: ${file}`);
    }
  }

  const markerPath = resolve(stagePath, STAGE_MARKER);
  if (existsSync(markerPath)) {
    const marker = readStageMarker(markerPath, root, lock);
    if (
      canonicalJson(stageOwnershipFields(marker.value)) !==
      canonicalJson(stageOwnershipFields(receipt))
    ) {
      throw new Error("Staging marker does not match its parent receipt");
    }
  }

  const files = tree.files.map((path) =>
    ownedPathIdentity(resolve(stagePath, path), "file", root.device)
  );
  const directories = tree.directories.map((path) =>
    ownedPathIdentity(resolve(stagePath, path), "directory", root.device)
  );
  assertSameOwnedPath(stageRoot);
  return { root: stageRoot, files, directories };
}

function inventoryIdentities(inventory: StageInventory): string[] {
  return [inventory.root, ...inventory.files, ...inventory.directories]
    .map((entry) => `${entry.kind}:${entry.path}:${entry.device}:${entry.inode}`)
    .sort();
}

function removeOwnedStage(
  stagePath: string,
  receipt: StageReceipt,
  root: RootContext,
  lock: SealLockReceipt,
  initial = stageInventory(stagePath, receipt, root, lock),
): void {
  const directories = [initial.root, ...initial.directories].sort((left, right) =>
    pathDepth(left.path) - pathDepth(right.path) || left.path.localeCompare(right.path)
  );
  for (const directory of directories) {
    assertSameOwnedPath(directory);
    chmodSync(directory.path, 0o700);
  }

  const confirmed = stageInventory(stagePath, receipt, root, lock);
  if (canonicalJson(inventoryIdentities(initial)) !== canonicalJson(inventoryIdentities(confirmed))) {
    throw new Error("Refusing to remove a staging directory that changed during validation");
  }

  for (const file of confirmed.files) {
    assertSameOwnedPath(file);
    unlinkSync(file.path);
  }
  for (const directory of [...confirmed.directories].sort((left, right) =>
    pathDepth(right.path) - pathDepth(left.path) || right.path.localeCompare(left.path)
  )) {
    assertSameOwnedPath(directory);
    rmdirSync(directory.path);
  }
  assertSameOwnedPath(confirmed.root);
  rmdirSync(confirmed.root.path);
}

function assertFinalBundleMatchesStage(
  finalPath: string,
  receipt: StageReceipt,
  root: RootContext,
): void {
  const bundle = validateBundleDirectory(finalPath, root, { expectedBundleId: receipt.bundleId });
  if (bundle.runId !== receipt.runId) {
    throw new Error("Committed bundle does not match its staging receipt");
  }
}

function cleanupStageReceipt(
  ownedReceipt: OwnedReceipt<StageReceipt>,
  root: RootContext,
  lock: SealLockReceipt,
): void {
  const receipt = ownedReceipt.value;
  const bundlesPath = resolve(root.path, BUNDLES_DIRECTORY);
  const stagePath = resolve(bundlesPath, receipt.stageName);
  const finalPath = resolve(bundlesPath, receipt.bundleId);
  ensureContained(bundlesPath, stagePath);
  ensureContained(bundlesPath, finalPath);
  const stageExists = existsSync(stagePath);
  const finalExists = existsSync(finalPath);
  if (stageExists && finalExists) {
    throw new Error("Both a staging directory and its final bundle exist");
  }
  if (stageExists) {
    const inventory = stageInventory(stagePath, receipt, root, lock);
    removeOwnedStage(stagePath, receipt, root, lock, inventory);
  } else if (finalExists) {
    assertFinalBundleMatchesStage(finalPath, receipt, root);
  }
  assertSameOwnedPath(ownedReceipt.identity);
  unlinkSync(ownedReceipt.identity.path);
  fsyncDirectory(bundlesPath);
}

function processIsProvablyAbandoned(pid: number): boolean {
  let signalError: unknown;
  try {
    process.kill(pid, 0);
  } catch (error) {
    signalError = error;
  }
  if (signalError === undefined) return false;
  if (isErrnoException(signalError, "ESRCH")) return true;
  throw new Error("Artifact seal lock owner liveness could not be proven");
}

function recoverAbandonedSeal(root: RootContext, lockPath: string): void {
  const lock = readSealLock(lockPath, root);
  if (!processIsProvablyAbandoned(lock.value.pid)) {
    throw new Error(`Artifact sealing is active in process ${lock.value.pid}`);
  }

  const bundlesPath = resolve(root.path, BUNDLES_DIRECTORY);
  const receipts: OwnedReceipt<StageReceipt>[] = [];
  const stages = new Map<string, string>();
  const finalBundles = new Map<BundleId, string>();
  for (const entry of readdirSync(bundlesPath, { withFileTypes: true })) {
    const path = resolve(bundlesPath, entry.name);
    if (entry.name === SEAL_LOCK) {
      const current = readSealLock(path, root);
      if (
        current.identity.inode !== lock.identity.inode ||
        current.identity.device !== lock.identity.device ||
        current.content !== lock.content
      ) {
        throw new Error("Artifact seal lock changed during abandoned-lock recovery");
      }
      continue;
    }
    if (STAGE_RECEIPT_NAME_PATTERN.test(entry.name)) {
      if (!entry.isFile()) throw new Error(`Internal staging receipt is not a file: ${entry.name}`);
      receipts.push(readStageReceipt(path, root, lock.value));
      continue;
    }
    if (STAGE_NAME_PATTERN.test(entry.name)) {
      if (!entry.isDirectory()) throw new Error(`Internal staging path is not a directory: ${entry.name}`);
      stageCoordinates(entry.name);
      stages.set(entry.name, path);
      continue;
    }
    let bundleId: BundleId;
    try {
      bundleId = asBundleId(entry.name);
    } catch {
      throw new Error(`Artifact bundles directory contains an unknown entry: ${entry.name}`);
    }
    if (!entry.isDirectory()) {
      throw new Error(`Sealed bundle path is not a directory: ${entry.name}`);
    }
    finalBundles.set(bundleId, path);
  }

  if (receipts.length > 1) {
    throw new Error("Abandoned artifact seal contains multiple staging receipts");
  }
  if (receipts.length === 0 && stages.size > 0) {
    throw new Error("Refusing to recover a staging directory without its parent receipt");
  }
  const receipt = receipts[0];
  if (receipt !== undefined) {
    const expectedStage = stages.get(receipt.value.stageName);
    if (stages.size > (expectedStage === undefined ? 0 : 1)) {
      throw new Error("Abandoned artifact seal contains a foreign staging directory");
    }
    const finalPath = finalBundles.get(receipt.value.bundleId);
    if (expectedStage !== undefined && finalPath !== undefined) {
      throw new Error("Both a staging directory and its final bundle exist");
    }
    if (expectedStage === undefined && finalPath !== undefined) {
      assertFinalBundleMatchesStage(finalPath, receipt.value, root);
    }
    if (expectedStage !== undefined) {
      stageInventory(expectedStage, receipt.value, root, lock.value);
    }
    if (!processIsProvablyAbandoned(lock.value.pid)) {
      throw new Error(`Artifact sealing became active in process ${lock.value.pid}`);
    }
    cleanupStageReceipt(receipt, root, lock.value);
  }

  for (const entry of readdirSync(bundlesPath, { withFileTypes: true })) {
    if (STAGE_NAME_PATTERN.test(entry.name) || STAGE_RECEIPT_NAME_PATTERN.test(entry.name)) {
      throw new Error("Internal staging state remained after abandoned-lock recovery");
    }
  }
  const current = readSealLock(lockPath, root);
  if (
    current.identity.inode !== lock.identity.inode ||
    current.identity.device !== lock.identity.device ||
    current.content !== lock.content
  ) {
    throw new Error("Artifact seal lock changed before abandoned-lock reclamation");
  }
  if (!processIsProvablyAbandoned(lock.value.pid)) {
    throw new Error(`Artifact sealing became active in process ${lock.value.pid}`);
  }
  assertSameOwnedPath(lock.identity);
  unlinkSync(lockPath);
  fsyncDirectory(bundlesPath);
}

function acquireSealLock(root: RootContext, acquiredAt: string): AcquiredSealLock {
  assertCanonicalTimestamp(acquiredAt, "Artifact seal lock acquiredAt");
  const bundlesPath = resolve(root.path, BUNDLES_DIRECTORY);
  const lockPath = resolve(bundlesPath, SEAL_LOCK);
  const receipt: SealLockReceipt = {
    magic: SEAL_LOCK_MAGIC,
    version: 1,
    ...rootIdentityFields(root),
    pid: process.pid,
    nonce: randomUUID(),
    acquiredAt,
  };
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      writeExclusive(lockPath, canonicalDocument(receipt));
      fsyncDirectory(bundlesPath);
      const owned = readSealLock(lockPath, root);
      if (owned.content !== canonicalDocument(receipt)) {
        throw new Error("New artifact seal lock does not match its receipt");
      }
      return { path: lockPath, receipt, identity: owned.identity };
    } catch (error) {
      if (!isErrnoException(error, "EEXIST")) throw error;
      try {
        recoverAbandonedSeal(root, lockPath);
      } catch (recoveryError) {
        if (isErrnoException(recoveryError, "ENOENT")) continue;
        throw recoveryError;
      }
    }
  }
  throw new Error("Artifact seal lock could not be acquired after concurrent recovery");
}

function releaseSealLock(lock: AcquiredSealLock, root: RootContext): void {
  const current = readSealLock(lock.path, root);
  if (
    current.identity.inode !== lock.identity.inode ||
    current.identity.device !== lock.identity.device ||
    current.content !== canonicalDocument(lock.receipt)
  ) {
    throw new Error("Refusing to release a replaced artifact seal lock");
  }
  assertSameOwnedPath(lock.identity);
  unlinkSync(lock.path);
  fsyncDirectory(resolve(root.path, BUNDLES_DIRECTORY));
}

function assertKnownInternalSealState(root: RootContext): void {
  const bundlesPath = resolve(root.path, BUNDLES_DIRECTORY);
  const entries = readdirSync(bundlesPath, { withFileTypes: true });
  const lockEntry = entries.find((entry) => entry.name === SEAL_LOCK);
  const receiptEntries = entries.filter((entry) => STAGE_RECEIPT_NAME_PATTERN.test(entry.name));
  const stageEntries = entries.filter((entry) => STAGE_NAME_PATTERN.test(entry.name));
  if (lockEntry === undefined) {
    if (receiptEntries.length > 0 || stageEntries.length > 0) {
      throw new Error("Internal staging state exists without a seal lock receipt");
    }
    return;
  }
  if (!lockEntry.isFile()) throw new Error("Artifact seal lock is not a regular file");
  const lock = readSealLock(resolve(bundlesPath, SEAL_LOCK), root);
  if (receiptEntries.length > 1) {
    throw new Error("Artifact seal contains multiple staging receipts");
  }
  if (receiptEntries.length === 0) {
    if (stageEntries.length > 0) {
      throw new Error("Internal staging directory exists without a parent receipt");
    }
    return;
  }

  const receiptEntry = receiptEntries[0]!;
  if (!receiptEntry.isFile()) throw new Error("Internal staging receipt is not a regular file");
  const receipt = readStageReceipt(resolve(bundlesPath, receiptEntry.name), root, lock.value);
  const expectedStage = stageEntries.find((entry) => entry.name === receipt.value.stageName);
  if (stageEntries.length > (expectedStage === undefined ? 0 : 1)) {
    throw new Error("Artifact seal contains a foreign staging directory");
  }
  const finalPath = resolve(bundlesPath, receipt.value.bundleId);
  const finalExists = existsSync(finalPath);
  if (expectedStage !== undefined) {
    if (!expectedStage.isDirectory()) throw new Error("Internal staging path is not a directory");
    if (finalExists) throw new Error("Both a staging directory and its final bundle exist");
    stageInventory(resolve(bundlesPath, expectedStage.name), receipt.value, root, lock.value);
  } else if (finalExists) {
    assertFinalBundleMatchesStage(finalPath, receipt.value, root);
  }
}

export class ArtifactStore {
  readonly root: string;
  readonly #context: RootContext;
  readonly #now: () => Date;
  readonly #producer: ArtifactProducer;

  constructor(options: ArtifactStoreOptions) {
    this.#context = openOrCreateRoot(options.root);
    this.root = this.#context.path;
    this.#now = options.now ?? (() => new Date());
    this.#producer = { ...DEFAULT_PRODUCER, ...options.producer };
  }

  #bundlesPath(): string {
    return resolve(this.root, BUNDLES_DIRECTORY);
  }

  #findByRunId(runId: RunId): ValidatedBundle | undefined {
    assertKnownInternalSealState(this.#context);
    let found: ValidatedBundle | undefined;
    for (const entry of readdirSync(this.#bundlesPath(), { withFileTypes: true })) {
      const path = resolve(this.#bundlesPath(), entry.name);
      if (entry.name === SEAL_LOCK) {
        ownedPathIdentity(path, "file", this.#context.device);
        continue;
      }
      if (STAGE_RECEIPT_NAME_PATTERN.test(entry.name)) {
        ownedPathIdentity(path, "file", this.#context.device);
        continue;
      }
      if (STAGE_NAME_PATTERN.test(entry.name)) {
        stageCoordinates(entry.name);
        ownedPathIdentity(path, "directory", this.#context.device);
        continue;
      }
      if (!entry.isDirectory()) {
        throw new Error(`Artifact bundles directory contains an unknown entry: ${entry.name}`);
      }
      let bundleId: BundleId;
      try {
        bundleId = asBundleId(entry.name);
      } catch {
        throw new Error(`Artifact bundles directory contains an unknown entry: ${entry.name}`);
      }
      const bundle = validateBundleDirectory(resolve(this.#bundlesPath(), entry.name), this.#context, {
        expectedBundleId: bundleId,
      });
      if (bundle.runId === runId) {
        if (found !== undefined) throw new Error(`Multiple sealed bundles exist for run ${runId}`);
        found = bundle;
      }
    }
    return found;
  }

  validateBundle(bundleId: BundleId): ValidatedBundle {
    const safeBundleId = asBundleId(bundleId);
    const bundle = validateBundleDirectory(
      resolve(this.#bundlesPath(), safeBundleId),
      this.#context,
      { expectedBundleId: safeBundleId },
    );
    if (bundle.manifest.parentRunId !== undefined) {
      const parent = this.#findByRunId(bundle.manifest.parentRunId);
      if (parent === undefined) throw new Error("Sealed child bundle has no immutable parent bundle");
      const reconstructed: FinalizeBundleInput = {
        bundleId: bundle.bundleId,
        runId: bundle.runId,
        createdAt: bundle.manifest.createdAt,
        request: bundle.request,
        profile: bundle.profile,
        operations: bundle.operations,
        evidence: bundle.evidence,
        contradictions: bundle.contradictions,
        investigation: investigationDraft(bundle.investigation),
      };
      assertParentVerificationContract(reconstructed, parent.investigation);
    }
    return bundle;
  }

  seal(input: FinalizeBundleInput): FinalizationResult {
    const prepared = prepareArtifacts(input);
    const sealedAt = this.#now().toISOString();
    const lock = acquireSealLock(this.#context, sealedAt);
    maybeCrashForTest("LOCK_ONLY");

    let stagePath: string | undefined;
    let stageReceipt: OwnedReceipt<StageReceipt> | undefined;
    let releaseLockOnExit = true;
    try {
      if (existsSync(resolve(this.#bundlesPath(), input.bundleId))) {
        throw new Error(`Bundle already exists: ${input.bundleId}`);
      }
      if (this.#findByRunId(input.runId) !== undefined) {
        throw new Error(`Run is already sealed and immutable: ${input.runId}`);
      }

      if (input.request.parentRunId !== undefined) {
        const parent = this.#findByRunId(input.request.parentRunId);
        if (parent === undefined) throw new Error("Parent run must be sealed before creating a child");
        assertParentVerificationContract(input, parent.investigation);
      }

      const stageNonce = randomUUID();
      const stageName = `.stage-${input.bundleId}-${stageNonce}`;
      const receiptName = `.stage-receipt-${stageNonce}.json`;
      const ownership = {
        ...rootIdentityFields(this.#context),
        lockNonce: lock.receipt.nonce,
        stageNonce,
        stageName,
        receiptName,
        bundleId: input.bundleId,
        runId: input.runId,
        createdAt: sealedAt,
      };
      const receiptValue: StageReceipt = {
        magic: STAGE_RECEIPT_MAGIC,
        version: 1,
        ...ownership,
      };
      const receiptPath = resolve(this.#bundlesPath(), receiptName);
      writeExclusive(receiptPath, canonicalDocument(receiptValue));
      fsyncDirectory(this.#bundlesPath());
      stageReceipt = readStageReceipt(receiptPath, this.#context, lock.receipt);

      stagePath = resolve(this.#bundlesPath(), stageName);
      createDirectory(stagePath, this.#context.device);
      fsyncDirectory(this.#bundlesPath());
      const stageMarker: StageMarker = {
        magic: STAGE_MAGIC,
        version: 1,
        ...ownership,
      };
      writeExclusive(resolve(stagePath, STAGE_MARKER), canonicalDocument(stageMarker));
      fsyncDirectory(stagePath);
      maybeCrashForTest("MARKED_STAGE");

      const entries = writePreparedFiles(stagePath, this.#context.device, prepared);
      const manifestBase = {
        schemaVersion: "1.0.0" as const,
        bundleId: input.bundleId,
        runId: input.runId,
        ...(input.request.parentRunId === undefined
          ? {}
          : { parentRunId: input.request.parentRunId }),
        origin: input.request.origin,
        producer: this.#producer,
        createdAt: input.createdAt,
        sealedAt,
        entries,
        bundleSha256: computeBundleHash(entries),
      };
      const manifest: BundleManifest = manifestBase;
      assertSchema("manifest", manifest);
      const manifestContent = canonicalDocument(manifest);
      const manifestSha256 = manifestDigest(manifest);

      writeExclusive(
        resolve(stagePath, MANIFEST_DIGEST_PATH),
        `${manifestSha256}  ${MANIFEST_PATH}\n`,
      );
      // Seal the non-circular semantic manifest before generating the readable
      // projection. report.md is validated by deterministic regeneration but is
      // deliberately absent from the semantic file table and its bundle hash.
      writeExclusive(resolve(stagePath, MANIFEST_PATH), manifestContent);
      writeExclusive(resolve(stagePath, "report.md"), prepared.report);

      validateBundleDirectory(stagePath, this.#context, {
        expectedBundleId: input.bundleId,
        allowStageMarker: true,
      });
      const marker = readStageMarker(
        resolve(stagePath, STAGE_MARKER),
        this.#context,
        lock.receipt,
      );
      if (
        canonicalJson(stageOwnershipFields(marker.value)) !==
        canonicalJson(stageOwnershipFields(receiptValue))
      ) {
        throw new Error("Staging marker changed before commit");
      }
      assertSameOwnedPath(marker.identity);
      unlinkSync(marker.identity.path);
      fsyncDirectory(stagePath);
      assertSecureTree(stagePath, this.#context.device);
      immutableTree(stagePath);
      maybeCrashForTest("PRE_RENAME");

      const finalPath = resolve(this.#bundlesPath(), input.bundleId);
      renameSync(stagePath, finalPath);
      stagePath = undefined;
      fsyncDirectory(this.#bundlesPath());
      maybeCrashForTest("POST_RENAME");

      const validated = validateBundleDirectory(finalPath, this.#context, {
        expectedBundleId: input.bundleId,
      });
      cleanupStageReceipt(stageReceipt, this.#context, lock.receipt);
      stageReceipt = undefined;
      return { ...validated, created: true };
    } catch (error) {
      if (stageReceipt !== undefined) {
        try {
          cleanupStageReceipt(stageReceipt, this.#context, lock.receipt);
          stageReceipt = undefined;
          stagePath = undefined;
        } catch {
          // Preserve the live lock plus uncertain staging data. A later process
          // may reclaim it only after ESRCH proves this process has exited.
          releaseLockOnExit = false;
        }
      } else if (stagePath !== undefined && existsSync(stagePath)) {
        // A stage without its durable parent receipt is never safe to remove.
        releaseLockOnExit = false;
      }
      throw error;
    } finally {
      if (releaseLockOnExit) releaseSealLock(lock, this.#context);
    }
  }
}

export function deleteOwnedArtifactRoot(root: string): ArtifactRootDeletionReceipt {
  if (!isAbsolute(root)) throw new Error("Artifact root must be an absolute path");
  const requestedPath = resolve(root);
  const rootStat = lstatSync(requestedPath, { bigint: false });
  assertDirectory(rootStat, "Artifact root");
  assertOwned(rootStat, "Artifact root");
  assertPrivateMode(rootStat, "Artifact root");
  const rootPath = realpathSync.native(requestedPath);
  const device = statDevice(statSync(rootPath, { bigint: false }));
  const marker = validateRootMarker(rootPath, device);
  assertSecureTree(rootPath, device);
  const context = { path: rootPath, device, marker };
  const inventory = artifactRootDeletionInventory(context);
  deleteEnumeratedArtifactRoot(context, inventory);
  return Object.freeze({
    schemaVersion: "1.0.0",
    action: "ARTIFACT_ROOT_DELETED",
    rootId: marker.rootId,
    rootPath,
    deletedAt: new Date().toISOString(),
  });
}

export function manifestDigest(manifest: BundleManifest): Sha256 {
  return sha256Bytes(canonicalJson(manifest as unknown as JsonValue));
}
