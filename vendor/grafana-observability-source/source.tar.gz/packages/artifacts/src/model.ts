import {
  assertAnalysisDraftSemantics,
  canonicalJson,
  computeIntegrity,
  computeOperationDefinitionHash,
  deriveEvidenceState,
  evidenceSourceIndependenceKey,
  evidenceStateToCoverageDisposition,
  sha256Canonical,
  verifyIntegrity,
  type BundleId,
  type ContradictionId,
  type ContradictionRecord,
  type Coverage,
  type CoverageDisposition,
  type CoverageEntry,
  type EvidenceEnvelope,
  type EvidenceId,
  type Investigation,
  type InvestigationStatus,
  type JsonPrimitive,
  type NormalizedValue,
  type OperationId,
  type OperationSnapshot,
  type RunId,
  type Sha256,
  type VerificationContract,
  type AnalysisDraft,
} from "../../contracts/src/index.ts";

import { assertSchema } from "./schema.ts";
import type {
  FinalizeBundleInput,
  IncidentCausalConclusion,
  IncidentPresentation,
  IncidentPresentationSignal,
  InvestigationDraft,
} from "./types.ts";

const RUN_ID = /^pmrun_[A-Za-z0-9_-]{20,128}$/u;
const BUNDLE_ID = /^pmbundle_[A-Za-z0-9_-]{20,128}$/u;

const EVIDENCE_KEYS = new Set([
  "schemaVersion",
  "evidenceId",
  "runId",
  "operationId",
  "operationDefinitionSha256",
  "trustBundleSha256",
  "origin",
  "authority",
  "source",
  "scope",
  "correlation",
  "evaluatedAt",
  "collectedAt",
  "window",
  "maxAcceptableAgeMs",
  "collectionState",
  "freshnessState",
  "native",
  "values",
  "redactions",
  "limitations",
  "pagination",
  "providerWarnings",
  "error",
  "integrity",
]);

const FORBIDDEN_RAW_KEYS = new Set([
  "raw",
  "rawpayload",
  "rawproviderpayload",
  "rawproviderdata",
  "rawresponse",
  "rawdata",
  "providerpayload",
  "providerresponse",
  "requestbody",
  "responsebody",
  "authorization",
  "cookie",
  "password",
  "secret",
]);

export interface PreparedArtifacts {
  request: FinalizeBundleInput["request"];
  profile: FinalizeBundleInput["profile"];
  operations: OperationSnapshot[];
  evidence: EvidenceEnvelope[];
  contradictions: ContradictionRecord[];
  investigation: Investigation;
  coverage: Coverage;
  report: string;
}

function assertIsoTimestamp(value: string, label: string): void {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime()) || date.toISOString() !== value) {
    throw new TypeError(`${label} must be an ISO 8601 UTC timestamp`);
  }
}

function assertEqual(left: unknown, right: unknown, message: string): void {
  if (canonicalJson(left) !== canonicalJson(right)) throw new TypeError(message);
}

function sortedUnique<T extends string>(values: readonly T[]): T[] {
  return [...new Set(values)].sort();
}

function assertNoUnexpectedEvidenceProperties(evidence: EvidenceEnvelope): void {
  for (const key of Object.keys(evidence)) {
    if (!EVIDENCE_KEYS.has(key)) {
      throw new TypeError(`Evidence ${evidence.evidenceId} has unsupported property ${key}`);
    }
  }
}

function assertNoRawProviderRetention(value: unknown, path = "$"): void {
  if (value === null || typeof value !== "object") return;
  if (Array.isArray(value)) {
    for (let index = 0; index < value.length; index += 1) {
      assertNoRawProviderRetention(value[index], `${path}[${index}]`);
    }
    return;
  }
  for (const [key, member] of Object.entries(value)) {
    const normalized = key.replaceAll(/[^a-z]/giu, "").toLowerCase();
    if (FORBIDDEN_RAW_KEYS.has(normalized)) {
      throw new TypeError(`Raw provider material is forbidden at ${path}.${key}`);
    }
    assertNoRawProviderRetention(member, `${path}.${key}`);
  }
}

function assertUnique<T extends string>(values: readonly T[], label: string): void {
  if (new Set(values).size !== values.length) throw new TypeError(`${label} must be unique`);
}

function jsonPointerExists(value: unknown, pointer: string): boolean {
  if (pointer === "") return true;
  let current: unknown = value;
  for (const encodedToken of pointer.slice(1).split("/")) {
    const token = encodedToken.replaceAll("~1", "/").replaceAll("~0", "~");
    if (Array.isArray(current)) {
      if (!/^(?:0|[1-9][0-9]*)$/u.test(token)) return false;
      const index = Number(token);
      if (!Number.isSafeInteger(index) || index >= current.length) return false;
      current = current[index];
    } else if (current !== null && typeof current === "object") {
      if (!Object.hasOwn(current, token)) return false;
      current = (current as Record<string, unknown>)[token];
    } else {
      return false;
    }
  }
  return true;
}

function validateVerificationContract(contract: VerificationContract): void {
  const semanticContract: Omit<VerificationContract, "contractSha256"> = {
    policyAlias: contract.policyAlias,
    scope: contract.scope,
    ...(contract.cohort === undefined ? {} : { cohort: contract.cohort }),
    windowStrategy: contract.windowStrategy,
    windowDurationSeconds: contract.windowDurationSeconds,
    requiredSamples: contract.requiredSamples,
    passCount: contract.passCount,
    criteria: contract.criteria,
  };
  const expected = sha256Canonical(semanticContract);
  if (contract.contractSha256 !== expected) {
    throw new TypeError("Verification contract hash does not match its semantic content");
  }
}

export function computeVerificationContractHash(
  contract: Omit<VerificationContract, "contractSha256">,
): Sha256 {
  return sha256Canonical(contract);
}

function assertCitations(
  draft: InvestigationDraft,
  evidenceIds: ReadonlySet<EvidenceId>,
): void {
  const requireEvidence = (id: EvidenceId, citation: string): void => {
    if (!evidenceIds.has(id)) throw new TypeError(`${citation} cites unknown evidence ${id}`);
  };

  for (const observation of draft.observations) {
    for (const id of observation.evidenceIds) requireEvidence(id, observation.observationId);
  }
  for (const inference of draft.inferences) {
    for (const id of inference.supportingEvidenceIds) requireEvidence(id, inference.inferenceId);
    for (const id of inference.contradictingEvidenceIds) requireEvidence(id, inference.inferenceId);
  }
  for (const hypothesis of draft.hypotheses) {
    for (const id of hypothesis.supportingEvidenceIds) requireEvidence(id, hypothesis.hypothesisId);
    for (const id of hypothesis.contradictingEvidenceIds) {
      requireEvidence(id, hypothesis.hypothesisId);
    }
  }
  for (const id of draft.verificationResult?.evidenceIds ?? []) {
    requireEvidence(id, "verificationResult");
  }
}

function validateAnalysis(draft: InvestigationDraft, evidenceIds: ReadonlySet<EvidenceId>): void {
  const analysis: AnalysisDraft = {
    schemaVersion: "1.0.0",
    observations: draft.observations,
    inferences: draft.inferences,
    hypotheses: draft.hypotheses,
    checksPerformed: draft.checksPerformed,
    missingEvidence: draft.missingEvidence,
    smallestSafeNextStep: draft.smallestSafeNextStep,
    approvalRequired: draft.approvalRequired,
    remainingUncertainty: draft.remainingUncertainty,
    owners: draft.owners,
  };
  assertSchema("analysisDraft", analysis);
  assertAnalysisDraftSemantics(analysis, evidenceIds);
}

function validateSourceInput(input: FinalizeBundleInput): Map<OperationId, OperationSnapshot> {
  if (!RUN_ID.test(input.runId)) throw new TypeError("Invalid runId");
  if (!BUNDLE_ID.test(input.bundleId)) throw new TypeError("Invalid bundleId");
  assertIsoTimestamp(input.createdAt, "createdAt");
  assertSchema("workflowRequest", input.request);
  assertSchema("trustedProfile", input.profile);

  if (input.request.profileAlias !== input.profile.profileAlias) {
    throw new TypeError("Request profileAlias does not match the captured profile");
  }
  if (!Object.hasOwn(input.profile.scopes, input.request.scopeAlias)) {
    throw new TypeError(`Unknown request scope alias: ${input.request.scopeAlias}`);
  }
  if (!input.profile.allowedOrigins.includes(input.request.origin)) {
    throw new TypeError(`Origin ${input.request.origin} is not allowed by the profile`);
  }
  if (input.operations.length === 0) {
    throw new TypeError("At least one reviewed operation snapshot is mandatory");
  }

  const operationIds = input.operations.map((operation) => operation.operationId);
  assertUnique(operationIds, "Operation snapshot IDs");
  const selectedOperationIds = input.request.requiredOperations ?? input.profile.operationIds;
  if (canonicalJson(sortedUnique(operationIds)) !== canonicalJson(sortedUnique(selectedOperationIds))) {
    throw new TypeError("Operation snapshots must cover the sealed run operation IDs exactly");
  }

  const operations = new Map<OperationId, OperationSnapshot>();
  for (const operation of input.operations) {
    assertSchema("operationSnapshot", operation);
    if (computeOperationDefinitionHash(operation) !== operation.definitionSha256) {
      throw new TypeError(`Operation definition hash mismatch: ${operation.operationId}`);
    }
    operations.set(operation.operationId, operation);
  }
  for (const required of input.request.requiredOperations ?? []) {
    if (!operations.has(required)) throw new TypeError(`Required operation is not captured: ${required}`);
  }

  const evidenceIds = input.evidence.map((evidence) => evidence.evidenceId);
  assertUnique(evidenceIds, "Evidence IDs");
  const evidenceIdSet = new Set(evidenceIds);
  const evidenceById = new Map(input.evidence.map((evidence) => [evidence.evidenceId, evidence]));
  let trustBundleSha256: Sha256 | undefined;
  const expectedScope = input.profile.scopes[input.request.scopeAlias];
  if (expectedScope === undefined) throw new TypeError("Request scope is unavailable");

  for (const evidence of input.evidence) {
    assertNoRawProviderRetention(evidence);
    assertNoUnexpectedEvidenceProperties(evidence);
    assertSchema("evidenceEnvelope", evidence);
    if (!verifyIntegrity(evidence)) throw new TypeError(`Evidence integrity failed: ${evidence.evidenceId}`);
    if (evidence.runId !== input.runId) {
      throw new TypeError(`Evidence ${evidence.evidenceId} belongs to a different run`);
    }
    if (evidence.origin !== input.request.origin) {
      throw new TypeError(`Evidence ${evidence.evidenceId} has a different origin`);
    }
    assertEqual(evidence.scope, expectedScope, `Evidence ${evidence.evidenceId} has a different scope`);
    const operation = operations.get(evidence.operationId);
    if (operation === undefined) {
      throw new TypeError(`Evidence ${evidence.evidenceId} cites an uncaptured operation`);
    }
    if (evidence.operationDefinitionSha256 !== operation.definitionSha256) {
      throw new TypeError(`Evidence ${evidence.evidenceId} cites a different operation revision`);
    }
    if (
      evidence.source.sourceAlias !== operation.definition.sourceAlias ||
      evidence.authority !== operation.definition.authority ||
      evidence.source.adapterPackageId !== operation.definition.adapterPackageId
    ) {
      throw new TypeError(`Evidence ${evidence.evidenceId} source does not match its operation`);
    }
    trustBundleSha256 ??= evidence.trustBundleSha256;
    if (trustBundleSha256 !== evidence.trustBundleSha256) {
      throw new TypeError("Evidence contains mixed trust-bundle identities");
    }
  }

  const contradictionIds = input.contradictions.map((item) => item.contradictionId);
  assertUnique(contradictionIds, "Contradiction IDs");
  for (const contradiction of input.contradictions) {
    assertSchema("contradiction", contradiction);
    if (!verifyIntegrity(contradiction)) {
      throw new TypeError(`Contradiction integrity failed: ${contradiction.contradictionId}`);
    }
    if (contradiction.runId !== input.runId) {
      throw new TypeError(`Contradiction ${contradiction.contradictionId} belongs to a different run`);
    }
    for (const claim of contradiction.claimRefs) {
      const citedEvidence = evidenceById.get(claim.evidenceId);
      if (citedEvidence === undefined) {
        throw new TypeError(
          `Contradiction ${contradiction.contradictionId} cites unknown evidence ${claim.evidenceId}`,
        );
      }
      if (!jsonPointerExists(citedEvidence, claim.jsonPointer)) {
        throw new TypeError(
          `Contradiction ${contradiction.contradictionId} cites a missing JSON pointer in ${claim.evidenceId}`,
        );
      }
    }
  }

  assertEqual(input.investigation.scope, expectedScope, "Investigation scope does not match request");
  assertEqual(
    input.investigation.requestedWindow,
    input.request.window,
    "Investigation requestedWindow does not match request",
  );
  assertCitations(input.investigation, evidenceIdSet);
  if (input.investigation.analysisState === "SUBMITTED") {
    validateAnalysis(input.investigation, evidenceIdSet);
  }

  if (input.investigation.verificationContract !== undefined) {
    validateVerificationContract(input.investigation.verificationContract);
    for (const criterion of input.investigation.verificationContract.criteria) {
      const operation = operations.get(criterion.operationId);
      if (
        operation === undefined ||
        operation.definitionSha256 !== criterion.operationDefinitionSha256
      ) {
        throw new TypeError(`Verification criterion ${criterion.criterionId} is not reproducible`);
      }
    }
  }

  return operations;
}

function aggregateDisposition(
  evidence: readonly EvidenceEnvelope[],
  contradictionEvidenceIds: ReadonlySet<EvidenceId>,
): CoverageDisposition {
  if (evidence.length === 0) return "DEFERRED";
  const states = evidence.map((item) =>
    deriveEvidenceState({
      collectionState: item.collectionState,
      freshnessState: item.freshnessState,
      hasUnresolvedContradiction: contradictionEvidenceIds.has(item.evidenceId),
    }),
  );
  for (const state of ["ERROR", "CONTRADICTORY", "STALE"] as const) {
    if (states.includes(state)) return evidenceStateToCoverageDisposition(state);
  }
  if (states.every((state) => state === "EMPTY")) return "EMPTY";
  return "AVAILABLE";
}

export function deriveArtifactCoverage(input: FinalizeBundleInput): Coverage {
  const operations = validateSourceInput(input);
  const required = new Set(
    input.request.workflow === "deep"
      ? input.operations.map((operation) => operation.operationId)
      : input.request.requiredOperations ?? input.operations.map((operation) => operation.operationId),
  );
  const unresolvedContradictions = input.contradictions.filter(
    (contradiction) => contradiction.resolutionState === "UNRESOLVED",
  );
  const contradictionEvidenceIds = new Set<EvidenceId>(
    unresolvedContradictions.flatMap((item) => item.claimRefs.map((claim) => claim.evidenceId)),
  );

  const entries: CoverageEntry[] = [...operations.values()]
    .sort((left, right) => left.operationId.localeCompare(right.operationId))
    .map((operation) => {
      const operationEvidence = input.evidence
        .filter((item) => item.operationId === operation.operationId)
        .sort((left, right) => left.evidenceId.localeCompare(right.evidenceId));
      const operationEvidenceIds = new Set(operationEvidence.map((item) => item.evidenceId));
      const operationContradictions = unresolvedContradictions
        .filter((item) => item.claimRefs.some((claim) => operationEvidenceIds.has(claim.evidenceId)))
        .map((item) => item.contradictionId)
        .sort();
      const truncated = operationEvidence.some((item) => !item.pagination.complete);
      const disposition = truncated
        ? "ERROR" as const
        : aggregateDisposition(operationEvidence, contradictionEvidenceIds);
      const isRequired = required.has(operation.operationId);
      const entry: CoverageEntry = {
        domain: operation.definition.domain,
        operationId: operation.operationId,
        requirement: isRequired ? "REQUIRED" : "OPTIONAL",
        sourceAlias: operation.definition.sourceAlias,
        authority: operation.definition.authority,
        disposition,
        evidenceIds: operationEvidence.map((item) => item.evidenceId),
        contradictionIds: operationContradictions,
        blocksWorkflow: isRequired && disposition !== "AVAILABLE",
      };
      if (operationEvidence.length > 0) {
        entry.paginationComplete = operationEvidence.every((item) => item.pagination.complete);
      }
      if (truncated) entry.reason = "Normalized evidence was truncated by a sealed limit";
      else if (disposition === "DEFERRED") entry.reason = "No normalized evidence was collected";
      return entry;
    });

  const considered = entries.filter(
    (entry) => entry.requirement === "REQUIRED" || entry.evidenceIds.length > 0,
  );
  const overall: Coverage["overall"] =
    considered.length === 0
      ? "UNKNOWN"
      : considered.every((entry) => entry.disposition === "AVAILABLE")
        ? "COMPLETE"
        : "PARTIAL";
  const withoutIntegrity: Omit<Coverage, "integrity"> = {
    schemaVersion: "1.0.0",
    runId: input.runId,
    overall,
    entries,
  };
  return { ...withoutIntegrity, integrity: computeIntegrity(withoutIntegrity) };
}

export function deriveInvestigationStatus(
  coverage: Coverage,
  analysisState: InvestigationDraft["analysisState"] = "SUBMITTED",
  recoveryState: InvestigationDraft["recoveryState"] = "NONE",
): InvestigationStatus {
  if (recoveryState === "INCOMPLETE") return "PARTIAL";
  if (analysisState === "EVIDENCE_ONLY") return "PARTIAL";
  const blockingRequired = coverage.entries.some(
    (entry) =>
      entry.requirement === "REQUIRED" &&
      (["ERROR", "UNSUPPORTED", "DEFERRED"] as CoverageDisposition[]).includes(
        entry.disposition,
      ),
  );
  if (blockingRequired) return "BLOCKED";
  return coverage.overall === "COMPLETE" ? "COMPLETE" : "PARTIAL";
}

function deriveInvestigation(
  input: FinalizeBundleInput,
  coverage: Coverage,
): Investigation {
  const coverageGaps = coverage.entries
    .filter((entry) => entry.disposition !== "AVAILABLE")
    .map((entry) => `${entry.operationId}: ${entry.disposition}`);
  const missingEvidence = sortedUnique([...input.investigation.missingEvidence, ...coverageGaps]);
  const withoutIntegrity: Omit<Investigation, "integrity"> = {
    schemaVersion: "1.0.0",
    runId: input.runId,
    ...input.investigation,
    status: deriveInvestigationStatus(
      coverage,
      input.investigation.analysisState,
      input.investigation.recoveryState,
    ),
    contradictionIds: input.contradictions.map((item) => item.contradictionId).sort(),
    missingEvidence,
  };
  const investigation: Investigation = {
    ...withoutIntegrity,
    integrity: computeIntegrity(withoutIntegrity),
  };
  assertSchema("investigation", investigation);
  return investigation;
}

function reportText(value: string): string {
  return value.replaceAll(/\s+/gu, " ").replaceAll("|", "\\|").trim();
}

function idList(values: readonly string[]): string {
  return values.length === 0 ? "—" : values.join(", ");
}

const PRESENTATION_LIMITS = {
  signals: 8,
  hypotheses: 3,
  contradictions: 8,
  gaps: 8,
  checks: 8,
  owners: 8,
  criteria: 8,
  contradictionEvidenceIds: 16,
  evidenceIds: 64,
  contradictionIds: 64,
} as const;

interface SignalCandidate {
  evidence: EvidenceEnvelope;
  kind: NormalizedValue["kind"];
  label: string;
  value: JsonPrimitive;
  unit?: string;
  dimensions: Record<string, string>;
  evaluatedAt: string;
}

function bounded<T>(values: readonly T[], limit: number): T[] {
  return values.slice(0, limit);
}

function omittedCount(values: readonly unknown[], limit: number): number {
  return Math.max(0, values.length - limit);
}

function boundedDimensions(dimensions: Readonly<Record<string, string>>): Record<string, string> {
  return Object.fromEntries(
    Object.entries(dimensions)
      .sort(([left], [right]) => left.localeCompare(right))
      .slice(0, 8),
  );
}

function sortedDimensions(dimensions: Readonly<Record<string, string>>): Record<string, string> {
  return Object.fromEntries(
    Object.entries(dimensions).sort(([left], [right]) => left.localeCompare(right)),
  );
}

function eventDimensions(
  attributes: Readonly<Record<string, JsonPrimitive>>,
): Record<string, string> {
  return sortedDimensions(
    Object.fromEntries(
      Object.entries(attributes).map(([key, value]) => [key, value === null ? "null" : String(value)]),
    ),
  );
}

function latestPoint(value: Extract<NormalizedValue, { kind: "TIMESERIES" }>) {
  return [...value.points].sort((left, right) =>
    left.at.localeCompare(right.at),
  ).at(-1);
}

function signalCandidates(evidence: readonly EvidenceEnvelope[]): SignalCandidate[] {
  return evidence.flatMap((envelope) =>
    envelope.values.map((value): SignalCandidate => {
      switch (value.kind) {
        case "SCALAR":
          return {
            evidence: envelope,
            kind: value.kind,
            label: value.name,
            value: value.value,
            ...(value.unit === undefined ? {} : { unit: value.unit }),
            dimensions: sortedDimensions(value.dimensions),
            evaluatedAt: value.observedAt ?? envelope.evaluatedAt,
          };
        case "TIMESERIES": {
          const point = latestPoint(value);
          return {
            evidence: envelope,
            kind: value.kind,
            label: value.name,
            value: point?.value ?? null,
            ...(value.unit === undefined ? {} : { unit: value.unit }),
            dimensions: sortedDimensions(value.dimensions),
            evaluatedAt: point?.at ?? envelope.evaluatedAt,
          };
        }
        case "TABLE":
          return {
            evidence: envelope,
            kind: value.kind,
            label: value.name,
            value: value.rows.length,
            unit: value.rows.length === 1 ? "row" : "rows",
            dimensions: {},
            evaluatedAt: envelope.evaluatedAt,
          };
        case "EVENT":
          return {
            evidence: envelope,
            kind: value.kind,
            label: value.name,
            value: value.summary,
            dimensions: eventDimensions(value.attributes),
            evaluatedAt: value.occurredAt,
          };
      }
    }),
  );
}

function signalSortKey(signal: SignalCandidate): string {
  return [
    signal.evidence.operationId,
    signal.evidence.source.sourceAlias,
    signal.kind,
    signal.label,
    canonicalJson(signal.dimensions),
    signal.evaluatedAt,
    signal.evidence.evidenceId,
  ].join("\u0000");
}

function signalPairKey(signal: SignalCandidate): string {
  return [
    signal.evidence.operationId,
    signal.evidence.source.sourceAlias,
    signal.kind,
    signal.label,
    signal.unit ?? "",
    canonicalJson(signal.dimensions),
  ].join("\u0000");
}

function formatNumber(value: number): string {
  if (!Number.isFinite(value)) return String(value);
  if (Object.is(value, -0)) return "0";
  const absolute = Math.abs(value);
  if (absolute !== 0 && (absolute >= 1_000_000 || absolute < 0.0001)) {
    return value.toExponential(3).replace(/\.0+(?=e)/u, "").replace(/(\.\d*?)0+(?=e)/u, "$1");
  }
  return Number(value.toFixed(4)).toLocaleString("en-US", { maximumFractionDigits: 4 });
}

function formatValue(value: JsonPrimitive, unit?: string): string {
  if (value === null) return "No value";
  if (typeof value !== "number") return String(value);
  if (unit?.toLowerCase() === "ratio") return `${formatNumber(value * 100)}%`;
  if (["percent", "percentage", "%"].includes(unit?.toLowerCase() ?? "")) {
    return `${formatNumber(value)}%`;
  }
  return `${formatNumber(value)}${unit === undefined ? "" : ` ${unit}`}`;
}

function signalChange(
  current: SignalCandidate,
  baseline: SignalCandidate,
): IncidentPresentationSignal["change"] | undefined {
  if (typeof current.value !== "number" || typeof baseline.value !== "number") return undefined;
  const value = current.value - baseline.value;
  const normalizedUnit = current.unit?.toLowerCase();
  if (normalizedUnit === "ratio") {
    const percentagePoints = value * 100;
    return {
      value,
      displayValue: `${percentagePoints >= 0 ? "+" : ""}${formatNumber(percentagePoints)} percentage points`,
      unit: "ratio",
    };
  }
  if (["percent", "percentage", "%"].includes(normalizedUnit ?? "")) {
    return {
      value,
      displayValue: `${value >= 0 ? "+" : ""}${formatNumber(value)} percentage points`,
      ...(current.unit === undefined ? {} : { unit: current.unit }),
    };
  }
  return {
    value,
    displayValue: `${value >= 0 ? "+" : ""}${formatValue(value, current.unit)}`,
    ...(current.unit === undefined ? {} : { unit: current.unit }),
  };
}

function isWindow(value: EvidenceEnvelope["window"], expected: EvidenceEnvelope["window"]): boolean {
  return canonicalJson(value) === canonicalJson(expected);
}

function presentationSignals(
  input: Pick<FinalizeBundleInput, "request" | "evidence">,
): { all: IncidentPresentationSignal[]; visible: IncidentPresentationSignal[] } {
  const baselineEvidence = input.request.baselineWindow === undefined
    ? []
    : input.evidence.filter((item) => isWindow(item.window, input.request.baselineWindow!));
  const exactCurrent = input.evidence.filter((item) => isWindow(item.window, input.request.window));
  const currentEvidence = exactCurrent.length > 0
    ? exactCurrent
    : input.evidence.filter((item) => !baselineEvidence.includes(item));
  const baselineByKey = new Map<string, SignalCandidate>();
  for (const signal of signalCandidates(baselineEvidence).sort((left, right) =>
    signalSortKey(left).localeCompare(signalSortKey(right)),
  )) {
    baselineByKey.set(signalPairKey(signal), signal);
  }

  const all = signalCandidates(currentEvidence)
    .sort((left, right) => signalSortKey(left).localeCompare(signalSortKey(right)))
    .map((current): IncidentPresentationSignal => {
      const baseline = baselineByKey.get(signalPairKey(current));
      const change = baseline === undefined ? undefined : signalChange(current, baseline);
      return {
        label: current.label,
        value: current.value,
        displayValue: formatValue(current.value, current.unit),
        ...(current.unit === undefined ? {} : { unit: current.unit }),
        dimensions: boundedDimensions(current.dimensions),
        freshness: current.evidence.freshnessState,
        evaluatedAt: current.evaluatedAt,
        maxAgeMs: current.evidence.maxAcceptableAgeMs,
        source: {
          provider: current.evidence.source.provider,
          alias: current.evidence.source.sourceAlias,
          authority: current.evidence.authority,
        },
        ...(baseline === undefined
          ? {}
          : {
              baseline: {
                value: baseline.value,
                displayValue: formatValue(baseline.value, baseline.unit),
                evaluatedAt: baseline.evaluatedAt,
                technicalDetails: { evidenceId: baseline.evidence.evidenceId },
              },
            }),
        ...(change === undefined ? {} : { change }),
        technicalDetails: {
          evidenceId: current.evidence.evidenceId,
          operationId: current.evidence.operationId,
        },
      };
    });
  return { all, visible: bounded(all, PRESENTATION_LIMITS.signals) };
}

function collectionSummary(state: Coverage["overall"]): string {
  switch (state) {
    case "COMPLETE":
      return "All required evidence operations produced available normalized evidence.";
    case "PARTIAL":
      return "Some required evidence is missing, stale, contradictory, empty, or unavailable.";
    case "UNKNOWN":
      return "No required evidence operation was available to assess.";
  }
}

function causalConclusion(investigation: Investigation): {
  state: IncidentCausalConclusion;
  summary: string;
} {
  if (investigation.analysisState === "EVIDENCE_ONLY") {
    return {
      state: "NOT_ASSESSED",
      summary: "Evidence was collected, but no causal analysis was submitted.",
    };
  }
  if (investigation.hypotheses.some((item) => item.status === "SUPPORTED")) {
    return {
      state: "SUPPORTED",
      summary: "The cited evidence supports at least one hypothesis; this is not proof of root cause.",
    };
  }
  if (investigation.hypotheses.some((item) => item.status === "OPEN")) {
    return {
      state: "OPEN",
      summary: "Causal hypotheses remain open; collection completeness does not establish cause.",
    };
  }
  return {
    state: "INCONCLUSIVE",
    summary: "The submitted analysis did not establish a supported causal explanation.",
  };
}

function recoverySummary(investigation: Investigation): string {
  if (investigation.verificationResult !== undefined) {
    return investigation.verificationResult.status === "PASSED"
      ? "The sealed recovery criteria passed in the verification evidence."
      : investigation.verificationResult.status === "FAILED"
        ? "The sealed recovery criteria did not pass."
        : "Recovery verification was incomplete.";
  }
  if (investigation.verificationContract !== undefined) {
    return "Recovery criteria are sealed but have not been evaluated in a verification run.";
  }
  if (investigation.recoveryState === "NONE") {
    return "Not assessed: no recovery criteria were sealed for this run.";
  }
  return `Recovery is ${investigation.recoveryState.toLowerCase().replaceAll("_", " ")}.`;
}

function verificationState(investigation: Investigation): IncidentPresentation["verification"]["state"] {
  if (investigation.verificationResult !== undefined) return investigation.verificationResult.status;
  return investigation.verificationContract === undefined ? "NOT_CONFIGURED" : "PENDING";
}

function verificationSummary(investigation: Investigation): string {
  const state = verificationState(investigation);
  switch (state) {
    case "NOT_CONFIGURED":
      return "No recovery criteria were sealed; recovery is not assessed.";
    case "PENDING":
      return "Recovery criteria are sealed and awaiting a verification result.";
    case "PASSED":
      return "All sealed recovery criteria passed.";
    case "FAILED":
      return "One or more sealed recovery criteria failed.";
    case "INCOMPLETE":
      return "The sealed recovery criteria could not be fully evaluated.";
  }
}

function independentEvidenceCount(
  evidence: readonly EvidenceEnvelope[],
  evidenceIds: readonly EvidenceId[],
): number {
  const evidenceById = new Map(evidence.map((envelope) => [envelope.evidenceId, envelope]));
  return new Set(evidenceIds.map((id) => {
    const envelope = evidenceById.get(id);
    return envelope === undefined ? `missing:${id}` : evidenceSourceIndependenceKey(envelope);
  })).size;
}

export function incidentPresentation(
  input: Pick<FinalizeBundleInput, "runId" | "request" | "profile" | "evidence" | "contradictions">,
  investigation: Investigation,
  coverage: Coverage,
): IncidentPresentation {
  const { all: allSignals, visible: signals } = presentationSignals(input);
  const allHypotheses = [...investigation.hypotheses].sort(
    (left, right) => left.rank - right.rank || left.hypothesisId.localeCompare(right.hypothesisId),
  );
  const hypotheses = bounded(allHypotheses, PRESENTATION_LIMITS.hypotheses).map((item) => ({
    rank: item.rank,
    statement: item.statement,
    status: item.status,
    rationale: item.rationale,
    ...(item.nextCheck === undefined ? {} : { nextCheck: item.nextCheck }),
    supportingEvidenceCount: independentEvidenceCount(input.evidence, item.supportingEvidenceIds),
    contradictingEvidenceCount: independentEvidenceCount(input.evidence, item.contradictingEvidenceIds),
    technicalDetails: { hypothesisId: item.hypothesisId },
  }));
  const allContradictions = [...input.contradictions].sort((left, right) =>
    left.contradictionId.localeCompare(right.contradictionId),
  );
  const contradictions = bounded(allContradictions, PRESENTATION_LIMITS.contradictions).map((item) => {
    const allEvidenceIds = sortedUnique(item.claimRefs.map((claim) => claim.evidenceId));
    return {
      summary: item.summary,
      resolutionState: item.resolutionState,
      evidenceCount: independentEvidenceCount(input.evidence, allEvidenceIds),
      technicalDetails: {
        contradictionId: item.contradictionId,
        evidenceIds: bounded(allEvidenceIds, PRESENTATION_LIMITS.contradictionEvidenceIds),
        omittedEvidenceIds: omittedCount(
          allEvidenceIds,
          PRESENTATION_LIMITS.contradictionEvidenceIds,
        ),
      },
    };
  });
  const allGaps = sortedUnique([
    ...investigation.missingEvidence,
    ...investigation.remainingUncertainty,
  ]);
  const allChecks = sortedUnique(investigation.checksPerformed);
  const allOwners = sortedUnique(investigation.owners);
  const allCriteria = [...(investigation.verificationContract?.criteria ?? [])].sort((left, right) =>
    left.criterionId.localeCompare(right.criterionId),
  );
  const criteria = bounded(allCriteria, PRESENTATION_LIMITS.criteria).map((criterion) => ({
    label: criterion.valueSelector.name,
    comparator: criterion.comparator,
    expected: criterion.expected,
    displayExpected: formatValue(criterion.expected, criterion.unit),
    ...(criterion.unit === undefined ? {} : { unit: criterion.unit }),
    maxAgeMs: criterion.maxEvidenceAgeMs,
    ...(criterion.requiredDurationSeconds === undefined
      ? {}
      : { requiredDurationSeconds: criterion.requiredDurationSeconds }),
    technicalDetails: {
      criterionId: criterion.criterionId,
      operationId: criterion.operationId,
      operationDefinitionSha256: criterion.operationDefinitionSha256,
    },
  }));
  const dispositions: CoverageDisposition[] = [
    "AVAILABLE",
    "EMPTY",
    "STALE",
    "CONTRADICTORY",
    "ERROR",
    "UNSUPPORTED",
    "DEFERRED",
  ];
  const byDisposition = Object.fromEntries(
    dispositions.map((disposition) => [
      disposition,
      coverage.entries.filter((entry) => entry.disposition === disposition).length,
    ]),
  ) as Record<CoverageDisposition, number>;
  const requiredEntries = coverage.entries.filter((entry) => entry.requirement === "REQUIRED");
  const evidenceIds = sortedUnique(input.evidence.map((item) => item.evidenceId));
  const contradictionIds = sortedUnique(input.contradictions.map((item) => item.contradictionId));
  const verificationResult = investigation.verificationResult;
  const contract = investigation.verificationContract;

  return {
    schemaVersion: "1.0.0",
    origin: input.request.origin,
    workflow: input.request.workflow,
    profile: input.profile.profileAlias,
    scope: investigation.scope,
    window: {
      requested: input.request.window,
      evaluated: investigation.evaluatedWindow,
      ...(input.request.baselineWindow === undefined
        ? {}
        : { baseline: input.request.baselineWindow }),
    },
    collectionStatus: {
      state: coverage.overall,
      summary: collectionSummary(coverage.overall),
      evidenceCount: input.evidence.length,
      freshEvidenceCount: input.evidence.filter((item) => item.freshnessState === "FRESH").length,
      requiredOperationCount: requiredEntries.length,
      availableRequiredOperationCount: requiredEntries.filter(
        (item) => item.disposition === "AVAILABLE",
      ).length,
    },
    causalConclusion: causalConclusion(investigation),
    recoveryState: {
      state: investigation.recoveryState,
      summary: recoverySummary(investigation),
    },
    signals,
    hypotheses,
    contradictions,
    gaps: bounded(allGaps, PRESENTATION_LIMITS.gaps),
    checks: bounded(allChecks, PRESENTATION_LIMITS.checks),
    owners: bounded(allOwners, PRESENTATION_LIMITS.owners),
    approval: {
      required: investigation.approvalRequired,
      summary: investigation.approvalRequired
        ? "Explicit operator approval is required before the proposed action."
        : "No runtime-changing action is requested by this investigation.",
    },
    verification: {
      state: verificationState(investigation),
      summary: verificationSummary(investigation),
      ...(contract === undefined ? {} : { policyAlias: contract.policyAlias }),
      criteria,
      ...(verificationResult === undefined
        ? {}
        : {
            result: {
              status: verificationResult.status,
              evidenceCount: new Set(verificationResult.evidenceIds).size,
            },
          }),
    },
    nextSafeStep: investigation.smallestSafeNextStep,
    coverage: {
      state: coverage.overall,
      summary: collectionSummary(coverage.overall),
      byDisposition,
      blockedRequiredOperationCount: requiredEntries.filter((item) => item.blocksWorkflow).length,
    },
    technicalDetails: {
      runId: input.runId,
      investigationStatus: investigation.status,
      evidenceIds: bounded(evidenceIds, PRESENTATION_LIMITS.evidenceIds),
      contradictionIds: bounded(contradictionIds, PRESENTATION_LIMITS.contradictionIds),
      ...(contract === undefined ? {} : { verificationContractSha256: contract.contractSha256 }),
      omitted: {
        signals: omittedCount(allSignals, PRESENTATION_LIMITS.signals),
        hypotheses: omittedCount(allHypotheses, PRESENTATION_LIMITS.hypotheses),
        contradictions: omittedCount(allContradictions, PRESENTATION_LIMITS.contradictions),
        gaps: omittedCount(allGaps, PRESENTATION_LIMITS.gaps),
        checks: omittedCount(allChecks, PRESENTATION_LIMITS.checks),
        owners: omittedCount(allOwners, PRESENTATION_LIMITS.owners),
        criteria: omittedCount(allCriteria, PRESENTATION_LIMITS.criteria),
        evidenceIds: omittedCount(evidenceIds, PRESENTATION_LIMITS.evidenceIds),
        contradictionIds: omittedCount(
          contradictionIds,
          PRESENTATION_LIMITS.contradictionIds,
        ),
      },
    },
  };
}

function formatDuration(milliseconds: number): string {
  if (milliseconds === 0) return "0 ms";
  if (milliseconds % 3_600_000 === 0) return `${milliseconds / 3_600_000} h`;
  if (milliseconds % 60_000 === 0) return `${milliseconds / 60_000} min`;
  if (milliseconds % 1_000 === 0) return `${milliseconds / 1_000} s`;
  return `${milliseconds} ms`;
}

function dimensionsText(dimensions: Readonly<Record<string, string>>): string {
  const entries = Object.entries(dimensions).sort(([left], [right]) => left.localeCompare(right));
  return entries.length === 0
    ? "—"
    : entries.map(([key, value]) => `${reportText(key)}=${reportText(value)}`).join(", ");
}

function comparatorText(comparator: string): string {
  return ({
    LT: "<",
    LTE: "≤",
    GT: ">",
    GTE: "≥",
    EQ: "=",
    INACTIVE: "inactive",
    ACTIVE: "active",
  } as Record<string, string>)[comparator] ?? comparator;
}

function recoveryDisplayState(presentation: IncidentPresentation): string {
  return presentation.recoveryState.state === "NONE" &&
    presentation.verification.state === "NOT_CONFIGURED"
    ? "NOT ASSESSED"
    : presentation.recoveryState.state;
}

export function renderIncidentReport(
  input: Pick<FinalizeBundleInput, "runId" | "request" | "profile" | "evidence" | "contradictions">,
  investigation: Investigation,
  coverage: Coverage,
): string {
  const presentation = incidentPresentation(input, investigation, coverage);
  const lines = [
    "# Production Monitoring Incident Report",
    "",
    ...(presentation.origin === "SIMULATED"
      ? ["> **SIMULATED EVIDENCE** — This report does not describe live production state.", ""]
      : [`> Evidence origin: **${presentation.origin}**.`, ""]),
    "## Incident at a glance",
    "",
    `- Evidence collection: **${presentation.collectionStatus.state}** — ${reportText(presentation.collectionStatus.summary)}`,
    `- Causal conclusion: **${presentation.causalConclusion.state}** — ${reportText(presentation.causalConclusion.summary)}`,
    `- Recovery: **${recoveryDisplayState(presentation)}** — ${reportText(presentation.recoveryState.summary)}`,
    `- Approval: **${presentation.approval.required ? "REQUIRED" : "NOT REQUESTED"}** — ${reportText(presentation.approval.summary)}`,
    "",
    `- Workflow: \`${presentation.workflow}\``,
    `- Origin: \`${presentation.origin}\``,
    `- Profile: \`${reportText(presentation.profile)}\``,
    `- Scope: \`${reportText(JSON.stringify(presentation.scope))}\``,
    `- Requested window: \`${presentation.window.requested.start}\` to \`${presentation.window.requested.end}\``,
    ...(presentation.window.baseline === undefined
      ? []
      : [
          `- Baseline window: \`${presentation.window.baseline.start}\` to \`${presentation.window.baseline.end}\``,
        ]),
    "",
    "## Signal summary",
    "",
    "| Signal | Current | Baseline | Change | Dimensions | Freshness | Evaluated at | Max age | Source |",
    "| --- | ---: | ---: | ---: | --- | --- | --- | ---: | --- |",
  ];

  for (const signal of presentation.signals) {
    lines.push(
      `| ${reportText(signal.label)} | ${reportText(signal.displayValue)} | ${signal.baseline === undefined ? "—" : reportText(signal.baseline.displayValue)} | ${signal.change === undefined ? "—" : reportText(signal.change.displayValue)} | ${dimensionsText(signal.dimensions)} | ${signal.freshness} | \`${signal.evaluatedAt}\` | ${formatDuration(signal.maxAgeMs)} | ${reportText(signal.source.provider)}/${reportText(signal.source.alias)} (${signal.source.authority}) |`,
    );
  }
  if (presentation.signals.length === 0) {
    lines.push("| No normalized values were available. | — | — | — | — | — | — | — | — |");
  }
  if (presentation.technicalDetails.omitted.signals > 0) {
    lines.push(
      "",
      `_Signal view is bounded; ${presentation.technicalDetails.omitted.signals} additional normalized value(s) remain in the canonical evidence._`,
    );
  }

  lines.push("", "## Observations", "");
  for (const observation of [...investigation.observations].sort((left, right) =>
    left.observationId.localeCompare(right.observationId),
  )) {
    lines.push(
      `- ${reportText(observation.statement)} _(${independentEvidenceCount(input.evidence, observation.evidenceIds)} independent cited source(s))_`,
    );
  }
  if (investigation.observations.length === 0) lines.push("- No evidence-backed observations.");

  lines.push("", "## Ranked hypotheses", "");
  for (const hypothesis of [...investigation.hypotheses].sort(
    (left, right) => left.rank - right.rank || left.hypothesisId.localeCompare(right.hypothesisId),
  )) {
    lines.push(
      `${hypothesis.rank}. **${hypothesis.status}:** ${reportText(hypothesis.statement)} ` +
        `_${independentEvidenceCount(input.evidence, hypothesis.supportingEvidenceIds)} supporting; ${independentEvidenceCount(input.evidence, hypothesis.contradictingEvidenceIds)} contradicting independent source(s)._`,
      `   - Rationale: ${reportText(hypothesis.rationale)}`,
      ...(hypothesis.nextCheck === undefined
        ? []
        : [`   - Next check: ${reportText(hypothesis.nextCheck)}`]),
    );
  }
  if (investigation.hypotheses.length === 0) lines.push("- No ranked hypotheses.");

  lines.push("", "## Contradictions", "");
  for (const contradiction of presentation.contradictions) {
    lines.push(
      `- **${contradiction.resolutionState}:** ${reportText(contradiction.summary)} _(${contradiction.evidenceCount} cited evidence item(s))_`,
    );
  }
  if (input.contradictions.length === 0) lines.push("- No cross-source contradictions recorded.");

  lines.push("", "## Recovery criteria and result", "");
  if (presentation.verification.criteria.length === 0) {
    lines.push(`- **${presentation.verification.state}:** ${reportText(presentation.verification.summary)}`);
  } else {
    lines.push(
      `- Policy: \`${reportText(presentation.verification.policyAlias ?? "sealed-policy")}\``,
      `- Result: **${presentation.verification.state}** — ${reportText(presentation.verification.summary)}`,
      "",
      "| Criterion | Condition | Max age | Required duration |",
      "| --- | --- | ---: | ---: |",
    );
    for (const criterion of presentation.verification.criteria) {
      lines.push(
        `| ${reportText(criterion.label)} | ${comparatorText(criterion.comparator)} ${reportText(criterion.displayExpected)} | ${formatDuration(criterion.maxAgeMs)} | ${criterion.requiredDurationSeconds === undefined ? "—" : `${criterion.requiredDurationSeconds} s`} |`,
      );
    }
  }

  lines.push(
    "",
    "## Evidence coverage",
    "",
    "| Operation | Domain | Requirement | Disposition | Evidence count | Contradiction count |",
    "| --- | --- | --- | --- | ---: | ---: |",
  );
  for (const entry of [...coverage.entries].sort((left, right) =>
    left.operationId.localeCompare(right.operationId),
  )) {
    lines.push(
      `| ${reportText(entry.operationId)} | ${entry.domain} | ${entry.requirement} | ${entry.disposition} | ${entry.evidenceIds.length} | ${entry.contradictionIds.length} |`,
    );
  }

  lines.push("", "## Checks performed", "");
  for (const check of presentation.checks) lines.push(`- ${reportText(check)}`);
  if (presentation.checks.length === 0) lines.push("- No analysis checks recorded.");

  lines.push("", "## Remaining uncertainty", "");
  for (const uncertainty of presentation.gaps) lines.push(`- ${reportText(uncertainty)}`);
  if (presentation.gaps.length === 0) lines.push("- None recorded.");

  lines.push("", "## Ownership and approval", "");
  lines.push(
    `- Owners: ${presentation.owners.length === 0 ? "Not assigned." : presentation.owners.map(reportText).join(", ")}`,
    `- Approval: ${reportText(presentation.approval.summary)}`,
  );

  lines.push(
    "",
    "## Smallest safe next step",
    "",
    reportText(presentation.nextSafeStep),
    "",
    "<details>",
    "<summary>Technical details and evidence references</summary>",
    "",
    `- Run: \`${presentation.technicalDetails.runId}\``,
    `- Runtime investigation status: \`${presentation.technicalDetails.investigationStatus}\``,
    `- Evidence IDs: ${idList(presentation.technicalDetails.evidenceIds)}`,
    `- Contradiction IDs: ${idList(presentation.technicalDetails.contradictionIds)}`,
    ...(presentation.technicalDetails.verificationContractSha256 === undefined
      ? []
      : [
          `- Verification contract SHA-256: \`${presentation.technicalDetails.verificationContractSha256}\``,
        ]),
    "",
    "</details>",
    "",
    "---",
    "This report is a deterministic projection of normalized, cited evidence. It does not retain raw provider responses.",
    "",
  );
  return lines.join("\n");
}

export function prepareArtifacts(input: FinalizeBundleInput): PreparedArtifacts {
  validateSourceInput(input);
  const coverage = deriveArtifactCoverage(input);
  assertSchema("coverage", coverage);
  const investigation = deriveInvestigation(input, coverage);
  const operations = [...input.operations].sort((left, right) =>
    left.operationId.localeCompare(right.operationId),
  );
  // Evidence is stored as evidence/<evidenceId>.json and manifest entries are
  // canonicalized by path. Keep the in-memory projection in that same order so
  // validation is independent of the operation/evidence insertion order.
  const evidence = [...input.evidence].sort((left, right) =>
    left.evidenceId.localeCompare(right.evidenceId),
  );
  const contradictions = [...input.contradictions].sort((left, right) =>
    left.contradictionId.localeCompare(right.contradictionId),
  );
  return {
    request: input.request,
    profile: input.profile,
    operations,
    evidence,
    contradictions,
    investigation,
    coverage,
    report: renderIncidentReport(input, investigation, coverage),
  };
}

export function validatePreparedArtifacts(
  input: FinalizeBundleInput,
  actual: PreparedArtifacts,
): void {
  const expected = prepareArtifacts(input);
  for (const key of [
    "request",
    "profile",
    "operations",
    "evidence",
    "contradictions",
    "investigation",
    "coverage",
  ] as const) {
    assertEqual(actual[key], expected[key], `Artifact ${key} is not canonical for this run`);
  }
  if (actual.report !== expected.report) throw new TypeError("Incident report is not deterministic");
}

export function assertParentVerificationContract(
  child: FinalizeBundleInput,
  parentInvestigation: Investigation,
): void {
  if (child.request.parentRunId === undefined) return;
  if (child.request.parentRunId === child.runId) throw new TypeError("A run cannot be its own parent");
  if (child.request.workflow !== "verify") return;
  const parentContract = parentInvestigation.verificationContract;
  if (parentContract === undefined) {
    throw new TypeError("Verification child requires a sealed parent verification contract");
  }
  if (child.investigation.verificationContract === undefined) {
    throw new TypeError("Verification child must snapshot the parent verification contract");
  }
  assertEqual(
    child.investigation.verificationContract,
    parentContract,
    "Verification child cannot change the sealed parent verification contract",
  );
}

export function assertManifestIdentity(
  manifest: { bundleId: BundleId; runId: RunId; parentRunId?: RunId },
  bundleId: BundleId,
  runId: RunId,
  parentRunId: RunId | undefined,
): void {
  if (manifest.bundleId !== bundleId || manifest.runId !== runId) {
    throw new TypeError("Manifest identity does not match the bundle contents");
  }
  if (manifest.parentRunId !== parentRunId) {
    throw new TypeError("Manifest parent identity does not match the request");
  }
}

export function asBundleId(value: string): BundleId {
  if (!BUNDLE_ID.test(value)) throw new TypeError("Invalid bundleId");
  return value as BundleId;
}

/** Stable immutable-artifact identity for a run. */
export function bundleIdForRunId(runId: RunId): BundleId {
  if (!RUN_ID.test(runId)) throw new TypeError("Invalid runId");
  return `pmbundle_${sha256Canonical({ domain: "pm-bundle-v1", runId }).slice(0, 40)}` as BundleId;
}

export function asRunId(value: string): RunId {
  if (!RUN_ID.test(value)) throw new TypeError("Invalid runId");
  return value as RunId;
}

export function asContradictionId(value: string): ContradictionId {
  return value as ContradictionId;
}
