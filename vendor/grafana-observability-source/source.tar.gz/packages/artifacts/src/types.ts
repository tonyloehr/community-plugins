import type {
  BundleId,
  BundleManifest,
  ContradictionRecord,
  Coverage,
  CoverageDisposition,
  EvidenceEnvelope,
  EvidenceId,
  FreshnessState,
  Investigation,
  JsonPrimitive,
  OperationId,
  OperationSnapshot,
  RecoveryState,
  RunId,
  Sha256,
  SourceAuthority,
  TimeWindow,
  TrustedProfile,
  VerificationCriterion,
  WorkflowRequest,
} from "../../contracts/src/index.ts";

export interface ArtifactProducer {
  pluginVersion: string;
  contractsVersion: string;
  reportProjectionVersion: string;
}

export type InvestigationDraft = Omit<
  Investigation,
  "schemaVersion" | "runId" | "status" | "contradictionIds" | "integrity"
>;

export interface FinalizeBundleInput {
  bundleId: BundleId;
  runId: RunId;
  createdAt: string;
  request: WorkflowRequest;
  profile: TrustedProfile;
  operations: OperationSnapshot[];
  evidence: EvidenceEnvelope[];
  contradictions: ContradictionRecord[];
  investigation: InvestigationDraft;
}

export interface ArtifactStoreOptions {
  root: string;
  now?: () => Date;
  producer?: Partial<ArtifactProducer>;
}

/** Returned only after an exact, fully receipted marker-bound artifact tree has been removed. */
export interface ArtifactRootDeletionReceipt {
  schemaVersion: "1.0.0";
  action: "ARTIFACT_ROOT_DELETED";
  rootId: string;
  rootPath: string;
  deletedAt: string;
}

export interface ValidatedBundle {
  bundleId: BundleId;
  runId: RunId;
  path: string;
  manifest: BundleManifest;
  manifestSha256: Sha256;
  request: WorkflowRequest;
  profile: TrustedProfile;
  operations: OperationSnapshot[];
  evidence: EvidenceEnvelope[];
  contradictions: ContradictionRecord[];
  investigation: Investigation;
  coverage: Coverage;
  report: string;
}

export interface FinalizationResult extends ValidatedBundle {
  created: true;
}

export type IncidentCausalConclusion =
  | "NOT_ASSESSED"
  | "OPEN"
  | "SUPPORTED"
  | "INCONCLUSIVE";

export interface IncidentPresentationSignal {
  label: string;
  value: JsonPrimitive;
  displayValue: string;
  unit?: string;
  dimensions: Record<string, string>;
  freshness: FreshnessState;
  evaluatedAt: string;
  maxAgeMs: number;
  source: {
    provider: string;
    alias: string;
    authority: SourceAuthority;
  };
  baseline?: {
    value: JsonPrimitive;
    displayValue: string;
    evaluatedAt: string;
    technicalDetails: {
      evidenceId: EvidenceId;
    };
  };
  change?: {
    value: number;
    displayValue: string;
    unit?: string;
  };
  technicalDetails: {
    evidenceId: EvidenceId;
    operationId: OperationId;
  };
}

export interface IncidentPresentationHypothesis {
  rank: number;
  statement: string;
  status: Investigation["hypotheses"][number]["status"];
  rationale: string;
  nextCheck?: string;
  supportingEvidenceCount: number;
  contradictingEvidenceCount: number;
  technicalDetails: {
    hypothesisId: string;
  };
}

export interface IncidentPresentationContradiction {
  summary: string;
  resolutionState: ContradictionRecord["resolutionState"];
  evidenceCount: number;
  technicalDetails: {
    contradictionId: ContradictionRecord["contradictionId"];
    evidenceIds: EvidenceId[];
    omittedEvidenceIds: number;
  };
}

export interface IncidentPresentationVerificationCriterion {
  label: string;
  comparator: VerificationCriterion["comparator"];
  expected: JsonPrimitive;
  displayExpected: string;
  unit?: string;
  maxAgeMs: number;
  requiredDurationSeconds?: number;
  technicalDetails: {
    criterionId: string;
    operationId: OperationId;
    operationDefinitionSha256: Sha256;
  };
}

export interface IncidentPresentation {
  schemaVersion: "1.0.0";
  origin: WorkflowRequest["origin"];
  workflow: WorkflowRequest["workflow"];
  profile: string;
  scope: Investigation["scope"];
  window: {
    requested: TimeWindow;
    evaluated: TimeWindow;
    baseline?: TimeWindow;
  };
  collectionStatus: {
    state: Coverage["overall"];
    summary: string;
    evidenceCount: number;
    freshEvidenceCount: number;
    requiredOperationCount: number;
    availableRequiredOperationCount: number;
  };
  causalConclusion: {
    state: IncidentCausalConclusion;
    summary: string;
  };
  recoveryState: {
    state: RecoveryState;
    summary: string;
  };
  signals: IncidentPresentationSignal[];
  hypotheses: IncidentPresentationHypothesis[];
  contradictions: IncidentPresentationContradiction[];
  gaps: string[];
  checks: string[];
  owners: string[];
  approval: {
    required: boolean;
    summary: string;
  };
  verification: {
    state: "NOT_CONFIGURED" | "PENDING" | "PASSED" | "FAILED" | "INCOMPLETE";
    summary: string;
    policyAlias?: string;
    criteria: IncidentPresentationVerificationCriterion[];
    result?: {
      status: "PASSED" | "FAILED" | "INCOMPLETE";
      evidenceCount: number;
    };
  };
  nextSafeStep: string;
  coverage: {
    state: Coverage["overall"];
    summary: string;
    byDisposition: Record<CoverageDisposition, number>;
    blockedRequiredOperationCount: number;
  };
  technicalDetails: {
    runId: RunId;
    investigationStatus: Investigation["status"];
    evidenceIds: EvidenceId[];
    contradictionIds: ContradictionRecord["contradictionId"][];
    verificationContractSha256?: Sha256;
    omitted: {
      signals: number;
      hypotheses: number;
      contradictions: number;
      gaps: number;
      checks: number;
      owners: number;
      criteria: number;
      evidenceIds: number;
      contradictionIds: number;
    };
  };
}
