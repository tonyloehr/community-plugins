import { Ajv2020 } from "ajv/dist/2020.js";
import addFormatsImport from "ajv-formats";

import {
  loadSchemaRegistry,
  SCHEMA_IDS,
  type SchemaName,
} from "../../contracts/src/index.ts";

const ajv = new Ajv2020({
  allErrors: true,
  allowUnionTypes: true,
  strict: true,
});
const addFormats = addFormatsImport as unknown as (instance: Ajv2020) => Ajv2020;
addFormats(ajv);
for (const schema of loadSchemaRegistry().values()) ajv.addSchema(schema);

export function assertSchema(name: SchemaName, value: unknown): void {
  const validator = ajv.getSchema(SCHEMA_IDS[name]);
  if (validator === undefined) throw new Error(`Schema is not registered: ${name}`);
  if (!validator(value)) {
    const details = ajv.errorsText(validator.errors, { separator: "; " });
    throw new TypeError(`${name} contract validation failed: ${details}`);
  }
}
