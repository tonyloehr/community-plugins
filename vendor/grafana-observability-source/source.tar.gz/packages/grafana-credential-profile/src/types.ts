import type { WorkerCredentialLease } from "../../adapter-host/src/index.ts";

export type GrafanaNetworkClass = "loopback" | "private" | "public";

export interface GrafanaCredentialReference {
  kind: "broker";
  key: string;
}

export interface SharedGrafanaProfileV1 {
  schemaVersion: "1.0.0";
  profileId: string;
  profileName: string;
  grafanaOrigin: string;
  networkClass: GrafanaNetworkClass;
  credentialRef: GrafanaCredentialReference;
  revision: number;
}

export interface SharedGrafanaProfileRegistryV1 {
  schemaVersion: "1.0.0";
  activeProfileId: string | null;
  profiles: SharedGrafanaProfileV1[];
}

export type GrafanaCredentialStatus = "AVAILABLE" | "MISSING_OR_UNAVAILABLE";

export type SupportedGrafanaKeyringPlatform = "darwin" | "linux";

export type NativeGrafanaKeyringBackendKind = "MACOS_KEYCHAIN" | "LINUX_SECRET_SERVICE";

export interface GrafanaKeyringBackend {
  getSecret(service: string, account: string): Promise<Uint8Array | undefined>;
  setSecret(service: string, account: string, secret: Uint8Array): Promise<void>;
  deleteSecret(service: string, account: string): Promise<boolean>;
}

export interface GrafanaCredentialStore {
  acquire(reference: Readonly<{ kind: string; key: string }>): Promise<WorkerCredentialLease | undefined>;
  set(reference: Readonly<{ kind: string; key: string }>, secret: Uint8Array): Promise<void>;
  status(reference: Readonly<{ kind: string; key: string }>): Promise<GrafanaCredentialStatus>;
  delete(reference: Readonly<{ kind: string; key: string }>): Promise<boolean>;
}

export type GrafanaCredentialLifecycleOperation = "CONNECT" | "ROTATE" | "DELETE";
export type GrafanaCredentialLifecyclePhase = "PREPARED" | "COMMITTED";
export type GrafanaCredentialLifecycleAuthority = "PREVIOUS" | "NEXT" | "INVALID";

export interface GrafanaCredentialLifecycleJournalV1 {
  schemaVersion: "1.0.0";
  operation: GrafanaCredentialLifecycleOperation;
  phase: GrafanaCredentialLifecyclePhase;
  profileId: string;
  previousRevision: number | null;
  previousCredentialRef: GrafanaCredentialReference | null;
  nextRevision: number | null;
  nextCredentialRef: GrafanaCredentialReference | null;
}

export interface SharedGrafanaProfileRegistryTransaction {
  read(): Readonly<SharedGrafanaProfileRegistryV1>;
  readCredentialLifecycleJournal(): Readonly<GrafanaCredentialLifecycleJournalV1> | undefined;
  writeCredentialLifecycleJournal(
    journal: Readonly<GrafanaCredentialLifecycleJournalV1>,
  ): Promise<void>;
  clearCredentialLifecycleJournal(): Promise<void>;
  update(
    mutation: (
      current: Readonly<SharedGrafanaProfileRegistryV1>,
    ) => SharedGrafanaProfileRegistryV1,
  ): Promise<Readonly<SharedGrafanaProfileRegistryV1>>;
}

export interface SharedGrafanaProfileRegistryStore {
  read(): Promise<Readonly<SharedGrafanaProfileRegistryV1>>;
  update(
    mutation: (
      current: Readonly<SharedGrafanaProfileRegistryV1>,
    ) => SharedGrafanaProfileRegistryV1,
  ): Promise<Readonly<SharedGrafanaProfileRegistryV1>>;
  withExclusiveLifecycle<R>(
    operation: (transaction: SharedGrafanaProfileRegistryTransaction) => Promise<R>,
  ): Promise<R>;
}
