import { createHash } from "node:crypto";
import { constants } from "node:fs";
import { chmod, lstat, mkdtemp, open, rmdir, unlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, isAbsolute, join } from "node:path";
import { URL, fileURLToPath } from "node:url";

import {
  NativeKeyringUnavailableError,
  type NativeKeyringModule,
  type NativeKeyringModuleLoader,
  type NativeSecretEntry,
} from "./native-keyring.ts";

const SHA256 = /^[a-f0-9]{64}$/u;
const MAX_NATIVE_ASSET_BYTES = 64 * 1_024 * 1_024;
const MAX_NATIVE_SECRET_BYTES = 16_384;

export interface HashPinnedMacOsKeychainAsset {
  /** A code-owned file URL resolved relative to the signed plugin bundle. */
  readonly fileUrl: URL;
  readonly bytes: number;
  readonly sha256: string;
}

export type NativeAddonImporter = (absolutePath: string) => unknown | Promise<unknown>;

interface RawAsyncEntry {
  // The pinned N-API addon returns null or number[] on macOS despite its .d.ts.
  getSecret(signal?: AbortSignal): Promise<unknown>;
  setSecret(secret: Uint8Array, signal?: AbortSignal): Promise<void>;
  deleteCredential(signal?: AbortSignal): Promise<boolean>;
}

type RawAsyncEntryConstructor = new (service: string, account: string) => RawAsyncEntry;

function defaultNativeAddonImporter(absolutePath: string): unknown {
  const nativeModule = { exports: {} };
  process.dlopen(nativeModule, absolutePath);
  return nativeModule.exports;
}

function record(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function copyNativeSecret(value: unknown): Uint8Array | undefined {
  if (value === undefined || value === null) return undefined;
  if (value instanceof Uint8Array) {
    if (value.byteLength < 1 || value.byteLength > MAX_NATIVE_SECRET_BYTES) throw new NativeKeyringUnavailableError();
    return Uint8Array.from(value);
  }
  if (!Array.isArray(value) || value.length < 1 || value.length > MAX_NATIVE_SECRET_BYTES ||
      Object.getOwnPropertyNames(value).length !== value.length + 1 || Object.getOwnPropertySymbols(value).length !== 0) {
    throw new NativeKeyringUnavailableError();
  }
  const bytes = new Uint8Array(value.length);
  try {
    for (let index = 0; index < value.length; index += 1) {
      const property = Object.getOwnPropertyDescriptor(value, String(index));
      if (property === undefined || !("value" in property) || property.writable !== true ||
          typeof property.value !== "number" || !Number.isInteger(property.value) || property.value < 0 || property.value > 255) {
        throw new NativeKeyringUnavailableError();
      }
      bytes[index] = property.value;
    }
    return bytes;
  } catch (error) {
    bytes.fill(0);
    throw error;
  }
}

function eraseNativeSecret(value: unknown): void {
  try {
    if (value instanceof Uint8Array) {
      Uint8Array.prototype.fill.call(value, 0);
    } else if (Array.isArray(value)) {
      // Do not densify an oversized sparse malformed array or invoke accessors.
      for (const name of Object.getOwnPropertyNames(value)) {
        if (!/^(?:0|[1-9][0-9]*)$/u.test(name) || Number(name) >= value.length) continue;
        const property = Object.getOwnPropertyDescriptor(value, name);
        if (property !== undefined && "value" in property && property.writable === true) {
          Object.defineProperty(value, name, { ...property, value: 0 });
        }
      }
    }
  } catch {
    // Rejected immutable or exotic values cannot be reliably overwritten.
  }
}

function adaptMacOsKeychainAddon(value: unknown): NativeKeyringModule {
  const AsyncEntry = record(value)?.AsyncEntry;
  if (typeof AsyncEntry !== "function") throw new NativeKeyringUnavailableError();
  const Entry = AsyncEntry as RawAsyncEntryConstructor;
  return Object.freeze({
    backendKind: "MACOS_KEYCHAIN" as const,
    createEntry(service: string, account: string): NativeSecretEntry {
      const entry = new Entry(service, account);
      if (
        typeof entry.getSecret !== "function"
        || typeof entry.setSecret !== "function"
        || typeof entry.deleteCredential !== "function"
      ) {
        throw new NativeKeyringUnavailableError();
      }
      return {
        async getSecret(signal?: AbortSignal): Promise<Uint8Array | undefined> {
          let nativeSecret: unknown;
          try {
            nativeSecret = await entry.getSecret(signal);
            return copyNativeSecret(nativeSecret);
          } finally {
            eraseNativeSecret(nativeSecret);
          }
        },
        async setSecret(secret: Uint8Array, signal?: AbortSignal): Promise<void> {
          await entry.setSecret(secret, signal);
        },
        async deleteCredential(signal?: AbortSignal): Promise<boolean> {
          const deleted = await entry.deleteCredential(signal);
          if (typeof deleted !== "boolean") throw new NativeKeyringUnavailableError();
          return deleted;
        },
      };
    },
  });
}

async function readAll(
  handle: Awaited<ReturnType<typeof open>>,
  contents: Buffer,
): Promise<void> {
  let offset = 0;
  while (offset < contents.byteLength) {
    const { bytesRead } = await handle.read(contents, offset, contents.byteLength - offset, offset);
    if (bytesRead === 0) throw new NativeKeyringUnavailableError();
    offset += bytesRead;
  }
}

async function writeAll(
  handle: Awaited<ReturnType<typeof open>>,
  contents: Buffer,
): Promise<void> {
  let offset = 0;
  while (offset < contents.byteLength) {
    const { bytesWritten } = await handle.write(contents, offset, contents.byteLength - offset, offset);
    if (bytesWritten === 0) throw new NativeKeyringUnavailableError();
    offset += bytesWritten;
  }
}

async function readVerifiedAsset(
  absolutePath: string,
  expectedBytes: number,
  expectedSha256: string,
): Promise<Buffer> {
  let contents: Buffer | undefined;
  let handle: Awaited<ReturnType<typeof open>> | undefined;
  try {
    handle = await open(absolutePath, constants.O_RDONLY | constants.O_NOFOLLOW);
    const before = await handle.stat();
    if (!before.isFile() || before.nlink !== 1 || before.size !== expectedBytes) {
      throw new NativeKeyringUnavailableError();
    }
    contents = Buffer.alloc(expectedBytes);
    await readAll(handle, contents);
    const trailing = Buffer.alloc(1);
    const [{ bytesRead }, after] = await Promise.all([
      handle.read(trailing, 0, 1, expectedBytes),
      handle.stat(),
    ]);
    if (
      bytesRead !== 0
      || before.dev !== after.dev
      || before.ino !== after.ino
      || before.size !== after.size
      || createHash("sha256").update(contents).digest("hex") !== expectedSha256
    ) {
      throw new NativeKeyringUnavailableError();
    }
    return contents;
  } catch {
    contents?.fill(0);
    throw new NativeKeyringUnavailableError();
  } finally {
    await handle?.close().catch(() => undefined);
  }
}

async function importPrivateVerifiedCopy(
  source: Buffer,
  filename: string,
  expectedSha256: string,
  importer: NativeAddonImporter,
): Promise<unknown> {
  let directory: string | undefined;
  let stagedPath: string | undefined;
  let handle: Awaited<ReturnType<typeof open>> | undefined;
  try {
    directory = await mkdtemp(join(tmpdir(), "codex-observability-keyring-"));
    await chmod(directory, 0o700);
    const directoryStat = await lstat(directory);
    if (
      !directoryStat.isDirectory()
      || directoryStat.isSymbolicLink()
      || (directoryStat.mode & 0o077) !== 0
      || (typeof process.getuid === "function" && directoryStat.uid !== process.getuid())
    ) {
      throw new NativeKeyringUnavailableError();
    }
    stagedPath = join(directory, filename);
    handle = await open(
      stagedPath,
      constants.O_CREAT | constants.O_EXCL | constants.O_RDWR | constants.O_NOFOLLOW,
      0o400,
    );
    await writeAll(handle, source);
    await handle.sync();
    await handle.chmod(0o400);
    const before = await handle.stat();
    if (!before.isFile() || before.nlink !== 1 || before.size !== source.byteLength) {
      throw new NativeKeyringUnavailableError();
    }
    const verified = Buffer.alloc(source.byteLength);
    try {
      await readAll(handle, verified);
      const after = await handle.stat();
      if (
        before.dev !== after.dev
        || before.ino !== after.ino
        || before.size !== after.size
        || createHash("sha256").update(verified).digest("hex") !== expectedSha256
      ) {
        throw new NativeKeyringUnavailableError();
      }
    } finally {
      verified.fill(0);
    }
    // Loading through the still-open descriptor avoids a verify/dlopen path
    // race. Keep the owner-only inode linked until dlopen finishes: macOS code
    // signing rejects an otherwise valid Mach-O library after it is unlinked.
    // The finally block removes the staged file and directory on either result.
    return await importer(`/dev/fd/${String(handle.fd)}`);
  } catch {
    throw new NativeKeyringUnavailableError();
  } finally {
    await handle?.close().catch(() => undefined);
    if (stagedPath !== undefined) await unlink(stagedPath).catch(() => undefined);
    if (directory !== undefined) await rmdir(directory).catch(() => undefined);
  }
}

/**
 * Loads only the pinned macOS N-API asset. Linux is deliberately unsupported:
 * @napi-rs/keyring 1.3.0 can silently fall back from Secret Service to keyutils.
 */
export class HashPinnedMacOsKeychainLoader implements NativeKeyringModuleLoader {
  readonly #absolutePath: string;
  readonly #filename: string;
  readonly #bytes: number;
  readonly #sha256: string;
  readonly #importer: NativeAddonImporter;
  readonly #platform: NodeJS.Platform;
  readonly #architecture: NodeJS.Architecture;
  #loaded: Promise<NativeKeyringModule> | undefined;

  constructor(options: {
    asset: Readonly<HashPinnedMacOsKeychainAsset>;
    importer?: NativeAddonImporter;
    platform?: NodeJS.Platform;
    architecture?: NodeJS.Architecture;
  }) {
    this.#platform = options.platform ?? process.platform;
    this.#architecture = options.architecture ?? process.arch;
    try {
      this.#absolutePath = fileURLToPath(new URL(options.asset.fileUrl.href));
    } catch {
      throw new NativeKeyringUnavailableError();
    }
    this.#filename = basename(this.#absolutePath);
    this.#bytes = options.asset.bytes;
    this.#sha256 = options.asset.sha256;
    this.#importer = options.importer ?? defaultNativeAddonImporter;
    const expectedFilenames = new Set([
      "keyring.darwin-universal.node",
      `keyring.darwin-${this.#architecture}.node`,
    ]);
    if (
      this.#platform !== "darwin"
      || (this.#architecture !== "arm64" && this.#architecture !== "x64")
      || !isAbsolute(this.#absolutePath)
      || !expectedFilenames.has(this.#filename)
      || !Number.isSafeInteger(this.#bytes)
      || this.#bytes < 1
      || this.#bytes > MAX_NATIVE_ASSET_BYTES
      || !SHA256.test(this.#sha256)
    ) {
      throw new NativeKeyringUnavailableError();
    }
  }

  async load(): Promise<NativeKeyringModule> {
    this.#loaded ??= this.#load().catch(() => {
      this.#loaded = undefined;
      throw new NativeKeyringUnavailableError();
    });
    return this.#loaded;
  }

  async #load(): Promise<NativeKeyringModule> {
    const source = await readVerifiedAsset(this.#absolutePath, this.#bytes, this.#sha256);
    try {
      const addon = await importPrivateVerifiedCopy(
        source,
        this.#filename,
        this.#sha256,
        this.#importer,
      );
      return adaptMacOsKeychainAddon(addon);
    } finally {
      source.fill(0);
    }
  }
}
