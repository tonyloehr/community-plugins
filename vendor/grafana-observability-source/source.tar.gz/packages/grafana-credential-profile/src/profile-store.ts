import { constants, type Stats } from "node:fs";
import { chmod, lstat, mkdir, open, realpath, rename, unlink } from "node:fs/promises";
import { homedir } from "node:os";
import { isAbsolute, join } from "node:path";

import { AtomicStateFile, RunStoreError } from "@codex-production-monitoring/run-store";

import {
  committedGrafanaCredentialLifecycleJournal,
  parseGrafanaCredentialLifecycleJournal,
} from "./lifecycle-journal.ts";
import {
  emptySharedGrafanaProfileRegistry,
  GrafanaProfileError,
  parseSharedGrafanaProfileRegistry,
} from "./profile.ts";
import type {
  GrafanaCredentialLifecycleJournalV1,
  SharedGrafanaProfileRegistryTransaction,
  SharedGrafanaProfileRegistryStore,
  SharedGrafanaProfileRegistryV1,
} from "./types.ts";

const REGISTRY_FILENAME = "grafana-profiles-v1.json";
const REGISTRY_TEMPORARY_FILENAME = `.${REGISTRY_FILENAME}.tmp`;
const LIFECYCLE_COORDINATOR_FILENAME = "grafana-profile-lifecycle-v1";
const LIFECYCLE_COORDINATOR_KIND = "grafana-profile-lifecycle-coordinator-v1";
const LIFECYCLE_JOURNAL_FILENAME = "grafana-credential-lifecycle-journal-v1.json";
const LIFECYCLE_JOURNAL_KIND = "grafana-credential-lifecycle-journal-v1";
const MAX_REGISTRY_BYTES = 262_144;
const MAX_JOURNAL_BYTES = 16_384;

export class GrafanaProfileStoreError extends Error {
  readonly code: "UNSUPPORTED_PLATFORM" | "UNSAFE_STATE" | "STATE_UNAVAILABLE" | "STATE_BUSY";

  constructor(code: GrafanaProfileStoreError["code"]) {
    super("Shared Grafana profile state is unavailable");
    this.name = "GrafanaProfileStoreError";
    this.code = code;
  }
}

export function sharedGrafanaProfileStateRoot(options: {
  platform?: NodeJS.Platform;
  environment?: Readonly<NodeJS.ProcessEnv>;
  homeDirectory?: string;
} = {}): string {
  const platform = options.platform ?? process.platform;
  const environment = options.environment ?? process.env;
  const homeDirectory = options.homeDirectory ?? homedir();
  if (!isAbsolute(homeDirectory)) throw new GrafanaProfileStoreError("UNSAFE_STATE");
  if (platform === "darwin") {
    return join(homeDirectory, "Library", "Application Support", "OpenAI", "Codex Observability");
  }
  if (platform === "linux") {
    const stateHome = environment.XDG_STATE_HOME;
    if (stateHome !== undefined && !isAbsolute(stateHome)) {
      throw new GrafanaProfileStoreError("UNSAFE_STATE");
    }
    return join(stateHome ?? join(homeDirectory, ".local", "state"), "openai", "codex-observability");
  }
  throw new GrafanaProfileStoreError("UNSUPPORTED_PLATFORM");
}

function assertOwner(metadata: Stats, kind: "file" | "directory"): void {
  const expectedKind = kind === "file" ? metadata.isFile() : metadata.isDirectory();
  if (!expectedKind || metadata.isSymbolicLink() || (metadata.mode & 0o077) !== 0) {
    throw new GrafanaProfileStoreError("UNSAFE_STATE");
  }
  if (typeof process.getuid === "function" && metadata.uid !== process.getuid()) {
    throw new GrafanaProfileStoreError("UNSAFE_STATE");
  }
  if (kind === "file" && metadata.nlink !== 1) throw new GrafanaProfileStoreError("UNSAFE_STATE");
}

async function writeAll(
  handle: Awaited<ReturnType<typeof open>>,
  contents: Buffer,
): Promise<void> {
  let offset = 0;
  while (offset < contents.byteLength) {
    const { bytesWritten } = await handle.write(contents, offset, contents.byteLength - offset, offset);
    if (bytesWritten === 0) throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
    offset += bytesWritten;
  }
}

export class SharedGrafanaProfileStore implements SharedGrafanaProfileRegistryStore {
  readonly #rootPath: string;
  readonly #registryPath: string;
  readonly #registryTemporaryPath: string;

  constructor(options: {
    rootPath?: string;
    platform?: NodeJS.Platform;
    environment?: Readonly<NodeJS.ProcessEnv>;
    homeDirectory?: string;
  } = {}) {
    // Resolve the supported platform even when a test supplies an explicit root.
    const platform = options.platform ?? process.platform;
    if (platform !== "darwin" && platform !== "linux") {
      throw new GrafanaProfileStoreError("UNSUPPORTED_PLATFORM");
    }
    this.#rootPath = options.rootPath ?? sharedGrafanaProfileStateRoot(options);
    if (!isAbsolute(this.#rootPath)) throw new GrafanaProfileStoreError("UNSAFE_STATE");
    this.#registryPath = join(this.#rootPath, REGISTRY_FILENAME);
    this.#registryTemporaryPath = join(this.#rootPath, REGISTRY_TEMPORARY_FILENAME);
  }

  async #ensureRoot(): Promise<void> {
    try {
      await mkdir(this.#rootPath, { recursive: true, mode: 0o700 });
      assertOwner(await lstat(this.#rootPath), "directory");
    } catch (error) {
      if (error instanceof GrafanaProfileStoreError) throw error;
      throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
    }
  }

  async #readUnlocked(): Promise<SharedGrafanaProfileRegistryV1> {
    await this.#ensureRoot();
    let handle: Awaited<ReturnType<typeof open>>;
    try {
      handle = await open(this.#registryPath, constants.O_RDONLY | constants.O_NOFOLLOW);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return emptySharedGrafanaProfileRegistry();
      throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
    }
    try {
      const before = await handle.stat();
      assertOwner(before, "file");
      if (before.size < 2 || before.size > MAX_REGISTRY_BYTES) {
        throw new GrafanaProfileStoreError("UNSAFE_STATE");
      }
      const contents = Buffer.alloc(before.size);
      let offset = 0;
      while (offset < contents.byteLength) {
        const { bytesRead } = await handle.read(contents, offset, contents.byteLength - offset, offset);
        if (bytesRead === 0) throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
        offset += bytesRead;
      }
      const trailing = Buffer.alloc(1);
      const [{ bytesRead }, after] = await Promise.all([
        handle.read(trailing, 0, 1, contents.byteLength),
        handle.stat(),
      ]);
      if (
        bytesRead !== 0
        || before.dev !== after.dev
        || before.ino !== after.ino
        || before.size !== after.size
      ) {
        throw new GrafanaProfileStoreError("UNSAFE_STATE");
      }
      try {
        return parseSharedGrafanaProfileRegistry(JSON.parse(contents.toString("utf8")));
      } catch {
        throw new GrafanaProfileStoreError("UNSAFE_STATE");
      } finally {
        contents.fill(0);
      }
    } finally {
      await handle.close().catch(() => undefined);
    }
  }

  async #syncRoot(): Promise<void> {
    const directory = await open(
      this.#rootPath,
      constants.O_RDONLY | constants.O_DIRECTORY | constants.O_NOFOLLOW,
    );
    try {
      await directory.sync();
    } finally {
      await directory.close().catch(() => undefined);
    }
  }

  async #recoverAbandonedRegistryTemporary(): Promise<void> {
    let metadata: Stats;
    try {
      metadata = await lstat(this.#registryTemporaryPath);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
      throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
    }
    assertOwner(metadata, "file");
    await unlink(this.#registryTemporaryPath);
    await this.#syncRoot();
  }

  async #writeUnlocked(registry: Readonly<SharedGrafanaProfileRegistryV1>): Promise<void> {
    const parsed = parseSharedGrafanaProfileRegistry(registry);
    const contents = Buffer.from(`${JSON.stringify(parsed, null, 2)}\n`, "utf8");
    if (contents.byteLength > MAX_REGISTRY_BYTES) throw new GrafanaProfileStoreError("UNSAFE_STATE");
    const temporaryPath = this.#registryTemporaryPath;
    let created = false;
    try {
      const handle = await open(
        temporaryPath,
        constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
        0o600,
      );
      created = true;
      try {
        await writeAll(handle, contents);
        await handle.sync();
      } finally {
        await handle.close().catch(() => undefined);
      }
      await chmod(temporaryPath, 0o600);
      assertOwner(await lstat(temporaryPath), "file");
      await rename(temporaryPath, this.#registryPath);
      created = false;
      await this.#syncRoot();
    } catch (error) {
      if (error instanceof GrafanaProfileStoreError) throw error;
      throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
    } finally {
      contents.fill(0);
      if (created) await unlink(temporaryPath).catch(() => undefined);
    }
  }

  async read(): Promise<Readonly<SharedGrafanaProfileRegistryV1>> {
    return this.#readUnlocked();
  }

  async update(
    mutation: (
      current: Readonly<SharedGrafanaProfileRegistryV1>,
    ) => SharedGrafanaProfileRegistryV1,
  ): Promise<Readonly<SharedGrafanaProfileRegistryV1>> {
    return this.withExclusiveLifecycle((transaction) => transaction.update(mutation));
  }

  async withExclusiveLifecycle<R>(
    operation: (transaction: SharedGrafanaProfileRegistryTransaction) => Promise<R>,
  ): Promise<R> {
    await this.#ensureRoot();
    let coordinator: AtomicStateFile<never>;
    try {
      coordinator = new AtomicStateFile<never>({
        stateRoot: await realpath(this.#rootPath),
        filename: LIFECYCLE_COORDINATOR_FILENAME,
        kind: LIFECYCLE_COORDINATOR_KIND,
        maximumBytes: MAX_REGISTRY_BYTES,
      });
    } catch (error) {
      if (error instanceof RunStoreError) {
        throw new GrafanaProfileStoreError(error.code === "STATE_LOCKED" ? "STATE_BUSY" : "UNSAFE_STATE");
      }
      throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
    }
    try {
      return await coordinator.inspectAsync(async () => {
        await this.#recoverAbandonedRegistryTemporary();
        const journalState = new AtomicStateFile<unknown>({
          stateRoot: coordinator.root,
          filename: LIFECYCLE_JOURNAL_FILENAME,
          kind: LIFECYCLE_JOURNAL_KIND,
          maximumBytes: MAX_JOURNAL_BYTES,
        });
        journalState.recoverAbandonedExactArtifacts();
        let current = await this.#readUnlocked();
        let currentReliable = true;
        const readCurrent = (): SharedGrafanaProfileRegistryV1 => {
          if (!currentReliable) throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
          return parseSharedGrafanaProfileRegistry(current);
        };
        const persistedJournal = journalState.read();
        let currentJournal: GrafanaCredentialLifecycleJournalV1 | undefined;
        if (persistedJournal !== undefined && persistedJournal !== null) {
          try {
            currentJournal = parseGrafanaCredentialLifecycleJournal(persistedJournal);
          } catch {
            throw new GrafanaProfileStoreError("UNSAFE_STATE");
          }
        }
        const transaction: SharedGrafanaProfileRegistryTransaction = Object.freeze({
          read: readCurrent,
          readCredentialLifecycleJournal: () => currentJournal === undefined
            ? undefined
            : parseGrafanaCredentialLifecycleJournal(currentJournal),
          writeCredentialLifecycleJournal: async (
            journal: Readonly<GrafanaCredentialLifecycleJournalV1>,
          ) => {
            let parsed: GrafanaCredentialLifecycleJournalV1;
            try {
              parsed = parseGrafanaCredentialLifecycleJournal(journal);
            } catch {
              throw new GrafanaProfileStoreError("UNSAFE_STATE");
            }
            const validTransition = currentJournal === undefined
              ? parsed.phase === "PREPARED"
              : currentJournal.phase === "PREPARED"
                && parsed.phase === "COMMITTED"
                && JSON.stringify(parsed) === JSON.stringify(
                  committedGrafanaCredentialLifecycleJournal(currentJournal),
                );
            if (!validTransition) throw new GrafanaProfileStoreError("UNSAFE_STATE");
            journalState.write(parsed);
            currentJournal = parsed;
          },
          clearCredentialLifecycleJournal: async () => {
            journalState.write(null);
            currentJournal = undefined;
          },
          update: async (
            mutation: (
              registry: Readonly<SharedGrafanaProfileRegistryV1>,
            ) => SharedGrafanaProfileRegistryV1,
          ) => {
            let next: SharedGrafanaProfileRegistryV1;
            try {
              next = parseSharedGrafanaProfileRegistry(
                mutation(readCurrent()),
              );
            } catch (error) {
              if (error instanceof GrafanaProfileError) throw error;
              throw new GrafanaProfileStoreError("STATE_UNAVAILABLE");
            }
            try {
              await this.#writeUnlocked(next);
            } catch (error) {
              try {
                current = await this.#readUnlocked();
                currentReliable = true;
              } catch {
                currentReliable = false;
              }
              throw error;
            }
            current = next;
            currentReliable = true;
            return readCurrent();
          },
        });
        return operation(transaction);
      });
    } catch (error) {
      if (error instanceof RunStoreError) {
        throw new GrafanaProfileStoreError(error.code === "STATE_LOCKED" ? "STATE_BUSY" : "UNSAFE_STATE");
      }
      throw error;
    }
  }
}
