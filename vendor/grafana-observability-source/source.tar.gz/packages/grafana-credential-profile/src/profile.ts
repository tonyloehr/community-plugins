import { isIP } from "node:net";

import type {
  GrafanaCredentialReference,
  GrafanaNetworkClass,
  SharedGrafanaProfileRegistryV1,
  SharedGrafanaProfileV1,
} from "./types.ts";

const PROFILE_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u;
const CREDENTIAL_REFERENCE = /^grafana:([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}):bearer(?::v([1-9][0-9]{0,15}))?$/u;
const SECRET_LIKE_PROFILE_NAME = /(?:\bBearer\s+[A-Za-z0-9._~+/=-]{8,}|\bglsa_[A-Za-z0-9_-]{8,}|\b(?:password|passwd|secret|token|api[_ -]?key)\s*[:=])/iu;
const MAX_PROFILES = 64;

export class GrafanaProfileError extends Error {
  readonly code:
    | "INVALID_PROFILE"
    | "INVALID_REGISTRY"
    | "PROFILE_NOT_FOUND"
    | "PROFILE_ALREADY_EXISTS";

  constructor(code: GrafanaProfileError["code"]) {
    super("Shared Grafana profile data is invalid or unavailable");
    this.name = "GrafanaProfileError";
    this.code = code;
  }
}

function object(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  return value as Record<string, unknown>;
}

function exact(value: Record<string, unknown>, keys: readonly string[], code: "INVALID_PROFILE" | "INVALID_REGISTRY"): void {
  const expected = new Set(keys);
  if (Object.keys(value).length !== expected.size || Object.keys(value).some((key) => !expected.has(key))) {
    throw new GrafanaProfileError(code);
  }
}

function unwrappedHost(hostname: string): string {
  return hostname.startsWith("[") && hostname.endsWith("]")
    ? hostname.slice(1, -1).toLowerCase()
    : hostname.toLowerCase();
}

function privateIpv4(hostname: string): boolean {
  const octets = hostname.split(".").map(Number);
  if (octets.length !== 4 || octets.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  return octets[0] === 10
    || (octets[0] === 172 && octets[1]! >= 16 && octets[1]! <= 31)
    || (octets[0] === 192 && octets[1] === 168);
}

export function classifyGrafanaOriginHost(hostname: string): GrafanaNetworkClass {
  const host = unwrappedHost(hostname);
  if (host === "localhost" || host === "::1" || host.startsWith("127.")) return "loopback";
  if (isIP(host) === 4) return privateIpv4(host) ? "private" : "public";
  if (isIP(host) === 6) {
    const first = Number.parseInt(host.split(":", 1)[0] ?? "", 16);
    return Number.isFinite(first) && (first & 0xfe00) === 0xfc00 ? "private" : "public";
  }
  return "public";
}

export function normalizeGrafanaOrigin(value: string): {
  grafanaOrigin: string;
  networkClass: GrafanaNetworkClass;
} {
  if (value.length === 0 || value.length > 2_048 || value.trim() !== value) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  if (
    (url.protocol !== "https:" && url.protocol !== "http:")
    || url.username !== ""
    || url.password !== ""
    || url.search !== ""
    || url.hash !== ""
    || url.pathname !== "/"
  ) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  const networkClass = classifyGrafanaOriginHost(url.hostname);
  if (url.protocol === "http:" && networkClass !== "loopback") {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  return { grafanaOrigin: url.origin, networkClass };
}

export function normalizeGrafanaProfileName(value: string): string {
  const normalized = value.trim();
  if (
    normalized !== value
    || normalized.length < 1
    || normalized.length > 80
    || SECRET_LIKE_PROFILE_NAME.test(normalized)
    || [...normalized].some((character) => {
      const codePoint = character.codePointAt(0)!;
      return codePoint < 0x20 || codePoint === 0x7f;
    })
  ) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  return normalized;
}

export function grafanaCredentialReference(
  profileId: string,
  slot = 1,
): SharedGrafanaProfileV1["credentialRef"] {
  if (
    !PROFILE_ID.test(profileId)
    || !Number.isSafeInteger(slot)
    || slot < 1
  ) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  return Object.freeze({ kind: "broker", key: `grafana:${profileId}:bearer:v${String(slot)}` });
}

/** The pre-slot reference remains readable so existing profiles migrate on their next rotate/delete. */
export function legacyGrafanaCredentialReference(
  profileId: string,
): SharedGrafanaProfileV1["credentialRef"] {
  if (!PROFILE_ID.test(profileId)) throw new GrafanaProfileError("INVALID_PROFILE");
  return Object.freeze({ kind: "broker", key: `grafana:${profileId}:bearer` });
}

export function parseGrafanaCredentialReference(
  reference: Readonly<{ kind: string; key: string }>,
): { profileId: string; slot: number | null; reference: GrafanaCredentialReference } | undefined {
  if (reference.kind !== "broker") return undefined;
  const match = CREDENTIAL_REFERENCE.exec(reference.key);
  if (match === null) return undefined;
  const profileId = match[1]!;
  if (match[2] === undefined) {
    return { profileId, slot: null, reference: legacyGrafanaCredentialReference(profileId) };
  }
  const slot = Number(match[2]);
  if (!Number.isSafeInteger(slot) || slot < 1) return undefined;
  return { profileId, slot, reference: grafanaCredentialReference(profileId, slot) };
}

export function grafanaProfileIdFromReference(
  reference: Readonly<{ kind: string; key: string }>,
): string | undefined {
  return parseGrafanaCredentialReference(reference)?.profileId;
}

export function grafanaCredentialSlotFromReference(
  reference: Readonly<{ kind: string; key: string }>,
): number | null | undefined {
  return parseGrafanaCredentialReference(reference)?.slot;
}

export function grafanaKeyringAccount(reference: Readonly<{ kind: string; key: string }>): string | undefined {
  const parsed = parseGrafanaCredentialReference(reference);
  return parsed === undefined
    ? undefined
    : parsed.slot === null
      ? `profile/${parsed.profileId}/bearer`
      : `profile/${parsed.profileId}/bearer/v${String(parsed.slot)}`;
}

export function createSharedGrafanaProfile(input: {
  profileId: string;
  profileName: string;
  grafanaOrigin: string;
}): SharedGrafanaProfileV1 {
  if (!PROFILE_ID.test(input.profileId)) throw new GrafanaProfileError("INVALID_PROFILE");
  const profileName = normalizeGrafanaProfileName(input.profileName);
  const origin = normalizeGrafanaOrigin(input.grafanaOrigin);
  return {
    schemaVersion: "1.0.0",
    profileId: input.profileId,
    profileName,
    ...origin,
    credentialRef: grafanaCredentialReference(input.profileId),
    revision: 1,
  };
}

export function parseSharedGrafanaProfile(value: unknown): SharedGrafanaProfileV1 {
  const profile = object(value);
  exact(profile, [
    "schemaVersion",
    "profileId",
    "profileName",
    "grafanaOrigin",
    "networkClass",
    "credentialRef",
    "revision",
  ], "INVALID_PROFILE");
  if (profile.schemaVersion !== "1.0.0" || typeof profile.profileId !== "string" || !PROFILE_ID.test(profile.profileId)) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  if (typeof profile.profileName !== "string") throw new GrafanaProfileError("INVALID_PROFILE");
  const profileName = normalizeGrafanaProfileName(profile.profileName);
  if (typeof profile.grafanaOrigin !== "string") throw new GrafanaProfileError("INVALID_PROFILE");
  const origin = normalizeGrafanaOrigin(profile.grafanaOrigin);
  if (profile.networkClass !== origin.networkClass || profile.grafanaOrigin !== origin.grafanaOrigin) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  if (!Number.isSafeInteger(profile.revision) || (profile.revision as number) < 1) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  const revision = profile.revision as number;
  const credentialRef = object(profile.credentialRef);
  exact(credentialRef, ["kind", "key"], "INVALID_PROFILE");
  if (typeof credentialRef.kind !== "string" || typeof credentialRef.key !== "string") {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  const parsedReference = parseGrafanaCredentialReference({
    kind: credentialRef.kind,
    key: credentialRef.key,
  });
  if (
    parsedReference === undefined
    || parsedReference.profileId !== profile.profileId
    || (parsedReference.slot !== null && parsedReference.slot > revision)
  ) {
    throw new GrafanaProfileError("INVALID_PROFILE");
  }
  return {
    schemaVersion: "1.0.0",
    profileId: profile.profileId,
    profileName,
    ...origin,
    credentialRef: parsedReference.reference,
    revision,
  };
}

export function emptySharedGrafanaProfileRegistry(): SharedGrafanaProfileRegistryV1 {
  return { schemaVersion: "1.0.0", activeProfileId: null, profiles: [] };
}

export function parseSharedGrafanaProfileRegistry(value: unknown): SharedGrafanaProfileRegistryV1 {
  let registry: Record<string, unknown>;
  try {
    registry = object(value);
    exact(registry, ["schemaVersion", "activeProfileId", "profiles"], "INVALID_REGISTRY");
  } catch {
    throw new GrafanaProfileError("INVALID_REGISTRY");
  }
  if (registry.schemaVersion !== "1.0.0" || !Array.isArray(registry.profiles) || registry.profiles.length > MAX_PROFILES) {
    throw new GrafanaProfileError("INVALID_REGISTRY");
  }
  let profiles: SharedGrafanaProfileV1[];
  try {
    profiles = registry.profiles.map(parseSharedGrafanaProfile);
  } catch {
    throw new GrafanaProfileError("INVALID_REGISTRY");
  }
  const ids = new Set(profiles.map((profile) => profile.profileId));
  const names = new Set(profiles.map((profile) => profile.profileName.toLowerCase()));
  if (ids.size !== profiles.length || names.size !== profiles.length) {
    throw new GrafanaProfileError("INVALID_REGISTRY");
  }
  const activeProfileId = registry.activeProfileId;
  if (activeProfileId !== null && (typeof activeProfileId !== "string" || !ids.has(activeProfileId))) {
    throw new GrafanaProfileError("INVALID_REGISTRY");
  }
  return { schemaVersion: "1.0.0", activeProfileId, profiles };
}

export function findSharedGrafanaProfile(
  registry: Readonly<SharedGrafanaProfileRegistryV1>,
  profileName: string | undefined,
): SharedGrafanaProfileV1 {
  const profile = profileName === undefined
    ? registry.profiles.find((candidate) => candidate.profileId === registry.activeProfileId)
    : registry.profiles.find((candidate) => candidate.profileName.toLowerCase() === profileName.toLowerCase());
  if (profile === undefined) throw new GrafanaProfileError("PROFILE_NOT_FOUND");
  return parseSharedGrafanaProfile(profile);
}

export function addSharedGrafanaProfile(
  registry: Readonly<SharedGrafanaProfileRegistryV1>,
  profile: Readonly<SharedGrafanaProfileV1>,
): SharedGrafanaProfileRegistryV1 {
  const current = parseSharedGrafanaProfileRegistry(registry);
  const parsed = parseSharedGrafanaProfile(profile);
  if (current.profiles.some((candidate) =>
    candidate.profileId === parsed.profileId
    || candidate.profileName.toLowerCase() === parsed.profileName.toLowerCase()
  )) {
    throw new GrafanaProfileError("PROFILE_ALREADY_EXISTS");
  }
  return parseSharedGrafanaProfileRegistry({
    schemaVersion: "1.0.0",
    activeProfileId: parsed.profileId,
    profiles: [...current.profiles, parsed],
  });
}

export function replaceSharedGrafanaProfile(
  registry: Readonly<SharedGrafanaProfileRegistryV1>,
  profile: Readonly<SharedGrafanaProfileV1>,
): SharedGrafanaProfileRegistryV1 {
  const current = parseSharedGrafanaProfileRegistry(registry);
  const parsed = parseSharedGrafanaProfile(profile);
  if (!current.profiles.some((candidate) => candidate.profileId === parsed.profileId)) {
    throw new GrafanaProfileError("PROFILE_NOT_FOUND");
  }
  return parseSharedGrafanaProfileRegistry({
    ...current,
    profiles: current.profiles.map((candidate) => candidate.profileId === parsed.profileId ? parsed : candidate),
  });
}

export function removeSharedGrafanaProfile(
  registry: Readonly<SharedGrafanaProfileRegistryV1>,
  profileId: string,
): SharedGrafanaProfileRegistryV1 {
  const current = parseSharedGrafanaProfileRegistry(registry);
  if (!current.profiles.some((candidate) => candidate.profileId === profileId)) {
    throw new GrafanaProfileError("PROFILE_NOT_FOUND");
  }
  const profiles = current.profiles.filter((candidate) => candidate.profileId !== profileId);
  return parseSharedGrafanaProfileRegistry({
    schemaVersion: "1.0.0",
    activeProfileId: current.activeProfileId === profileId ? profiles[0]?.profileId ?? null : current.activeProfileId,
    profiles,
  });
}
