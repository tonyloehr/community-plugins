import type { WorkerCredentialLease, WorkerCredentialSource } from "../../adapter-host/src/index.ts";

import { grafanaCredentialLifecycleAuthority } from "./lifecycle-journal.ts";
import {
  grafanaKeyringAccount,
  parseGrafanaCredentialReference,
} from "./profile.ts";
import type {
  GrafanaCredentialStatus,
  GrafanaCredentialStore,
  GrafanaKeyringBackend,
  SharedGrafanaProfileRegistryStore,
} from "./types.ts";

export const GRAFANA_KEYRING_SERVICE = "com.openai.codex.observability.grafana";
const MAX_GRAFANA_BEARER_BYTES = 16_384;

export class GrafanaKeyringError extends Error {
  readonly code: "INVALID_REFERENCE" | "INVALID_SECRET" | "KEYRING_UNAVAILABLE";

  constructor(code: GrafanaKeyringError["code"]) {
    super("The shared Grafana credential is unavailable");
    this.name = "GrafanaKeyringError";
    this.code = code;
  }
}

function validBearerSecret(secret: Uint8Array): boolean {
  if (secret.byteLength < 1 || secret.byteLength > MAX_GRAFANA_BEARER_BYTES) return false;
  for (const byte of secret) {
    if (byte < 0x21 || byte > 0x7e) return false;
  }
  return true;
}

export class BufferSecretLease implements WorkerCredentialLease {
  readonly bytes: Uint8Array;
  #disposed = false;

  constructor(secret: Uint8Array) {
    this.bytes = Uint8Array.from(secret);
  }

  dispose(): void {
    if (this.#disposed) return;
    this.#disposed = true;
    this.bytes.fill(0);
  }
}

export class GrafanaCredentialKeyring implements GrafanaCredentialStore, WorkerCredentialSource {
  readonly #backend: GrafanaKeyringBackend;

  constructor(backend: GrafanaKeyringBackend) {
    this.#backend = backend;
  }

  async acquire(reference: Readonly<{ kind: string; key: string }>): Promise<WorkerCredentialLease | undefined> {
    const account = grafanaKeyringAccount(reference);
    if (account === undefined) return undefined;
    let backendSecret: Uint8Array | undefined;
    try {
      backendSecret = await this.#backend.getSecret(GRAFANA_KEYRING_SERVICE, account);
      if (backendSecret === undefined || !validBearerSecret(backendSecret)) return undefined;
      return new BufferSecretLease(backendSecret);
    } catch {
      return undefined;
    } finally {
      backendSecret?.fill(0);
    }
  }

  async set(reference: Readonly<{ kind: string; key: string }>, secret: Uint8Array): Promise<void> {
    const account = grafanaKeyringAccount(reference);
    if (account === undefined) throw new GrafanaKeyringError("INVALID_REFERENCE");
    if (!validBearerSecret(secret)) throw new GrafanaKeyringError("INVALID_SECRET");
    const copy = Uint8Array.from(secret);
    try {
      await this.#backend.setSecret(GRAFANA_KEYRING_SERVICE, account, copy);
    } catch {
      throw new GrafanaKeyringError("KEYRING_UNAVAILABLE");
    } finally {
      copy.fill(0);
    }
  }

  async status(reference: Readonly<{ kind: string; key: string }>): Promise<GrafanaCredentialStatus> {
    const lease = await this.acquire(reference);
    if (lease === undefined) return "MISSING_OR_UNAVAILABLE";
    lease.dispose();
    return "AVAILABLE";
  }

  async delete(reference: Readonly<{ kind: string; key: string }>): Promise<boolean> {
    const account = grafanaKeyringAccount(reference);
    if (account === undefined) throw new GrafanaKeyringError("INVALID_REFERENCE");
    try {
      return await this.#backend.deleteSecret(GRAFANA_KEYRING_SERVICE, account);
    } catch {
      throw new GrafanaKeyringError("KEYRING_UNAVAILABLE");
    }
  }
}

/**
 * Resolves a reviewed profile identity to its current revision-addressed keyring
 * slot. The reviewed reference remains stable while rotation atomically advances
 * the profile registry pointer under the same lifecycle lock used by the CLI.
 */
export class SharedGrafanaProfileCredentialSource implements WorkerCredentialSource {
  readonly #credentialStore: Pick<GrafanaCredentialStore, "acquire">;
  readonly #profileStore: SharedGrafanaProfileRegistryStore;

  constructor(
    credentialStore: Pick<GrafanaCredentialStore, "acquire">,
    profileStore: SharedGrafanaProfileRegistryStore,
  ) {
    this.#credentialStore = credentialStore;
    this.#profileStore = profileStore;
  }

  async acquire(reference: Readonly<{ kind: string; key: string }>): Promise<WorkerCredentialLease | undefined> {
    const reviewed = parseGrafanaCredentialReference(reference);
    if (reviewed === undefined) return undefined;
    try {
      return await this.#profileStore.withExclusiveLifecycle(async (transaction) => {
        const journal = transaction.readCredentialLifecycleJournal();
        if (journal !== undefined) {
          const authority = grafanaCredentialLifecycleAuthority(transaction.read(), journal);
          if (authority === "INVALID" || (journal.phase === "COMMITTED" && authority !== "NEXT")) {
            return undefined;
          }
        }
        const profile = transaction.read().profiles.find(
          (candidate) => candidate.profileId === reviewed.profileId,
        );
        if (profile === undefined) return undefined;
        return this.#credentialStore.acquire(profile.credentialRef);
      });
    } catch {
      return undefined;
    }
  }
}
