import type {
  GrafanaKeyringBackend,
  NativeGrafanaKeyringBackendKind,
  SupportedGrafanaKeyringPlatform,
} from "./types.ts";

export interface NativeSecretEntry {
  getSecret(signal?: AbortSignal): Promise<Uint8Array | undefined>;
  setSecret(secret: Uint8Array, signal?: AbortSignal): Promise<void>;
  deleteCredential(signal?: AbortSignal): Promise<boolean>;
}

export interface NativeKeyringModule {
  /** Must be attested by the code-owned native wrapper, not inferred from the OS. */
  readonly backendKind: NativeGrafanaKeyringBackendKind;
  createEntry(service: string, account: string): NativeSecretEntry;
}

export interface NativeKeyringModuleLoader {
  /** Load only a release-pinned, hash-verified native asset. */
  load(): Promise<NativeKeyringModule>;
}

export class NativeKeyringUnavailableError extends Error {
  constructor() {
    super("The native OS keyring backend is unavailable");
    this.name = "NativeKeyringUnavailableError";
  }
}

export class NativeGrafanaKeyringBackend implements GrafanaKeyringBackend {
  readonly #platform: SupportedGrafanaKeyringPlatform;
  readonly #loader: NativeKeyringModuleLoader;
  #loaded: Promise<NativeKeyringModule> | undefined;

  constructor(options: {
    platform?: NodeJS.Platform;
    loader: NativeKeyringModuleLoader;
  }) {
    const platform = options.platform ?? process.platform;
    if (platform !== "darwin" && platform !== "linux") throw new NativeKeyringUnavailableError();
    this.#platform = platform;
    this.#loader = options.loader;
  }

  async #module(): Promise<NativeKeyringModule> {
    // The pinned upstream Linux addon can silently use kernel keyutils when
    // Secret Service is unavailable. A claimed string kind is not attestation,
    // so Linux remains fail-closed until a dedicated wrapper removes fallback.
    if (this.#platform === "linux") throw new NativeKeyringUnavailableError();
    this.#loaded ??= this.#loader.load().then((module) => {
      if (module.backendKind !== "MACOS_KEYCHAIN" || typeof module.createEntry !== "function") {
        throw new NativeKeyringUnavailableError();
      }
      return module;
    }).catch(() => {
      this.#loaded = undefined;
      throw new NativeKeyringUnavailableError();
    });
    return this.#loaded;
  }

  async #entry(service: string, account: string): Promise<NativeSecretEntry> {
    if (service.length === 0 || service.length > 256 || account.length === 0 || account.length > 256) {
      throw new NativeKeyringUnavailableError();
    }
    try {
      return (await this.#module()).createEntry(service, account);
    } catch {
      throw new NativeKeyringUnavailableError();
    }
  }

  async getSecret(service: string, account: string): Promise<Uint8Array | undefined> {
    let secret: Uint8Array | undefined;
    try {
      secret = await (await this.#entry(service, account)).getSecret();
      return secret === undefined ? undefined : Uint8Array.from(secret);
    } catch {
      throw new NativeKeyringUnavailableError();
    } finally {
      secret?.fill(0);
    }
  }

  async setSecret(service: string, account: string, secret: Uint8Array): Promise<void> {
    const copy = Uint8Array.from(secret);
    try {
      await (await this.#entry(service, account)).setSecret(copy);
    } catch {
      throw new NativeKeyringUnavailableError();
    } finally {
      copy.fill(0);
    }
  }

  async deleteSecret(service: string, account: string): Promise<boolean> {
    try {
      return await (await this.#entry(service, account)).deleteCredential();
    } catch {
      throw new NativeKeyringUnavailableError();
    }
  }
}
