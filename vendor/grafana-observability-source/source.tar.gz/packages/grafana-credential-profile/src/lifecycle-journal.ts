import {
  parseSharedGrafanaProfileRegistry,
  parseGrafanaCredentialReference,
} from "./profile.ts";
import type {
  GrafanaCredentialLifecycleAuthority,
  GrafanaCredentialLifecycleJournalV1,
  GrafanaCredentialReference,
  SharedGrafanaProfileRegistryV1,
} from "./types.ts";

function invalidJournal(): never {
  throw new Error("Grafana credential lifecycle journal is invalid");
}

function exactObject(value: unknown, keys: readonly string[]): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) invalidJournal();
  const record = value as Record<string, unknown>;
  const expected = new Set(keys);
  if (Object.keys(record).length !== expected.size || Object.keys(record).some((key) => !expected.has(key))) {
    invalidJournal();
  }
  return record;
}

function nullableRevision(value: unknown): number | null {
  if (value === null) return null;
  if (!Number.isSafeInteger(value) || (value as number) < 1) invalidJournal();
  return value as number;
}

function nullableReference(
  value: unknown,
  profileId: string,
  revision: number | null,
): GrafanaCredentialReference | null {
  if (value === null) {
    if (revision !== null) invalidJournal();
    return null;
  }
  if (revision === null) invalidJournal();
  const record = exactObject(value, ["kind", "key"]);
  if (typeof record.kind !== "string" || typeof record.key !== "string") invalidJournal();
  const parsed = parseGrafanaCredentialReference({ kind: record.kind, key: record.key });
  if (
    parsed === undefined
    || parsed.profileId !== profileId
    || (parsed.slot !== null && parsed.slot > revision)
  ) {
    invalidJournal();
  }
  return parsed.reference;
}

export function parseGrafanaCredentialLifecycleJournal(
  value: unknown,
): GrafanaCredentialLifecycleJournalV1 {
  const journal = exactObject(value, [
    "schemaVersion",
    "operation",
    "phase",
    "profileId",
    "previousRevision",
    "previousCredentialRef",
    "nextRevision",
    "nextCredentialRef",
  ]);
  if (
    journal.schemaVersion !== "1.0.0"
    || (journal.operation !== "CONNECT" && journal.operation !== "ROTATE" && journal.operation !== "DELETE")
    || (journal.phase !== "PREPARED" && journal.phase !== "COMMITTED")
    || typeof journal.profileId !== "string"
  ) {
    invalidJournal();
  }
  const profileId = journal.profileId;
  const previousRevision = nullableRevision(journal.previousRevision);
  const nextRevision = nullableRevision(journal.nextRevision);
  const previousCredentialRef = nullableReference(
    journal.previousCredentialRef,
    profileId,
    previousRevision,
  );
  const nextCredentialRef = nullableReference(
    journal.nextCredentialRef,
    profileId,
    nextRevision,
  );
  const nextSlot = nextCredentialRef === null
    ? null
    : parseGrafanaCredentialReference(nextCredentialRef)?.slot ?? null;
  if (
    (journal.operation === "CONNECT" && (
      previousRevision !== null
      || previousCredentialRef !== null
      || nextRevision !== 1
      || nextCredentialRef === null
      || nextSlot !== nextRevision
    ))
    || (journal.operation === "ROTATE" && (
      previousRevision === null
      || previousCredentialRef === null
      || nextRevision === null
      || nextCredentialRef === null
      || nextRevision !== previousRevision + 1
      || nextSlot !== nextRevision
      || nextCredentialRef.key === previousCredentialRef.key
    ))
    || (journal.operation === "DELETE" && (
      previousRevision === null
      || previousCredentialRef === null
      || nextRevision !== null
      || nextCredentialRef !== null
    ))
  ) {
    invalidJournal();
  }
  return {
    schemaVersion: "1.0.0",
    operation: journal.operation,
    phase: journal.phase,
    profileId,
    previousRevision,
    previousCredentialRef,
    nextRevision,
    nextCredentialRef,
  };
}

export function committedGrafanaCredentialLifecycleJournal(
  journal: Readonly<GrafanaCredentialLifecycleJournalV1>,
): GrafanaCredentialLifecycleJournalV1 {
  return parseGrafanaCredentialLifecycleJournal({ ...journal, phase: "COMMITTED" });
}

function sameCredentialReference(
  left: Readonly<GrafanaCredentialReference>,
  right: Readonly<GrafanaCredentialReference>,
): boolean {
  return left.kind === right.kind && left.key === right.key;
}

export function grafanaCredentialLifecycleAuthority(
  registry: Readonly<SharedGrafanaProfileRegistryV1>,
  journal: Readonly<GrafanaCredentialLifecycleJournalV1>,
): GrafanaCredentialLifecycleAuthority {
  const parsedRegistry = parseSharedGrafanaProfileRegistry(registry);
  const parsedJournal = parseGrafanaCredentialLifecycleJournal(journal);
  const profile = parsedRegistry.profiles.find(
    (candidate) => candidate.profileId === parsedJournal.profileId,
  );
  const matches = (
    revision: number | null,
    reference: Readonly<GrafanaCredentialReference> | null,
  ): boolean => revision !== null
    && reference !== null
    && profile !== undefined
    && profile.revision === revision
    && sameCredentialReference(profile.credentialRef, reference);
  if (parsedJournal.operation === "CONNECT") {
    if (profile === undefined) return "PREVIOUS";
    return matches(parsedJournal.nextRevision, parsedJournal.nextCredentialRef) ? "NEXT" : "INVALID";
  }
  if (parsedJournal.operation === "ROTATE") {
    if (matches(parsedJournal.previousRevision, parsedJournal.previousCredentialRef)) return "PREVIOUS";
    return matches(parsedJournal.nextRevision, parsedJournal.nextCredentialRef) ? "NEXT" : "INVALID";
  }
  if (matches(parsedJournal.previousRevision, parsedJournal.previousCredentialRef)) return "PREVIOUS";
  return profile === undefined ? "NEXT" : "INVALID";
}
