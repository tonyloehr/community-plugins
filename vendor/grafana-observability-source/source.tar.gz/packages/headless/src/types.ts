import type {
  AnalysisDraft,
  EvidenceEnvelope,
  EvidenceId,
  RunId,
  WorkflowEvent,
  WorkflowResult,
  WorkflowRequest,
} from "@codex-production-monitoring/contracts";

export interface AnalysisDriverInput {
  runId: RunId;
  request: Readonly<WorkflowRequest>;
  evidence: readonly Readonly<EvidenceEnvelope>[];
}

export interface AnalysisDriver {
  readonly kind?: "codex" | "deterministic-fixture" | "custom";
  analyze(
    input: Readonly<AnalysisDriverInput>,
    signal?: AbortSignal,
  ): AnalysisDraft | Promise<AnalysisDraft>;
}

export type HeadlessEvent = WorkflowEvent;

export interface HeadlessRunOptions {
  /** @deprecated The canonical request owns this value; a supplied value must match exactly. */
  idempotencyKey?: string;
  signal?: AbortSignal;
  /** @deprecated The canonical request owns this value; a supplied value must match exactly. */
  failOn?: "none" | "partial" | "error";
  terminationExitCode?: 130 | 143;
  emit?: (event: Readonly<HeadlessEvent>) => void | Promise<void>;
  now?: () => Date;
  /** Owner-only state root used to encrypt retained local run authority. */
  controlRoot?: string;
  resumeMode?: "auto" | "never" | "required";
  /** Explicit analysis implementation. Absence or failure seals a PARTIAL evidence-only artifact. */
  analysisDriver?: AnalysisDriver;
}

export interface HeadlessRunOutcome {
  result: WorkflowResult;
  events: HeadlessEvent[];
}

export interface HeadlessCancelOptions {
  /** @deprecated The canonical request owns this value; a supplied value must match exactly. */
  idempotencyKey?: string;
  controlRoot: string;
  reason?: "USER_REQUEST" | "INTERRUPTED" | "BUDGET_EXCEEDED" | "PROVIDER_UNAVAILABLE";
  emit?: (event: Readonly<HeadlessEvent>) => void | Promise<void>;
  now?: () => Date;
}

export interface HeadlessCancelOutcome {
  runId: RunId;
  revision: number;
  retainedEvidenceIds: EvidenceId[];
  events: HeadlessEvent[];
}
