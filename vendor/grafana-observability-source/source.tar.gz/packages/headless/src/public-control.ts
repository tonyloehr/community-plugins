import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { existsSync, lstatSync, mkdirSync, realpathSync } from "node:fs";
import { isAbsolute, resolve } from "node:path";

import {
  canonicalJson,
  sha256Bytes,
  type RunId,
  type WorkflowRequest,
} from "@codex-production-monitoring/contracts";
import { AtomicStateFile, RunStoreError } from "@codex-production-monitoring/run-store";

const RUN_ID = /^pmrun_[A-Za-z0-9_-]{20,128}$/u;
const SHA256 = /^[a-f0-9]{64}$/u;
const MAXIMUM_CIPHERTEXT_BYTES = 2 * 1_024 * 1_024;
const LOCK_RETRY_WAIT = new Int32Array(new SharedArrayBuffer(4));

interface PublicControlKeyState {
  schemaVersion: "1.0.0";
  keyBase64: string;
}

interface PublicControlRecord {
  schemaVersion: "1.0.0";
  runId: RunId;
  active: boolean;
  ivBase64: string | null;
  ciphertextBase64: string | null;
  tagBase64: string | null;
}

export interface PublicRunControlPayload {
  schemaVersion: "1.0.0";
  request: WorkflowRequest;
  requestSha256: string;
  outputRoot: string;
  stateRoot: string;
  idempotencyKey: string;
  analysisDriver: "codex" | "deterministic-fixture" | null;
}

function canonicalBase64(value: string, bytes: number | { minimum: number; maximum: number }): boolean {
  const decoded = Buffer.from(value, "base64");
  const sizeMatches = typeof bytes === "number"
    ? decoded.byteLength === bytes
    : decoded.byteLength >= bytes.minimum && decoded.byteLength <= bytes.maximum;
  return sizeMatches && decoded.toString("base64") === value;
}

function validateKeyState(value: PublicControlKeyState): Buffer {
  if (
    value.schemaVersion !== "1.0.0" ||
    typeof value.keyBase64 !== "string" ||
    !canonicalBase64(value.keyBase64, 32)
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Public control key state is invalid");
  }
  return Buffer.from(value.keyBase64, "base64");
}

function retryStateLock<T>(callback: () => T): T {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try {
      return callback();
    } catch (error) {
      if (!(error instanceof RunStoreError) || error.code !== "STATE_LOCKED" || attempt === 49) throw error;
      Atomics.wait(LOCK_RETRY_WAIT, 0, 0, 5);
    }
  }
  throw new RunStoreError("STATE_LOCKED", "Public control key initialization did not complete");
}

function validateRecord(
  value: PublicControlRecord | undefined,
  expectedRunId: string,
): PublicControlRecord | undefined {
  if (value === undefined) return undefined;
  const inactiveFieldsAreNull =
    value.ivBase64 === null &&
    value.tagBase64 === null &&
    value.ciphertextBase64 === null;
  const activeFieldsAreValid =
    typeof value.ivBase64 === "string" && canonicalBase64(value.ivBase64, 12) &&
    typeof value.tagBase64 === "string" && canonicalBase64(value.tagBase64, 16) &&
    typeof value.ciphertextBase64 === "string" &&
      canonicalBase64(value.ciphertextBase64, { minimum: 16, maximum: MAXIMUM_CIPHERTEXT_BYTES });
  if (
    value.schemaVersion !== "1.0.0" ||
    value.runId !== expectedRunId ||
    !RUN_ID.test(value.runId) ||
    typeof value.active !== "boolean" ||
    (value.active ? !activeFieldsAreValid : !inactiveFieldsAreNull)
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Public control record is invalid");
  }
  return structuredClone(value);
}

function aad(runId: string): Buffer {
  return Buffer.from(canonicalJson({ schemaVersion: "1.0.0", runId }), "utf8");
}

function validatePayload(value: unknown): PublicRunControlPayload {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new RunStoreError("STATE_CORRUPT", "Public run control payload is invalid");
  }
  const object = value as Record<string, unknown>;
  const keys = Object.keys(object).sort();
  if (canonicalJson(keys) !== canonicalJson([
    "analysisDriver",
    "idempotencyKey",
    "outputRoot",
    "request",
    "requestSha256",
    "schemaVersion",
    "stateRoot",
  ])) {
    throw new RunStoreError("STATE_CORRUPT", "Public run control payload has unexpected fields");
  }
  if (
    object.schemaVersion !== "1.0.0" ||
    object.request === null ||
    typeof object.request !== "object" ||
    Array.isArray(object.request) ||
    typeof object.requestSha256 !== "string" ||
    !SHA256.test(object.requestSha256) ||
    typeof object.outputRoot !== "string" ||
    !isAbsolute(object.outputRoot) ||
    object.outputRoot.length > 4_096 ||
    typeof object.stateRoot !== "string" ||
    !isAbsolute(object.stateRoot) ||
    object.stateRoot.length > 4_096 ||
    typeof object.idempotencyKey !== "string" ||
    object.idempotencyKey.length < 1 ||
    object.idempotencyKey.length > 256 ||
    !(
      object.analysisDriver === null ||
      object.analysisDriver === "codex" ||
      object.analysisDriver === "deterministic-fixture"
    )
  ) {
    throw new RunStoreError("STATE_CORRUPT", "Public run control payload failed validation");
  }
  return structuredClone(value as PublicRunControlPayload);
}

/**
 * Maps a public run ID to the inputs needed to reopen the existing encrypted
 * headless authority store. The run handle is never present in this index.
 */
export class PublicRunControlIndex {
  readonly #stateRoot: string;
  readonly #key: Buffer;

  constructor(stateRoot: string) {
    if (!isAbsolute(stateRoot)) throw new RunStoreError("STATE_ROOT_INVALID", "Public control root must be absolute");
    this.#stateRoot = resolve(stateRoot);
    if (!existsSync(this.#stateRoot)) {
      try {
        mkdirSync(this.#stateRoot, { mode: 0o700, recursive: false });
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      }
    }
    const stat = lstatSync(this.#stateRoot);
    const expectedUid = typeof process.getuid === "function" ? process.getuid() : undefined;
    if (
      stat.isSymbolicLink() ||
      !stat.isDirectory() ||
      (expectedUid !== undefined && stat.uid !== expectedUid) ||
      (stat.mode & 0o077) !== 0 ||
      realpathSync.native(this.#stateRoot) !== this.#stateRoot
    ) {
      throw new RunStoreError("STATE_ROOT_INVALID", "Public control root must be canonical and owner-only");
    }
    const keyFile = new AtomicStateFile<PublicControlKeyState>({
      stateRoot: this.#stateRoot,
      filename: "public-control-key.json",
      kind: "production-monitoring-public-control-key-v1",
    });
    const existingKey = keyFile.read();
    const keyState = existingKey ?? retryStateLock(() => keyFile.transact((current) => {
      const payload = current ?? {
        schemaVersion: "1.0.0" as const,
        keyBase64: randomBytes(32).toString("base64"),
      };
      validateKeyState(payload);
      return { payload, result: payload };
    }));
    this.#key = validateKeyState(keyState);
  }

  get(runId: string): PublicRunControlPayload | undefined {
    if (!RUN_ID.test(runId)) throw new TypeError("Run ID is invalid");
    const record = validateRecord(this.#record(runId).read(), runId);
    if (record === undefined || !record.active) return undefined;
    try {
      const decipher = createDecipheriv(
        "aes-256-gcm",
        this.#key,
        Buffer.from(record.ivBase64!, "base64"),
      );
      decipher.setAAD(aad(record.runId));
      decipher.setAuthTag(Buffer.from(record.tagBase64!, "base64"));
      const plaintext = Buffer.concat([
        decipher.update(Buffer.from(record.ciphertextBase64!, "base64")),
        decipher.final(),
      ]).toString("utf8");
      return validatePayload(JSON.parse(plaintext) as unknown);
    } catch (error) {
      if (error instanceof RunStoreError) throw error;
      throw new RunStoreError("STATE_CORRUPT", "Public run control payload could not be authenticated");
    }
  }

  put(runId: RunId, rawPayload: PublicRunControlPayload): void {
    if (!RUN_ID.test(runId)) throw new TypeError("Run ID is invalid");
    const payload = validatePayload(rawPayload);
    const plaintext = Buffer.from(canonicalJson(payload), "utf8");
    if (plaintext.byteLength > MAXIMUM_CIPHERTEXT_BYTES) {
      throw new TypeError("Public run control payload exceeds its size limit");
    }
    const iv = randomBytes(12);
    const cipher = createCipheriv("aes-256-gcm", this.#key, iv);
    cipher.setAAD(aad(runId));
    const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
    const record: PublicControlRecord = {
      schemaVersion: "1.0.0",
      runId,
      active: true,
      ivBase64: iv.toString("base64"),
      ciphertextBase64: ciphertext.toString("base64"),
      tagBase64: cipher.getAuthTag().toString("base64"),
    };
    this.#record(runId).transact((current) => {
      validateRecord(current, runId);
      return { payload: record, result: undefined };
    });
  }

  remove(runId: string): void {
    if (!RUN_ID.test(runId)) throw new TypeError("Run ID is invalid");
    const file = this.#record(runId);
    if (validateRecord(file.read(), runId) === undefined) return;
    file.transact((current) => {
      validateRecord(current, runId);
      return { payload: {
        schemaVersion: "1.0.0",
        runId: runId as RunId,
        active: false,
        ivBase64: null,
        ciphertextBase64: null,
        tagBase64: null,
      }, result: undefined };
    });
  }

  #record(runId: string): AtomicStateFile<PublicControlRecord> {
    return new AtomicStateFile({
      stateRoot: this.#stateRoot,
      filename: `public-run-${sha256Bytes(runId).slice(0, 48)}.json`,
      kind: "production-monitoring-public-control-record-v1",
    });
  }
}
