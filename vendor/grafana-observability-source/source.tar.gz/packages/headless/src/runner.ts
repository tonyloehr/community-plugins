import type { Clock } from "@codex-production-monitoring/adapter-sdk";
import {
  deriveEvidenceState,
  sha256Canonical,
  type EvidenceEnvelope,
  type EvidenceStateSummary,
  type AnalysisDraft,
  type RunHandle,
  type RunId,
  type Sha256,
  type WorkflowRequest,
  type WorkflowResult,
} from "@codex-production-monitoring/contracts";
import {
  MonitoringRuntime,
  validateWorkflowRequest,
} from "@codex-production-monitoring/evidence-server";

import { HeadlessControlStore } from "./control.ts";
import { validateWorkflowEvent, validateWorkflowSummary } from "./validation.ts";
import type {
  HeadlessCancelOptions,
  HeadlessCancelOutcome,
  HeadlessEvent,
  HeadlessRunOptions,
  HeadlessRunOutcome,
  AnalysisDriver,
} from "./types.ts";

type HeadlessEventInput = HeadlessEvent extends infer Event
  ? Event extends HeadlessEvent
    ? Omit<Event, "schemaVersion" | "sequence" | "at">
    : never
  : never;

function emptySummary(): EvidenceStateSummary {
  return { COMPLETE: 0, EMPTY: 0, STALE: 0, CONTRADICTORY: 0, ERROR: 0 };
}

/** Collection events precede cross-source contradiction assessment at finalization. */
function summarizePreFinalizationEvidence(evidence: readonly EvidenceEnvelope[]): EvidenceStateSummary {
  const result = emptySummary();
  for (const envelope of evidence) {
    const state = deriveEvidenceState({
      collectionState: envelope.collectionState,
      freshnessState: envelope.freshnessState,
      hasUnresolvedContradiction: false,
    });
    result[state] += 1;
  }
  return result;
}

function sanitizedCode(error: unknown): string {
  const candidate = error as { code?: unknown; name?: unknown };
  if (typeof candidate.code === "string" && /^[A-Z0-9_]{1,128}$/u.test(candidate.code)) return candidate.code;
  if (typeof candidate.name === "string") {
    const code = candidate.name.replaceAll(/[^A-Za-z0-9]+/gu, "_").toUpperCase();
    if (/^[A-Z0-9_]{1,128}$/u.test(code)) return code;
  }
  return "WORKFLOW_BLOCKED";
}

function requiredOperationIds(runtime: MonitoringRuntime, request: WorkflowRequest): string[] {
  return request.requiredOperations === undefined
    ? runtime.listOperations(request.profileAlias).map((operation) => operation.operationId)
    : [...request.requiredOperations];
}

function canonicalExecutionPolicy(
  request: Readonly<WorkflowRequest>,
  options: Pick<HeadlessRunOptions, "idempotencyKey" | "failOn">,
): { idempotencyKey: string; failOn: WorkflowRequest["failOn"] } {
  if (options.idempotencyKey !== undefined && options.idempotencyKey !== request.idempotencyKey) {
    throw new TypeError("Headless idempotency policy conflicts with the canonical workflow request");
  }
  if (options.failOn !== undefined && options.failOn !== request.failOn) {
    throw new TypeError("Headless fail-on policy conflicts with the canonical workflow request");
  }
  return { idempotencyKey: request.idempotencyKey, failOn: request.failOn };
}

function fixturePercent(value: number): string {
  return `${Number(value.toFixed(4)).toLocaleString("en-US", { maximumFractionDigits: 4 })}%`;
}

function degradedFixtureAnalysis(input: {
  evidence: readonly Readonly<EvidenceEnvelope>[];
}): AnalysisDraft | undefined {
  const evidence = input.evidence.find((item) => item.operationId === "fixture.degraded");
  if (
    evidence === undefined ||
    evidence.collectionState !== "COMPLETE" ||
    evidence.freshnessState !== "FRESH"
  ) {
    return undefined;
  }
  const signal = evidence.values.find(
    (value) =>
      value.kind === "SCALAR" &&
      value.name === "checkout_error_rate" &&
      value.unit === "percent" &&
      typeof value.value === "number" &&
      value.dimensions.release === "v2",
  );
  if (signal?.kind !== "SCALAR" || typeof signal.value !== "number") return undefined;
  const evaluatedAt = signal.observedAt ?? evidence.evaluatedAt;
  const maxAgeSeconds = evidence.maxAcceptableAgeMs / 1_000;
  const displayValue = fixturePercent(signal.value);

  return {
    schemaVersion: "1.0.0",
    observations: [
      {
        observationId: "degraded-checkout-error-rate",
        statement:
          `The SIMULATED checkout error rate is ${displayValue} for release=v2 at ${evaluatedAt}; ` +
          `the evidence is FRESH with a maximum age of ${maxAgeSeconds} seconds.`,
        evidenceIds: [evidence.evidenceId],
      },
    ],
    inferences: [
      {
        inferenceId: "degraded-checkout-symptom",
        statement: "The normalized evidence shows an elevated simulated checkout-error symptom scoped to release=v2.",
        confidence: 0.9,
        rationale:
          `${displayValue} is the directly observed aggregate; it establishes the fixture symptom, not why the symptom occurred.`,
        supportingEvidenceIds: [evidence.evidenceId],
        contradictingEvidenceIds: [],
      },
    ],
    hypotheses: [
      {
        hypothesisId: "release-v2-associated-regression",
        rank: 1,
        statement: "A release-v2 regression may be contributing to the elevated simulated checkout error rate.",
        status: "OPEN",
        rationale:
          "The elevated signal is dimensioned to release=v2, but no baseline, change, log, or trace evidence was collected; this evidence does not establish causality.",
        supportingEvidenceIds: [evidence.evidenceId],
        contradictingEvidenceIds: [],
        nextCheck:
          "Compare the same signal with the requested baseline, then inspect one bounded release change or trace sample.",
      },
    ],
    checksPerformed: [
      "Collected fixture.degraded and inspected the normalized checkout_error_rate value, release dimension, and freshness.",
    ],
    missingEvidence: [
      "No normalized baseline evidence was collected for a before-and-after comparison.",
      "No change, log, or trace evidence was collected to test the release-associated hypothesis.",
    ],
    smallestSafeNextStep:
      "Compare this cited signal with the requested baseline, then collect one bounded change or trace check before proposing remediation.",
    approvalRequired: false,
    remainingUncertainty: [
      "The evidence establishes the simulated symptom and release dimension, not a root cause.",
    ],
    owners: [],
  };
}

/** Deterministic, offline driver for conformance/eval harnesses; never selected implicitly. */
export const deterministicEvidenceAnalysisDriver: AnalysisDriver = {
  kind: "deterministic-fixture",
  analyze(input): AnalysisDraft {
    const degraded = degradedFixtureAnalysis(input);
    if (degraded !== undefined) return degraded;
    const evidenceIds = input.evidence.map((item) => item.evidenceId);
    return {
      schemaVersion: "1.0.0",
      observations: input.evidence.map((item, index) => ({
        observationId: `evidence-${index + 1}`,
        statement: `${item.operationId} produced normalized ${item.collectionState.toLowerCase()} evidence.`,
        evidenceIds: [item.evidenceId],
      })),
      inferences: [],
      hypotheses: evidenceIds.length === 0 ? [] : [{
        hypothesisId: "evidence-requires-review",
        rank: 1,
        statement: "The collected signals require an operator-reviewed causal interpretation.",
        status: "OPEN",
        rationale: "This deterministic offline driver does not infer beyond normalized evidence.",
        supportingEvidenceIds: evidenceIds,
        contradictingEvidenceIds: [],
        nextCheck: "Review the selected evidence operations and their declared source authority.",
      }],
      checksPerformed: input.evidence.map((item) => `Collected ${item.operationId}`),
      missingEvidence: [],
      smallestSafeNextStep: "Review the cited normalized evidence before any separate approved action.",
      approvalRequired: false,
      remainingUncertainty: [],
      owners: [],
    };
  },
};

export async function runHeadlessWorkflow(
  runtime: MonitoringRuntime,
  rawRequest: unknown,
  options: HeadlessRunOptions,
): Promise<HeadlessRunOutcome> {
  const request = validateWorkflowRequest(rawRequest);
  const executionPolicy = canonicalExecutionPolicy(request, options);
  if (
    options.analysisDriver?.kind === "deterministic-fixture" &&
    (request.profileAlias !== "fixture" || !new Set(["SIMULATED", "REPLAY"]).has(request.origin))
  ) {
    throw new TypeError("Deterministic fixture analysis is restricted to fixture SIMULATED or REPLAY requests");
  }
  const events: HeadlessEvent[] = [];
  const now = options.now ?? (() => new Date());
  let sequence = 0;
  const emit = async (event: HeadlessEventInput): Promise<void> => {
    const completed = validateWorkflowEvent({
      schemaVersion: "1.0.0" as const,
      sequence: ++sequence,
      at: now().toISOString(),
      ...event,
    });
    events.push(completed);
    await options.emit?.(completed);
  };
  const requestSha256 = sha256Canonical(request);
  await emit({ event: "workflow_started", workflow: request.workflow, requestSha256 });

  const control = options.controlRoot === undefined ? undefined : new HeadlessControlStore(options.controlRoot);
  const retained = control?.get(executionPolicy.idempotencyKey, requestSha256);
  const resumeMode = options.resumeMode ?? "auto";
  if (retained !== undefined && resumeMode === "never") {
    throw new Error("A recoverable run already exists for this idempotency key");
  }
  if (retained === undefined && resumeMode === "required") {
    throw new Error("No recoverable run exists for this idempotency key");
  }
  const begun = retained === undefined
    ? runtime.beginRun(request, executionPolicy.idempotencyKey)
    : runtime.resumeRun(retained.handle, undefined, true);
  if (begun.runHandle === undefined) {
    throw new Error("Idempotent run exists but no retained owner authority is available");
  }
  const handle = begun.runHandle as RunHandle;
  let revision = begun.revision;
  const runId = begun.runId as RunId;
  if (retained !== undefined && retained.runId !== runId) {
    throw new Error("Retained control resolved to an unexpected run identity");
  }
  control?.put(executionPolicy.idempotencyKey, requestSha256, { runId, revision, handle });
  if (retained !== undefined) {
    revision = runtime.acknowledgeResume(handle, revision);
    control?.put(executionPolicy.idempotencyKey, requestSha256, { runId, revision, handle });
  }
  let evidence: EvidenceEnvelope[] = [];
  await emit(retained === undefined
    ? {
        event: "run_started",
        runId,
        revision,
        origin: request.origin,
        operationSnapshotSha256: begun.operationSnapshotSha256 as Sha256,
      }
    : {
        event: "run_resumed",
        runId,
        revision,
        operationSnapshotSha256: begun.operationSnapshotSha256 as Sha256,
      });

  try {
    if (options.signal?.aborted) throw options.signal.reason ?? new Error("Interrupted");
    const collected = await runtime.collect(
      handle,
      revision,
      requiredOperationIds(runtime, request),
      "CURRENT",
      options.signal,
    );
    revision = collected.revision;
    evidence = collected.evidence;
    control?.put(executionPolicy.idempotencyKey, requestSha256, { runId, revision, handle });
    if (options.signal?.aborted) throw options.signal.reason ?? new Error("Interrupted");
    await emit({
      event: "evidence_collected",
      runId,
      revision,
      evidence: evidence.map((envelope) => ({
        evidenceId: envelope.evidenceId,
        operationId: envelope.operationId,
        state: deriveEvidenceState({
          collectionState: envelope.collectionState,
          freshnessState: envelope.freshnessState,
          hasUnresolvedContradiction: false,
        }),
      })),
    });
    let analysisDraft: AnalysisDraft | undefined;
    let analysisFailure = false;
    if (options.analysisDriver !== undefined) {
      try {
        analysisDraft = await options.analysisDriver.analyze({ runId, request, evidence }, options.signal);
      } catch {
        if (options.signal?.aborted === true) throw options.signal.reason ?? new Error("Interrupted");
        analysisFailure = true;
        analysisDraft = undefined;
      }
    }
    const sealed = runtime.finalizeRun(handle, revision, analysisDraft);
    revision = sealed.revision;
    control?.remove(executionPolicy.idempotencyKey);
    await emit({
      event: "run_sealed",
      runId,
      revision,
      bundleId: sealed.bundleId,
      manifestSha256: sealed.manifestSha256 as Sha256,
      artifactRelativePath: sealed.artifactRelativePath,
    });
    const evidenceSummary = sealed.evidenceSummary;
    const explicitFailure = (executionPolicy.failOn === "partial" && sealed.status !== "COMPLETE") ||
      (executionPolicy.failOn === "error" && evidenceSummary.ERROR > 0);
    const exitCode = explicitFailure ? 1 : sealed.status === "COMPLETE" ? 0 : 2;
    const limitations = sealed.status === "COMPLETE"
      ? []
      : [
          "Required evidence coverage is incomplete",
          ...(options.analysisDriver === undefined
            ? ["No trusted analysis driver was available; the artifact is evidence-only"]
            : analysisFailure
              ? ["Trusted analysis failed; the artifact is evidence-only"]
              : []),
        ];
    const result: WorkflowResult = validateWorkflowSummary({
      schemaVersion: "1.0.0",
      runId,
      workflow: request.workflow,
      terminalState: "SEALED",
      investigationStatus: sealed.status,
      recoveryState: sealed.recoveryState,
      evidenceSummary,
      limitations,
      artifact: {
        bundleId: sealed.bundleId,
        manifestSha256: sealed.manifestSha256 as Sha256,
        relativePath: sealed.artifactRelativePath,
      },
      exitCode,
    });
    await emit({
      event: "workflow_result",
      result,
      requestSha256,
      operationSnapshotSha256: begun.operationSnapshotSha256 as Sha256,
    });
    return { result, events };
  } catch (error) {
    const interrupted = options.signal?.aborted === true;
    const code = interrupted ? "INTERRUPTED" : sanitizedCode(error);
    if (interrupted) {
      try {
        const paused = runtime.pauseRun(handle, revision);
        revision = paused.revision;
        control?.put(executionPolicy.idempotencyKey, requestSha256, { runId, revision, handle });
      } catch {
        // A hard interruption may leave a bounded lease; retained authority can retry after expiry.
      }
    } else {
      try {
        runtime.cancelRun(handle, revision, "PROVIDER_UNAVAILABLE");
        control?.remove(executionPolicy.idempotencyKey);
      } catch {
        // The original sanitized failure remains authoritative.
      }
    }
    await emit({ event: "workflow_stopped", runId, state: interrupted ? "PAUSED" : "BLOCKED", code });
    const result: WorkflowResult = validateWorkflowSummary({
      schemaVersion: "1.0.0",
      runId,
      workflow: request.workflow,
      terminalState: interrupted ? "PAUSED" : "BLOCKED",
      investigationStatus: "BLOCKED",
      recoveryState: request.workflow === "verify" ? "INCOMPLETE" : "NONE",
      evidenceSummary: summarizePreFinalizationEvidence(evidence),
      limitations: [interrupted ? "Workflow interrupted; owned partial evidence was retained" : "Workflow blocked by a sanitized runtime failure"],
      exitCode: interrupted ? (options.terminationExitCode ?? 130) : 2,
    });
    await emit({
      event: "workflow_result",
      result,
      requestSha256,
      operationSnapshotSha256: begun.operationSnapshotSha256 as Sha256,
    });
    return { result, events };
  }
}

export async function cancelHeadlessWorkflow(
  runtime: MonitoringRuntime,
  rawRequest: unknown,
  options: HeadlessCancelOptions,
): Promise<HeadlessCancelOutcome> {
  const request = validateWorkflowRequest(rawRequest);
  if (options.idempotencyKey !== undefined && options.idempotencyKey !== request.idempotencyKey) {
    throw new TypeError("Headless idempotency policy conflicts with the canonical workflow request");
  }
  const idempotencyKey = request.idempotencyKey;
  const requestSha256 = sha256Canonical(request);
  const control = new HeadlessControlStore(options.controlRoot);
  const retained = control.get(idempotencyKey, requestSha256);
  if (retained === undefined) throw new Error("No recoverable run exists for this idempotency key");
  const resumed = runtime.resumeRun(retained.handle, undefined, true);
  if (resumed.runHandle === undefined || resumed.runId !== retained.runId) {
    throw new Error("Retained run authority could not be resumed");
  }
  control.put(idempotencyKey, requestSha256, {
    runId: resumed.runId,
    revision: resumed.revision,
    handle: resumed.runHandle,
  });
  const acknowledgedRevision = runtime.acknowledgeResume(resumed.runHandle, resumed.revision);
  control.put(idempotencyKey, requestSha256, {
    runId: resumed.runId,
    revision: acknowledgedRevision,
    handle: resumed.runHandle,
  });
  const cancelled = runtime.cancelRun(
    resumed.runHandle,
    acknowledgedRevision,
    options.reason ?? "USER_REQUEST",
  );
  control.remove(idempotencyKey);
  const event: HeadlessEvent = validateWorkflowEvent({
    schemaVersion: "1.0.0",
    sequence: 1,
    at: (options.now ?? (() => new Date()))().toISOString(),
    event: "run_cancelled",
    runId: cancelled.runId,
    revision: cancelled.revision,
    retainedEvidenceIds: cancelled.retainedEvidenceIds,
  });
  await options.emit?.(event);
  return {
    runId: cancelled.runId,
    revision: cancelled.revision,
    retainedEvidenceIds: cancelled.retainedEvidenceIds,
    events: [event],
  };
}

export function deterministicClock(value: string): Clock {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime()) || date.toISOString() !== value) {
    throw new TypeError("Deterministic clock must be an ISO UTC timestamp");
  }
  return { now: () => new Date(date) };
}
