import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
} from "node:crypto";

import {
  canonicalJson,
  sha256Canonical,
  type RunHandle,
  type RunId,
} from "@codex-production-monitoring/contracts";
import { AtomicStateFile, RunStoreError } from "@codex-production-monitoring/run-store";

interface KeyState {
  schemaVersion: "1.0.0";
  keyBase64: string;
}

interface ControlEntry {
  keySha256: string;
  requestSha256: string;
  runId: RunId;
  revision: number;
  ivBase64: string;
  ciphertextBase64: string;
  tagBase64: string;
}

interface ControlState {
  schemaVersion: "1.0.0";
  entries: ControlEntry[];
}

export interface RetainedRunControl {
  runId: RunId;
  revision: number;
  handle: RunHandle;
}

function lookupKey(idempotencyKey: string): string {
  if (idempotencyKey.length === 0 || idempotencyKey.length > 256) {
    throw new TypeError("Idempotency key is invalid");
  }
  return sha256Canonical({ domain: "pm-headless-control-v1", idempotencyKey });
}

function aad(entry: Pick<ControlEntry, "keySha256" | "requestSha256" | "runId" | "revision">): Buffer {
  return Buffer.from(canonicalJson({
    keySha256: entry.keySha256,
    requestSha256: entry.requestSha256,
    runId: entry.runId,
    revision: entry.revision,
  }), "utf8");
}

function validateKeyState(value: KeyState): Buffer {
  if (value.schemaVersion !== "1.0.0" || typeof value.keyBase64 !== "string") {
    throw new RunStoreError("STATE_CORRUPT", "Headless control key state is invalid");
  }
  const key = Buffer.from(value.keyBase64, "base64");
  if (key.byteLength !== 32 || key.toString("base64") !== value.keyBase64) {
    throw new RunStoreError("STATE_CORRUPT", "Headless control key state is invalid");
  }
  return key;
}

function validateControlState(value: ControlState | undefined): ControlState {
  if (value === undefined) return { schemaVersion: "1.0.0", entries: [] };
  if (value.schemaVersion !== "1.0.0" || !Array.isArray(value.entries)) {
    throw new RunStoreError("STATE_CORRUPT", "Headless control state is invalid");
  }
  const keys = new Set<string>();
  for (const entry of value.entries) {
    if (
      !/^[a-f0-9]{64}$/u.test(entry.keySha256) ||
      !/^[a-f0-9]{64}$/u.test(entry.requestSha256) ||
      !/^pmrun_[A-Za-z0-9_-]{20,128}$/u.test(entry.runId) ||
      !Number.isSafeInteger(entry.revision) || entry.revision < 1 ||
      typeof entry.ivBase64 !== "string" || Buffer.from(entry.ivBase64, "base64").byteLength !== 12 ||
      typeof entry.tagBase64 !== "string" || Buffer.from(entry.tagBase64, "base64").byteLength !== 16 ||
      typeof entry.ciphertextBase64 !== "string" || Buffer.from(entry.ciphertextBase64, "base64").byteLength < 16 ||
      keys.has(entry.keySha256)
    ) {
      throw new RunStoreError("STATE_CORRUPT", "Headless control entry is invalid");
    }
    keys.add(entry.keySha256);
  }
  return structuredClone(value);
}

/** Encrypted, owner-only control state. Handles never appear in JSONL or plaintext state. */
export class HeadlessControlStore {
  readonly #key: Buffer;
  readonly #state: AtomicStateFile<ControlState>;

  constructor(stateRoot: string) {
    const keyFile = new AtomicStateFile<KeyState>({
      stateRoot,
      filename: "headless-key.json",
      kind: "production-monitoring-headless-key-v1",
    });
    const keyState = keyFile.transact((existing) => {
      const payload = existing ?? {
        schemaVersion: "1.0.0" as const,
        keyBase64: randomBytes(32).toString("base64"),
      };
      validateKeyState(payload);
      return { payload, result: payload };
    });
    this.#key = validateKeyState(keyState);
    this.#state = new AtomicStateFile({
      stateRoot,
      filename: "headless-control.json",
      kind: "production-monitoring-headless-control-v1",
    });
    this.#state.transact((current) => {
      const payload = validateControlState(current);
      return { payload, result: undefined };
    });
  }

  get(idempotencyKey: string, requestSha256: string): RetainedRunControl | undefined {
    const keySha256 = lookupKey(idempotencyKey);
    const state = validateControlState(this.#state.read());
    const entry = state.entries.find((candidate) => candidate.keySha256 === keySha256);
    if (entry === undefined) return undefined;
    if (entry.requestSha256 !== requestSha256) {
      throw new RunStoreError("IDEMPOTENCY_CONFLICT", "Retained control belongs to another request");
    }
    try {
      const decipher = createDecipheriv("aes-256-gcm", this.#key, Buffer.from(entry.ivBase64, "base64"));
      decipher.setAAD(aad(entry));
      decipher.setAuthTag(Buffer.from(entry.tagBase64, "base64"));
      const plaintext = Buffer.concat([
        decipher.update(Buffer.from(entry.ciphertextBase64, "base64")),
        decipher.final(),
      ]).toString("utf8");
      if (!/^pmh_[A-Za-z0-9_-]{43}$/u.test(plaintext)) throw new Error("invalid handle");
      return { runId: entry.runId, revision: entry.revision, handle: plaintext as RunHandle };
    } catch {
      throw new RunStoreError("STATE_CORRUPT", "Retained run authority could not be authenticated");
    }
  }

  put(
    idempotencyKey: string,
    requestSha256: string,
    control: RetainedRunControl,
  ): void {
    const keySha256 = lookupKey(idempotencyKey);
    const iv = randomBytes(12);
    const metadata = { keySha256, requestSha256, runId: control.runId, revision: control.revision };
    const cipher = createCipheriv("aes-256-gcm", this.#key, iv);
    cipher.setAAD(aad(metadata));
    const ciphertext = Buffer.concat([
      cipher.update(control.handle, "utf8"),
      cipher.final(),
    ]);
    const entry: ControlEntry = {
      ...metadata,
      ivBase64: iv.toString("base64"),
      ciphertextBase64: ciphertext.toString("base64"),
      tagBase64: cipher.getAuthTag().toString("base64"),
    };
    this.#state.transact((current) => {
      const state = validateControlState(current);
      const entries = state.entries.filter((candidate) => candidate.keySha256 !== keySha256);
      entries.push(entry);
      entries.sort((left, right) => left.keySha256.localeCompare(right.keySha256));
      return { payload: { schemaVersion: "1.0.0", entries }, result: undefined };
    });
  }

  remove(idempotencyKey: string): void {
    const keySha256 = lookupKey(idempotencyKey);
    this.#state.transact((current) => {
      const state = validateControlState(current);
      return {
        payload: {
          schemaVersion: "1.0.0",
          entries: state.entries.filter((candidate) => candidate.keySha256 !== keySha256),
        },
        result: undefined,
      };
    });
  }
}
