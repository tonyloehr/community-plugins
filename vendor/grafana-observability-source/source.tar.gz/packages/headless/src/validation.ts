import {
  loadSchemaRegistry,
  SCHEMA_IDS,
  type WorkflowEvent,
  type WorkflowResult,
  type WorkflowSummary,
} from "@codex-production-monitoring/contracts";
import { Ajv2020 } from "ajv/dist/2020.js";
import type { ErrorObject, ValidateFunction } from "ajv";
import addFormatsImport from "ajv-formats";

const ajv = new Ajv2020({ allErrors: true, allowUnionTypes: true, strict: true });
const addFormats = addFormatsImport as unknown as (instance: Ajv2020) => Ajv2020;
addFormats(ajv);
for (const schema of loadSchemaRegistry().values()) ajv.addSchema(schema);

function validator<T>(id: string): ValidateFunction<T> {
  const validate = ajv.getSchema(id);
  if (validate === undefined) throw new Error(`Headless contract schema is not registered: ${id}`);
  return validate as ValidateFunction<T>;
}

const eventValidator = validator<WorkflowEvent>(SCHEMA_IDS.workflowEvent);
const resultValidator = validator<WorkflowResult>(SCHEMA_IDS.workflowResult);
const summaryValidator = validator<WorkflowSummary>(SCHEMA_IDS.workflowSummary);

function summarize(errors: ErrorObject[] | null | undefined): string {
  return (errors ?? [])
    .slice(0, 5)
    .map((error) => `${error.instancePath || "/"} ${error.message ?? "is invalid"}`)
    .join("; ");
}

export class HeadlessContractValidationError extends Error {
  readonly code = "INVALID_HEADLESS_CONTRACT";

  constructor(kind: "event" | "result" | "summary", errors: ErrorObject[] | null | undefined) {
    super(`Workflow ${kind} is invalid: ${summarize(errors)}`);
    this.name = "HeadlessContractValidationError";
  }
}

export function validateWorkflowEvent(value: unknown): WorkflowEvent {
  if (!eventValidator(value)) throw new HeadlessContractValidationError("event", eventValidator.errors);
  return structuredClone(value);
}

export function validateWorkflowResult(value: unknown): WorkflowResult {
  if (!resultValidator(value)) throw new HeadlessContractValidationError("result", resultValidator.errors);
  return structuredClone(value);
}

export function validateWorkflowSummary(value: unknown): WorkflowSummary {
  if (!summaryValidator(value)) throw new HeadlessContractValidationError("summary", summaryValidator.errors);
  return structuredClone(value);
}
