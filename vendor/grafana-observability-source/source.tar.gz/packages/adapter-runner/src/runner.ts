import type { Readable, Writable } from "node:stream";

import {
  AdapterContractError,
  AdapterExecutionError,
  assertWorkerResponse,
  BudgetExceededError,
  createBudgetController,
  DEFAULT_MAX_WORKER_FRAME_BYTES,
  encodeWorkerFrame,
  parseWorkerRequestPayload,
  WorkerFrameDecoder,
  WorkerProtocolError,
  WORKER_PROTOCOL,
  type EvidenceAdapter,
  type WorkerRequest,
  type WorkerResponse,
} from "../../adapter-sdk/src/index.ts";
import type { SanitizedError } from "../../contracts/src/index.ts";

export interface AdapterWorkerRunnerOptions {
  input?: Readable;
  output?: Writable;
  maxRequestFrameBytes?: number;
  maxResponseFrameBytes?: number;
  clock?: { now(): Date };
}

class RunnerDeadlineError extends Error {
  constructor() {
    super("Worker request deadline exceeded");
    this.name = "RunnerDeadlineError";
  }
}

function runnerError(error: unknown, signal?: AbortSignal): SanitizedError {
  if (error instanceof AdapterExecutionError) return error.sanitized;
  if (error instanceof BudgetExceededError) {
    return {
      code: `ADAPTER_WORKER_BUDGET_${error.dimension.toUpperCase()}`,
      category: "POLICY",
      message: `Adapter worker ${error.dimension} budget exceeded`,
      retryable: false,
    };
  }
  if (error instanceof RunnerDeadlineError || (signal?.aborted === true && signal.reason instanceof RunnerDeadlineError)) {
    return {
      code: "ADAPTER_WORKER_DEADLINE_EXCEEDED",
      category: "TIMEOUT",
      message: "Adapter worker request deadline exceeded",
      retryable: true,
    };
  }
  if (signal?.aborted === true) {
    return {
      code: "ADAPTER_WORKER_CANCELLED",
      category: "POLICY",
      message: "Adapter worker request was cancelled",
      retryable: false,
    };
  }
  if (error instanceof AdapterContractError || error instanceof TypeError) {
    return {
      code: "ADAPTER_WORKER_CONTRACT",
      category: "INVALID_RESPONSE",
      message: "Adapter worker rejected an invalid request or result",
      retryable: false,
    };
  }
  return {
    code: "ADAPTER_WORKER_FAILURE",
    category: "INTERNAL",
    message: "Adapter worker request failed",
    retryable: false,
  };
}

function errorResponse(requestId: string, error: SanitizedError): WorkerResponse {
  return { protocol: WORKER_PROTOCOL, kind: "error", requestId, error };
}

function onceDrain(output: Writable): Promise<void> {
  return new Promise((resolve, reject) => {
    const onDrain = (): void => {
      cleanup();
      resolve();
    };
    const onError = (): void => {
      cleanup();
      reject(new Error("Worker stdout failed"));
    };
    const cleanup = (): void => {
      output.removeListener("drain", onDrain);
      output.removeListener("error", onError);
    };
    output.once("drain", onDrain);
    output.once("error", onError);
  });
}

async function writeFrame(output: Writable, frame: Buffer): Promise<void> {
  if (!output.write(frame)) await onceDrain(output);
}

async function sendResponse(
  output: Writable,
  response: WorkerResponse,
  maximumBytes: number,
): Promise<void> {
  try {
    assertWorkerResponse(response);
    await writeFrame(output, encodeWorkerFrame(response, maximumBytes));
  } catch (error) {
    if (!(error instanceof WorkerProtocolError) || error.failure !== "OVERSIZE") throw error;
    const fallback = errorResponse(response.requestId, {
      code: "ADAPTER_WORKER_RESPONSE_OVERSIZE",
      category: "POLICY",
      message: "Adapter worker response exceeded the configured byte limit",
      retryable: false,
    });
    await writeFrame(output, encodeWorkerFrame(fallback, maximumBytes));
  }
}

async function handleRequest(
  adapter: EvidenceAdapter,
  request: WorkerRequest,
  clock: { now(): Date },
): Promise<WorkerResponse> {
  if (request.kind === "doctor") {
    const deadline = new AbortController();
    const timer = setTimeout(() => deadline.abort(new RunnerDeadlineError()), 5_000);
    timer.unref();
    try {
      const result = await adapter.doctor({ signal: deadline.signal, clock });
      return { protocol: WORKER_PROTOCOL, kind: "doctor-result", requestId: request.requestId, result };
    } catch (error) {
      return errorResponse(request.requestId, runnerError(error, deadline.signal));
    } finally {
      clearTimeout(timer);
    }
  }
  if (request.kind === "compile") {
    try {
      const operation = await adapter.compile(request.operation, {
        adapterPackage: request.adapterPackage,
        maxDefinitionBytes: request.maxDefinitionBytes,
      });
      return { protocol: WORKER_PROTOCOL, kind: "compiled", requestId: request.requestId, operation };
    } catch (error) {
      return errorResponse(request.requestId, runnerError(error));
    }
  }

  const deadline = new AbortController();
  const remaining = Math.max(
    0,
    Math.min(request.context.limits.timeoutMs, Date.parse(request.context.deadlineAt) - Date.now()),
  );
  const timer = setTimeout(() => deadline.abort(new RunnerDeadlineError()), remaining);
  timer.unref();
  try {
    const result = await adapter.execute(
      {
        origin: request.context.origin,
        scope: request.context.scope,
        window: request.context.window,
        ...(request.context.expectedTenantSha256 === undefined
          ? {}
          : { expectedTenantSha256: request.context.expectedTenantSha256 }),
        clock,
        budget: createBudgetController(request.context.limits, deadline.signal),
        signal: deadline.signal,
      },
      request.operation,
    );
    return { protocol: WORKER_PROTOCOL, kind: "result", requestId: request.requestId, result };
  } catch (error) {
    return errorResponse(request.requestId, runnerError(error, deadline.signal));
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Runs one adapter behind PM_ADAPTER_STDIO_V1 until stdin closes. The process
 * owns no authority beyond the adapter and fixed environment supplied by its host.
 */
export async function runAdapterWorker(
  adapter: EvidenceAdapter,
  options: AdapterWorkerRunnerOptions = {},
): Promise<void> {
  const input = options.input ?? process.stdin;
  const output = options.output ?? process.stdout;
  const requestLimit = options.maxRequestFrameBytes ?? DEFAULT_MAX_WORKER_FRAME_BYTES;
  const responseLimit = options.maxResponseFrameBytes ?? DEFAULT_MAX_WORKER_FRAME_BYTES;
  const clock = options.clock ?? { now: () => new Date() };
  const decoder = new WorkerFrameDecoder(requestLimit);
  const seenRequestIds = new Set<string>();
  let queue = Promise.resolve();
  let failed = false;

  await new Promise<void>((resolve, reject) => {
    const fail = (error: unknown): void => {
      if (failed) return;
      failed = true;
      input.pause();
      reject(error);
    };
    input.on("data", (chunk: Buffer) => {
      if (failed) return;
      let payloads: Buffer[];
      try {
        payloads = decoder.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
      } catch (error) {
        fail(error);
        return;
      }
      for (const payload of payloads) {
        let request: WorkerRequest;
        try {
          request = parseWorkerRequestPayload(payload);
          if (seenRequestIds.has(request.requestId)) throw new WorkerProtocolError("INVALID_MESSAGE");
          seenRequestIds.add(request.requestId);
          if (seenRequestIds.size > 4096) {
            const oldest = seenRequestIds.values().next().value as string | undefined;
            if (oldest !== undefined) seenRequestIds.delete(oldest);
          }
        } catch (error) {
          fail(error);
          return;
        }
        queue = queue
          .then(async () => {
            const response = await handleRequest(adapter, request, clock);
            await sendResponse(output, response, responseLimit);
          })
          .catch(fail);
      }
    });
    input.once("end", () => {
      try {
        decoder.finish();
      } catch (error) {
        fail(error);
        return;
      }
      void queue.then(() => resolve(), fail);
    });
    input.once("error", fail);
    output.once("error", fail);
    input.resume();
  });
}
