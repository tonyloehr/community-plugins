import type {
  CollectionState,
  CoverageDisposition,
  EvidenceState,
  FreshnessState,
} from "./types.ts";

export interface EvidenceStateInput {
  collectionState: CollectionState;
  freshnessState: FreshnessState;
  hasUnresolvedContradiction?: boolean;
}

/**
 * Produce the canonical five-state evidence projection without conflating a
 * source read with cross-source consistency. Error takes precedence because
 * no source claim exists to compare; contradiction then outranks freshness.
 */
export function deriveEvidenceState(input: EvidenceStateInput): EvidenceState {
  if (input.collectionState === "ERROR") return "ERROR";
  if (input.hasUnresolvedContradiction === true) return "CONTRADICTORY";
  if (input.freshnessState === "STALE") return "STALE";
  if (input.collectionState === "EMPTY") return "EMPTY";
  return "COMPLETE";
}

export function evidenceStateToCoverageDisposition(state: EvidenceState): CoverageDisposition {
  return state === "COMPLETE" ? "AVAILABLE" : state;
}
