import { computeCapabilityPackDefinitionHash, sha256Canonical } from "./canonical-json.ts";
import type {
  CapabilityPackId,
  EvidenceEnvelope,
  OperationId,
  ProviderCapabilityPackV1,
  Sha256,
} from "./types.ts";

type PackDraft = Omit<ProviderCapabilityPackV1, "definitionSha256">;

function operation(value: string): OperationId {
  return value as OperationId;
}

function packId(value: string): CapabilityPackId {
  return value as CapabilityPackId;
}

/** Seal one reviewed pack with the canonical hash used by trust activation and run policy. */
export function sealCapabilityPack(draft: PackDraft): Readonly<ProviderCapabilityPackV1> {
  const pack: ProviderCapabilityPackV1 = {
    ...structuredClone(draft),
    definitionSha256: computeCapabilityPackDefinitionHash(draft),
  };
  validateCapabilityPack(pack);
  return deepFreeze(pack);
}

function deepFreeze<T>(value: T, seen = new Set<object>()): Readonly<T> {
  if (value === null || typeof value !== "object" || seen.has(value)) return value;
  seen.add(value);
  for (const child of Object.values(value as Record<string, unknown>)) deepFreeze(child, seen);
  return Object.freeze(value);
}

function unique(values: readonly string[], label: string): void {
  if (new Set(values).size !== values.length) throw new TypeError(`${label} must be unique`);
}

/** Semantic checks beyond what JSON Schema can express. */
export function validateCapabilityPack(pack: Readonly<ProviderCapabilityPackV1>): void {
  const { definitionSha256: _definitionSha256, ...draft } = pack;
  void _definitionSha256;
  if (computeCapabilityPackDefinitionHash(draft) !== pack.definitionSha256) {
    throw new TypeError(`Capability pack ${pack.packId} has an invalid definition hash`);
  }
  unique(pack.requiredOperationIds, `${pack.packId} required operations`);
  unique(pack.optionalOperationIds, `${pack.packId} optional operations`);
  unique(pack.supportedSubjectKinds, `${pack.packId} subject kinds`);
  unique(pack.scopeMappings.map((mapping) => mapping.scopeField), `${pack.packId} scope fields`);
  unique(pack.scopeMappings.map((mapping) => mapping.providerField), `${pack.packId} provider scope fields`);
  unique(pack.signals.map((signal) => signal.signalId), `${pack.packId} signal IDs`);
  unique(pack.signals.map((signal) => String(signal.order)), `${pack.packId} signal order`);
  unique(pack.issueRules.map((rule) => rule.ruleId), `${pack.packId} rule IDs`);
  const required = new Set(pack.requiredOperationIds);
  if (pack.optionalOperationIds.some((id) => required.has(id))) {
    throw new TypeError(`Capability pack ${pack.packId} repeats required operations as optional`);
  }
  const subjectMapping = pack.scopeMappings.find((mapping) => mapping.scopeField === "subject.ref");
  if (pack.supportedSubjectKinds.length > 0 && (subjectMapping === undefined || !subjectMapping.required)) {
    throw new TypeError(`Capability pack ${pack.packId} must require an opaque subject mapping`);
  }
  if (pack.supportedSubjectKinds.length === 0 && subjectMapping !== undefined) {
    throw new TypeError(`Capability pack ${pack.packId} cannot map a subject kind it does not support`);
  }
  const admitted = new Set([...pack.requiredOperationIds, ...pack.optionalOperationIds]);
  for (const signal of pack.signals) {
    if (!admitted.has(signal.operationId)) {
      throw new TypeError(`Capability pack ${pack.packId} signal references an unbound operation`);
    }
    if (
      signal.thresholds !== undefined &&
      signal.thresholds.warning === undefined &&
      signal.thresholds.critical === undefined
    ) {
      throw new TypeError(`Capability pack ${pack.packId} has an empty signal threshold`);
    }
  }
  for (const rule of pack.issueRules) {
    if (!admitted.has(rule.operationId)) {
      throw new TypeError(`Capability pack ${pack.packId} rule references an unbound operation`);
    }
    if (rule.comparisonOperationId !== undefined && !admitted.has(rule.comparisonOperationId)) {
      throw new TypeError(`Capability pack ${pack.packId} rule comparison is unbound`);
    }
    if (rule.issueKind === "ANOMALY" && !rule.signedThreshold) {
      throw new TypeError(`Capability pack ${pack.packId} cannot label an unsigned deviation as an anomaly`);
    }
    if (
      rule.comparison === "THRESHOLD" &&
      (rule.resultName === undefined || rule.comparator === undefined || rule.threshold === undefined)
    ) {
      throw new TypeError(`Capability pack ${pack.packId} threshold rule is incomplete`);
    }
    if (
      rule.comparison === "BASELINE_DELTA" &&
      (rule.resultName === undefined || rule.comparator === undefined || rule.delta === undefined)
    ) {
      throw new TypeError(`Capability pack ${pack.packId} baseline rule is incomplete`);
    }
    if (rule.comparison === "STALE" && rule.maxAgeMs === undefined) {
      throw new TypeError(`Capability pack ${pack.packId} stale rule is incomplete`);
    }
    if (
      rule.reducer !== undefined &&
      rule.comparison !== "THRESHOLD" &&
      rule.comparison !== "BASELINE_DELTA"
    ) {
      throw new TypeError(`Capability pack ${pack.packId} reducer is valid only for numeric rules`);
    }
    if (rule.comparison === "THRESHOLD" || rule.comparison === "BASELINE_DELTA") {
      const currentSignals = pack.signals.filter((signal) =>
        signal.operationId === rule.operationId && signal.resultName === rule.resultName);
      if (currentSignals.length !== 1) {
        throw new TypeError(`Capability pack ${pack.packId} numeric rule must name exactly one declared signal`);
      }
      if (rule.comparison === "BASELINE_DELTA") {
        const comparisonOperationId = rule.comparisonOperationId ?? rule.operationId;
        const baselineSignals = pack.signals.filter((signal) =>
          signal.operationId === comparisonOperationId && signal.resultName === rule.resultName);
        if (baselineSignals.length !== 1 || baselineSignals[0]!.unit !== currentSignals[0]!.unit) {
          throw new TypeError(`Capability pack ${pack.packId} baseline rule must compare compatible declared signal units`);
        }
      }
    }
  }
}

/** Stable corroboration key: equal datasource identities never count as independent evidence. */
export function evidenceSourceIndependenceKey(
  envelope: Pick<EvidenceEnvelope, "source">,
): Sha256 {
  return envelope.source.lineage?.sourceIdentitySha256 ?? sha256Canonical({
    provider: envelope.source.provider,
    sourceAlias: envelope.source.sourceAlias,
  });
}

const ENVIRONMENT_SCOPE = [
  { scopeField: "environment", providerField: "environment", required: true },
  { scopeField: "service", providerField: "service", required: false },
] as const;

export const GRAFANA_INFRASTRUCTURE_PACK = sealCapabilityPack({
  schemaVersion: "1.0.0",
  packId: packId("grafana.infrastructure"),
  revision: 1,
  useCase: "INFRASTRUCTURE",
  requiredOperationIds: [
    operation("grafana.infrastructure.cpu.usage"),
    operation("grafana.infrastructure.memory.load"),
    operation("grafana.infrastructure.disk.free"),
    operation("grafana.infrastructure.system.load"),
  ],
  optionalOperationIds: [],
  supportedSubjectKinds: ["HOST", "FLEET"],
  scopeMappings: [
    ...ENVIRONMENT_SCOPE,
    { scopeField: "subject.ref", providerField: "instance", required: true },
  ],
  signals: [
    { signalId: "cpu_usage", operationId: operation("grafana.infrastructure.cpu.usage"), resultName: "cpu_usage", order: 1, unit: "percent", polarity: "HIGH_IS_BAD", thresholds: { comparator: "GTE", warning: 80, critical: 95 } },
    { signalId: "memory_load", operationId: operation("grafana.infrastructure.memory.load"), resultName: "memory_load", order: 2, unit: "percent", polarity: "HIGH_IS_BAD", thresholds: { comparator: "GTE", warning: 80, critical: 95 } },
    { signalId: "disk_free", operationId: operation("grafana.infrastructure.disk.free"), resultName: "disk_free", order: 3, unit: "percent", polarity: "LOW_IS_BAD", thresholds: { comparator: "LTE", warning: 20, critical: 10 } },
    { signalId: "system_load", operationId: operation("grafana.infrastructure.system.load"), resultName: "system_load", order: 4, unit: "ratio", polarity: "HIGH_IS_BAD", thresholds: { comparator: "GTE", warning: 1, critical: 2 } },
  ],
  issueRules: [
    { ruleId: "cpu_critical", comparison: "THRESHOLD", operationId: operation("grafana.infrastructure.cpu.usage"), resultName: "cpu_usage", comparator: "GTE", threshold: 95, issueKind: "ALERT", severity: "CRITICAL", signedThreshold: true },
    { ruleId: "memory_critical", comparison: "THRESHOLD", operationId: operation("grafana.infrastructure.memory.load"), resultName: "memory_load", comparator: "GTE", threshold: 95, issueKind: "ALERT", severity: "CRITICAL", signedThreshold: true },
    { ruleId: "disk_critical", comparison: "THRESHOLD", operationId: operation("grafana.infrastructure.disk.free"), resultName: "disk_free", comparator: "LTE", threshold: 10, issueKind: "ALERT", severity: "CRITICAL", signedThreshold: true },
    { ruleId: "infrastructure_gap", comparison: "ERROR", operationId: operation("grafana.infrastructure.system.load"), issueKind: "EVIDENCE_GAP", severity: "WARNING", signedThreshold: false },
  ],
});

export const GRAFANA_APM_PACK = sealCapabilityPack({
  schemaVersion: "1.0.0",
  packId: packId("grafana.apm"),
  revision: 1,
  useCase: "APPLICATION_PERFORMANCE",
  requiredOperationIds: [
    operation("grafana.apm.request.rate"),
    operation("grafana.apm.error.codes"),
    operation("grafana.apm.error.rate"),
    operation("grafana.apm.latency.p95"),
    // Tempo is certified as bounded event/table evidence. Keep slow/error traces
    // required without inventing a numeric threshold until an aggregation contract is reviewed.
    operation("grafana.apm.traces.slow"),
  ],
  optionalOperationIds: [],
  supportedSubjectKinds: [],
  scopeMappings: [...ENVIRONMENT_SCOPE],
  signals: [
    { signalId: "request_rate", operationId: operation("grafana.apm.request.rate"), resultName: "request_rate", order: 1, unit: "requests_per_second", polarity: "NEUTRAL" },
    { signalId: "error_rate", operationId: operation("grafana.apm.error.rate"), resultName: "error_rate", order: 2, unit: "percent", polarity: "HIGH_IS_BAD", thresholds: { comparator: "GTE", warning: 1, critical: 5 } },
    { signalId: "latency_p95", operationId: operation("grafana.apm.latency.p95"), resultName: "latency_p95", order: 3, unit: "milliseconds", polarity: "HIGH_IS_BAD", thresholds: { comparator: "GTE", warning: 500, critical: 1000 } },
  ],
  issueRules: [
    { ruleId: "error_rate_regression", comparison: "BASELINE_DELTA", operationId: operation("grafana.apm.error.rate"), resultName: "error_rate", comparator: "GTE", delta: 2, issueKind: "REGRESSION", severity: "CRITICAL", signedThreshold: true },
    { ruleId: "latency_regression", comparison: "BASELINE_DELTA", operationId: operation("grafana.apm.latency.p95"), resultName: "latency_p95", comparator: "GTE", delta: 250, issueKind: "REGRESSION", severity: "WARNING", signedThreshold: true },
    { ruleId: "apm_empty", comparison: "EMPTY", operationId: operation("grafana.apm.request.rate"), issueKind: "EVIDENCE_GAP", severity: "WARNING", signedThreshold: false },
  ],
});

export const GRAFANA_LOGS_PACK = sealCapabilityPack({
  schemaVersion: "1.0.0",
  packId: packId("grafana.logs"),
  revision: 1,
  useCase: "LOG_ANALYTICS",
  requiredOperationIds: [
    operation("grafana.logs.events"),
    operation("grafana.logs.error.rate"),
    operation("grafana.logs.security.markers"),
  ],
  optionalOperationIds: [],
  supportedSubjectKinds: ["HOST", "DEVICE"],
  scopeMappings: [
    ...ENVIRONMENT_SCOPE,
    { scopeField: "subject.ref", providerField: "subject", required: true },
  ],
  signals: [
    { signalId: "log_events", operationId: operation("grafana.logs.events"), resultName: "log_events", order: 1, unit: "events", polarity: "NEUTRAL" },
    { signalId: "log_error_rate", operationId: operation("grafana.logs.error.rate"), resultName: "log_error_rate", order: 2, unit: "events_per_second", polarity: "HIGH_IS_BAD" },
    { signalId: "security_markers", operationId: operation("grafana.logs.security.markers"), resultName: "security_markers", order: 3, unit: "events", polarity: "HIGH_IS_BAD", thresholds: { comparator: "GTE", critical: 1 } },
  ],
  issueRules: [
    { ruleId: "error_log_deviation", comparison: "BASELINE_DELTA", operationId: operation("grafana.logs.error.rate"), resultName: "log_error_rate", comparator: "GTE", delta: 1, issueKind: "REGRESSION", severity: "WARNING", signedThreshold: true },
    { ruleId: "security_marker", comparison: "THRESHOLD", operationId: operation("grafana.logs.security.markers"), resultName: "security_markers", comparator: "GTE", threshold: 1, issueKind: "ANOMALY", severity: "CRITICAL", signedThreshold: true },
  ],
});

export const GRAFANA_IOT_EDGE_PACK = sealCapabilityPack({
  schemaVersion: "1.0.0",
  packId: packId("grafana.iot-edge"),
  revision: 1,
  useCase: "IOT_EDGE",
  requiredOperationIds: [operation("grafana.iot.telemetry"), operation("grafana.iot.device.freshness")],
  optionalOperationIds: [],
  supportedSubjectKinds: ["DEVICE", "FLEET"],
  scopeMappings: [
    { scopeField: "environment", providerField: "environment", required: true },
    { scopeField: "subject.ref", providerField: "device", required: true },
  ],
  signals: [
    { signalId: "telemetry", operationId: operation("grafana.iot.telemetry"), resultName: "telemetry", order: 1, polarity: "NEUTRAL" },
    { signalId: "device_freshness", operationId: operation("grafana.iot.device.freshness"), resultName: "device_age", order: 2, unit: "seconds", polarity: "HIGH_IS_BAD", thresholds: { comparator: "GTE", warning: 300, critical: 900 } },
  ],
  issueRules: [
    { ruleId: "device_stale", comparison: "THRESHOLD", operationId: operation("grafana.iot.device.freshness"), resultName: "device_age", reducer: "MAX", comparator: "GTE", threshold: 300, issueKind: "ALERT", severity: "WARNING", signedThreshold: true },
    { ruleId: "telemetry_empty", comparison: "EMPTY", operationId: operation("grafana.iot.telemetry"), issueKind: "EVIDENCE_GAP", severity: "WARNING", signedThreshold: false },
  ],
});

export const GRAFANA_BUSINESS_KPI_PACK = sealCapabilityPack({
  schemaVersion: "1.0.0",
  packId: packId("grafana.business-kpis"),
  revision: 1,
  useCase: "BUSINESS_INTELLIGENCE",
  requiredOperationIds: [
    operation("grafana.business.revenue"),
    operation("grafana.business.conversion"),
    operation("grafana.business.operational.kpi"),
  ],
  optionalOperationIds: [],
  supportedSubjectKinds: ["BUSINESS_UNIT", "KPI_SET"],
  scopeMappings: [
    { scopeField: "environment", providerField: "environment", required: true },
    { scopeField: "subject.ref", providerField: "business_scope", required: true },
  ],
  signals: [
    { signalId: "revenue", operationId: operation("grafana.business.revenue"), resultName: "revenue", order: 1, unit: "currency", polarity: "NEUTRAL" },
    { signalId: "conversion", operationId: operation("grafana.business.conversion"), resultName: "conversion", order: 2, unit: "percent", polarity: "LOW_IS_BAD" },
    { signalId: "operational_kpi", operationId: operation("grafana.business.operational.kpi"), resultName: "operational_kpi", order: 3, polarity: "NEUTRAL" },
  ],
  issueRules: [
    { ruleId: "revenue_deviation", comparison: "BASELINE_DELTA", operationId: operation("grafana.business.revenue"), resultName: "revenue", comparator: "LTE", delta: -10, issueKind: "REGRESSION", severity: "WARNING", signedThreshold: true },
    { ruleId: "business_data_gap", comparison: "ERROR", operationId: operation("grafana.business.operational.kpi"), issueKind: "EVIDENCE_GAP", severity: "WARNING", signedThreshold: false },
  ],
});

export const GRAFANA_CAPABILITY_PACKS: readonly Readonly<ProviderCapabilityPackV1>[] = Object.freeze([
  GRAFANA_INFRASTRUCTURE_PACK,
  GRAFANA_APM_PACK,
  GRAFANA_LOGS_PACK,
  GRAFANA_IOT_EDGE_PACK,
  GRAFANA_BUSINESS_KPI_PACK,
]);
