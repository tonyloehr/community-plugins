export type Brand<T, Name extends string> = T & {
  readonly __brand: Name;
};

export type JsonPrimitive = null | boolean | number | string;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = { [key: string]: JsonValue };

export type Sha256 = Brand<string, "Sha256">;
export type RunId = Brand<string, "RunId">;
export type RunHandle = Brand<string, "RunHandle">;
export type EvidenceId = Brand<string, "EvidenceId">;
export type ContradictionId = Brand<string, "ContradictionId">;
export type OperationId = Brand<string, "OperationId">;
export type AdapterPackageId = Brand<string, "AdapterPackageId">;
export type BundleId = Brand<string, "BundleId">;
export type MonitoringWorkspaceId = Brand<string, "MonitoringWorkspaceId">;
export type WorkbenchEvidenceRef = Brand<string, "WorkbenchEvidenceRef">;
export type WorkbenchLinkRef = Brand<string, "WorkbenchLinkRef">;
export type WorkbenchIssueRef = Brand<string, "WorkbenchIssueRef">;
export type SubjectRef = Brand<string, "SubjectRef">;
export type CapabilityPackId = Brand<string, "CapabilityPackId">;

export type Workflow = "triage" | "investigate" | "deep" | "change-review" | "verify";
export type WorkflowFailOn = "none" | "partial" | "error";
export type WorkflowTerminalState = "SEALED" | "BLOCKED" | "PAUSED" | "CANCELLED";
export type EvidenceOrigin = "LIVE" | "REPLAY" | "SIMULATED";
export type SourceAuthority = "AUTHORITATIVE" | "CORROBORATING";
export type InvestigationStatus = "COMPLETE" | "PARTIAL" | "BLOCKED";
export type RecoveryState =
  | "NONE"
  | "APPROVAL_REQUIRED"
  | "ACTION_FAILED"
  | "INCOMPLETE"
  | "NOT_RECOVERED"
  | "RECOVERED";

/** A single adapter's collection outcome. Cross-source consistency is separate. */
export type CollectionState = "COMPLETE" | "EMPTY" | "ERROR";
export type FreshnessState = "FRESH" | "STALE" | "NOT_APPLICABLE";
export type ConsistencyState = "NOT_ASSESSED" | "CONSISTENT" | "CONTRADICTORY";

/** Canonical operator-facing projection derived from collection, freshness, and contradictions. */
export type EvidenceState = "COMPLETE" | "EMPTY" | "STALE" | "CONTRADICTORY" | "ERROR";

export type WorkbenchLifecycle =
  | "IDLE"
  | "PREFLIGHT"
  | "RUNNING"
  | "SEALED"
  | "PARTIAL"
  | "BLOCKED"
  | "CANCELLED";

export type WorkbenchPhase =
  | "READINESS"
  | "SCOPING"
  | "BASELINE"
  | "COLLECTING"
  | "COMPARING"
  | "ANALYZING"
  | "FINALIZING"
  | "PATCHING"
  | "VERIFYING";

export type WorkbenchPatchState =
  | "NOT_ELIGIBLE"
  | "ELIGIBLE"
  | "REQUESTED"
  | "HANDOFF_COMPLETE"
  | "BLOCKED"
  | "STALE";

export type WorkbenchIssueKind =
  | "ALERT"
  | "REGRESSION"
  | "ANOMALY"
  | "CONTRADICTION"
  | "EVIDENCE_GAP";

export type WorkbenchIssueSeverity = "INFO" | "WARNING" | "CRITICAL";

export type WorkbenchIssueStatus = "OPEN" | "SUPPORTED" | "RESOLVED" | "BLOCKED";

/** Sanitized presentation state only; it is not a patch artifact or mutation receipt. */
export interface WorkbenchPatchStatus {
  schemaVersion: "1.0.0";
  state: WorkbenchPatchState;
  eligible: boolean;
  updatedAt: string;
  title?: string;
  reason?: string;
  evidenceRefs: WorkbenchEvidenceRef[];
  limitations: string[];
}

/** Compact alias for consumers that do not use the Workbench prefix. */
export type PatchStatus = WorkbenchPatchStatus;

export type WorkbenchEvidenceLinkKind =
  | "GRAFANA_DASHBOARD"
  | "GRAFANA_PANEL"
  | "PROMETHEUS_VIEW"
  | "LOG_VIEW"
  | "TRACE_VIEW"
  | "CODE_REVISION"
  | "CODE_LOCATION";

/** Opaque navigation metadata. A trusted resolver owns any eventual URL or code location. */
export interface WorkbenchEvidenceLink {
  schemaVersion: "1.0.0";
  workspaceId: MonitoringWorkspaceId;
  linkRef: WorkbenchLinkRef;
  evidenceRef?: WorkbenchEvidenceRef;
  kind: WorkbenchEvidenceLinkKind;
  label: string;
  availability: "AVAILABLE" | "UNAVAILABLE";
  unavailableReason?: string;
}

export type EvidenceLink = WorkbenchEvidenceLink;

/** App-only result of resolving one opaque, ownership-checked link reference. */
export type WorkbenchResolvedLinkTarget =
  | {
      schemaVersion: "1.0.0";
      workspaceId: MonitoringWorkspaceId;
      linkRef: WorkbenchLinkRef;
      mode: "OPEN_EXTERNAL";
      label: string;
      url: string;
    }
  | {
      schemaVersion: "1.0.0";
      workspaceId: MonitoringWorkspaceId;
      linkRef: WorkbenchLinkRef;
      mode: "CODE_FOLLOW_UP";
      label: string;
      intent: "OPEN_CODE_EVIDENCE";
    };

export type ResolvedEvidenceLink = WorkbenchResolvedLinkTarget;

export interface WorkbenchEvidenceMetric {
  kind: "METRIC";
  label: string;
  value: number | null;
  unit?: string;
  points: Array<{ at: string; value: number | null }>;
}

export interface WorkbenchEvidenceFact {
  kind: "FACT";
  label: string;
  value: JsonPrimitive;
}

export interface WorkbenchEvidenceEvent {
  kind: "EVENT";
  at: string;
  summary: string;
}

export type WorkbenchEvidenceValue =
  | WorkbenchEvidenceMetric
  | WorkbenchEvidenceFact
  | WorkbenchEvidenceEvent;

/** Bounded, normalized evidence detail safe for a workbench drawer. */
export interface WorkbenchEvidenceDetail {
  schemaVersion: "1.0.0";
  workspaceId: MonitoringWorkspaceId;
  evidenceRef: WorkbenchEvidenceRef;
  title: string;
  domain: EvidenceDomain;
  origin: EvidenceOrigin;
  authority: SourceAuthority;
  state: EvidenceState;
  source: { provider: string; sourceAlias: string };
  evaluatedAt: string;
  collectedAt: string;
  window: TimeWindow;
  summary: string;
  values: WorkbenchEvidenceValue[];
  limitations: string[];
  linkRefs: WorkbenchLinkRef[];
}

export type MonitoringEvidenceDetail = WorkbenchEvidenceDetail;

export interface WorkbenchSignalCard {
  signalRef: string;
  title: string;
  displayValue: string;
  unit?: string;
  severity: "NEUTRAL" | "GOOD" | "WARNING" | "CRITICAL";
  direction: "UP" | "DOWN" | "FLAT" | "UNKNOWN";
  points: Array<number | null>;
  evidenceRefs: WorkbenchEvidenceRef[];
}

export interface WorkbenchHypothesisCard {
  hypothesisRef: string;
  rank: number;
  statement: string;
  status: "OPEN" | "SUPPORTED" | "WEAKENED" | "REJECTED";
  confidence?: number;
  rationale: string;
  evidenceRefs: WorkbenchEvidenceRef[];
}

/** Provider-neutral issue derived deterministically from sealed evidence and signed pack rules. */
export interface WorkbenchIssueCard {
  issueRef: WorkbenchIssueRef;
  kind: WorkbenchIssueKind;
  severity: WorkbenchIssueSeverity;
  status: WorkbenchIssueStatus;
  classification: "SIGNED_RULE" | "DEVIATION";
  title: string;
  summary: string;
  evidenceRefs: WorkbenchEvidenceRef[];
  hypothesisRefs: string[];
  patch: WorkbenchPatchStatus;
}

export interface WorkbenchEvidenceCard {
  evidenceRef: WorkbenchEvidenceRef;
  title: string;
  domain: EvidenceDomain;
  state: EvidenceState;
  authority: SourceAuthority;
  sourceLabel: string;
  summary: string;
  observedAt?: string;
  linkRefs: WorkbenchLinkRef[];
}

export interface WorkbenchActivityItem {
  activityRef: string;
  at: string;
  kind: "READINESS" | "SCOPE" | "EVIDENCE" | "ANALYSIS" | "PATCH" | "RECOVERY" | "SYSTEM";
  state: "PENDING" | "RUNNING" | "COMPLETE" | "PARTIAL" | "ERROR";
  title: string;
  detail?: string;
}

export interface WorkbenchActionAvailability {
  action:
    | "NONE"
    | "COLLECT_EVIDENCE"
    | "RETRY_COLLECTION"
    | "GENERATE_PATCH"
    | "REVIEW_PATCH"
    | "VERIFY_RECOVERY";
  enabled: boolean;
  label: string;
  reason?: string;
}

export interface MonitoringWorkspaceSnapshot {
  schemaVersion: "1.0.0" | "1.1.0";
  workspaceId: MonitoringWorkspaceId;
  stateVersion: number;
  asOf: string;
  lifecycle: WorkbenchLifecycle;
  phase: WorkbenchPhase;
  origin?: EvidenceOrigin;
  scope?: { service?: string; environment: string; window?: TimeWindow };
  status: {
    service: "HEALTHY" | "DEGRADED" | "RECOVERING" | "UNKNOWN";
    collection: "NOT_STARTED" | "IN_PROGRESS" | "COMPLETE" | "PARTIAL" | "ERROR";
    causality: "NOT_ASSESSED" | "OPEN" | "SUPPORTED" | "INCONCLUSIVE";
    recovery:
      | "NOT_ASSESSED"
      | "APPROVAL_REQUIRED"
      | "ACTION_FAILED"
      | "INCOMPLETE"
      | "NOT_RECOVERED"
      | "RECOVERED";
    audit: "INITIALIZING" | "HEALTHY" | "DEGRADED" | "ERROR";
  };
  progress: {
    completedOperations: number;
    requiredOperations: number;
    sourceStates: Record<string, number>;
  };
  signals: WorkbenchSignalCard[];
  hypotheses: WorkbenchHypothesisCard[];
  /** Required by the 1.1 schema and absent from legacy 1.0 snapshots. */
  issues?: WorkbenchIssueCard[];
  evidence: WorkbenchEvidenceCard[];
  activity: WorkbenchActivityItem[];
  patch: WorkbenchPatchStatus;
  nextAction: WorkbenchActionAvailability;
  limitations: string[];
}

/** Version-aware poll result; a future cursor must be rejected by the projection authority. */
export type MonitoringWorkspaceSnapshotRead =
  | {
      schemaVersion: "1.0.0";
      changed: false;
      workspaceId: MonitoringWorkspaceId;
      stateVersion: number;
      asOf: string;
    }
  | {
      schemaVersion: "1.0.0";
      changed: true;
      snapshot: MonitoringWorkspaceSnapshot;
    };

export type RunState = "OPEN" | "FINALIZING" | "SEALED" | "ABORTED" | "EXPIRED";
export type AuditState = "HEALTHY" | "DEGRADED" | "FAILED";
export type CapabilityProfile = "observe" | "investigate" | "prepare_patch";
export type EvidenceDomain =
  | "METRICS"
  | "ALERTS"
  | "LOGS"
  | "TRACES"
  | "RUNTIME"
  | "CHANGES"
  | "RUNBOOKS";

export interface TimeWindow {
  start: string;
  end: string;
}

export interface Scope {
  environment: string;
  service?: string;
  region?: string;
  cohort?: string;
  subject?: {
    kind: SubjectKind;
    ref: SubjectRef;
  };
}

export type SubjectKind = "HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET";

export interface CorrelationIdentity {
  environment: string;
  serviceNamespace?: string;
  serviceName?: string;
  releaseVersion?: string;
  deploymentId?: string;
  gitCommit?: string;
  traceId?: string;
}

export interface Integrity {
  hashContractVersion: "sha256-jcs-v1";
  algorithm: "sha256";
  canonicalization: "RFC8785";
  contentSha256: Sha256;
}

export interface RedactionRecord {
  ruleId: string;
  path: string;
  action: "REMOVED" | "MASKED" | "HASHED" | "GENERALIZED";
}

export interface SanitizedError {
  code: string;
  category:
    | "AUTHORIZATION"
    | "AUTHENTICATION"
    | "UNAVAILABLE"
    | "TIMEOUT"
    | "RATE_LIMIT"
    | "INVALID_RESPONSE"
    | "POLICY"
    | "INTERNAL";
  message: string;
  retryable: boolean;
  providerStatus?: number;
}

export interface Pagination {
  complete: boolean;
  pages: number;
  truncatedReason?: "BYTE_LIMIT" | "ROW_LIMIT" | "SERIES_LIMIT" | "POINT_LIMIT" | "TIME_LIMIT";
}

export interface ScalarValue {
  kind: "SCALAR";
  name: string;
  value: JsonPrimitive;
  unit?: string;
  dimensions: Record<string, string>;
  observedAt?: string;
}

export interface TimeSeriesPoint {
  at: string;
  value: number | null;
}

export interface TimeSeriesValue {
  kind: "TIMESERIES";
  name: string;
  unit?: string;
  dimensions: Record<string, string>;
  points: TimeSeriesPoint[];
}

export interface TableColumn {
  name: string;
  type: "STRING" | "NUMBER" | "BOOLEAN" | "DATETIME" | "NULL";
}

export interface TableValue {
  kind: "TABLE";
  name: string;
  columns: TableColumn[];
  rows: JsonPrimitive[][];
}

export interface EventValue {
  kind: "EVENT";
  name: string;
  occurredAt: string;
  summary: string;
  attributes: Record<string, JsonPrimitive>;
}

export type NormalizedValue = ScalarValue | TimeSeriesValue | TableValue | EventValue;

export interface OperationLimits {
  timeoutMs: number;
  maxAgeMs: number;
  maxBytes: number;
  maxRows: number;
  maxSeries: number;
  maxPoints: number;
}

export interface WorkflowRequest {
  schemaVersion: "1.0.0";
  idempotencyKey: string;
  workflow: Workflow;
  profileAlias: string;
  scopeAlias: string;
  origin: EvidenceOrigin;
  window: TimeWindow;
  baselineWindow?: TimeWindow;
  incidentAlias?: string;
  parentRunId?: RunId;
  verificationPolicyAlias?: string;
  requiredOperations?: OperationId[];
  requiredCapabilityPacks?: CapabilityPackId[];
  artifactPolicy: { mode: "required" | "best_effort" };
  failOn: WorkflowFailOn;
}

export interface EvidenceStateSummary {
  COMPLETE: number;
  EMPTY: number;
  STALE: number;
  CONTRADICTORY: number;
  ERROR: number;
}

export interface ArtifactReference {
  bundleId: BundleId;
  manifestSha256: Sha256;
  relativePath?: string;
}

export interface WorkflowResult {
  schemaVersion: "1.0.0";
  runId: RunId;
  workflow: Workflow;
  terminalState: WorkflowTerminalState;
  investigationStatus: InvestigationStatus;
  recoveryState: RecoveryState;
  evidenceSummary: EvidenceStateSummary;
  limitations: string[];
  artifact?: ArtifactReference;
  exitCode: 0 | 1 | 2 | 130 | 143;
}

/** Public terminal summary. Kept as a named compatibility contract for JSONL consumers. */
export type WorkflowSummary = WorkflowResult;

export type WorkflowEvent =
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "workflow_started";
      workflow: Workflow;
      requestSha256: Sha256;
    }
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "run_started";
      runId: RunId;
      revision: number;
      origin: EvidenceOrigin;
      operationSnapshotSha256: Sha256;
    }
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "run_resumed";
      runId: RunId;
      revision: number;
      operationSnapshotSha256: Sha256;
    }
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "evidence_collected";
      runId: RunId;
      revision: number;
      evidence: Array<{ evidenceId: EvidenceId; operationId: OperationId; state: EvidenceState }>;
    }
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "run_sealed";
      runId: RunId;
      revision: number;
      bundleId: BundleId;
      manifestSha256: Sha256;
      artifactRelativePath: string;
    }
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "workflow_stopped";
      runId: RunId;
      state: "BLOCKED" | "CANCELLED" | "PAUSED";
      code: string;
    }
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "run_cancelled";
      runId: RunId;
      revision: number;
      retainedEvidenceIds: EvidenceId[];
    }
  | {
      schemaVersion: "1.0.0";
      sequence: number;
      at: string;
      event: "workflow_result";
      result: WorkflowSummary;
      requestSha256: Sha256;
      operationSnapshotSha256: Sha256;
    };

export interface CredentialReference {
  kind: "env" | "workload_identity" | "broker";
  key: string;
}

export type EndpointAuthentication =
  | { mode: "NONE" }
  | { mode: "BEARER"; tokenRef: CredentialReference }
  | {
      mode: "BASIC";
      usernameRef: CredentialReference;
      passwordRef: CredentialReference;
    }
  | {
      mode: "MTLS";
      certificateRef: CredentialReference;
      privateKeyRef: CredentialReference;
    };

export interface EndpointTlsPolicy {
  minimumVersion: "TLSv1.2" | "TLSv1.3";
  caRef?: CredentialReference;
  serverName?: string;
}

export interface TenantBinding {
  headerName: string;
  valueRef: string;
}

export interface NetworkPolicy {
  followRedirects: false;
  allowLoopbackHttp: boolean;
  allowedHosts: string[];
  networkClass: "loopback" | "private" | "public";
  routeMode: "direct" | "host_vpn" | "application_proxy";
}

export interface TrustedEndpoint {
  endpointId: string;
  adapterId: string;
  baseUrl: string;
  authentication: EndpointAuthentication;
  tls: EndpointTlsPolicy;
  network: NetworkPolicy;
  tenantBinding?: TenantBinding;
}

export type OperatorSetting =
  | { mode: "OPERATOR_REQUIRED" }
  | { mode: "FIXED"; durationSeconds: number };

/** The current core never persists opaque provider responses. */
export type RetentionPolicy = { mode: "NONE" };

export interface TrustedPolicy {
  defaultLookback: OperatorSetting;
  maxEvidenceAge: OperatorSetting;
  rawEvidenceRetention: RetentionPolicy;
  auditRequired: boolean;
  limits: OperationLimits;
}

export interface VerificationValueSelector {
  kind: "SCALAR" | "TIMESERIES";
  name: string;
  reducer: "SINGLE" | "LATEST" | "ALL";
  dimensions?: Record<string, string>;
}

export interface TrustedVerificationCriterion {
  criterionId: string;
  operationId: OperationId;
  valueSelector: VerificationValueSelector;
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ" | "INACTIVE" | "ACTIVE";
  expected: JsonPrimitive;
  unit?: string;
  maxEvidenceAgeMs: number;
  requiredDurationSeconds?: number;
}

export interface TrustedVerificationPolicy {
  policyAlias: string;
  windowStrategy: "FIXED" | "ROLLING" | "REPEATED_CHECKS";
  windowDurationSeconds: number;
  requiredSamples: number;
  passCount: number;
  criteria: TrustedVerificationCriterion[];
}

export interface TrustedProfile {
  schemaVersion: "1.0.0";
  profileAlias: string;
  capabilityProfile: CapabilityProfile;
  allowedOrigins: EvidenceOrigin[];
  compiledAt: string;
  configSha256: Sha256;
  endpointRegistrySha256: Sha256;
  catalogSha256: Sha256;
  scopes: Record<string, Scope>;
  endpointIds: string[];
  operationIds: OperationId[];
  capabilityPackIds?: CapabilityPackId[];
  capabilityPackCatalogSha256?: Sha256;
  defaultVerificationPolicyAlias?: string;
  verificationPolicies?: Record<string, TrustedVerificationPolicy>;
  policy: TrustedPolicy;
}

export interface OperationNormalization {
  resultKind: "SCALAR" | "TIMESERIES" | "TABLE" | "EVENT";
  targetUnit?: string;
  dimensionMappings: Record<string, string>;
}

export interface OperationDefinition {
  domain: EvidenceDomain;
  sourceAlias: string;
  adapterPackageId: AdapterPackageId;
  adapterOperation: string;
  authority: SourceAuthority;
  sanitizedProviderDefinition: JsonObject;
  /** Hash-bound lineage the adapter must emit; absent operations may not invent lineage. */
  expectedSourceLineage?: EvidenceSourceLineage;
  scopeMapping: Record<string, string>;
  allowedDimensions: string[];
  requiredProviderScopes: string[];
  sensitivity: "PUBLIC" | "INTERNAL" | "CONFIDENTIAL" | "RESTRICTED";
  limits: OperationLimits;
  normalization: OperationNormalization;
}

export interface OperationSnapshot {
  schemaVersion: "1.0.0";
  operationId: OperationId;
  revision: number;
  capturedAt: string;
  definition: OperationDefinition;
  definitionSha256: Sha256;
}

export type CapabilityPackUseCase =
  | "INFRASTRUCTURE"
  | "APPLICATION_PERFORMANCE"
  | "LOG_ANALYTICS"
  | "IOT_EDGE"
  | "BUSINESS_INTELLIGENCE";

export type CapabilityPackPolarity = "HIGH_IS_BAD" | "LOW_IS_BAD" | "NEUTRAL";

export type CapabilityPackIssueComparison =
  | "THRESHOLD"
  | "BASELINE_DELTA"
  | "STALE"
  | "EMPTY"
  | "ERROR"
  | "CONTRADICTION";

export interface CapabilityPackScopeMappingV1 {
  scopeField: "environment" | "service" | "region" | "cohort" | "subject.ref";
  providerField: string;
  required: boolean;
}

export interface CapabilityPackThresholdV1 {
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ";
  warning?: number;
  critical?: number;
}

export interface CapabilityPackSignalV1 {
  signalId: string;
  operationId: OperationId;
  resultName: string;
  order: number;
  unit?: string;
  polarity: CapabilityPackPolarity;
  thresholds?: CapabilityPackThresholdV1;
}

export interface CapabilityPackIssueRuleV1 {
  ruleId: string;
  comparison: CapabilityPackIssueComparison;
  operationId: OperationId;
  comparisonOperationId?: OperationId;
  resultName?: string;
  reducer?: "SINGLE" | "MAX" | "MIN";
  comparator?: "LT" | "LTE" | "GT" | "GTE" | "EQ";
  threshold?: number;
  delta?: number;
  maxAgeMs?: number;
  issueKind: WorkbenchIssueKind;
  severity: WorkbenchIssueSeverity;
  signedThreshold: boolean;
}

/** A reviewed, immutable provider capability pack sealed into the activated trust bundle. */
export interface ProviderCapabilityPackV1 {
  schemaVersion: "1.0.0";
  packId: CapabilityPackId;
  revision: number;
  useCase: CapabilityPackUseCase;
  requiredOperationIds: OperationId[];
  optionalOperationIds: OperationId[];
  supportedSubjectKinds: SubjectKind[];
  scopeMappings: CapabilityPackScopeMappingV1[];
  signals: CapabilityPackSignalV1[];
  issueRules: CapabilityPackIssueRuleV1[];
  definitionSha256: Sha256;
}

export interface AdapterEntrypointBuiltin {
  kind: "BUILTIN";
  registryKey: string;
}

export interface AdapterEntrypointWorker {
  kind: "SIGNED_WORKER";
  protocol: "PM_ADAPTER_STDIO_V1";
  artifactPath: string;
  artifactSha256: Sha256;
  signature: string;
  signingKeyId: string;
}

export interface AdapterProviderCompatibility {
  provider: string;
  versions: string;
}

export interface AdapterPackage {
  schemaVersion: "1.0.0";
  packageId: AdapterPackageId;
  name: string;
  version: string;
  protocolVersion: "1.0";
  publisher: { name: string; keyId?: string };
  entrypoint: AdapterEntrypointBuiltin | AdapterEntrypointWorker;
  domains: EvidenceDomain[];
  capabilities: string[];
  providerCompatibility: AdapterProviderCompatibility[];
  supportedContractVersions: string[];
  conformance: Array<
    | "CORE_READ"
    | "METRICS"
    | "LOGS"
    | "TRACES"
    | "ALERTS"
    | "RUNTIME"
    | "CHANGES"
    | "RUNBOOKS"
    | "REMOTE_DEPLOYMENT"
    | "ACTION_READY"
  >;
}

export interface TrustBundle {
  schemaVersion: "1.0.0";
  createdAt: string;
  profile: TrustedProfile;
  endpoints: TrustedEndpoint[];
  operations: OperationSnapshot[];
  capabilityPacks?: ProviderCapabilityPackV1[];
  adapters: AdapterPackage[];
  integrity: Integrity;
}

export interface PrincipalBinding {
  issuerAlias: string;
  subjectSha256: Sha256;
  tenantSha256: Sha256;
  sessionSha256: Sha256;
}

export interface ParentRunBinding {
  runId: RunId;
  verificationContractSha256: Sha256;
}

export interface RunRecord {
  schemaVersion: "1.0.0";
  runId: RunId;
  state: RunState;
  workflow: Workflow;
  origin: EvidenceOrigin;
  principal: PrincipalBinding;
  handleSha256: Sha256;
  requestSha256: Sha256;
  trustBundleSha256: Sha256;
  profileAlias: string;
  scope: Scope;
  window: TimeWindow;
  baselineWindow?: TimeWindow;
  incidentAlias?: string;
  parent?: ParentRunBinding;
  allowedOperationHashes: Record<string, Sha256>;
  evidenceIds: EvidenceId[];
  contradictionIds: ContradictionId[];
  audit: { required: boolean; state: AuditState };
  createdAt: string;
  expiresAt: string;
  finalizedAt?: string;
  abortedAt?: string;
  integrity: Integrity;
}

export interface EvidenceSource {
  provider: string;
  sourceAlias: string;
  adapterPackageId: AdapterPackageId;
  adapterVersion: string;
  sanitizedReference?: string;
  lineage?: EvidenceSourceLineage;
}

/** Source identity is independent of its access path and is used for corroboration de-duplication. */
export interface EvidenceSourceLineage {
  accessPath: "DIRECT" | "GRAFANA";
  datasourceType: "prometheus" | "loki" | "tempo" | "postgres";
  sourceIdentitySha256: Sha256;
}

export interface EvidenceEnvelope {
  schemaVersion: "1.0.0" | "1.1.0";
  evidenceId: EvidenceId;
  runId: RunId;
  operationId: OperationId;
  operationDefinitionSha256: Sha256;
  trustBundleSha256: Sha256;
  origin: EvidenceOrigin;
  authority: SourceAuthority;
  source: EvidenceSource;
  scope: Scope;
  correlation: CorrelationIdentity;
  evaluatedAt: string;
  collectedAt: string;
  window: TimeWindow;
  maxAcceptableAgeMs: number;
  collectionState: CollectionState;
  freshnessState: FreshnessState;
  native: {
    resultType: string;
    unit?: string;
    dimensions: Record<string, string>;
  };
  values: NormalizedValue[];
  redactions: RedactionRecord[];
  limitations: string[];
  pagination: Pagination;
  providerWarnings: string[];
  error?: SanitizedError;
  integrity: Integrity;
}

export interface ContradictionClaimReference {
  evidenceId: EvidenceId;
  jsonPointer: string;
  claim: string;
}

export interface ContradictionRecord {
  schemaVersion: "1.0.0";
  contradictionId: ContradictionId;
  runId: RunId;
  consistencyState: "CONTRADICTORY";
  kind: "VALUE" | "SCOPE" | "TIME" | "IDENTITY" | "AUTHORITY" | "SEMANTIC";
  summary: string;
  claimRefs: ContradictionClaimReference[];
  resolutionState: "UNRESOLVED" | "EXPLAINED" | "RESOLVED";
  resolution?: string;
  assessedAt: string;
  integrity: Integrity;
}

export interface Observation {
  observationId: string;
  statement: string;
  evidenceIds: EvidenceId[];
}

export interface Inference {
  inferenceId: string;
  statement: string;
  confidence: number;
  rationale: string;
  supportingEvidenceIds: EvidenceId[];
  contradictingEvidenceIds: EvidenceId[];
}

export interface Hypothesis {
  hypothesisId: string;
  rank: number;
  statement: string;
  status: "OPEN" | "SUPPORTED" | "WEAKENED" | "REJECTED";
  rationale: string;
  supportingEvidenceIds: EvidenceId[];
  contradictingEvidenceIds: EvidenceId[];
  nextCheck?: string;
}

/** Model/driver-authored analysis only. Runtime-owned identity and state are deliberately absent. */
export interface AnalysisDraft {
  schemaVersion: "1.0.0";
  observations: Observation[];
  inferences: Inference[];
  hypotheses: Hypothesis[];
  checksPerformed: string[];
  missingEvidence: string[];
  smallestSafeNextStep: string;
  approvalRequired: boolean;
  remainingUncertainty: string[];
  owners: string[];
}

export interface VerificationCriterion {
  criterionId: string;
  operationId: OperationId;
  operationDefinitionSha256: Sha256;
  valueSelector: VerificationValueSelector;
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ" | "INACTIVE" | "ACTIVE";
  expected: JsonPrimitive;
  unit?: string;
  maxEvidenceAgeMs: number;
  requiredDurationSeconds?: number;
}

export interface VerificationContract {
  contractSha256: Sha256;
  policyAlias: string;
  scope: Scope;
  cohort?: string;
  windowStrategy: "FIXED" | "ROLLING" | "REPEATED_CHECKS";
  windowDurationSeconds: number;
  requiredSamples: number;
  passCount: number;
  criteria: VerificationCriterion[];
}

export interface Investigation {
  schemaVersion: "1.0.0";
  runId: RunId;
  analysisState: "SUBMITTED" | "EVIDENCE_ONLY";
  status: InvestigationStatus;
  recoveryState: RecoveryState;
  scope: Scope;
  requestedWindow: TimeWindow;
  evaluatedWindow: TimeWindow;
  observations: Observation[];
  inferences: Inference[];
  hypotheses: Hypothesis[];
  contradictionIds: ContradictionId[];
  checksPerformed: string[];
  missingEvidence: string[];
  smallestSafeNextStep: string;
  approvalRequired: boolean;
  verificationContract?: VerificationContract;
  verificationResult?: {
    status: "PASSED" | "FAILED" | "INCOMPLETE";
    evidenceIds: EvidenceId[];
  };
  remainingUncertainty: string[];
  owners: string[];
  integrity: Integrity;
}

export type CoverageDisposition =
  | "AVAILABLE"
  | "EMPTY"
  | "STALE"
  | "CONTRADICTORY"
  | "ERROR"
  | "UNSUPPORTED"
  | "DEFERRED";

export interface CoverageEntry {
  domain: EvidenceDomain;
  operationId: OperationId;
  requirement: "REQUIRED" | "OPTIONAL";
  sourceAlias?: string;
  authority?: SourceAuthority;
  disposition: CoverageDisposition;
  evidenceIds: EvidenceId[];
  contradictionIds: ContradictionId[];
  paginationComplete?: boolean;
  blocksWorkflow: boolean;
  reason?: string;
}

export interface Coverage {
  schemaVersion: "1.0.0";
  runId: RunId;
  overall: "COMPLETE" | "PARTIAL" | "UNKNOWN";
  entries: CoverageEntry[];
  integrity: Integrity;
}

export interface ManifestEntry {
  path: string;
  role:
    | "RUN"
    | "PROFILE"
    | "OPERATIONS"
    | "EVIDENCE"
    | "CONTRADICTIONS"
    | "COVERAGE"
    | "INVESTIGATION"
    | "RECEIPT";
  mediaType: string;
  bytes: number;
  sha256: Sha256;
}

export interface BundleManifest {
  schemaVersion: "1.0.0";
  bundleId: BundleId;
  runId: RunId;
  parentRunId?: RunId;
  origin: EvidenceOrigin;
  producer: {
    pluginVersion: string;
    contractsVersion: string;
    reportProjectionVersion: string;
  };
  createdAt: string;
  sealedAt: string;
  entries: ManifestEntry[];
  bundleSha256: Sha256;
}
