import { createHash } from "node:crypto";

import type {
  BundleManifest,
  Integrity,
  JsonObject,
  JsonValue,
  ManifestEntry,
  OperationSnapshot,
  ProviderCapabilityPackV1,
  Sha256,
} from "./types.ts";

const HEX_64 = /^[a-f0-9]{64}$/u;
const HASH_CONTRACT_VERSION = "sha256-jcs-v1" as const;
const JCS_CANONICALIZATION = "RFC8785" as const;
const MANIFEST_EXCLUDED_PATHS = new Set([
  "manifest.json",
  "manifest.sha256",
  "manifest.sig",
  "report.md",
]);

function assertValidUnicode(value: string, path: string): void {
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = value.charCodeAt(index + 1);
      if (!Number.isInteger(next) || next < 0xdc00 || next > 0xdfff) {
        throw new TypeError(`Unpaired high surrogate at ${path}`);
      }
      index += 1;
    } else if (code >= 0xdc00 && code <= 0xdfff) {
      throw new TypeError(`Unpaired low surrogate at ${path}`);
    }
  }
}

function assertJsonDataProperties(value: object, path: string): void {
  const descriptors = Object.getOwnPropertyDescriptors(value);
  for (const key of Reflect.ownKeys(descriptors)) {
    if (typeof key === "symbol") throw new TypeError(`Symbol-keyed member at ${path}`);
    if (Array.isArray(value) && key === "length") continue;
    const descriptor = descriptors[key];
    if (descriptor === undefined || descriptor.get !== undefined || descriptor.set !== undefined) {
      throw new TypeError(`Accessor member at ${path}.${key}`);
    }
    if (!descriptor.enumerable) throw new TypeError(`Non-enumerable member at ${path}.${key}`);
    if (Array.isArray(value) && !/^(?:0|[1-9][0-9]*)$/u.test(key)) {
      throw new TypeError(`Non-index array member at ${path}.${key}`);
    }
  }
}

function canonicalize(value: unknown, path: string, ancestors: Set<object>): string {
  if (value === null) return "null";
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "string") {
    assertValidUnicode(value, path);
    return JSON.stringify(value);
  }
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new TypeError(`Non-finite number at ${path}`);
    return JSON.stringify(value);
  }
  if (typeof value !== "object") {
    throw new TypeError(`Non-JSON value at ${path}`);
  }
  if (ancestors.has(value)) throw new TypeError(`Circular reference at ${path}`);
  assertJsonDataProperties(value, path);
  ancestors.add(value);
  try {
    if (Array.isArray(value)) {
      const items: string[] = [];
      for (let index = 0; index < value.length; index += 1) {
        if (!Object.hasOwn(value, index)) {
          throw new TypeError(`Sparse array at ${path}[${index}]`);
        }
        items.push(canonicalize(value[index], `${path}[${index}]`, ancestors));
      }
      return `[${items.join(",")}]`;
    }

    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) {
      throw new TypeError(`Non-plain object at ${path}`);
    }

    const object = value as Record<string, unknown>;
    // ECMAScript's default string order is unsigned UTF-16 code-unit order,
    // which is the ordering required by RFC 8785 section 3.2.3.
    const keys = Object.keys(object).sort();
    const properties: string[] = [];
    for (const key of keys) {
      assertValidUnicode(key, `${path} key`);
      const member = object[key];
      if (member === undefined) throw new TypeError(`Undefined member at ${path}.${key}`);
      properties.push(`${JSON.stringify(key)}:${canonicalize(member, `${path}.${key}`, ancestors)}`);
    }
    return `{${properties.join(",")}}`;
  } finally {
    ancestors.delete(value);
  }
}

/**
 * RFC 8785 JSON Canonicalization Scheme serialization for in-memory I-JSON data.
 *
 * The accepted programmatic subset is deliberately stricter than JSON.stringify:
 * plain/null-prototype data objects and dense arrays with data properties only;
 * finite IEEE-754 numbers; valid Unicode scalar sequences; and no undefined,
 * symbols, accessors, custom array members, or circular references. Parsed JSON
 * satisfying I-JSON falls within this subset. The returned string's UTF-8 bytes
 * are the hash preimage.
 */
export function canonicalJson(value: JsonValue | unknown): string {
  return canonicalize(value, "$", new Set<object>());
}

export function sha256Bytes(value: string | Uint8Array): Sha256 {
  return createHash("sha256").update(value).digest("hex") as Sha256;
}

export function sha256Canonical(value: JsonValue | unknown): Sha256 {
  return sha256Bytes(canonicalJson(value));
}

function withoutTopLevelIntegrity<T extends object>(value: T): JsonObject {
  const copy = { ...(value as Record<string, JsonValue>) };
  delete copy.integrity;
  return copy;
}

export function computeIntegrity<T extends object>(value: T): Integrity {
  return {
    hashContractVersion: HASH_CONTRACT_VERSION,
    algorithm: "sha256",
    canonicalization: JCS_CANONICALIZATION,
    contentSha256: sha256Canonical(withoutTopLevelIntegrity(value)),
  };
}

export function verifyIntegrity<T extends { integrity: Integrity }>(value: T): boolean {
  return (
    value.integrity.hashContractVersion === HASH_CONTRACT_VERSION &&
    value.integrity.algorithm === "sha256" &&
    value.integrity.canonicalization === JCS_CANONICALIZATION &&
    HEX_64.test(value.integrity.contentSha256) &&
    computeIntegrity(value).contentSha256 === value.integrity.contentSha256
  );
}

/** Hash semantic operation material only; capturedAt and the hash itself are excluded. */
export function computeOperationDefinitionHash(
  snapshot: Pick<OperationSnapshot, "operationId" | "revision" | "definition">,
): Sha256 {
  return sha256Canonical({
    operationId: snapshot.operationId,
    revision: snapshot.revision,
    definition: snapshot.definition,
  });
}

/** Hash reviewed capability-pack material; the self-referential digest is excluded. */
export function computeCapabilityPackDefinitionHash(
  pack: Omit<ProviderCapabilityPackV1, "definitionSha256">,
): Sha256 {
  return sha256Canonical(pack);
}

function assertManifestPath(path: string): void {
  if (MANIFEST_EXCLUDED_PATHS.has(path)) {
    throw new TypeError(`${path} is excluded from the semantic manifest table`);
  }
  if (path.startsWith("/") || path.includes("\\") || path.split("/").includes("..")) {
    throw new TypeError(`Unsafe manifest path: ${path}`);
  }
}

/**
 * Hash the semantic file table. The manifest, detached digest/signature, and
 * deterministic report projection are intentionally excluded to avoid cycles
 * and keep presentation outside the semantic seal.
 */
export function computeBundleHash(entries: readonly ManifestEntry[]): Sha256 {
  const seen = new Set<string>();
  const normalized = [...entries]
    .map((entry) => {
      assertManifestPath(entry.path);
      if (seen.has(entry.path)) throw new TypeError(`Duplicate manifest path: ${entry.path}`);
      seen.add(entry.path);
      return {
        path: entry.path,
        role: entry.role,
        mediaType: entry.mediaType,
        bytes: entry.bytes,
        sha256: entry.sha256,
      };
    })
    .sort((left, right) => (left.path < right.path ? -1 : left.path > right.path ? 1 : 0));
  return sha256Canonical(normalized);
}

export function verifyBundleHash(manifest: BundleManifest): boolean {
  return computeBundleHash(manifest.entries) === manifest.bundleSha256;
}
