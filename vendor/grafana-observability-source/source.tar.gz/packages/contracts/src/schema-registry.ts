import type { JsonObject } from "./types.ts";

import adapterPackageSchema from "../schemas/adapter-package.schema.json" with { type: "json" };
import analysisDraftSchema from "../schemas/analysis-draft.schema.json" with { type: "json" };
import commonSchema from "../schemas/common.schema.json" with { type: "json" };
import contradictionSchema from "../schemas/contradiction.schema.json" with { type: "json" };
import coverageSchema from "../schemas/coverage.schema.json" with { type: "json" };
import evidenceEnvelopeSchema from "../schemas/evidence-envelope.schema.json" with { type: "json" };
import evidenceLinkSchema from "../schemas/evidence-link.schema.json" with { type: "json" };
import investigationSchema from "../schemas/investigation.schema.json" with { type: "json" };
import manifestSchema from "../schemas/manifest.schema.json" with { type: "json" };
import monitoringEvidenceDetailSchema from "../schemas/monitoring-evidence-detail.schema.json" with { type: "json" };
import monitoringWorkspaceSnapshotSchema from "../schemas/monitoring-workspace-snapshot.schema.json" with { type: "json" };
import operationSnapshotSchema from "../schemas/operation-snapshot.schema.json" with { type: "json" };
import patchStatusSchema from "../schemas/patch-status.schema.json" with { type: "json" };
import providerCapabilityPackSchema from "../schemas/provider-capability-pack.schema.json" with { type: "json" };
import resolvedEvidenceLinkSchema from "../schemas/resolved-evidence-link.schema.json" with { type: "json" };
import runRecordSchema from "../schemas/run-record.schema.json" with { type: "json" };
import trustedProfileSchema from "../schemas/trusted-profile.schema.json" with { type: "json" };
import trustBundleSchema from "../schemas/trust-bundle.schema.json" with { type: "json" };
import workflowEventSchema from "../schemas/workflow-event.schema.json" with { type: "json" };
import workflowRequestSchema from "../schemas/workflow-request.schema.json" with { type: "json" };
import workflowResultSchema from "../schemas/workflow-result.schema.json" with { type: "json" };
import workflowSummarySchema from "../schemas/workflow-summary.schema.json" with { type: "json" };

export const SCHEMA_FILES = {
  common: "common.schema.json",
  workflowRequest: "workflow-request.schema.json",
  workflowEvent: "workflow-event.schema.json",
  workflowSummary: "workflow-summary.schema.json",
  workflowResult: "workflow-result.schema.json",
  trustedProfile: "trusted-profile.schema.json",
  trustBundle: "trust-bundle.schema.json",
  operationSnapshot: "operation-snapshot.schema.json",
  runRecord: "run-record.schema.json",
  evidenceEnvelope: "evidence-envelope.schema.json",
  evidenceLink: "evidence-link.schema.json",
  contradiction: "contradiction.schema.json",
  analysisDraft: "analysis-draft.schema.json",
  investigation: "investigation.schema.json",
  coverage: "coverage.schema.json",
  manifest: "manifest.schema.json",
  monitoringEvidenceDetail: "monitoring-evidence-detail.schema.json",
  monitoringWorkspaceSnapshot: "monitoring-workspace-snapshot.schema.json",
  adapterPackage: "adapter-package.schema.json",
  patchStatus: "patch-status.schema.json",
  providerCapabilityPack: "provider-capability-pack.schema.json",
  resolvedEvidenceLink: "resolved-evidence-link.schema.json",
} as const;

export type SchemaName = keyof typeof SCHEMA_FILES;

export const SCHEMA_IDS = {
  common: "urn:production-monitoring:schema:common:1",
  workflowRequest: "urn:production-monitoring:schema:workflow-request:1",
  workflowEvent: "urn:production-monitoring:schema:workflow-event:1",
  workflowSummary: "urn:production-monitoring:schema:workflow-summary:1",
  workflowResult: "urn:production-monitoring:schema:workflow-result:1",
  trustedProfile: "urn:production-monitoring:schema:trusted-profile:1",
  trustBundle: "urn:production-monitoring:schema:trust-bundle:1",
  operationSnapshot: "urn:production-monitoring:schema:operation-snapshot:1",
  runRecord: "urn:production-monitoring:schema:run-record:1",
  evidenceEnvelope: "urn:production-monitoring:schema:evidence-envelope:1",
  evidenceLink: "urn:production-monitoring:schema:evidence-link:1",
  contradiction: "urn:production-monitoring:schema:contradiction:1",
  analysisDraft: "urn:production-monitoring:schema:analysis-draft:1",
  investigation: "urn:production-monitoring:schema:investigation:1",
  coverage: "urn:production-monitoring:schema:coverage:1",
  manifest: "urn:production-monitoring:schema:manifest:1",
  monitoringEvidenceDetail: "urn:production-monitoring:schema:monitoring-evidence-detail:1",
  monitoringWorkspaceSnapshot: "urn:production-monitoring:schema:monitoring-workspace-snapshot:1",
  adapterPackage: "urn:production-monitoring:schema:adapter-package:1",
  patchStatus: "urn:production-monitoring:schema:patch-status:1",
  providerCapabilityPack: "urn:production-monitoring:schema:provider-capability-pack:1",
  resolvedEvidenceLink: "urn:production-monitoring:schema:resolved-evidence-link:1",
} as const satisfies Record<SchemaName, string>;

const SCHEMA_DOCUMENTS: Record<SchemaName, unknown> = {
  common: commonSchema,
  workflowRequest: workflowRequestSchema,
  workflowEvent: workflowEventSchema,
  workflowSummary: workflowSummarySchema,
  workflowResult: workflowResultSchema,
  trustedProfile: trustedProfileSchema,
  trustBundle: trustBundleSchema,
  operationSnapshot: operationSnapshotSchema,
  runRecord: runRecordSchema,
  evidenceEnvelope: evidenceEnvelopeSchema,
  evidenceLink: evidenceLinkSchema,
  contradiction: contradictionSchema,
  analysisDraft: analysisDraftSchema,
  investigation: investigationSchema,
  coverage: coverageSchema,
  manifest: manifestSchema,
  monitoringEvidenceDetail: monitoringEvidenceDetailSchema,
  monitoringWorkspaceSnapshot: monitoringWorkspaceSnapshotSchema,
  adapterPackage: adapterPackageSchema,
  patchStatus: patchStatusSchema,
  providerCapabilityPack: providerCapabilityPackSchema,
  resolvedEvidenceLink: resolvedEvidenceLinkSchema,
};

export function loadSchemaRegistry(): ReadonlyMap<string, JsonObject> {
  const schemas = new Map<string, JsonObject>();
  for (const name of Object.keys(SCHEMA_FILES) as SchemaName[]) {
    const document = JSON.parse(JSON.stringify(SCHEMA_DOCUMENTS[name])) as JsonObject;
    const actualId = document.$id;
    if (actualId !== SCHEMA_IDS[name]) {
      throw new Error(`Schema ${name} has id ${String(actualId)}; expected ${SCHEMA_IDS[name]}`);
    }
    if (schemas.has(actualId)) throw new Error(`Duplicate schema id: ${actualId}`);
    schemas.set(actualId, document);
  }
  return schemas;
}

export function getSchema(name: SchemaName): JsonObject {
  const schema = loadSchemaRegistry().get(SCHEMA_IDS[name]);
  if (schema === undefined) throw new Error(`Schema is not registered: ${name}`);
  return schema;
}
