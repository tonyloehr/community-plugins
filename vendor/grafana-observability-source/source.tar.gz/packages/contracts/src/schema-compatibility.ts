import type {
  AnalysisDraftSchema,
  AdapterPackageSchema,
  BundleManifestSchema,
  ContradictionRecordSchema,
  CoverageSchema,
  EvidenceEnvelopeSchema,
  EvidenceLinkSchema,
  InvestigationSchema,
  MonitoringEvidenceDetailSchema,
  MonitoringWorkspaceSnapshotSchema,
  OperationSnapshotSchema,
  PatchStatusSchema,
  ProviderCapabilityPackSchema,
  ResolvedEvidenceLinkSchema,
  RunRecordSchema,
  TrustBundleSchema,
  TrustedProfileSchema,
  WorkflowRequestSchema,
  WorkflowEventSchema,
  WorkflowSummarySchema,
  WorkflowResultSchema,
} from "./generated/index.ts";
import type {
  AnalysisDraft,
  AdapterPackage,
  Brand,
  BundleManifest,
  ContradictionRecord,
  Coverage,
  EvidenceEnvelope,
  WorkbenchEvidenceLink,
  Investigation,
  JsonObject,
  OperationSnapshot,
  MonitoringWorkspaceSnapshot,
  WorkbenchEvidenceDetail,
  WorkbenchPatchStatus,
  ProviderCapabilityPackV1,
  WorkbenchResolvedLinkTarget,
  RunRecord,
  TrustBundle,
  TrustedProfile,
  WorkflowRequest,
  WorkflowEvent,
  WorkflowSummary,
  WorkflowResult,
} from "./types.ts";

type Equal<Left, Right> =
  (<Value>() => Value extends Left ? 1 : 2) extends
  (<Value>() => Value extends Right ? 1 : 2)
    ? true
    : false;
type Assert<Condition extends true> = Condition;

type StripBrands<Value> = Value extends JsonObject
  ? JsonObject extends Value
    ? Record<string, unknown>
    : { [Key in keyof Value]: StripBrands<Value[Key]> }
  : Value extends Brand<unknown, string>
  ? Value extends string
    ? string
    : Value extends number
      ? number
      : Value extends boolean
        ? boolean
        : never
  : Value extends readonly (infer Item)[]
    ? StripBrands<Item>[]
    : Value extends object
      ? { [Key in keyof Value]: StripBrands<Value[Key]> }
      : Value;

type OptionalKeys<Value> = {
  [Key in keyof Value]-?: object extends Pick<Value, Key> ? Key : never;
}[keyof Value];

type IncompatibleRuntimeKeys<Runtime, Generated> = {
  [Key in keyof Runtime]-?: Key extends keyof Generated
    ? StripBrands<Runtime[Key]> extends Generated[Key]
      ? Generated[Key] extends StripBrands<Runtime[Key]>
        ? never
        : Key
      : Key
    : Key;
}[keyof Runtime];

type ContractPair<Runtime, Generated> = Equal<keyof Runtime, keyof Generated> extends true
  ? Equal<OptionalKeys<Runtime>, OptionalKeys<Generated>> extends true
    ? IncompatibleRuntimeKeys<Runtime, Generated> extends never
      ? true
      : false
    : false
  : false;

/**
 * Compile-time guard between the ergonomic/branded runtime contracts and the
 * schema-generated public shapes. Any field, optionality, enum, union, or
 * nested-shape widening on the runtime side fails `tsc` here. Runtime AJV tests
 * separately enforce constraints TypeScript cannot express (formats, bounds,
 * uniqueness, and conditional requirements).
 */
export type SchemaRuntimeCompatibility = [
  Assert<ContractPair<AnalysisDraft, AnalysisDraftSchema>>,
  Assert<ContractPair<AdapterPackage, AdapterPackageSchema>>,
  Assert<ContractPair<ContradictionRecord, ContradictionRecordSchema>>,
  Assert<ContractPair<Coverage, CoverageSchema>>,
  Assert<ContractPair<EvidenceEnvelope, EvidenceEnvelopeSchema>>,
  Assert<ContractPair<WorkbenchEvidenceLink, EvidenceLinkSchema>>,
  Assert<ContractPair<Investigation, InvestigationSchema>>,
  Assert<ContractPair<BundleManifest, BundleManifestSchema>>,
  Assert<ContractPair<OperationSnapshot, OperationSnapshotSchema>>,
  Assert<ContractPair<WorkbenchEvidenceDetail, MonitoringEvidenceDetailSchema>>,
  Assert<ContractPair<MonitoringWorkspaceSnapshot, MonitoringWorkspaceSnapshotSchema>>,
  Assert<ContractPair<WorkbenchPatchStatus, PatchStatusSchema>>,
  Assert<ContractPair<ProviderCapabilityPackV1, ProviderCapabilityPackSchema>>,
  Assert<Equal<StripBrands<WorkbenchResolvedLinkTarget>, ResolvedEvidenceLinkSchema>>,
  Assert<ContractPair<RunRecord, RunRecordSchema>>,
  Assert<ContractPair<TrustBundle, TrustBundleSchema>>,
  Assert<ContractPair<TrustedProfile, TrustedProfileSchema>>,
  Assert<ContractPair<WorkflowRequest, WorkflowRequestSchema>>,
  Assert<Equal<StripBrands<WorkflowEvent>, WorkflowEventSchema>>,
  Assert<ContractPair<WorkflowSummary, WorkflowSummarySchema>>,
  Assert<ContractPair<WorkflowResult, WorkflowResultSchema>>,
];
