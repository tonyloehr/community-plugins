import type { AnalysisDraft, EvidenceId } from "./types.ts";

const INSTRUCTION_LIKE = /(?:ignore\s+(?:all\s+)?(?:previous|prior)\s+instructions?|reveal\s+(?:the\s+)?system\s+prompt|<\|(?:system|assistant|user)\|>|\bsystem\s*:\s*you\s+are|execute\s+(?:this\s+)?(?:shell|command))/iu;
const SECRET_LIKE = /(?:-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:sk|ghp|github_pat|xox[baprs])[-_][A-Za-z0-9_-]{12,}|\bBearer\s+[A-Za-z0-9._~+/=-]{12,}|\b(?:password|passwd|secret|token|api[_-]?key)\s*[:=]\s*[^\s]{6,})/iu;

function allStrings(value: unknown): string[] {
  if (typeof value === "string") return [value];
  if (Array.isArray(value)) return value.flatMap(allStrings);
  if (value !== null && typeof value === "object") return Object.values(value).flatMap(allStrings);
  return [];
}

function assertUnique(values: readonly string[], label: string): void {
  if (new Set(values).size !== values.length) throw new TypeError(`${label} must be unique`);
}

/** Semantic checks JSON Schema cannot express; safe to reuse at every trust boundary. */
export function assertAnalysisDraftSemantics(
  draft: AnalysisDraft,
  allowedEvidenceIds?: ReadonlySet<EvidenceId>,
): void {
  for (const text of allStrings(draft)) {
    if (INSTRUCTION_LIKE.test(text)) throw new TypeError("Analysis draft contains instruction-like content");
    if (SECRET_LIKE.test(text)) throw new TypeError("Analysis draft contains secret-like content");
  }

  const ids = [
    ...draft.observations.map((item) => item.observationId),
    ...draft.inferences.map((item) => item.inferenceId),
    ...draft.hypotheses.map((item) => item.hypothesisId),
  ];
  assertUnique(ids, "Analysis IDs");
  const ranks = draft.hypotheses.map((item) => item.rank);
  assertUnique(ranks.map(String), "Hypothesis ranks");
  const expectedRanks = Array.from({ length: ranks.length }, (_unused, index) => index + 1);
  if ([...ranks].sort((left, right) => left - right).some((rank, index) => rank !== expectedRanks[index])) {
    throw new TypeError("Hypothesis ranks must be contiguous from 1");
  }

  const citations: EvidenceId[] = [];
  for (const observation of draft.observations) citations.push(...observation.evidenceIds);
  for (const item of [...draft.inferences, ...draft.hypotheses]) {
    if (item.supportingEvidenceIds.length === 0) {
      throw new TypeError(`${"hypothesisId" in item ? item.hypothesisId : item.inferenceId} requires supporting evidence`);
    }
    const supporting = new Set(item.supportingEvidenceIds);
    if (item.contradictingEvidenceIds.some((id) => supporting.has(id))) {
      throw new TypeError(`${"hypothesisId" in item ? item.hypothesisId : item.inferenceId} cites the same evidence as support and contradiction`);
    }
    citations.push(...item.supportingEvidenceIds, ...item.contradictingEvidenceIds);
  }
  for (const hypothesis of draft.hypotheses) {
    if (hypothesis.contradictingEvidenceIds.length === 0 && hypothesis.nextCheck === undefined) {
      throw new TypeError(`Hypothesis ${hypothesis.hypothesisId} requires counter-evidence or a next check`);
    }
  }
  if (allowedEvidenceIds !== undefined) {
    for (const id of citations) {
      if (!allowedEvidenceIds.has(id)) throw new TypeError(`Analysis draft cites evidence outside this run: ${id}`);
    }
  }
}
