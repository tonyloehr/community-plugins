/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export interface WorkflowSummarySchema {
  schemaVersion: "1.0.0";
  runId: string;
  workflow: "triage" | "investigate" | "deep" | "change-review" | "verify";
  terminalState: "SEALED" | "BLOCKED" | "PAUSED" | "CANCELLED";
  investigationStatus: "COMPLETE" | "PARTIAL" | "BLOCKED";
  recoveryState:
    "NONE" | "APPROVAL_REQUIRED" | "ACTION_FAILED" | "INCOMPLETE" | "NOT_RECOVERED" | "RECOVERED";
  evidenceSummary: {
    COMPLETE: number;
    EMPTY: number;
    STALE: number;
    CONTRADICTORY: number;
    ERROR: number;
  };
  /**
   * @maxItems 256
   */
  limitations: string[];
  artifact?: {
    bundleId: string;
    manifestSha256: string;
    relativePath?: string;
  };
  exitCode: 0 | 1 | 2 | 130 | 143;
}
