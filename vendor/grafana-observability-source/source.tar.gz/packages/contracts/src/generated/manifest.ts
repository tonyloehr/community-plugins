/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export interface BundleManifestSchema {
  schemaVersion: "1.0.0";
  bundleId: string;
  runId: string;
  parentRunId?: string;
  origin: "LIVE" | "REPLAY" | "SIMULATED";
  producer: {
    pluginVersion: string;
    contractsVersion: string;
    reportProjectionVersion: string;
  };
  createdAt: string;
  sealedAt: string;
  /**
   * @minItems 1
   * @maxItems 10000
   */
  entries: {
    path: string;
    role:
      | "RUN"
      | "PROFILE"
      | "OPERATIONS"
      | "EVIDENCE"
      | "CONTRADICTIONS"
      | "COVERAGE"
      | "INVESTIGATION"
      | "RECEIPT";
    mediaType: string;
    bytes: number;
    sha256: string;
  }[];
  bundleSha256: string;
}
