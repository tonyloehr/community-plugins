/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type MonitoringWorkspaceSnapshotSchema = {
  schemaVersion: "1.0.0" | "1.1.0";
  workspaceId: string;
  stateVersion: number;
  asOf: string;
  lifecycle: "IDLE" | "PREFLIGHT" | "RUNNING" | "SEALED" | "PARTIAL" | "BLOCKED" | "CANCELLED";
  phase:
    | "READINESS"
    | "SCOPING"
    | "BASELINE"
    | "COLLECTING"
    | "COMPARING"
    | "ANALYZING"
    | "FINALIZING"
    | "PATCHING"
    | "VERIFYING";
  origin?: "LIVE" | "REPLAY" | "SIMULATED";
  scope?: {
    service?: string;
    environment: string;
    window?: TimeWindow;
  };
  status: {
    service: "HEALTHY" | "DEGRADED" | "RECOVERING" | "UNKNOWN";
    collection: "NOT_STARTED" | "IN_PROGRESS" | "COMPLETE" | "PARTIAL" | "ERROR";
    causality: "NOT_ASSESSED" | "OPEN" | "SUPPORTED" | "INCONCLUSIVE";
    recovery:
      | "NOT_ASSESSED"
      | "APPROVAL_REQUIRED"
      | "ACTION_FAILED"
      | "INCOMPLETE"
      | "NOT_RECOVERED"
      | "RECOVERED";
    audit: "INITIALIZING" | "HEALTHY" | "DEGRADED" | "ERROR";
  };
  progress: {
    completedOperations: number;
    requiredOperations: number;
    sourceStates: {
      [k: string]: number;
    };
  };
  /**
   * @maxItems 3
   */
  signals: SignalCard[];
  /**
   * @maxItems 3
   */
  hypotheses: HypothesisCard[];
  /**
   * @maxItems 24
   */
  issues?: IssueCard[];
  /**
   * @maxItems 24
   */
  evidence: EvidenceCard[];
  /**
   * @maxItems 40
   */
  activity: ActivityItem[];
  patch: PatchStatusSchema;
  nextAction: ActionAvailability;
  /**
   * @maxItems 16
   */
  limitations: string[];
};
/**
 * @maxItems 8
 */
export type EvidenceRefs = string[];
export type IssueCard = {
  issueRef: string;
  kind: "ALERT" | "REGRESSION" | "ANOMALY" | "CONTRADICTION" | "EVIDENCE_GAP";
  severity: "INFO" | "WARNING" | "CRITICAL";
  status: "OPEN" | "SUPPORTED" | "RESOLVED" | "BLOCKED";
  classification: "SIGNED_RULE" | "DEVIATION";
  title: string;
  summary: string;
  evidenceRefs: EvidenceRefs;
  /**
   * @maxItems 8
   */
  hypothesisRefs: string[];
  patch: PatchStatusSchema;
};
/**
 * @maxItems 4
 */
export type LinkRefs = string[];

export interface TimeWindow {
  start: string;
  end: string;
}
export interface SignalCard {
  signalRef: string;
  title: string;
  displayValue: string;
  unit?: string;
  severity: "NEUTRAL" | "GOOD" | "WARNING" | "CRITICAL";
  direction: "UP" | "DOWN" | "FLAT" | "UNKNOWN";
  /**
   * @maxItems 30
   */
  points: (number | null)[];
  evidenceRefs: EvidenceRefs;
}
export interface HypothesisCard {
  hypothesisRef: string;
  rank: number;
  statement: string;
  status: "OPEN" | "SUPPORTED" | "WEAKENED" | "REJECTED";
  confidence?: number;
  rationale: string;
  evidenceRefs: EvidenceRefs;
}
export interface PatchStatusSchema {
  schemaVersion: "1.0.0";
  state: "NOT_ELIGIBLE" | "ELIGIBLE" | "REQUESTED" | "HANDOFF_COMPLETE" | "BLOCKED" | "STALE";
  eligible: boolean;
  updatedAt: string;
  title?: string;
  reason?: string;
  /**
   * @maxItems 16
   */
  evidenceRefs: string[];
  /**
   * @maxItems 12
   */
  limitations: string[];
}
export interface EvidenceCard {
  evidenceRef: string;
  title: string;
  domain: "METRICS" | "ALERTS" | "LOGS" | "TRACES" | "RUNTIME" | "CHANGES" | "RUNBOOKS";
  state: "COMPLETE" | "EMPTY" | "STALE" | "CONTRADICTORY" | "ERROR";
  authority: "AUTHORITATIVE" | "CORROBORATING";
  sourceLabel: string;
  summary: string;
  observedAt?: string;
  linkRefs: LinkRefs;
}
export interface ActivityItem {
  activityRef: string;
  at: string;
  kind: "READINESS" | "SCOPE" | "EVIDENCE" | "ANALYSIS" | "PATCH" | "RECOVERY" | "SYSTEM";
  state: "PENDING" | "RUNNING" | "COMPLETE" | "PARTIAL" | "ERROR";
  title: string;
  detail?: string;
}
export interface ActionAvailability {
  action:
    | "NONE"
    | "COLLECT_EVIDENCE"
    | "RETRY_COLLECTION"
    | "GENERATE_PATCH"
    | "REVIEW_PATCH"
    | "VERIFY_RECOVERY";
  enabled: boolean;
  label: string;
  reason?: string;
}
