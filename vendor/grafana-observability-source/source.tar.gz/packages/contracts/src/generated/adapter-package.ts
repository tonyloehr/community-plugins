/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export interface AdapterPackageSchema {
  schemaVersion: "1.0.0";
  packageId: string;
  name: string;
  version: string;
  protocolVersion: "1.0";
  publisher: {
    name: string;
    keyId?: string;
  };
  entrypoint:
    | {
        kind: "BUILTIN";
        registryKey: string;
      }
    | {
        kind: "SIGNED_WORKER";
        protocol: "PM_ADAPTER_STDIO_V1";
        artifactPath: string;
        artifactSha256: string;
        signature: string;
        signingKeyId: string;
      };
  /**
   * @minItems 1
   */
  domains: ("METRICS" | "ALERTS" | "LOGS" | "TRACES" | "RUNTIME" | "CHANGES" | "RUNBOOKS")[];
  capabilities: string[];
  providerCompatibility: {
    provider: string;
    versions: string;
  }[];
  /**
   * @minItems 1
   */
  supportedContractVersions: string[];
  /**
   * @minItems 1
   */
  conformance: (
    | "CORE_READ"
    | "METRICS"
    | "LOGS"
    | "TRACES"
    | "ALERTS"
    | "RUNTIME"
    | "CHANGES"
    | "RUNBOOKS"
    | "REMOTE_DEPLOYMENT"
    | "ACTION_READY"
  )[];
}
