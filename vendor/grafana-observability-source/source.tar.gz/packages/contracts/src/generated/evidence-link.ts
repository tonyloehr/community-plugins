/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type EvidenceLinkSchema = {
  schemaVersion: "1.0.0";
  workspaceId: string;
  linkRef: string;
  evidenceRef?: string;
  kind:
    | "GRAFANA_DASHBOARD"
    | "GRAFANA_PANEL"
    | "PROMETHEUS_VIEW"
    | "LOG_VIEW"
    | "TRACE_VIEW"
    | "CODE_REVISION"
    | "CODE_LOCATION";
  label: string;
  availability: "AVAILABLE" | "UNAVAILABLE";
  unavailableReason?: string;
};
