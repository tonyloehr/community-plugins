/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type IssueRule = {
  ruleId: string;
  comparison: "THRESHOLD" | "BASELINE_DELTA" | "STALE" | "EMPTY" | "ERROR" | "CONTRADICTION";
  operationId: string;
  comparisonOperationId?: string;
  resultName?: string;
  reducer?: "SINGLE" | "MAX" | "MIN";
  comparator?: "LT" | "LTE" | "GT" | "GTE" | "EQ";
  threshold?: number;
  delta?: number;
  maxAgeMs?: number;
  issueKind: "ALERT" | "REGRESSION" | "ANOMALY" | "CONTRADICTION" | "EVIDENCE_GAP";
  severity: "INFO" | "WARNING" | "CRITICAL";
  signedThreshold: boolean;
};

export interface ProviderCapabilityPackSchema {
  schemaVersion: "1.0.0";
  packId: string;
  revision: number;
  useCase:
    | "INFRASTRUCTURE"
    | "APPLICATION_PERFORMANCE"
    | "LOG_ANALYTICS"
    | "IOT_EDGE"
    | "BUSINESS_INTELLIGENCE";
  /**
   * @minItems 1
   * @maxItems 128
   */
  requiredOperationIds: string[];
  /**
   * @maxItems 128
   */
  optionalOperationIds: string[];
  /**
   * @maxItems 5
   */
  supportedSubjectKinds: ("HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET")[];
  /**
   * @minItems 1
   * @maxItems 16
   */
  scopeMappings: ScopeMapping[];
  /**
   * @minItems 1
   * @maxItems 64
   */
  signals: Signal[];
  /**
   * @maxItems 64
   */
  issueRules: IssueRule[];
  definitionSha256: string;
}
export interface ScopeMapping {
  scopeField: "environment" | "service" | "region" | "cohort" | "subject.ref";
  providerField: string;
  required: boolean;
}
export interface Signal {
  signalId: string;
  operationId: string;
  resultName: string;
  order: number;
  unit?: string;
  polarity: "HIGH_IS_BAD" | "LOW_IS_BAD" | "NEUTRAL";
  thresholds?: Threshold;
}
export interface Threshold {
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ";
  warning?: number;
  critical?: number;
}
