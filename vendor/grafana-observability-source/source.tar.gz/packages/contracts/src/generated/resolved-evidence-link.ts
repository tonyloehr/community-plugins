/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type ResolvedEvidenceLinkSchema =
  | {
      schemaVersion: "1.0.0";
      workspaceId: string;
      linkRef: string;
      mode: "OPEN_EXTERNAL";
      label: string;
      url: string;
    }
  | {
      schemaVersion: "1.0.0";
      workspaceId: string;
      linkRef: string;
      mode: "CODE_FOLLOW_UP";
      label: string;
      intent: "OPEN_CODE_EVIDENCE";
    };
