/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type WorkflowRequestSchema = {
  schemaVersion: "1.0.0";
  idempotencyKey: string;
  workflow: "triage" | "investigate" | "deep" | "change-review" | "verify";
  profileAlias: string;
  scopeAlias: string;
  origin: "LIVE" | "REPLAY" | "SIMULATED";
  window: TimeWindow;
  baselineWindow?: TimeWindow;
  incidentAlias?: string;
  parentRunId?: string;
  verificationPolicyAlias?: string;
  artifactPolicy: {
    mode: "required" | "best_effort";
  };
  failOn: "none" | "partial" | "error";
  /**
   * @minItems 1
   * @maxItems 128
   */
  requiredOperations?: string[];
  /**
   * @minItems 1
   * @maxItems 32
   */
  requiredCapabilityPacks?: string[];
};

export interface TimeWindow {
  start: string;
  end: string;
}
