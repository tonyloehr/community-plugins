/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type ContradictionRecordSchema = {
  schemaVersion: "1.0.0";
  contradictionId: string;
  runId: string;
  consistencyState: "CONTRADICTORY";
  kind: "VALUE" | "SCOPE" | "TIME" | "IDENTITY" | "AUTHORITY" | "SEMANTIC";
  summary: string;
  /**
   * @minItems 2
   * @maxItems 128
   */
  claimRefs: {
    evidenceId: string;
    jsonPointer: string;
    claim: string;
  }[];
  resolutionState: "UNRESOLVED" | "EXPLAINED" | "RESOLVED";
  resolution?: string;
  assessedAt: string;
  integrity: Integrity;
};

export interface Integrity {
  hashContractVersion: "sha256-jcs-v1";
  algorithm: "sha256";
  canonicalization: "RFC8785";
  contentSha256: string;
}
