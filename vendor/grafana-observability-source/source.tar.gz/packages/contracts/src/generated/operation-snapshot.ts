/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export interface OperationSnapshotSchema {
  schemaVersion: "1.0.0";
  operationId: string;
  revision: number;
  capturedAt: string;
  definition: {
    domain: "METRICS" | "ALERTS" | "LOGS" | "TRACES" | "RUNTIME" | "CHANGES" | "RUNBOOKS";
    sourceAlias: string;
    adapterPackageId: string;
    adapterOperation: string;
    authority: "AUTHORITATIVE" | "CORROBORATING";
    sanitizedProviderDefinition: Record<string, unknown>;
    expectedSourceLineage?: {
      accessPath: "DIRECT" | "GRAFANA";
      datasourceType: "prometheus" | "loki" | "tempo" | "postgres";
      sourceIdentitySha256: string;
    };
    scopeMapping: {
      [k: string]: string;
    };
    /**
     * @maxItems 128
     */
    allowedDimensions: string[];
    /**
     * @maxItems 128
     */
    requiredProviderScopes: string[];
    sensitivity: "PUBLIC" | "INTERNAL" | "CONFIDENTIAL" | "RESTRICTED";
    limits: OperationLimits;
    normalization: {
      resultKind: "SCALAR" | "TIMESERIES" | "TABLE" | "EVENT";
      targetUnit?: string;
      dimensionMappings: {
        [k: string]: string;
      };
    };
  };
  definitionSha256: string;
}
export interface OperationLimits {
  timeoutMs: number;
  maxAgeMs: number;
  maxBytes: number;
  maxRows: number;
  maxSeries: number;
  maxPoints: number;
}
