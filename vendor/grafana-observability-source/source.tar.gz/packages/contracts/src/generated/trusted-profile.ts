/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type OperatorSetting =
  | {
      mode: "OPERATOR_REQUIRED";
    }
  | {
      mode: "FIXED";
      durationSeconds: number;
    };

export interface TrustedProfileSchema {
  schemaVersion: "1.0.0";
  profileAlias: string;
  capabilityProfile: "observe" | "investigate" | "prepare_patch";
  /**
   * @minItems 1
   */
  allowedOrigins: ("LIVE" | "REPLAY" | "SIMULATED")[];
  compiledAt: string;
  configSha256: string;
  endpointRegistrySha256: string;
  catalogSha256: string;
  scopes: {
    [k: string]: Scope;
  };
  endpointIds: string[];
  operationIds: string[];
  /**
   * @maxItems 32
   */
  capabilityPackIds?: string[];
  capabilityPackCatalogSha256?: string;
  defaultVerificationPolicyAlias?: string;
  verificationPolicies?: {
    [k: string]: VerificationPolicy;
  };
  policy: {
    defaultLookback: OperatorSetting;
    maxEvidenceAge: OperatorSetting;
    rawEvidenceRetention: {
      mode: "NONE";
    };
    auditRequired: boolean;
    limits: OperationLimits;
  };
}
export interface Scope {
  environment: string;
  service?: string;
  region?: string;
  cohort?: string;
  subject?: {
    kind: "HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET";
    ref: string;
  };
}
export interface VerificationPolicy {
  policyAlias: string;
  windowStrategy: "FIXED" | "ROLLING" | "REPEATED_CHECKS";
  windowDurationSeconds: number;
  requiredSamples: number;
  passCount: number;
  /**
   * @minItems 1
   * @maxItems 128
   */
  criteria: VerificationCriterion[];
}
export interface VerificationCriterion {
  criterionId: string;
  operationId: string;
  valueSelector: ValueSelector;
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ" | "INACTIVE" | "ACTIVE";
  expected: null | boolean | number | string;
  unit?: string;
  maxEvidenceAgeMs: number;
  requiredDurationSeconds?: number;
}
export interface ValueSelector {
  kind: "SCALAR" | "TIMESERIES";
  name: string;
  reducer: "SINGLE" | "LATEST" | "ALL";
  dimensions?: Dimensions;
}
export interface Dimensions {
  [k: string]: string;
}
export interface OperationLimits {
  timeoutMs: number;
  maxAgeMs: number;
  maxBytes: number;
  maxRows: number;
  maxSeries: number;
  maxPoints: number;
}
