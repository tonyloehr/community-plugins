/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export interface MonitoringEvidenceDetailSchema {
  schemaVersion: "1.0.0";
  workspaceId: string;
  evidenceRef: string;
  title: string;
  domain: "METRICS" | "ALERTS" | "LOGS" | "TRACES" | "RUNTIME" | "CHANGES" | "RUNBOOKS";
  origin: "LIVE" | "REPLAY" | "SIMULATED";
  authority: "AUTHORITATIVE" | "CORROBORATING";
  state: "COMPLETE" | "EMPTY" | "STALE" | "CONTRADICTORY" | "ERROR";
  source: {
    provider: string;
    sourceAlias: string;
  };
  evaluatedAt: string;
  collectedAt: string;
  window: TimeWindow;
  summary: string;
  /**
   * @maxItems 24
   */
  values: (Metric | Fact | Event)[];
  /**
   * @maxItems 12
   */
  limitations: string[];
  /**
   * @maxItems 8
   */
  linkRefs: string[];
}
export interface TimeWindow {
  start: string;
  end: string;
}
export interface Metric {
  kind: "METRIC";
  label: string;
  value: number | null;
  unit?: string;
  /**
   * @maxItems 60
   */
  points: {
    at: string;
    value: number | null;
  }[];
}
export interface Fact {
  kind: "FACT";
  label: string;
  value: null | boolean | number | string;
}
export interface Event {
  kind: "EVENT";
  at: string;
  summary: string;
}
