/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type InvestigationSchema = {
  schemaVersion: "1.0.0";
  runId: string;
  analysisState: "SUBMITTED" | "EVIDENCE_ONLY";
  status: "COMPLETE" | "PARTIAL" | "BLOCKED";
  recoveryState:
    "NONE" | "APPROVAL_REQUIRED" | "ACTION_FAILED" | "INCOMPLETE" | "NOT_RECOVERED" | "RECOVERED";
  scope: Scope;
  requestedWindow: TimeWindow;
  evaluatedWindow: TimeWindow;
  /**
   * @maxItems 1000
   */
  observations: Observation[];
  /**
   * @maxItems 1000
   */
  inferences: Inference[];
  /**
   * @maxItems 256
   */
  hypotheses: Hypothesis[];
  contradictionIds: string[];
  checksPerformed: StringList;
  missingEvidence: StringList;
  smallestSafeNextStep: string;
  approvalRequired: boolean;
  verificationContract?: VerificationContract;
  verificationResult?: {
    status: "PASSED" | "FAILED" | "INCOMPLETE";
    evidenceIds: string[];
  };
  remainingUncertainty: StringList;
  owners: StringList;
  integrity: Integrity;
};
/**
 * @minItems 1
 * @maxItems 128
 */
export type SupportingEvidenceIds = string[];
/**
 * @maxItems 128
 */
export type EvidenceIds = string[];
/**
 * @maxItems 256
 */
export type StringList = string[];

export interface Scope {
  environment: string;
  service?: string;
  region?: string;
  cohort?: string;
  subject?: {
    kind: "HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET";
    ref: string;
  };
}
export interface TimeWindow {
  start: string;
  end: string;
}
export interface Observation {
  observationId: string;
  statement: string;
  /**
   * @minItems 1
   * @maxItems 128
   */
  evidenceIds: string[];
}
export interface Inference {
  inferenceId: string;
  statement: string;
  confidence: number;
  rationale: string;
  supportingEvidenceIds: SupportingEvidenceIds;
  contradictingEvidenceIds: EvidenceIds;
}
export interface Hypothesis {
  hypothesisId: string;
  rank: number;
  statement: string;
  status: "OPEN" | "SUPPORTED" | "WEAKENED" | "REJECTED";
  rationale: string;
  supportingEvidenceIds: SupportingEvidenceIds;
  contradictingEvidenceIds: EvidenceIds;
  nextCheck?: string;
}
export interface VerificationContract {
  contractSha256: string;
  policyAlias: string;
  scope: Scope;
  cohort?: string;
  windowStrategy: "FIXED" | "ROLLING" | "REPEATED_CHECKS";
  windowDurationSeconds: number;
  requiredSamples: number;
  passCount: number;
  /**
   * @minItems 1
   * @maxItems 128
   */
  criteria: {
    criterionId: string;
    operationId: string;
    operationDefinitionSha256: string;
    valueSelector: {
      kind: "SCALAR" | "TIMESERIES";
      name: string;
      reducer: "SINGLE" | "LATEST" | "ALL";
      dimensions?: Dimensions;
    };
    comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ" | "INACTIVE" | "ACTIVE";
    expected: null | boolean | number | string;
    unit?: string;
    maxEvidenceAgeMs: number;
    requiredDurationSeconds?: number;
  }[];
}
export interface Dimensions {
  [k: string]: string;
}
export interface Integrity {
  hashContractVersion: "sha256-jcs-v1";
  algorithm: "sha256";
  canonicalization: "RFC8785";
  contentSha256: string;
}
