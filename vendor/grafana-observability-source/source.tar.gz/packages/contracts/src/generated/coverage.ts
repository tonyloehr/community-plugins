/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export interface CoverageSchema {
  schemaVersion: "1.0.0";
  runId: string;
  overall: "COMPLETE" | "PARTIAL" | "UNKNOWN";
  /**
   * @maxItems 1024
   */
  entries: {
    domain: "METRICS" | "ALERTS" | "LOGS" | "TRACES" | "RUNTIME" | "CHANGES" | "RUNBOOKS";
    operationId: string;
    requirement: "REQUIRED" | "OPTIONAL";
    sourceAlias?: string;
    authority?: "AUTHORITATIVE" | "CORROBORATING";
    disposition:
      "AVAILABLE" | "EMPTY" | "STALE" | "CONTRADICTORY" | "ERROR" | "UNSUPPORTED" | "DEFERRED";
    evidenceIds: string[];
    contradictionIds: string[];
    paginationComplete?: boolean;
    blocksWorkflow: boolean;
    reason?: string;
  }[];
  integrity: Integrity;
}
export interface Integrity {
  hashContractVersion: "sha256-jcs-v1";
  algorithm: "sha256";
  canonicalization: "RFC8785";
  contentSha256: string;
}
