/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export interface PatchStatusSchema {
  schemaVersion: "1.0.0";
  state: "NOT_ELIGIBLE" | "ELIGIBLE" | "REQUESTED" | "HANDOFF_COMPLETE" | "BLOCKED" | "STALE";
  eligible: boolean;
  updatedAt: string;
  title?: string;
  reason?: string;
  /**
   * @maxItems 16
   */
  evidenceRefs: string[];
  /**
   * @maxItems 12
   */
  limitations: string[];
}
