/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type WorkflowEventSchema =
  | WorkflowStarted
  | RunStarted
  | RunResumed
  | EvidenceCollected
  | RunSealed
  | WorkflowStopped
  | RunCancelled
  | WorkflowResult;

export interface WorkflowStarted {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "workflow_started";
  workflow: "triage" | "investigate" | "deep" | "change-review" | "verify";
  requestSha256: string;
}
export interface RunStarted {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "run_started";
  runId: string;
  revision: number;
  origin: "LIVE" | "REPLAY" | "SIMULATED";
  operationSnapshotSha256: string;
}
export interface RunResumed {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "run_resumed";
  runId: string;
  revision: number;
  operationSnapshotSha256: string;
}
export interface EvidenceCollected {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "evidence_collected";
  runId: string;
  revision: number;
  /**
   * @maxItems 128
   */
  evidence: {
    evidenceId: string;
    operationId: string;
    state: "COMPLETE" | "EMPTY" | "STALE" | "CONTRADICTORY" | "ERROR";
  }[];
}
export interface RunSealed {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "run_sealed";
  runId: string;
  revision: number;
  bundleId: string;
  manifestSha256: string;
  artifactRelativePath: string;
}
export interface WorkflowStopped {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "workflow_stopped";
  runId: string;
  state: "BLOCKED" | "CANCELLED" | "PAUSED";
  code: string;
}
export interface RunCancelled {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "run_cancelled";
  runId: string;
  revision: number;
  /**
   * @maxItems 128
   */
  retainedEvidenceIds: string[];
}
export interface WorkflowResult {
  schemaVersion: "1.0.0";
  sequence: number;
  at: string;
  event: "workflow_result";
  result: WorkflowSummarySchema;
  requestSha256: string;
  operationSnapshotSha256: string;
}
export interface WorkflowSummarySchema {
  schemaVersion: "1.0.0";
  runId: string;
  workflow: "triage" | "investigate" | "deep" | "change-review" | "verify";
  terminalState: "SEALED" | "BLOCKED" | "PAUSED" | "CANCELLED";
  investigationStatus: "COMPLETE" | "PARTIAL" | "BLOCKED";
  recoveryState:
    "NONE" | "APPROVAL_REQUIRED" | "ACTION_FAILED" | "INCOMPLETE" | "NOT_RECOVERED" | "RECOVERED";
  evidenceSummary: {
    COMPLETE: number;
    EMPTY: number;
    STALE: number;
    CONTRADICTORY: number;
    ERROR: number;
  };
  /**
   * @maxItems 256
   */
  limitations: string[];
  artifact?: {
    bundleId: string;
    manifestSha256: string;
    relativePath?: string;
  };
  exitCode: 0 | 1 | 2 | 130 | 143;
}
