/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

/**
 * @minItems 1
 * @maxItems 128
 */
export type SupportingEvidenceIds = string[];
/**
 * @maxItems 128
 */
export type EvidenceIds = string[];
/**
 * @maxItems 256
 */
export type StringList = string[];

export interface AnalysisDraftSchema {
  schemaVersion: "1.0.0";
  /**
   * @maxItems 1000
   */
  observations: Observation[];
  /**
   * @maxItems 1000
   */
  inferences: Inference[];
  /**
   * @maxItems 256
   */
  hypotheses: Hypothesis[];
  checksPerformed: StringList;
  missingEvidence: StringList;
  smallestSafeNextStep: string;
  approvalRequired: boolean;
  remainingUncertainty: StringList;
  owners: StringList;
}
export interface Observation {
  observationId: string;
  statement: string;
  /**
   * @minItems 1
   * @maxItems 128
   */
  evidenceIds: string[];
}
export interface Inference {
  inferenceId: string;
  statement: string;
  confidence: number;
  rationale: string;
  supportingEvidenceIds: SupportingEvidenceIds;
  contradictingEvidenceIds: EvidenceIds;
}
export interface Hypothesis {
  hypothesisId: string;
  rank: number;
  statement: string;
  status: "OPEN" | "SUPPORTED" | "WEAKENED" | "REJECTED";
  rationale: string;
  supportingEvidenceIds: SupportingEvidenceIds;
  contradictingEvidenceIds: EvidenceIds;
  nextCheck?: string;
}
