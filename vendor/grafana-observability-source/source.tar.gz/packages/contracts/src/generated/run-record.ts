/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type RunRecordSchema = {
  schemaVersion: "1.0.0";
  runId: string;
  state: "OPEN" | "FINALIZING" | "SEALED" | "ABORTED" | "EXPIRED";
  workflow: "triage" | "investigate" | "deep" | "change-review" | "verify";
  origin: "LIVE" | "REPLAY" | "SIMULATED";
  principal: {
    issuerAlias: string;
    subjectSha256: string;
    tenantSha256: string;
    sessionSha256: string;
  };
  handleSha256: string;
  requestSha256: string;
  trustBundleSha256: string;
  profileAlias: string;
  scope: Scope;
  window: TimeWindow;
  baselineWindow?: TimeWindow;
  incidentAlias?: string;
  parent?: {
    runId: string;
    verificationContractSha256: string;
  };
  allowedOperationHashes: {
    [k: string]: string;
  };
  evidenceIds: string[];
  contradictionIds: string[];
  audit: {
    required: boolean;
    state: "HEALTHY" | "DEGRADED" | "FAILED";
  };
  createdAt: string;
  expiresAt: string;
  finalizedAt?: string;
  abortedAt?: string;
  integrity: Integrity;
};

export interface Scope {
  environment: string;
  service?: string;
  region?: string;
  cohort?: string;
  subject?: {
    kind: "HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET";
    ref: string;
  };
}
export interface TimeWindow {
  start: string;
  end: string;
}
export interface Integrity {
  hashContractVersion: "sha256-jcs-v1";
  algorithm: "sha256";
  canonicalization: "RFC8785";
  contentSha256: string;
}
