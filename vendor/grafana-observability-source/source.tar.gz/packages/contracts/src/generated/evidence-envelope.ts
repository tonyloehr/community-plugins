/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type EvidenceEnvelopeSchema = {
  schemaVersion: "1.0.0" | "1.1.0";
  evidenceId: string;
  runId: string;
  operationId: string;
  operationDefinitionSha256: string;
  trustBundleSha256: string;
  origin: "LIVE" | "REPLAY" | "SIMULATED";
  authority: "AUTHORITATIVE" | "CORROBORATING";
  source: {
    provider: string;
    sourceAlias: string;
    adapterPackageId: string;
    adapterVersion: string;
    sanitizedReference?: string;
    lineage?: {
      accessPath: "DIRECT" | "GRAFANA";
      datasourceType: "prometheus" | "loki" | "tempo" | "postgres";
      sourceIdentitySha256: string;
    };
  };
  scope: Scope;
  correlation: CorrelationIdentity;
  evaluatedAt: string;
  collectedAt: string;
  window: TimeWindow;
  maxAcceptableAgeMs: number;
  collectionState: "COMPLETE" | "EMPTY" | "ERROR";
  freshnessState: "FRESH" | "STALE" | "NOT_APPLICABLE";
  native: {
    resultType: string;
    unit?: string;
    dimensions: Dimensions;
  };
  /**
   * @maxItems 10000
   */
  values: (ScalarValue | TimeSeriesValue | TableValue | EventValue)[];
  /**
   * @maxItems 10000
   */
  redactions: RedactionRecord[];
  /**
   * @maxItems 256
   */
  limitations: string[];
  pagination: Pagination;
  /**
   * @maxItems 256
   */
  providerWarnings: string[];
  error?: SanitizedError;
  integrity: Integrity;
} & (
    | {
        collectionState: "COMPLETE";
        freshnessState: "FRESH" | "STALE";
        /**
         * @minItems 1
         */
        values: unknown[];
      }
    | {
        collectionState: "EMPTY";
        freshnessState: "FRESH" | "STALE";
        /**
         * @maxItems 0
         */
        values: unknown[];
      }
    | {
        collectionState: "ERROR";
        freshnessState: "NOT_APPLICABLE";
        /**
         * @maxItems 0
         */
        values: unknown[];
        error: SanitizedError;
      }
  );

export interface Scope {
  environment: string;
  service?: string;
  region?: string;
  cohort?: string;
  subject?: {
    kind: "HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET";
    ref: string;
  };
}
export interface CorrelationIdentity {
  environment: string;
  serviceNamespace?: string;
  serviceName?: string;
  releaseVersion?: string;
  deploymentId?: string;
  gitCommit?: string;
  traceId?: string;
}
export interface TimeWindow {
  start: string;
  end: string;
}
export interface Dimensions {
  [k: string]: string;
}
export interface ScalarValue {
  kind: "SCALAR";
  name: string;
  value: null | boolean | number | string;
  unit?: string;
  dimensions: Dimensions;
  observedAt?: string;
}
export interface TimeSeriesValue {
  kind: "TIMESERIES";
  name: string;
  unit?: string;
  dimensions: Dimensions;
  /**
   * @minItems 1
   * @maxItems 10000
   */
  points: TimeSeriesPoint[];
}
export interface TimeSeriesPoint {
  at: string;
  value: number | null;
}
export interface TableValue {
  kind: "TABLE";
  name: string;
  /**
   * @minItems 1
   * @maxItems 128
   */
  columns: TableColumn[];
  /**
   * @maxItems 10000
   */
  rows: (null | boolean | number | string)[][];
}
export interface TableColumn {
  name: string;
  type: "STRING" | "NUMBER" | "BOOLEAN" | "DATETIME" | "NULL";
}
export interface EventValue {
  kind: "EVENT";
  name: string;
  occurredAt: string;
  summary: string;
  attributes: {
    [k: string]: null | boolean | number | string;
  };
}
export interface RedactionRecord {
  ruleId: string;
  path: string;
  action: "REMOVED" | "MASKED" | "HASHED" | "GENERALIZED";
}
export interface Pagination {
  complete: boolean;
  pages: number;
  truncatedReason?: "BYTE_LIMIT" | "ROW_LIMIT" | "SERIES_LIMIT" | "POINT_LIMIT" | "TIME_LIMIT";
}
export interface SanitizedError {
  code: string;
  category:
    | "AUTHORIZATION"
    | "AUTHENTICATION"
    | "UNAVAILABLE"
    | "TIMEOUT"
    | "RATE_LIMIT"
    | "INVALID_RESPONSE"
    | "POLICY"
    | "INTERNAL";
  message: string;
  retryable: boolean;
  providerStatus?: number;
}
export interface Integrity {
  hashContractVersion: "sha256-jcs-v1";
  algorithm: "sha256";
  canonicalization: "RFC8785";
  contentSha256: string;
}
