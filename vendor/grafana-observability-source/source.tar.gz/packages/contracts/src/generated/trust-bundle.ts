/**
 * Generated from packages/contracts/schemas.
 * Do not edit by hand; run `npm run generate:contracts`.
 */

export type Authentication =
  | {
      mode: "NONE";
    }
  | {
      mode: "BEARER";
      tokenRef: Credential;
    }
  | {
      mode: "BASIC";
      usernameRef: Credential;
      passwordRef: Credential;
    }
  | {
      mode: "MTLS";
      certificateRef: Credential;
      privateKeyRef: Credential;
    };
export type IssueRule = {
  ruleId: string;
  comparison: "THRESHOLD" | "BASELINE_DELTA" | "STALE" | "EMPTY" | "ERROR" | "CONTRADICTION";
  operationId: string;
  comparisonOperationId?: string;
  resultName?: string;
  reducer?: "SINGLE" | "MAX" | "MIN";
  comparator?: "LT" | "LTE" | "GT" | "GTE" | "EQ";
  threshold?: number;
  delta?: number;
  maxAgeMs?: number;
  issueKind: "ALERT" | "REGRESSION" | "ANOMALY" | "CONTRADICTION" | "EVIDENCE_GAP";
  severity: "INFO" | "WARNING" | "CRITICAL";
  signedThreshold: boolean;
};

export interface TrustBundleSchema {
  schemaVersion: "1.0.0";
  createdAt: string;
  profile: TrustedProfileSchema;
  endpoints: Endpoint[];
  operations: OperationSnapshotSchema[];
  /**
   * @maxItems 32
   */
  capabilityPacks?: ProviderCapabilityPackSchema[];
  adapters: AdapterPackageSchema[];
  integrity: Integrity;
}
export interface TrustedProfileSchema {
  schemaVersion: "1.0.0";
  profileAlias: string;
  capabilityProfile: "observe" | "investigate" | "prepare_patch";
  /**
   * @minItems 1
   */
  allowedOrigins: ("LIVE" | "REPLAY" | "SIMULATED")[];
  compiledAt: string;
  configSha256: string;
  endpointRegistrySha256: string;
  catalogSha256: string;
  scopes: {
    [k: string]: Scope;
  };
  endpointIds: string[];
  operationIds: string[];
  /**
   * @maxItems 32
   */
  capabilityPackIds?: string[];
  capabilityPackCatalogSha256?: string;
  defaultVerificationPolicyAlias?: string;
  verificationPolicies?: {
    [k: string]: VerificationPolicy;
  };
  policy: {
    defaultLookback:
      | {
          mode: "OPERATOR_REQUIRED";
        }
      | {
          mode: "FIXED";
          durationSeconds: number;
        };
    maxEvidenceAge:
      | {
          mode: "OPERATOR_REQUIRED";
        }
      | {
          mode: "FIXED";
          durationSeconds: number;
        };
    rawEvidenceRetention: {
      mode: "NONE";
    };
    auditRequired: boolean;
    limits: OperationLimits;
  };
}
export interface Scope {
  environment: string;
  service?: string;
  region?: string;
  cohort?: string;
  subject?: {
    kind: "HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET";
    ref: string;
  };
}
export interface VerificationPolicy {
  policyAlias: string;
  windowStrategy: "FIXED" | "ROLLING" | "REPEATED_CHECKS";
  windowDurationSeconds: number;
  requiredSamples: number;
  passCount: number;
  /**
   * @minItems 1
   * @maxItems 128
   */
  criteria: VerificationCriterion[];
}
export interface VerificationCriterion {
  criterionId: string;
  operationId: string;
  valueSelector: ValueSelector;
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ" | "INACTIVE" | "ACTIVE";
  expected: null | boolean | number | string;
  unit?: string;
  maxEvidenceAgeMs: number;
  requiredDurationSeconds?: number;
}
export interface ValueSelector {
  kind: "SCALAR" | "TIMESERIES";
  name: string;
  reducer: "SINGLE" | "LATEST" | "ALL";
  dimensions?: Dimensions;
}
export interface Dimensions {
  [k: string]: string;
}
export interface OperationLimits {
  timeoutMs: number;
  maxAgeMs: number;
  maxBytes: number;
  maxRows: number;
  maxSeries: number;
  maxPoints: number;
}
export interface Endpoint {
  endpointId: string;
  adapterId: string;
  baseUrl: string;
  authentication: Authentication;
  tls: {
    minimumVersion: "TLSv1.2" | "TLSv1.3";
    caRef?: Credential;
    serverName?: string;
  };
  network: {
    followRedirects: false;
    allowLoopbackHttp: boolean;
    /**
     * @minItems 1
     */
    allowedHosts: string[];
    networkClass: "loopback" | "private" | "public";
    routeMode: "direct" | "host_vpn" | "application_proxy";
  };
  tenantBinding?: {
    headerName: string;
    valueRef: string;
  };
}
export interface Credential {
  kind: "env" | "workload_identity" | "broker";
  key: string;
}
export interface OperationSnapshotSchema {
  schemaVersion: "1.0.0";
  operationId: string;
  revision: number;
  capturedAt: string;
  definition: {
    domain: "METRICS" | "ALERTS" | "LOGS" | "TRACES" | "RUNTIME" | "CHANGES" | "RUNBOOKS";
    sourceAlias: string;
    adapterPackageId: string;
    adapterOperation: string;
    authority: "AUTHORITATIVE" | "CORROBORATING";
    sanitizedProviderDefinition: Record<string, unknown>;
    expectedSourceLineage?: {
      accessPath: "DIRECT" | "GRAFANA";
      datasourceType: "prometheus" | "loki" | "tempo" | "postgres";
      sourceIdentitySha256: string;
    };
    scopeMapping: {
      [k: string]: string;
    };
    /**
     * @maxItems 128
     */
    allowedDimensions: string[];
    /**
     * @maxItems 128
     */
    requiredProviderScopes: string[];
    sensitivity: "PUBLIC" | "INTERNAL" | "CONFIDENTIAL" | "RESTRICTED";
    limits: OperationLimits;
    normalization: {
      resultKind: "SCALAR" | "TIMESERIES" | "TABLE" | "EVENT";
      targetUnit?: string;
      dimensionMappings: {
        [k: string]: string;
      };
    };
  };
  definitionSha256: string;
}
export interface ProviderCapabilityPackSchema {
  schemaVersion: "1.0.0";
  packId: string;
  revision: number;
  useCase:
    | "INFRASTRUCTURE"
    | "APPLICATION_PERFORMANCE"
    | "LOG_ANALYTICS"
    | "IOT_EDGE"
    | "BUSINESS_INTELLIGENCE";
  /**
   * @minItems 1
   * @maxItems 128
   */
  requiredOperationIds: string[];
  /**
   * @maxItems 128
   */
  optionalOperationIds: string[];
  /**
   * @maxItems 5
   */
  supportedSubjectKinds: ("HOST" | "DEVICE" | "FLEET" | "BUSINESS_UNIT" | "KPI_SET")[];
  /**
   * @minItems 1
   * @maxItems 16
   */
  scopeMappings: ScopeMapping[];
  /**
   * @minItems 1
   * @maxItems 64
   */
  signals: Signal[];
  /**
   * @maxItems 64
   */
  issueRules: IssueRule[];
  definitionSha256: string;
}
export interface ScopeMapping {
  scopeField: "environment" | "service" | "region" | "cohort" | "subject.ref";
  providerField: string;
  required: boolean;
}
export interface Signal {
  signalId: string;
  operationId: string;
  resultName: string;
  order: number;
  unit?: string;
  polarity: "HIGH_IS_BAD" | "LOW_IS_BAD" | "NEUTRAL";
  thresholds?: Threshold;
}
export interface Threshold {
  comparator: "LT" | "LTE" | "GT" | "GTE" | "EQ";
  warning?: number;
  critical?: number;
}
export interface AdapterPackageSchema {
  schemaVersion: "1.0.0";
  packageId: string;
  name: string;
  version: string;
  protocolVersion: "1.0";
  publisher: {
    name: string;
    keyId?: string;
  };
  entrypoint:
    | {
        kind: "BUILTIN";
        registryKey: string;
      }
    | {
        kind: "SIGNED_WORKER";
        protocol: "PM_ADAPTER_STDIO_V1";
        artifactPath: string;
        artifactSha256: string;
        signature: string;
        signingKeyId: string;
      };
  /**
   * @minItems 1
   */
  domains: ("METRICS" | "ALERTS" | "LOGS" | "TRACES" | "RUNTIME" | "CHANGES" | "RUNBOOKS")[];
  capabilities: string[];
  providerCompatibility: {
    provider: string;
    versions: string;
  }[];
  /**
   * @minItems 1
   */
  supportedContractVersions: string[];
  /**
   * @minItems 1
   */
  conformance: (
    | "CORE_READ"
    | "METRICS"
    | "LOGS"
    | "TRACES"
    | "ALERTS"
    | "RUNTIME"
    | "CHANGES"
    | "RUNBOOKS"
    | "REMOTE_DEPLOYMENT"
    | "ACTION_READY"
  )[];
}
export interface Integrity {
  hashContractVersion: "sha256-jcs-v1";
  algorithm: "sha256";
  canonicalization: "RFC8785";
  contentSha256: string;
}
