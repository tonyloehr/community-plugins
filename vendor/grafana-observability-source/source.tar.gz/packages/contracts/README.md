# `@codex-production-monitoring/contracts`

Canonical JSON Schemas, generated TypeScript types, stable canonical JSON, and
hashing helpers shared by Production Monitoring hosts and adapters.

```js
import { getSchema, sha256Canonical } from "@codex-production-monitoring/contracts";

const workflowSchema = getSchema("workflowRequest");
const digest = sha256Canonical({ schemaId: workflowSchema.$id });
```

The `./schemas/*` and `./examples/*` export paths expose the versioned JSON
assets included in the package. Treat schema identifiers and protocol versions
as compatibility contracts; do not infer trust from schema validity alone.

The workbench presentation boundary is also contract-first:

- `monitoring-workspace-snapshot.schema.json` bounds the incident pulse, evidence cards,
  activity, and patch status shown by the UI.
- `monitoring-evidence-detail.schema.json` permits only bounded normalized metrics,
  facts, and events for evidence drill-down.
- `evidence-link.schema.json` exposes opaque link metadata only. Trusted navigation
  resolution owns any eventual URL, query, revision, or code location.
- `resolved-evidence-link.schema.json` is the separate app-only result of that
  ownership-checked resolution. It permits HTTPS or loopback HTTP navigation and
  a fixed code follow-up intent; runtime policy still enforces the configured host.
- `patch-status.schema.json` is presentation state, not a patch artifact, approval,
  mutation capability, or proof of production recovery.

These UI-facing contracts deliberately omit run handles, credentials, endpoint
configuration, absolute paths, raw provider payloads, and integrity hashes.

Licensed under Apache-2.0.
