import {
  WORKER_PROTOCOL,
  assertWorkerRequest,
} from "@codex-production-monitoring/adapter-sdk";

const request = {
  protocol: WORKER_PROTOCOL,
  kind: "doctor",
  requestId: "example-doctor",
};

assertWorkerRequest(request);
console.log(JSON.stringify(request));
