import type { OperationLimits } from "@codex-production-monitoring/contracts";

import { BudgetExceededError } from "./errors.ts";
import type { BudgetController, BudgetSnapshot } from "./types.ts";

function assertCount(value: number): void {
  if (!Number.isSafeInteger(value) || value < 0) throw new TypeError("Budget consumption must be a non-negative safe integer");
}

export function createBudgetController(
  limits: Readonly<OperationLimits>,
  signal: AbortSignal,
): BudgetController {
  const used: BudgetSnapshot = { bytes: 0, rows: 0, series: 0, points: 0 };
  const consume = (dimension: keyof BudgetSnapshot, count: number): void => {
    assertCount(count);
    if (signal.aborted) throw signal.reason ?? new Error("Evidence collection cancelled");
    used[dimension] += count;
    const maximum = {
      bytes: limits.maxBytes,
      rows: limits.maxRows,
      series: limits.maxSeries,
      points: limits.maxPoints,
    }[dimension];
    if (used[dimension] > maximum) throw new BudgetExceededError(dimension);
  };
  return {
    limits,
    consumeBytes: (count) => consume("bytes", count),
    consumeRows: (count) => consume("rows", count),
    consumeSeries: (count) => consume("series", count),
    consumePoints: (count) => consume("points", count),
    checkpoint: () => ({ ...used }),
    throwIfAborted: () => {
      if (signal.aborted) throw signal.reason ?? new Error("Evidence collection cancelled");
    },
  };
}
