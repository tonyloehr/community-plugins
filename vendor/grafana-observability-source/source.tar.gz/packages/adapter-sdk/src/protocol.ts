import { TextDecoder } from "node:util";

import type {
  AdapterPackage,
  JsonValue,
  OperationLimits,
  OperationSnapshot,
} from "@codex-production-monitoring/contracts";

import { WorkerProtocolError } from "./errors.ts";
import type {
  CompiledAdapterOperation,
  AdapterDoctorResult,
  ProviderResult,
  ProviderValue,
  WorkerRequest,
  WorkerResponse,
} from "./types.ts";

export const WORKER_PROTOCOL = "PM_ADAPTER_STDIO_V1" as const;
export const WORKER_FRAME_HEADER_BYTES = 4;
export const DEFAULT_MAX_WORKER_FRAME_BYTES = 1024 * 1024;

const utf8 = new TextDecoder("utf-8", { fatal: true });
const HASH = /^[a-f0-9]{64}$/u;
const REQUEST_ID = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u;
const ERROR_CODE = /^(?:[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)*|[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*)$/u;
const CATEGORIES = new Set([
  "AUTHORIZATION",
  "AUTHENTICATION",
  "UNAVAILABLE",
  "TIMEOUT",
  "RATE_LIMIT",
  "INVALID_RESPONSE",
  "POLICY",
  "INTERNAL",
]);

type UnknownRecord = Record<string, unknown>;

function invalid(): never {
  throw new WorkerProtocolError("INVALID_MESSAGE");
}

function record(value: unknown): UnknownRecord {
  if (value === null || typeof value !== "object" || Array.isArray(value)) invalid();
  return value as UnknownRecord;
}

function exact(value: unknown, required: readonly string[], optional: readonly string[] = []): UnknownRecord {
  const object = record(value);
  const permitted = new Set([...required, ...optional]);
  if (Object.keys(object).some((key) => !permitted.has(key))) invalid();
  if (required.some((key) => !Object.hasOwn(object, key))) invalid();
  return object;
}

function string(value: unknown, maximum = 4096): string {
  if (typeof value !== "string" || value.length === 0 || value.length > maximum || value.includes("\0")) invalid();
  return value;
}

function optionalString(value: unknown, maximum = 4096): string | undefined {
  return value === undefined ? undefined : string(value, maximum);
}

function integer(value: unknown, minimum = 0, maximum = Number.MAX_SAFE_INTEGER): number {
  if (!Number.isSafeInteger(value) || (value as number) < minimum || (value as number) > maximum) invalid();
  return value as number;
}

function finiteNumber(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value)) invalid();
  return value;
}

function boolean(value: unknown): boolean {
  if (typeof value !== "boolean") invalid();
  return value;
}

function enumeration<T extends string>(value: unknown, values: readonly T[]): T {
  if (typeof value !== "string" || !(values as readonly string[]).includes(value)) invalid();
  return value as T;
}

function date(value: unknown): string {
  const result = string(value, 64);
  if (!Number.isFinite(Date.parse(result))) invalid();
  return result;
}

function hash(value: unknown): string {
  const result = string(value, 64);
  if (!HASH.test(result)) invalid();
  return result;
}

function requestId(value: unknown): string {
  const result = string(value, 128);
  if (!REQUEST_ID.test(result)) invalid();
  return result;
}

function stringArray(value: unknown, maximum = 1024): string[] {
  if (!Array.isArray(value) || value.length > maximum) invalid();
  return value.map((item) => string(item, 2048));
}

function stringMap(value: unknown, maximum = 1024): Record<string, string> {
  const object = record(value);
  if (Object.keys(object).length > maximum) invalid();
  return Object.fromEntries(
    Object.entries(object).map(([key, member]) => [string(key, 256), string(member, 2048)]),
  );
}

function jsonValue(value: unknown, depth = 0, budget = { nodes: 0 }): JsonValue {
  budget.nodes += 1;
  if (budget.nodes > 100_000 || depth > 32) invalid();
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number") return finiteNumber(value);
  if (Array.isArray(value)) {
    if (value.length > 10_000) invalid();
    return value.map((member) => jsonValue(member, depth + 1, budget));
  }
  const object = record(value);
  if (Object.keys(object).length > 10_000) invalid();
  return Object.fromEntries(
    Object.entries(object).map(([key, member]) => [string(key, 256), jsonValue(member, depth + 1, budget)]),
  );
}

function limits(value: unknown): OperationLimits {
  const object = exact(value, ["timeoutMs", "maxAgeMs", "maxBytes", "maxRows", "maxSeries", "maxPoints"]);
  return {
    timeoutMs: integer(object.timeoutMs, 1, 300_000),
    maxAgeMs: integer(object.maxAgeMs, 0, 31_536_000_000),
    maxBytes: integer(object.maxBytes, 1, 1_073_741_824),
    maxRows: integer(object.maxRows, 0, 1_000_000),
    maxSeries: integer(object.maxSeries, 0, 100_000),
    maxPoints: integer(object.maxPoints, 0, 10_000_000),
  };
}

function adapterPackage(value: unknown): AdapterPackage {
  const object = exact(value, [
    "schemaVersion",
    "packageId",
    "name",
    "version",
    "protocolVersion",
    "publisher",
    "entrypoint",
    "domains",
    "capabilities",
    "providerCompatibility",
    "supportedContractVersions",
    "conformance",
  ]);
  if (object.schemaVersion !== "1.0.0" || object.protocolVersion !== "1.0") invalid();
  const publisher = exact(object.publisher, ["name"], ["keyId"]);
  string(publisher.name, 256);
  optionalString(publisher.keyId, 256);
  const entrypoint = record(object.entrypoint);
  if (entrypoint.kind === "BUILTIN") {
    const builtin = exact(entrypoint, ["kind", "registryKey"]);
    string(builtin.registryKey, 128);
  } else if (entrypoint.kind === "SIGNED_WORKER") {
    const worker = exact(entrypoint, [
      "kind",
      "protocol",
      "artifactPath",
      "artifactSha256",
      "signature",
      "signingKeyId",
    ]);
    if (worker.protocol !== WORKER_PROTOCOL) invalid();
    string(worker.artifactPath, 1024);
    hash(worker.artifactSha256);
    string(worker.signature, 4096);
    string(worker.signingKeyId, 256);
  } else invalid();
  string(object.packageId, 128);
  string(object.name, 128);
  string(object.version, 128);
  stringArray(object.domains, 16);
  stringArray(object.capabilities, 1024);
  if (!Array.isArray(object.providerCompatibility) || object.providerCompatibility.length > 1024) invalid();
  for (const item of object.providerCompatibility) {
    const compatibility = exact(item, ["provider", "versions"]);
    string(compatibility.provider, 128);
    string(compatibility.versions, 256);
  }
  stringArray(object.supportedContractVersions, 64);
  stringArray(object.conformance, 64);
  return value as AdapterPackage;
}

function operationSnapshot(value: unknown): OperationSnapshot {
  const object = exact(value, [
    "schemaVersion",
    "operationId",
    "revision",
    "capturedAt",
    "definition",
    "definitionSha256",
  ]);
  if (object.schemaVersion !== "1.0.0") invalid();
  string(object.operationId, 128);
  integer(object.revision, 1);
  date(object.capturedAt);
  hash(object.definitionSha256);
  const definition = exact(object.definition, [
    "domain",
    "sourceAlias",
    "adapterPackageId",
    "adapterOperation",
    "authority",
    "sanitizedProviderDefinition",
    "scopeMapping",
    "allowedDimensions",
    "requiredProviderScopes",
    "sensitivity",
    "limits",
    "normalization",
  ], ["expectedSourceLineage"]);
  enumeration(definition.domain, ["METRICS", "ALERTS", "LOGS", "TRACES", "RUNTIME", "CHANGES", "RUNBOOKS"]);
  string(definition.sourceAlias, 128);
  string(definition.adapterPackageId, 128);
  string(definition.adapterOperation, 128);
  enumeration(definition.authority, ["AUTHORITATIVE", "CORROBORATING"]);
  jsonValue(definition.sanitizedProviderDefinition);
  if (definition.expectedSourceLineage !== undefined) {
    const lineage = exact(definition.expectedSourceLineage, [
      "accessPath",
      "datasourceType",
      "sourceIdentitySha256",
    ]);
    enumeration(lineage.accessPath, ["DIRECT", "GRAFANA"]);
    enumeration(lineage.datasourceType, ["prometheus", "loki", "tempo", "postgres"]);
    hash(lineage.sourceIdentitySha256);
  }
  stringMap(definition.scopeMapping);
  stringArray(definition.allowedDimensions);
  stringArray(definition.requiredProviderScopes);
  enumeration(definition.sensitivity, ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"]);
  limits(definition.limits);
  const normalization = exact(definition.normalization, ["resultKind", "dimensionMappings"], ["targetUnit"]);
  enumeration(normalization.resultKind, ["SCALAR", "TIMESERIES", "TABLE", "EVENT"]);
  optionalString(normalization.targetUnit, 64);
  stringMap(normalization.dimensionMappings);
  return value as OperationSnapshot;
}

function compiledOperation(value: unknown): CompiledAdapterOperation {
  const object = exact(value, [
    "operationId",
    "operationDefinitionSha256",
    "adapterPackageId",
    "adapterOperation",
    "binding",
  ]);
  string(object.operationId, 128);
  hash(object.operationDefinitionSha256);
  string(object.adapterPackageId, 128);
  string(object.adapterOperation, 128);
  record(jsonValue(object.binding));
  return value as CompiledAdapterOperation;
}

function pagination(value: unknown): ProviderResult["pagination"] {
  const object = exact(value, ["complete", "pages"], ["truncatedReason"]);
  boolean(object.complete);
  integer(object.pages, 0, 10_000);
  if (object.truncatedReason !== undefined) {
    enumeration(object.truncatedReason, ["BYTE_LIMIT", "ROW_LIMIT", "SERIES_LIMIT", "POINT_LIMIT", "TIME_LIMIT"]);
  }
  return value as ProviderResult["pagination"];
}

function sanitizedError(value: unknown): ProviderResult["error"] {
  const object = exact(value, ["code", "category", "message", "retryable"], ["providerStatus"]);
  const code = string(object.code, 128);
  if (!ERROR_CODE.test(code)) invalid();
  if (typeof object.category !== "string" || !CATEGORIES.has(object.category)) invalid();
  string(object.message, 1024);
  boolean(object.retryable);
  if (object.providerStatus !== undefined) integer(object.providerStatus, 100, 599);
  return value as ProviderResult["error"];
}

function providerValue(value: unknown): ProviderValue {
  const kind = record(value).kind;
  if (kind === "SCALAR") {
    const object = exact(value, ["kind", "name", "value", "dimensions"], ["unit", "observedAt"]);
    string(object.name, 256);
    const scalar = object.value;
    if (!(scalar === null || typeof scalar === "string" || typeof scalar === "boolean" || typeof scalar === "number")) invalid();
    if (typeof scalar === "number") finiteNumber(scalar);
    stringMap(object.dimensions);
    optionalString(object.unit, 64);
    if (object.observedAt !== undefined) date(object.observedAt);
  } else if (kind === "TIMESERIES") {
    const object = exact(value, ["kind", "name", "dimensions", "points"], ["unit"]);
    string(object.name, 256);
    stringMap(object.dimensions);
    optionalString(object.unit, 64);
    if (!Array.isArray(object.points) || object.points.length > 100_000) invalid();
    for (const pointValue of object.points) {
      const point = exact(pointValue, ["at", "value"]);
      date(point.at);
      if (point.value !== null) finiteNumber(point.value);
    }
  } else if (kind === "TABLE") {
    const object = exact(value, ["kind", "name", "columns", "rows"]);
    string(object.name, 256);
    if (!Array.isArray(object.columns) || object.columns.length > 1024) invalid();
    for (const columnValue of object.columns) {
      const column = exact(columnValue, ["name", "type"]);
      string(column.name, 256);
      enumeration(column.type, ["STRING", "NUMBER", "BOOLEAN", "DATETIME", "NULL"]);
    }
    if (!Array.isArray(object.rows) || object.rows.length > 100_000) invalid();
    for (const row of object.rows) {
      if (!Array.isArray(row) || row.length !== object.columns.length) invalid();
      for (const cell of row) {
        if (!(cell === null || typeof cell === "string" || typeof cell === "boolean" || typeof cell === "number")) invalid();
        if (typeof cell === "number") finiteNumber(cell);
      }
    }
  } else if (kind === "EVENT") {
    const object = exact(value, ["kind", "name", "occurredAt", "summary", "attributes"]);
    string(object.name, 256);
    date(object.occurredAt);
    string(object.summary, 4096);
    const attributes = record(object.attributes);
    if (Object.keys(attributes).length > 10_000) invalid();
    for (const [key, member] of Object.entries(attributes)) {
      string(key, 256);
      if (!(member === null || typeof member === "string" || typeof member === "boolean" || typeof member === "number")) invalid();
      if (typeof member === "number") finiteNumber(member);
    }
  } else invalid();
  return value as ProviderValue;
}

function providerResult(value: unknown): ProviderResult {
  const object = exact(value, [
    "schemaVersion",
    "collectionState",
    "evaluatedAt",
    "nativeResultType",
    "nativeDimensions",
    "records",
    "pagination",
    "warnings",
  ], ["nativeUnit", "sanitizedReference", "sourceLineage", "providerScope", "error"]);
  string(object.schemaVersion, 32);
  enumeration(object.collectionState, ["COMPLETE", "EMPTY", "ERROR"]);
  date(object.evaluatedAt);
  string(object.nativeResultType, 128);
  optionalString(object.nativeUnit, 64);
  stringMap(object.nativeDimensions);
  if (!Array.isArray(object.records) || object.records.length > 100_000) invalid();
  object.records.forEach(providerValue);
  pagination(object.pagination);
  stringArray(object.warnings, 256);
  optionalString(object.sanitizedReference, 2048);
  if (object.sourceLineage !== undefined) {
    const lineage = exact(object.sourceLineage, [
      "accessPath",
      "datasourceType",
      "sourceIdentitySha256",
    ]);
    enumeration(lineage.accessPath, ["DIRECT", "GRAFANA"]);
    enumeration(lineage.datasourceType, ["prometheus", "loki", "tempo", "postgres"]);
    hash(lineage.sourceIdentitySha256);
  }
  if (object.providerScope !== undefined) {
    const scope = exact(object.providerScope, [], ["environment", "service", "subject", "tenantSha256", "mappings"]);
    optionalString(scope.environment, 128);
    optionalString(scope.service, 128);
    if (scope.subject !== undefined) {
      const subject = exact(scope.subject, ["kind", "ref"]);
      enumeration(subject.kind, ["HOST", "DEVICE", "FLEET", "BUSINESS_UNIT", "KPI_SET"]);
      const ref = string(subject.ref, 134);
      if (!/^pmsub_[A-Za-z0-9_-]{20,128}$/u.test(ref)) invalid();
    }
    if (scope.tenantSha256 !== undefined) hash(scope.tenantSha256);
    if (scope.mappings !== undefined) {
      const mappings = stringMap(scope.mappings);
      if (Object.keys(mappings).some((key) => !["environment", "service", "subject.ref", "tenantSha256"].includes(key))) {
        invalid();
      }
    }
  }
  if (object.error !== undefined) sanitizedError(object.error);
  if (object.collectionState === "EMPTY" && object.records.length !== 0) invalid();
  if (object.collectionState === "ERROR" && (object.records.length !== 0 || object.error === undefined)) invalid();
  return value as ProviderResult;
}

function doctorResult(value: unknown): AdapterDoctorResult {
  const object = exact(value, ["status", "checks"]);
  enumeration(object.status, ["READY", "WARN", "BLOCKED"]);
  if (!Array.isArray(object.checks) || object.checks.length > 64) invalid();
  for (const rawCheck of object.checks) {
    const check = exact(rawCheck, ["name", "status", "message"]);
    string(check.name, 256);
    enumeration(check.status, ["PASS", "WARN", "FAIL"]);
    string(check.message, 1024);
  }
  return value as AdapterDoctorResult;
}

export function assertWorkerRequest(value: unknown): asserts value is WorkerRequest {
  const base = record(value);
  if (base.kind === "doctor") {
    const object = exact(value, ["protocol", "kind", "requestId"]);
    if (object.protocol !== WORKER_PROTOCOL) invalid();
    requestId(object.requestId);
    return;
  }
  if (base.kind === "compile") {
    const object = exact(value, ["protocol", "kind", "requestId", "operation", "adapterPackage", "maxDefinitionBytes"]);
    if (object.protocol !== WORKER_PROTOCOL) invalid();
    requestId(object.requestId);
    operationSnapshot(object.operation);
    adapterPackage(object.adapterPackage);
    integer(object.maxDefinitionBytes, 1);
    return;
  }
  if (base.kind === "execute") {
    const object = exact(value, ["protocol", "kind", "requestId", "operation", "context"]);
    if (object.protocol !== WORKER_PROTOCOL) invalid();
    requestId(object.requestId);
    compiledOperation(object.operation);
    const context = exact(object.context, ["origin", "scope", "window", "deadlineAt", "limits"], ["expectedTenantSha256"]);
    enumeration(context.origin, ["LIVE", "REPLAY", "SIMULATED"]);
    const scope = exact(context.scope, ["environment"], ["service", "region", "cohort", "subject"]);
    string(scope.environment, 128);
    optionalString(scope.service, 128);
    optionalString(scope.region, 128);
    optionalString(scope.cohort, 128);
    if (scope.subject !== undefined) {
      const subject = exact(scope.subject, ["kind", "ref"]);
      enumeration(subject.kind, ["HOST", "DEVICE", "FLEET", "BUSINESS_UNIT", "KPI_SET"]);
      const subjectRef = string(subject.ref, 134);
      if (!/^pmsub_[A-Za-z0-9_-]{20,128}$/u.test(subjectRef)) invalid();
    }
    const window = exact(context.window, ["start", "end"]);
    date(window.start);
    date(window.end);
    date(context.deadlineAt);
    limits(context.limits);
    if (context.expectedTenantSha256 !== undefined) hash(context.expectedTenantSha256);
    return;
  }
  invalid();
}

export function assertWorkerResponse(value: unknown): asserts value is WorkerResponse {
  const base = record(value);
  if (base.kind === "doctor-result") {
    const object = exact(value, ["protocol", "kind", "requestId", "result"]);
    if (object.protocol !== WORKER_PROTOCOL) invalid();
    requestId(object.requestId);
    doctorResult(object.result);
    return;
  }
  if (base.kind === "compiled") {
    const object = exact(value, ["protocol", "kind", "requestId", "operation"]);
    if (object.protocol !== WORKER_PROTOCOL) invalid();
    requestId(object.requestId);
    compiledOperation(object.operation);
    return;
  }
  if (base.kind === "result") {
    const object = exact(value, ["protocol", "kind", "requestId", "result"]);
    if (object.protocol !== WORKER_PROTOCOL) invalid();
    requestId(object.requestId);
    providerResult(object.result);
    return;
  }
  if (base.kind === "error") {
    const object = exact(value, ["protocol", "kind", "requestId", "error"]);
    if (object.protocol !== WORKER_PROTOCOL) invalid();
    requestId(object.requestId);
    sanitizedError(object.error);
    return;
  }
  invalid();
}

function parsePayload(payload: Buffer): unknown {
  let source: string;
  try {
    source = utf8.decode(payload);
    return JSON.parse(source) as unknown;
  } catch {
    throw new WorkerProtocolError("INVALID_FRAME");
  }
}

export function parseWorkerRequestPayload(payload: Buffer): WorkerRequest {
  const value = parsePayload(payload);
  assertWorkerRequest(value);
  return value;
}

export function parseWorkerResponsePayload(payload: Buffer): WorkerResponse {
  const value = parsePayload(payload);
  assertWorkerResponse(value);
  return value;
}

export function encodeWorkerFrame(value: WorkerRequest | WorkerResponse, maximumBytes = DEFAULT_MAX_WORKER_FRAME_BYTES): Buffer {
  if (!Number.isSafeInteger(maximumBytes) || maximumBytes < 1 || maximumBytes > 0xffff_ffff) {
    throw new RangeError("Worker frame byte limit is invalid");
  }
  const payload = Buffer.from(JSON.stringify(value), "utf8");
  if (payload.byteLength > maximumBytes) throw new WorkerProtocolError("OVERSIZE");
  const frame = Buffer.allocUnsafe(WORKER_FRAME_HEADER_BYTES + payload.byteLength);
  frame.writeUInt32BE(payload.byteLength, 0);
  payload.copy(frame, WORKER_FRAME_HEADER_BYTES);
  return frame;
}

/** Incremental uint32-BE length-prefixed decoder with a strict per-frame allocation bound. */
export class WorkerFrameDecoder {
  readonly #maximumBytes: number;
  #buffer: Buffer<ArrayBufferLike> = Buffer.alloc(0);

  constructor(maximumBytes = DEFAULT_MAX_WORKER_FRAME_BYTES) {
    if (!Number.isSafeInteger(maximumBytes) || maximumBytes < 1 || maximumBytes > 0xffff_ffff) {
      throw new RangeError("Worker frame byte limit is invalid");
    }
    this.#maximumBytes = maximumBytes;
  }

  push(chunk: Buffer): Buffer[] {
    if (!Buffer.isBuffer(chunk)) throw new TypeError("Worker protocol chunks must be buffers");
    if (chunk.byteLength === 0) return [];
    this.#buffer = this.#buffer.byteLength === 0 ? chunk : Buffer.concat([this.#buffer, chunk]);
    const payloads: Buffer[] = [];
    while (this.#buffer.byteLength >= WORKER_FRAME_HEADER_BYTES) {
      const length = this.#buffer.readUInt32BE(0);
      if (length === 0) throw new WorkerProtocolError("INVALID_FRAME");
      if (length > this.#maximumBytes) throw new WorkerProtocolError("OVERSIZE");
      const frameBytes = WORKER_FRAME_HEADER_BYTES + length;
      if (this.#buffer.byteLength < frameBytes) break;
      payloads.push(this.#buffer.subarray(WORKER_FRAME_HEADER_BYTES, frameBytes));
      this.#buffer = this.#buffer.subarray(frameBytes);
    }
    if (this.#buffer.byteLength > this.#maximumBytes + WORKER_FRAME_HEADER_BYTES) {
      throw new WorkerProtocolError("OVERSIZE");
    }
    return payloads;
  }

  finish(): void {
    if (this.#buffer.byteLength !== 0) throw new WorkerProtocolError("INVALID_FRAME");
  }
}
