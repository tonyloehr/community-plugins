import { createHash, createPublicKey, randomUUID, verify, type KeyObject } from "node:crypto";
import { constants } from "node:fs";
import { open } from "node:fs/promises";
import { isAbsolute, posix } from "node:path";

import {
  canonicalJson,
  type AdapterPackage,
  type AdapterPackageId,
  type JsonObject,
  type Sha256,
} from "@codex-production-monitoring/contracts";

import { AdapterAdmissionError, AdapterContractError, AdapterExecutionError } from "./errors.ts";
import { assertWorkerResponse, WORKER_PROTOCOL } from "./protocol.ts";
import type {
  AdapterDescriptor,
  AdmittedWorkerArtifact,
  EvidenceAdapter,
  WorkerFactory,
  WorkerRequest,
  WorkerResponse,
  WorkerTransport,
} from "./types.ts";

const SHA256_PATTERN = /^[a-f0-9]{64}$/u;
const MAX_WORKER_ARTIFACT_BYTES = 64 * 1024 * 1024;
const MAX_WORKER_SOURCE_PART_BYTES = 140_000;
const MAX_WORKER_SOURCE_PARTS = 128;
const SOURCE_PART_MANIFEST_PATTERN = /(?:^|\n)const __PM_SOURCE_PARTS__=(\{[^\n]+\});(?:\n|$)/u;
const WORKER_SOURCE_PART_PATTERN = /^provider-worker\.mjs\.source\.part-(\d{3})$/u;

export interface AdmittedWorkerSourcePart {
  name: string;
  bytes: number;
  sha256: Sha256;
}

export interface AdmittedWorkerSourceManifest {
  schemaVersion: 1;
  sourceBytes: number;
  sourceSha256: Sha256;
  parts: AdmittedWorkerSourcePart[];
}

/**
 * Parse only the fixed generated-loader manifest. This runs on loader bytes
 * returned by the no-follow digest verifier, never on an unverified pathname.
 */
export function parseAdmittedWorkerSourceManifest(
  loaderBytes: Buffer,
): AdmittedWorkerSourceManifest | undefined {
  const source = loaderBytes.toString("utf8");
  const match = SOURCE_PART_MANIFEST_PATTERN.exec(source);
  if (match === null) return undefined;
  let value: unknown;
  try {
    value = JSON.parse(match[1]!);
  } catch {
    throw new AdapterAdmissionError("Verified worker source manifest is invalid");
  }
  if (
    value === null
    || typeof value !== "object"
    || (value as Partial<AdmittedWorkerSourceManifest>).schemaVersion !== 1
    || !Number.isSafeInteger((value as Partial<AdmittedWorkerSourceManifest>).sourceBytes)
    || (value as Partial<AdmittedWorkerSourceManifest>).sourceBytes! < 1
    || (value as Partial<AdmittedWorkerSourceManifest>).sourceBytes! > MAX_WORKER_ARTIFACT_BYTES
    || !SHA256_PATTERN.test((value as Partial<AdmittedWorkerSourceManifest>).sourceSha256 ?? "")
    || !Array.isArray((value as Partial<AdmittedWorkerSourceManifest>).parts)
    || (value as Partial<AdmittedWorkerSourceManifest>).parts!.length < 1
    || (value as Partial<AdmittedWorkerSourceManifest>).parts!.length > MAX_WORKER_SOURCE_PARTS
  ) {
    throw new AdapterAdmissionError("Verified worker source manifest is invalid");
  }
  const manifest = value as AdmittedWorkerSourceManifest;
  let totalBytes = 0;
  for (const [index, part] of manifest.parts.entries()) {
    const nameMatch = WORKER_SOURCE_PART_PATTERN.exec(part.name);
    if (
      nameMatch?.[1] !== String(index).padStart(3, "0")
      || !Number.isSafeInteger(part.bytes)
      || part.bytes < 1
      || part.bytes > MAX_WORKER_SOURCE_PART_BYTES
      || !SHA256_PATTERN.test(part.sha256)
    ) {
      throw new AdapterAdmissionError("Verified worker source manifest is invalid");
    }
    totalBytes += part.bytes;
  }
  if (totalBytes !== manifest.sourceBytes) {
    throw new AdapterAdmissionError("Verified worker source manifest is invalid");
  }
  return manifest;
}

export interface WorkerAdmissionPolicy {
  trustedSigningKeys: ReadonlyMap<string, KeyObject | string | Buffer>;
  allowedPackageIds: ReadonlySet<AdapterPackageId>;
  allowedArtifactHashes: ReadonlySet<Sha256>;
  revokedPackageIds?: ReadonlySet<AdapterPackageId>;
  revokedArtifactHashes?: ReadonlySet<Sha256>;
  revokedArtifactPaths?: ReadonlySet<string>;
  revokedSigningKeyIds?: ReadonlySet<string>;
}

export interface StaticWorkerRegistration {
  packageId: AdapterPackageId;
  /** Portable path value pinned into the signed package metadata. */
  packageArtifactPath: string;
  /** Absolute code-owned path that the host is permitted to execute. */
  artifactPath: string;
  artifactSha256: Sha256;
  factory: WorkerFactory;
}

/** The signed material excludes only the signature itself. */
export function adapterAdmissionPayload(adapterPackage: AdapterPackage): JsonObject {
  if (adapterPackage.entrypoint.kind !== "SIGNED_WORKER") {
    throw new AdapterAdmissionError("Adapter package is not a signed worker");
  }
  const entrypoint = { ...adapterPackage.entrypoint } as Omit<typeof adapterPackage.entrypoint, "signature"> & {
    signature?: string;
  };
  delete entrypoint.signature;
  return { ...adapterPackage, entrypoint } as unknown as JsonObject;
}

function decodeEd25519Signature(value: string): Buffer {
  if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(value) || value.length % 4 !== 0) {
    throw new AdapterAdmissionError("Adapter signature is not valid base64");
  }
  const signature = Buffer.from(value, "base64");
  if (signature.byteLength !== 64 || signature.toString("base64") !== value) {
    throw new AdapterAdmissionError("Adapter signature is not a valid Ed25519 signature");
  }
  return signature;
}

function ed25519PublicKey(value: KeyObject | string | Buffer): KeyObject {
  try {
    const key = typeof value === "string" || Buffer.isBuffer(value) ? createPublicKey(value) : value;
    if (key.type !== "public" || key.asymmetricKeyType !== "ed25519") {
      throw new AdapterAdmissionError("Adapter signing key is not an Ed25519 public key");
    }
    return key;
  } catch (error) {
    if (error instanceof AdapterAdmissionError) throw error;
    throw new AdapterAdmissionError("Adapter signing key is invalid");
  }
}

function isPortableArtifactPath(value: string): boolean {
  return (
    value.length > 0 &&
    value.length <= 1024 &&
    !isAbsolute(value) &&
    !value.includes("\\") &&
    !value.includes("\0") &&
    posix.normalize(value) === value &&
    !value.split("/").some((part) => part === "" || part === "." || part === "..")
  );
}

export function verifyWorkerAdmission(adapterPackage: AdapterPackage, policy: WorkerAdmissionPolicy): void {
  if (adapterPackage.entrypoint.kind !== "SIGNED_WORKER") {
    throw new AdapterAdmissionError("Only signed worker packages may use the worker host");
  }
  if (
    adapterPackage.schemaVersion !== "1.0.0" ||
    adapterPackage.protocolVersion !== "1.0" ||
    adapterPackage.entrypoint.protocol !== WORKER_PROTOCOL
  ) {
    throw new AdapterAdmissionError("Unsupported adapter package or worker protocol version");
  }
  if (!isPortableArtifactPath(adapterPackage.entrypoint.artifactPath)) {
    throw new AdapterAdmissionError("Signed worker artifact path is not a portable relative path");
  }
  if (!SHA256_PATTERN.test(adapterPackage.entrypoint.artifactSha256)) {
    throw new AdapterAdmissionError("Signed worker artifact digest is invalid");
  }
  if (policy.revokedPackageIds?.has(adapterPackage.packageId) === true) {
    throw new AdapterAdmissionError("Adapter package is revoked");
  }
  if (policy.revokedArtifactHashes?.has(adapterPackage.entrypoint.artifactSha256) === true) {
    throw new AdapterAdmissionError("Adapter artifact is revoked");
  }
  if (policy.revokedArtifactPaths?.has(adapterPackage.entrypoint.artifactPath) === true) {
    throw new AdapterAdmissionError("Adapter artifact path is revoked");
  }
  if (policy.revokedSigningKeyIds?.has(adapterPackage.entrypoint.signingKeyId) === true) {
    throw new AdapterAdmissionError("Adapter signing key is revoked");
  }
  if (!policy.allowedPackageIds.has(adapterPackage.packageId)) {
    throw new AdapterAdmissionError("Adapter package is not allowlisted");
  }
  if (!policy.allowedArtifactHashes.has(adapterPackage.entrypoint.artifactSha256)) {
    throw new AdapterAdmissionError("Adapter artifact hash is not allowlisted");
  }
  const configuredKey = policy.trustedSigningKeys.get(adapterPackage.entrypoint.signingKeyId);
  if (configuredKey === undefined) throw new AdapterAdmissionError("Adapter signing key is not trusted");
  const signature = decodeEd25519Signature(adapterPackage.entrypoint.signature);
  let valid = false;
  try {
    valid = verify(
      null,
      Buffer.from(canonicalJson(adapterAdmissionPayload(adapterPackage)), "utf8"),
      ed25519PublicKey(configuredKey),
      signature,
    );
  } catch (error) {
    if (error instanceof AdapterAdmissionError) throw error;
    throw new AdapterAdmissionError("Adapter signature verification failed");
  }
  if (!valid) throw new AdapterAdmissionError("Adapter signature verification failed");
}

/**
 * Opens without following the final path component and returns only bytes read
 * from that opened regular-file inode. Callers that execute these bytes must not
 * reopen the source pathname.
 */
export async function readVerifiedWorkerArtifactBytes(
  artifact: Readonly<AdmittedWorkerArtifact>,
): Promise<Buffer> {
  if (!isAbsolute(artifact.artifactPath)) {
    throw new AdapterAdmissionError("Code-owned worker artifact path must be absolute");
  }
  if (!SHA256_PATTERN.test(artifact.artifactSha256)) {
    throw new AdapterAdmissionError("Code-owned worker artifact digest is invalid");
  }
  const noFollow = constants.O_NOFOLLOW;
  if (!Number.isSafeInteger(noFollow) || noFollow === 0) {
    throw new AdapterAdmissionError("Worker artifact no-follow opens are unavailable on this platform");
  }
  let handle: Awaited<ReturnType<typeof open>>;
  try {
    handle = await open(artifact.artifactPath, constants.O_RDONLY | noFollow);
  } catch {
    throw new AdapterAdmissionError("Code-owned worker artifact is unavailable");
  }
  try {
    const before = await handle.stat();
    if (!before.isFile()) {
      throw new AdapterAdmissionError("Code-owned worker artifact path is not a regular file");
    }
    if (!Number.isSafeInteger(before.size) || before.size < 1 || before.size > MAX_WORKER_ARTIFACT_BYTES) {
      throw new AdapterAdmissionError("Code-owned worker artifact size is outside the admitted bound");
    }
    const contents = Buffer.allocUnsafe(before.size);
    let offset = 0;
    while (offset < contents.byteLength) {
      const { bytesRead } = await handle.read(contents, offset, contents.byteLength - offset, offset);
      if (bytesRead === 0) {
        throw new AdapterAdmissionError("Code-owned worker artifact changed during digest verification");
      }
      offset += bytesRead;
    }
    const trailingByte = Buffer.allocUnsafe(1);
    const [{ bytesRead: trailingBytes }, after] = await Promise.all([
      handle.read(trailingByte, 0, 1, contents.byteLength),
      handle.stat(),
    ]);
    if (trailingBytes !== 0 || after.size !== before.size || after.dev !== before.dev || after.ino !== before.ino) {
      throw new AdapterAdmissionError("Code-owned worker artifact changed during digest verification");
    }
    const actual = createHash("sha256").update(contents).digest("hex");
    if (actual !== artifact.artifactSha256) {
      throw new AdapterAdmissionError("Code-owned worker artifact digest does not match the pinned digest");
    }
    return contents;
  } catch (error) {
    if (error instanceof AdapterAdmissionError) throw error;
    throw new AdapterAdmissionError("Code-owned worker artifact is unavailable");
  } finally {
    await handle.close().catch(() => undefined);
  }
}

/** Rechecks that the opened regular-file bytes still have the pinned digest. */
export async function verifyWorkerArtifact(artifact: Readonly<AdmittedWorkerArtifact>): Promise<void> {
  await readVerifiedWorkerArtifactBytes(artifact);
}

/** Immutable mapping from signed metadata to an absolute code-owned launcher. */
export class StaticWorkerRegistry {
  readonly #registrations: ReadonlyMap<string, StaticWorkerRegistration>;
  readonly #policy: WorkerAdmissionPolicy;

  constructor(registrations: readonly StaticWorkerRegistration[], policy: WorkerAdmissionPolicy) {
    const indexed = new Map<string, StaticWorkerRegistration>();
    for (const registration of registrations) {
      if (!isPortableArtifactPath(registration.packageArtifactPath)) {
        throw new AdapterAdmissionError("Registered package artifact path is not portable");
      }
      if (!isAbsolute(registration.artifactPath)) {
        throw new AdapterAdmissionError("Code-owned worker artifact path must be absolute");
      }
      if (!SHA256_PATTERN.test(registration.artifactSha256)) {
        throw new AdapterAdmissionError("Registered worker artifact digest is invalid");
      }
      const key = `${registration.packageId}:${registration.packageArtifactPath}:${registration.artifactSha256}`;
      if (indexed.has(key)) throw new AdapterAdmissionError("Duplicate static worker registration");
      indexed.set(key, Object.freeze({ ...registration }));
    }
    this.#registrations = indexed;
    this.#policy = policy;
  }

  async create(adapterPackage: AdapterPackage): Promise<WorkerTransport> {
    verifyWorkerAdmission(adapterPackage, this.#policy);
    if (adapterPackage.entrypoint.kind !== "SIGNED_WORKER") {
      throw new AdapterAdmissionError("Adapter package is not a signed worker");
    }
    const key = `${adapterPackage.packageId}:${adapterPackage.entrypoint.artifactPath}:${adapterPackage.entrypoint.artifactSha256}`;
    const registration = this.#registrations.get(key);
    if (registration === undefined) {
      throw new AdapterAdmissionError("No code-owned launcher exists for this signed worker path and digest");
    }
    const artifact: AdmittedWorkerArtifact = {
      artifactPath: registration.artifactPath,
      artifactSha256: registration.artifactSha256,
    };
    await verifyWorkerArtifact(artifact);
    return registration.factory.create(Object.freeze(artifact));
  }
}

function expectResponse<T extends WorkerResponse["kind"]>(
  response: WorkerResponse,
  kind: T,
  requestId: string,
): Extract<WorkerResponse, { kind: T }> {
  assertWorkerResponse(response);
  if (response.requestId !== requestId) throw new AdapterContractError("Worker response request ID mismatch");
  if (response.kind === "error") throw new AdapterExecutionError(response.error);
  if (response.kind !== kind) throw new AdapterContractError(`Unexpected worker response: ${response.kind}`);
  return response as Extract<WorkerResponse, { kind: T }>;
}

/** A protocol adapter around an admitted transport; this makes no OS-sandbox claim. */
export function createWorkerBackedAdapter(adapterPackage: AdapterPackage, transport: WorkerTransport): EvidenceAdapter {
  const descriptor: AdapterDescriptor = {
    packageId: adapterPackage.packageId,
    name: adapterPackage.name,
    version: adapterPackage.version,
    provider: adapterPackage.providerCompatibility[0]?.provider ?? "unknown",
    domains: adapterPackage.domains,
    operations: adapterPackage.capabilities,
    resultSchemaVersions: adapterPackage.supportedContractVersions,
  };
  return {
    descriptor,
    async doctor(context) {
      const requestId = randomUUID();
      const message: WorkerRequest = {
        protocol: WORKER_PROTOCOL,
        kind: "doctor",
        requestId,
      };
      return expectResponse(await transport.request(message, context.signal), "doctor-result", requestId).result;
    },
    async compile(operation, context) {
      const requestId = randomUUID();
      const message: WorkerRequest = {
        protocol: WORKER_PROTOCOL,
        kind: "compile",
        requestId,
        operation: { ...operation },
        adapterPackage: context.adapterPackage,
        maxDefinitionBytes: context.maxDefinitionBytes,
      };
      return expectResponse(
        await transport.request(message, context.signal ?? new AbortController().signal),
        "compiled",
        requestId,
      )
        .operation;
    },
    async execute(context, operation) {
      const requestId = randomUUID();
      const workerContext = {
        origin: context.origin,
        scope: { ...context.scope },
        window: { ...context.window },
        deadlineAt: new Date(context.clock.now().getTime() + context.budget.limits.timeoutMs).toISOString(),
        limits: { ...context.budget.limits },
        ...(context.expectedTenantSha256 === undefined
          ? {}
          : { expectedTenantSha256: context.expectedTenantSha256 }),
      };
      const message: WorkerRequest = {
        protocol: WORKER_PROTOCOL,
        kind: "execute",
        requestId,
        operation,
        context: workerContext,
      };
      return expectResponse(await transport.request(message, context.signal), "result", requestId).result;
    },
  };
}
