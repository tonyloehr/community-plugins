import type { RedactionRecord } from "@codex-production-monitoring/contracts";

import type { ProviderResult } from "./types.ts";

export interface RedactionPolicy {
  rejectKeys: readonly string[];
  rejectValuePatterns: readonly RegExp[];
  maskKeys: readonly string[];
}

export const defaultRedactionPolicy: RedactionPolicy = {
  rejectKeys: ["authorization", "cookie", "password", "token", "api_key", "apikey", "secret"],
  rejectValuePatterns: [/\bBearer\s+[A-Za-z0-9._~+/-]+=*\b/iu, /\bsk-[A-Za-z0-9_-]{8,}\b/u],
  maskKeys: ["email", "user", "username"],
};

export interface RedactionOutcome {
  result: ProviderResult;
  records: RedactionRecord[];
  rejected: boolean;
  untrustedInstructionsDetected: boolean;
}

const INSTRUCTION_PATTERN = /\b(ignore|disregard|override)\b.{0,80}\b(instruction|prompt|system|previous)\b/iu;

function matches(pattern: RegExp, value: string): boolean {
  const stableFlags = pattern.flags.replaceAll("g", "").replaceAll("y", "");
  return new RegExp(pattern.source, stableFlags).test(value);
}

export function redactProviderResult(
  result: ProviderResult,
  policy: RedactionPolicy = defaultRedactionPolicy,
): RedactionOutcome {
  const records: RedactionRecord[] = [];
  let rejected = false;
  let untrustedInstructionsDetected = false;
  const rejectKeys = new Set(policy.rejectKeys.map((key) => key.toLowerCase()));
  const maskKeys = new Set(policy.maskKeys.map((key) => key.toLowerCase()));

  const visit = (value: unknown, path: string, key?: string): unknown => {
    if (key !== undefined && rejectKeys.has(key.toLowerCase())) {
      rejected = true;
      records.push({ ruleId: "secret-key", path, action: "REMOVED" });
      return "[REDACTED]";
    }
    if (typeof value === "string") {
      if (INSTRUCTION_PATTERN.test(value)) untrustedInstructionsDetected = true;
      if (policy.rejectValuePatterns.some((pattern) => matches(pattern, value))) {
        rejected = true;
        records.push({ ruleId: "secret-value", path, action: "REMOVED" });
        return "[REDACTED]";
      }
      if (key !== undefined && maskKeys.has(key.toLowerCase())) {
        records.push({ ruleId: "personal-field", path, action: "MASKED" });
        return "[MASKED]";
      }
      return value;
    }
    if (Array.isArray(value)) return value.map((item, index) => visit(item, `${path}/${index}`));
    if (value !== null && typeof value === "object") {
      return Object.fromEntries(
        Object.entries(value).map(([member, memberValue]) => [
          member,
          visit(memberValue, `${path}/${member.replaceAll("~", "~0").replaceAll("/", "~1")}`, member),
        ]),
      );
    }
    return value;
  };

  return {
    result: visit(result, "") as ProviderResult,
    records,
    rejected,
    untrustedInstructionsDetected,
  };
}
