import type {
  AdapterPackage,
  AdapterPackageId,
  EvidenceDomain,
  EvidenceOrigin,
  EvidenceSourceLineage,
  JsonObject,
  JsonPrimitive,
  OperationId,
  OperationLimits,
  OperationSnapshot,
  Pagination,
  SanitizedError,
  Scope,
  Sha256,
  SubjectKind,
  SubjectRef,
  TimeWindow,
} from "@codex-production-monitoring/contracts";

export interface Clock {
  now(): Date;
}

export const systemClock: Clock = { now: () => new Date() };

export interface AdapterDescriptor {
  packageId: AdapterPackageId;
  name: string;
  version: string;
  provider: string;
  domains: readonly EvidenceDomain[];
  operations: readonly string[];
  resultSchemaVersions: readonly string[];
}

export interface AdapterDoctorContext {
  signal: AbortSignal;
  clock: Clock;
}

export interface AdapterDoctorResult {
  status: "READY" | "WARN" | "BLOCKED";
  checks: Array<{ name: string; status: "PASS" | "WARN" | "FAIL"; message: string }>;
}

export interface AdapterCompileContext {
  adapterPackage: AdapterPackage;
  maxDefinitionBytes: number;
  /** Host-owned cancellation/deadline signal. Worker-backed adapters must forward it. */
  signal?: AbortSignal;
}

export interface CompiledAdapterOperation<Binding extends JsonObject = JsonObject> {
  operationId: OperationId;
  operationDefinitionSha256: Sha256;
  adapterPackageId: AdapterPackageId;
  adapterOperation: string;
  binding: Binding;
}

export interface ProviderScalar {
  kind: "SCALAR";
  name: string;
  value: JsonPrimitive;
  unit?: string;
  dimensions: Record<string, string>;
  observedAt?: string;
}

export interface ProviderSeries {
  kind: "TIMESERIES";
  name: string;
  unit?: string;
  dimensions: Record<string, string>;
  points: Array<{ at: string; value: number | null }>;
}

export interface ProviderTable {
  kind: "TABLE";
  name: string;
  columns: Array<{ name: string; type: "STRING" | "NUMBER" | "BOOLEAN" | "DATETIME" | "NULL" }>;
  rows: JsonPrimitive[][];
}

export interface ProviderEvent {
  kind: "EVENT";
  name: string;
  occurredAt: string;
  summary: string;
  attributes: Record<string, JsonPrimitive>;
}

export type ProviderValue = ProviderScalar | ProviderSeries | ProviderTable | ProviderEvent;

export interface ProviderScopeClaim {
  environment?: string;
  service?: string;
  subject?: {
    kind: SubjectKind;
    ref: SubjectRef;
  };
  tenantSha256?: Sha256;
  /** Provider-native fields/filters that the adapter actually verified for each claim. */
  mappings?: Readonly<Record<string, string>>;
}

/** Provider-owned output. It deliberately contains no trusted envelope fields. */
export interface ProviderResult {
  schemaVersion: string;
  collectionState: "COMPLETE" | "EMPTY" | "ERROR";
  evaluatedAt: string;
  nativeResultType: string;
  nativeUnit?: string;
  nativeDimensions: Record<string, string>;
  records: ProviderValue[];
  pagination: Pagination;
  warnings: string[];
  sanitizedReference?: string;
  sourceLineage?: EvidenceSourceLineage;
  providerScope?: ProviderScopeClaim;
  error?: SanitizedError;
}

export interface BudgetSnapshot {
  bytes: number;
  rows: number;
  series: number;
  points: number;
}

export interface BudgetController {
  readonly limits: Readonly<OperationLimits>;
  consumeBytes(count: number): void;
  consumeRows(count: number): void;
  consumeSeries(count: number): void;
  consumePoints(count: number): void;
  checkpoint(): BudgetSnapshot;
  throwIfAborted(): void;
}

export interface AdapterExecutionContext {
  origin: EvidenceOrigin;
  scope: Readonly<Scope>;
  window: Readonly<TimeWindow>;
  expectedTenantSha256?: Sha256;
  clock: Clock;
  budget: BudgetController;
  signal: AbortSignal;
}

export interface EvidenceAdapter<Binding extends JsonObject = JsonObject> {
  readonly descriptor: AdapterDescriptor;
  doctor(context: AdapterDoctorContext): Promise<AdapterDoctorResult>;
  compile(
    operation: Readonly<OperationSnapshot>,
    context: AdapterCompileContext,
  ): Promise<CompiledAdapterOperation<Binding>>;
  execute(
    context: AdapterExecutionContext,
    operation: Readonly<CompiledAdapterOperation<Binding>>,
  ): Promise<ProviderResult>;
}

export interface WorkerCompileRequest {
  protocol: "PM_ADAPTER_STDIO_V1";
  kind: "compile";
  requestId: string;
  operation: OperationSnapshot;
  adapterPackage: AdapterPackage;
  maxDefinitionBytes: number;
}

export interface WorkerDoctorRequest {
  protocol: "PM_ADAPTER_STDIO_V1";
  kind: "doctor";
  requestId: string;
}

export interface WorkerExecuteRequest {
  protocol: "PM_ADAPTER_STDIO_V1";
  kind: "execute";
  requestId: string;
  operation: CompiledAdapterOperation;
  context: {
    origin: EvidenceOrigin;
    scope: Scope;
    window: TimeWindow;
    expectedTenantSha256?: Sha256;
    deadlineAt: string;
    limits: OperationLimits;
  };
}

export type WorkerRequest = WorkerDoctorRequest | WorkerCompileRequest | WorkerExecuteRequest;

export type WorkerResponse =
  | {
      protocol: "PM_ADAPTER_STDIO_V1";
      kind: "doctor-result";
      requestId: string;
      result: AdapterDoctorResult;
    }
  | {
      protocol: "PM_ADAPTER_STDIO_V1";
      kind: "compiled";
      requestId: string;
      operation: CompiledAdapterOperation;
    }
  | { protocol: "PM_ADAPTER_STDIO_V1"; kind: "result"; requestId: string; result: ProviderResult }
  | { protocol: "PM_ADAPTER_STDIO_V1"; kind: "error"; requestId: string; error: SanitizedError };

export interface AdmittedWorkerArtifact {
  /** Absolute, code-owned path. It never comes from request or manifest input. */
  artifactPath: string;
  artifactSha256: Sha256;
}

export interface WorkerTransport {
  request(message: WorkerRequest, signal: AbortSignal): Promise<WorkerResponse>;
  close(): Promise<void>;
}

export interface WorkerFactory {
  create(artifact: Readonly<AdmittedWorkerArtifact>): Promise<WorkerTransport>;
}
