import type { SanitizedError } from "@codex-production-monitoring/contracts";

export class AdapterExecutionError extends Error {
  readonly sanitized: SanitizedError;

  constructor(sanitized: SanitizedError) {
    super(sanitized.message);
    this.name = "AdapterExecutionError";
    this.sanitized = sanitized;
  }
}

export class AdapterContractError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AdapterContractError";
  }
}

export class BudgetExceededError extends Error {
  readonly dimension: "bytes" | "rows" | "series" | "points";

  constructor(dimension: "bytes" | "rows" | "series" | "points") {
    super(`Evidence ${dimension} budget exceeded`);
    this.name = "BudgetExceededError";
    this.dimension = dimension;
  }
}

export class AdapterAdmissionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AdapterAdmissionError";
  }
}

export type WorkerProtocolFailure = "INVALID_FRAME" | "INVALID_MESSAGE" | "OVERSIZE";

/** Internal protocol diagnostics. Hosts must translate this to a fixed sanitized error. */
export class WorkerProtocolError extends Error {
  readonly failure: WorkerProtocolFailure;

  constructor(failure: WorkerProtocolFailure) {
    super(`Adapter worker protocol failure: ${failure}`);
    this.name = "WorkerProtocolError";
    this.failure = failure;
  }
}
