# `@codex-production-monitoring/adapter-sdk`

The provider-neutral adapter SDK for Production Monitoring. It defines bounded
adapter execution, redaction, the `PM_ADAPTER_STDIO_V1` protocol, and the host
checks required before a signed worker can run.

```js
import {
  WORKER_PROTOCOL,
  assertWorkerRequest,
} from "@codex-production-monitoring/adapter-sdk";

assertWorkerRequest({
  protocol: WORKER_PROTOCOL,
  kind: "doctor",
  requestId: "example-doctor",
});
```

`verifyWorkerAdmission` validates an Ed25519 signature plus administrator-owned
package, key, and artifact allowlists. A host must still execute only a
code-owned launcher and call `verifyWorkerArtifact` immediately before use.

Licensed under Apache-2.0.
