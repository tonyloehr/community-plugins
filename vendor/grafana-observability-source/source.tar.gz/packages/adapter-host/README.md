# `@codex-production-monitoring/adapter-host`

The code-owned host for Production Monitoring adapters. It verifies pinned
worker artifacts, launches them without a shell or inherited environment,
speaks the bounded `PM_ADAPTER_STDIO_V1` protocol, and normalizes provider
results into integrity-protected evidence.

This child-process boundary is not an OS sandbox: the library does not deny
filesystem access, enforce an egress allowlist, prevent further process
creation, or impose CPU/memory quotas. The bundled pre-1.0 production runtime
therefore admits only its exact release-code-owned first-party provider worker
and fixture package IDs. Third-party packages may use the SDK and conformance
host for authoring tests, but require a separately implemented and verified
deployment containment boundary before production activation.

Use `StaticWorkerRegistry` from the adapter SDK to authenticate the signed
package and exact artifact digest, `createStdioWorkerFactory` to launch the
admitted regular file, and `createWorkerBackedAdapter` to expose the portable
adapter contract. The reusable conformance package must still pass through that
worker before certification.

The host never turns schema validity into trust: signing keys, package IDs,
artifact hashes, paths, revocations, operations, scopes, and limits remain
administrator-owned inputs.

Licensed under Apache-2.0.
