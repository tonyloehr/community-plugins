import { randomUUID } from "node:crypto";

import {
  canonicalJson,
  computeIntegrity,
  type ContradictionId,
  type ContradictionRecord,
  type EvidenceEnvelope,
  type JsonPrimitive,
} from "@codex-production-monitoring/contracts";

import type { Clock } from "@codex-production-monitoring/adapter-sdk";

import type { IdFactory } from "./types.ts";

function sameScope(left: EvidenceEnvelope, right: EvidenceEnvelope): boolean {
  return canonicalJson(left.scope) === canonicalJson(right.scope);
}

interface ScalarClaim {
  index: number;
  value: JsonPrimitive;
}

function scalarClaims(envelope: EvidenceEnvelope): Map<string, ScalarClaim> {
  const claims = new Map<string, ScalarClaim>();
  for (const [index, value] of envelope.values.entries()) {
    if (value.kind === "SCALAR") {
      claims.set(`${value.name}:${canonicalJson(value.dimensions)}`, { index, value: value.value });
    }
  }
  return claims;
}

export function detectContradictions(
  envelopes: readonly EvidenceEnvelope[],
  runId: EvidenceEnvelope["runId"],
  clock: Clock,
  ids: Pick<IdFactory, "contradictionId"> = {
    contradictionId: () => `pmct_${randomUUID()}` as ContradictionId,
  },
): ContradictionRecord[] {
  const records: ContradictionRecord[] = [];
  for (let leftIndex = 0; leftIndex < envelopes.length; leftIndex += 1) {
    const left = envelopes[leftIndex]!;
    if (left.runId !== runId || left.collectionState !== "COMPLETE") continue;
    const leftClaims = scalarClaims(left);
    for (let rightIndex = leftIndex + 1; rightIndex < envelopes.length; rightIndex += 1) {
      const right = envelopes[rightIndex]!;
      if (
        right.runId !== runId ||
        right.collectionState !== "COMPLETE" ||
        canonicalJson(right.window) !== canonicalJson(left.window) ||
        !sameScope(left, right)
      ) continue;
      const rightClaims = scalarClaims(right);
      for (const [claimKey, leftClaim] of leftClaims) {
        if (!rightClaims.has(claimKey)) continue;
        const rightClaim = rightClaims.get(claimKey)!;
        if (canonicalJson(leftClaim.value) === canonicalJson(rightClaim.value)) continue;
        const draft: Omit<ContradictionRecord, "integrity"> = {
          schemaVersion: "1.0.0",
          contradictionId: ids.contradictionId(),
          runId,
          consistencyState: "CONTRADICTORY",
          kind: "VALUE",
          summary: "Normalized scalar values disagree across evidence sources",
          claimRefs: [
            {
              evidenceId: left.evidenceId,
              jsonPointer: `/values/${leftClaim.index}/value`,
              claim: canonicalJson(leftClaim.value),
            },
            {
              evidenceId: right.evidenceId,
              jsonPointer: `/values/${rightClaim.index}/value`,
              claim: canonicalJson(rightClaim.value),
            },
          ],
          resolutionState: "UNRESOLVED",
          assessedAt: clock.now().toISOString(),
        };
        records.push({ ...draft, integrity: computeIntegrity(draft) });
      }
    }
  }
  return records;
}
