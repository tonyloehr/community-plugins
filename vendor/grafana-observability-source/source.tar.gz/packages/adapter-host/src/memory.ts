import type { EvidenceEnvelope } from "@codex-production-monitoring/contracts";

import type { AuditEvent, AuditSink, EvidenceStore } from "./types.ts";

export class MemoryAuditSink implements AuditSink {
  readonly events: AuditEvent[] = [];

  async append(event: Readonly<AuditEvent>): Promise<void> {
    this.events.push(structuredClone(event));
  }
}

export class MemoryEvidenceStore implements EvidenceStore {
  readonly evidence: EvidenceEnvelope[] = [];

  async put(envelope: Readonly<EvidenceEnvelope>): Promise<void> {
    this.evidence.push(structuredClone(envelope));
  }
}
