import type {
  AdapterPackage,
  ContradictionId,
  EvidenceEnvelope,
  EvidenceId,
  EvidenceOrigin,
  OperationId,
  OperationLimits,
  OperationSnapshot,
  RunId,
  Scope,
  Sha256,
  TimeWindow,
} from "@codex-production-monitoring/contracts";
import type { EvidenceAdapter, RedactionPolicy } from "@codex-production-monitoring/adapter-sdk";

export interface AuthorizedRunContext {
  runId: RunId;
  trustBundleSha256: Sha256;
  origin: EvidenceOrigin;
  scope: Scope;
  window: TimeWindow;
  allowedOperationHashes: Readonly<Record<string, Sha256>>;
  /** Policy-compiled limits sealed into the authorized run, keyed by operation ID. */
  authorizedOperationLimits?: Readonly<Record<string, Readonly<OperationLimits>>>;
  expectedTenantSha256?: Sha256;
}

export interface AdapterRegistration {
  adapterPackage: AdapterPackage;
  adapter: EvidenceAdapter;
}

export interface AuditEvent {
  schemaVersion: "1.0.0";
  event: "COLLECTION_STARTED" | "COLLECTION_COMPLETED" | "COLLECTION_FAILED";
  at: string;
  runId: RunId;
  operationId: OperationId;
  adapterPackageId: string;
  evidenceId?: EvidenceId;
  outcome?: "COMPLETE" | "EMPTY" | "ERROR";
}

export interface AuditSink {
  append(event: Readonly<AuditEvent>): Promise<void>;
}

export interface EvidenceStore {
  put(envelope: Readonly<EvidenceEnvelope>): Promise<void>;
}

export interface IdFactory {
  evidenceId(): EvidenceId;
  contradictionId(): ContradictionId;
}

export interface AdapterHostPolicy {
  auditRequired: boolean;
  maxDefinitionBytes: number;
  maxClockSkewMs: number;
  redactionPolicy?: RedactionPolicy;
}

export interface CollectEvidenceRequest {
  run: AuthorizedRunContext;
  operation: OperationSnapshot;
  effectiveLimits: Readonly<OperationLimits>;
  adapterPackage: AdapterPackage;
  signal?: AbortSignal;
}

export interface AdapterRegistry {
  get(packageId: string): AdapterRegistration;
}
