import { randomUUID } from "node:crypto";

import {
  canonicalJson,
  computeIntegrity,
  computeOperationDefinitionHash,
  type EvidenceEnvelope,
  type EvidenceId,
  type FreshnessState,
  type OperationLimits,
  type OperationSnapshot,
  type Pagination,
  type SanitizedError,
} from "@codex-production-monitoring/contracts";
import {
  AdapterContractError,
  AdapterExecutionError,
  BudgetExceededError,
  createBudgetController,
  defaultRedactionPolicy,
  redactProviderResult,
  systemClock,
  type Clock,
  type ProviderResult,
} from "@codex-production-monitoring/adapter-sdk";

import { normalizeProviderResult } from "./normalization.ts";
import type {
  AdapterHostPolicy,
  AdapterRegistry,
  AuditEvent,
  AuditSink,
  CollectEvidenceRequest,
  EvidenceStore,
  IdFactory,
} from "./types.ts";

const PROVIDER_RESULT_SCHEMA_VERSION = "1.0.0";
const OPERATION_LIMIT_KEYS = [
  "timeoutMs",
  "maxAgeMs",
  "maxBytes",
  "maxRows",
  "maxSeries",
  "maxPoints",
] as const satisfies readonly (keyof OperationLimits)[];
const ZERO_ALLOWED_LIMIT_KEYS = new Set<keyof OperationLimits>([
  "maxAgeMs",
  "maxRows",
  "maxSeries",
  "maxPoints",
]);

class DeadlineExceededError extends Error {
  constructor() {
    super("Evidence collection deadline exceeded");
    this.name = "DeadlineExceededError";
  }
}

function defaultIds(): IdFactory {
  return {
    evidenceId: () => `pmev_${randomUUID()}` as EvidenceId,
    contradictionId: () => `pmct_${randomUUID()}` as never,
  };
}

function errorFromUnknown(error: unknown, signal: AbortSignal): SanitizedError {
  if (error instanceof AdapterExecutionError) return error.sanitized;
  if (error instanceof BudgetExceededError) {
    return {
      code: `BUDGET_${error.dimension.toUpperCase()}`,
      category: "POLICY",
      message: `Evidence ${error.dimension} limit exceeded`,
      retryable: false,
    };
  }
  if (error instanceof DeadlineExceededError || (signal.aborted && signal.reason instanceof DeadlineExceededError)) {
    return {
      code: "DEADLINE_EXCEEDED",
      category: "TIMEOUT",
      message: "Evidence collection deadline exceeded",
      retryable: true,
    };
  }
  if (signal.aborted) {
    return { code: "CANCELLED", category: "POLICY", message: "Evidence collection cancelled", retryable: false };
  }
  if (error instanceof AdapterContractError || error instanceof TypeError) {
    return {
      code: "INVALID_PROVIDER_RESPONSE",
      category: "INVALID_RESPONSE",
      message: "Provider returned an invalid response",
      retryable: false,
    };
  }
  return { code: "ADAPTER_FAILURE", category: "INTERNAL", message: "Adapter execution failed", retryable: false };
}

function assertProviderResult(result: ProviderResult): void {
  if (result.schemaVersion !== PROVIDER_RESULT_SCHEMA_VERSION) {
    throw new AdapterContractError(`Unsupported provider result schema: ${result.schemaVersion}`);
  }
  if (!(["COMPLETE", "EMPTY", "ERROR"] as const).includes(result.collectionState)) {
    throw new AdapterContractError("Invalid provider collection state");
  }
  if (!Array.isArray(result.records) || !Array.isArray(result.warnings)) {
    throw new AdapterContractError("Invalid provider records or warnings");
  }
  if (result.collectionState === "EMPTY" && result.records.length !== 0) {
    throw new AdapterContractError("EMPTY provider result cannot contain records");
  }
  if (result.collectionState === "ERROR" && result.records.length !== 0) {
    throw new AdapterContractError("ERROR provider result cannot contain records");
  }
  if (result.collectionState === "ERROR" && result.error === undefined) {
    throw new AdapterContractError("ERROR provider result requires a sanitized error");
  }
}

function assertProviderScope(result: ProviderResult, request: CollectEvidenceRequest): void {
  const claim = result.providerScope;
  if (claim?.environment !== undefined && claim.environment !== request.run.scope.environment) {
    throw new AdapterContractError("Provider environment claim does not match authorized scope");
  }
  if (claim?.service !== undefined && claim.service !== request.run.scope.service) {
    throw new AdapterContractError("Provider service claim does not match authorized scope");
  }
  if (claim?.subject !== undefined &&
      canonicalJson(claim.subject) !== canonicalJson(request.run.scope.subject ?? null)) {
    throw new AdapterContractError("Provider subject claim does not match authorized scope");
  }
  if (
    claim?.tenantSha256 !== undefined &&
    request.run.expectedTenantSha256 !== undefined &&
    claim.tenantSha256 !== request.run.expectedTenantSha256
  ) {
    throw new AdapterContractError("Provider tenant claim does not match authenticated tenant");
  }
  if (result.collectionState === "ERROR") return;
  const expectedClaims = {
    environment: request.run.scope.environment,
    service: request.run.scope.service,
    "subject.ref": request.run.scope.subject?.ref,
    tenantSha256: request.run.expectedTenantSha256,
  } as const;
  const actualClaims = {
    environment: claim?.environment,
    service: claim?.service,
    "subject.ref": claim?.subject?.ref,
    tenantSha256: claim?.tenantSha256,
  } as const;
  for (const key of ["environment", "service", "subject.ref", "tenantSha256"] as const) {
    const providerField = request.operation.definition.scopeMapping[key];
    if (providerField === undefined) continue;
    if (expectedClaims[key] === undefined || actualClaims[key] === undefined) {
      throw new AdapterContractError(`Provider response omitted mapped ${key} claim`);
    }
    if (claim?.mappings?.[key] !== providerField) {
      throw new AdapterContractError(`Provider ${key} claim lacks the sealed mapping proof`);
    }
  }
}

function assertSourceLineage(result: ProviderResult, request: CollectEvidenceRequest): void {
  const expected = request.operation.definition.expectedSourceLineage;
  const actual = result.sourceLineage;
  if (expected === undefined) {
    if (actual !== undefined) {
      throw new AdapterContractError("Provider response invented source lineage outside the sealed operation");
    }
    return;
  }
  if (actual === undefined || canonicalJson(actual) !== canonicalJson(expected)) {
    throw new AdapterContractError("Provider source lineage does not match the sealed operation");
  }
}

function assertAuthoritativeLiveScopeMapping(request: CollectEvidenceRequest): void {
  if (request.run.origin !== "LIVE" || request.operation.definition.authority !== "AUTHORITATIVE") return;
  const required = request.run.scope.service === undefined
    ? ["environment"]
    : ["environment", "service"];
  if (request.run.scope.subject !== undefined) required.push("subject.ref");
  for (const key of required) {
    const providerField = request.operation.definition.scopeMapping[key];
    if (typeof providerField !== "string" || providerField.length === 0) {
      throw new AdapterContractError(
        `Authoritative live operation lacks a sealed ${key} scope mapping`,
      );
    }
  }
}

function validateEffectiveLimits(
  candidate: Readonly<OperationLimits>,
  upperLimits: Readonly<OperationLimits>,
  upperLabel: "catalog operation" | "authorized run policy",
): Readonly<OperationLimits> {
  if (typeof candidate !== "object" || candidate === null || Array.isArray(candidate)) {
    throw new AdapterContractError("Effective operation limits are invalid");
  }
  const keys = Object.keys(candidate);
  if (
    keys.length !== OPERATION_LIMIT_KEYS.length ||
    keys.some((key) => !(OPERATION_LIMIT_KEYS as readonly string[]).includes(key))
  ) {
    throw new AdapterContractError("Effective operation limits must contain exactly the supported dimensions");
  }
  const limits = {} as OperationLimits;
  for (const key of OPERATION_LIMIT_KEYS) {
    const value = candidate[key];
    const minimum = ZERO_ALLOWED_LIMIT_KEYS.has(key) ? 0 : 1;
    if (!Number.isSafeInteger(value) || value < minimum) {
      throw new AdapterContractError(`Effective ${key} limit is invalid`);
    }
    if (value > upperLimits[key]) {
      throw new AdapterContractError(`Effective ${key} limit widens the ${upperLabel}`);
    }
    limits[key] = value;
  }
  return Object.freeze(limits);
}

function assertResultBudget(result: ProviderResult, limits: Readonly<OperationLimits>): void {
  const bytes = Buffer.byteLength(canonicalJson(result), "utf8");
  if (bytes > limits.maxBytes) throw new BudgetExceededError("bytes");
  let rows = 0;
  let series = 0;
  let points = 0;
  for (const record of result.records) {
    if (record.kind === "TABLE") rows += record.rows.length;
    else if (record.kind === "TIMESERIES") {
      series += 1;
      points += record.points.length;
    } else rows += 1;
  }
  if (rows > limits.maxRows) throw new BudgetExceededError("rows");
  if (series > limits.maxSeries) throw new BudgetExceededError("series");
  if (points > limits.maxPoints) throw new BudgetExceededError("points");
}

function freshnessState(
  collectionState: ProviderResult["collectionState"],
  evaluatedAt: string,
  collectedAt: Date,
  maxAgeMs: number,
  maxClockSkewMs: number,
): FreshnessState {
  if (collectionState === "ERROR") return "NOT_APPLICABLE";
  const evaluatedMs = Date.parse(evaluatedAt);
  if (!Number.isFinite(evaluatedMs)) throw new AdapterContractError("Provider evaluatedAt is invalid");
  if (evaluatedMs > collectedAt.getTime() + maxClockSkewMs) {
    throw new AdapterContractError("Provider evaluatedAt exceeds clock-skew tolerance");
  }
  return collectedAt.getTime() - evaluatedMs > maxAgeMs ? "STALE" : "FRESH";
}

function nativeDimensions(result: ProviderResult, operation: OperationSnapshot): Record<string, string> {
  const safe: Record<string, string> = {};
  for (const [name, value] of Object.entries(result.nativeDimensions)) {
    const mapped = operation.definition.normalization.dimensionMappings[name] ?? name;
    if (operation.definition.allowedDimensions.includes(mapped)) safe[name] = value;
  }
  return safe;
}

function errorPagination(): Pagination {
  return { complete: false, pages: 0 };
}

async function awaitWithAbort<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const onAbort = (): void => reject(signal.reason ?? new Error("Cancelled"));
    promise.then(
      (value) => {
        signal.removeEventListener("abort", onAbort);
        resolve(value);
      },
      (error: unknown) => {
        signal.removeEventListener("abort", onAbort);
        reject(error);
      },
    );
    if (signal.aborted) onAbort();
    else signal.addEventListener("abort", onAbort, { once: true });
  });
}

export interface EvidenceHostOptions {
  registry: AdapterRegistry;
  audit: AuditSink;
  store: EvidenceStore;
  policy: AdapterHostPolicy;
  clock?: Clock;
  ids?: IdFactory;
}

export class EvidenceHost {
  readonly #registry: AdapterRegistry;
  readonly #audit: AuditSink;
  readonly #store: EvidenceStore;
  readonly #policy: AdapterHostPolicy;
  readonly #clock: Clock;
  readonly #ids: IdFactory;

  constructor(options: EvidenceHostOptions) {
    this.#registry = options.registry;
    this.#audit = options.audit;
    this.#store = options.store;
    this.#policy = options.policy;
    this.#clock = options.clock ?? systemClock;
    this.#ids = options.ids ?? defaultIds();
  }

  async #auditEvent(event: AuditEvent): Promise<boolean> {
    try {
      await this.#audit.append(event);
      return true;
    } catch (error) {
      if (this.#policy.auditRequired) throw error;
      return false;
    }
  }

  async collect(request: CollectEvidenceRequest): Promise<EvidenceEnvelope> {
    const operation = request.operation;
    const allowedHash = request.run.allowedOperationHashes[operation.operationId];
    if (allowedHash === undefined || allowedHash !== operation.definitionSha256) {
      throw new AdapterContractError("Operation is not authorized for this run");
    }
    if (computeOperationDefinitionHash(operation) !== operation.definitionSha256) {
      throw new AdapterContractError("Operation snapshot hash is invalid");
    }
    if (operation.definition.adapterPackageId !== request.adapterPackage.packageId) {
      throw new AdapterContractError("Operation and adapter package do not match");
    }
    if (Buffer.byteLength(canonicalJson(operation.definition), "utf8") > this.#policy.maxDefinitionBytes) {
      throw new AdapterContractError("Operation definition exceeds host limit");
    }
    assertAuthoritativeLiveScopeMapping(request);
    const catalogBoundLimits = validateEffectiveLimits(
      request.effectiveLimits,
      operation.definition.limits,
      "catalog operation",
    );
    const authorizedLimits = request.run.authorizedOperationLimits?.[operation.operationId];
    if (authorizedLimits === undefined) {
      throw new AdapterContractError("Authorized run omits policy-compiled operation limits");
    }
    const effectiveLimits = validateEffectiveLimits(
      catalogBoundLimits,
      validateEffectiveLimits(authorizedLimits, operation.definition.limits, "catalog operation"),
      "authorized run policy",
    );
    const registration = this.#registry.get(request.adapterPackage.packageId);
    if (canonicalJson(registration.adapterPackage) !== canonicalJson(request.adapterPackage)) {
      throw new AdapterContractError("Requested adapter package does not match the trusted registry");
    }
    const limitations: string[] = [];
    const startedAt = this.#clock.now().toISOString();
    const startAudited = await this.#auditEvent({
      schemaVersion: "1.0.0",
      event: "COLLECTION_STARTED",
      at: startedAt,
      runId: request.run.runId,
      operationId: operation.operationId,
      adapterPackageId: registration.adapterPackage.packageId,
    });
    if (!startAudited) limitations.push("Audit sink unavailable when collection started");

    const deadline = new AbortController();
    const deadlineTimer = setTimeout(
      () => deadline.abort(new DeadlineExceededError()),
      effectiveLimits.timeoutMs,
    );
    const signals = request.signal === undefined ? [deadline.signal] : [deadline.signal, request.signal];
    const signal = AbortSignal.any(signals);
    const budget = createBudgetController(effectiveLimits, signal);
    let providerResult: ProviderResult | undefined;
    let sanitizedError: SanitizedError | undefined;
    let redactions: EvidenceEnvelope["redactions"] = [];
    try {
      const compiled = await awaitWithAbort(
        registration.adapter.compile(operation, {
          adapterPackage: registration.adapterPackage,
          maxDefinitionBytes: this.#policy.maxDefinitionBytes,
          signal,
        }),
        signal,
      );
      if (
        compiled.operationId !== operation.operationId ||
        compiled.operationDefinitionSha256 !== operation.definitionSha256 ||
        compiled.adapterPackageId !== registration.adapterPackage.packageId ||
        compiled.adapterOperation !== operation.definition.adapterOperation
      ) {
        throw new AdapterContractError("Adapter compiled an operation outside the trusted snapshot");
      }
      providerResult = await awaitWithAbort(
        registration.adapter.execute(
          {
            origin: request.run.origin,
            scope: request.run.scope,
            window: request.run.window,
            ...(request.run.expectedTenantSha256 === undefined
              ? {}
              : { expectedTenantSha256: request.run.expectedTenantSha256 }),
            clock: this.#clock,
            budget,
            signal,
          },
          compiled,
        ),
        signal,
      );
      assertProviderResult(providerResult);
      assertSourceLineage(providerResult, request);
      assertResultBudget(providerResult, effectiveLimits);
      const outcome = redactProviderResult(providerResult, this.#policy.redactionPolicy ?? defaultRedactionPolicy);
      providerResult = outcome.result;
      redactions = outcome.records;
      if (outcome.untrustedInstructionsDetected) {
        limitations.push("Provider text contained instruction-like content and was treated only as evidence data");
      }
      if (outcome.rejected) {
        providerResult = undefined;
        sanitizedError = {
          code: "SENSITIVE_PROVIDER_PAYLOAD",
          category: "POLICY",
          message: "Provider payload was discarded by redaction policy",
          retryable: false,
        };
      } else {
        assertProviderScope(providerResult, request);
      }
    } catch (error) {
      providerResult = undefined;
      sanitizedError = errorFromUnknown(error, signal);
    } finally {
      clearTimeout(deadlineTimer);
    }

    const collectedAt = this.#clock.now();
    let values: EvidenceEnvelope["values"] = [];
    let collectionState: EvidenceEnvelope["collectionState"] = "ERROR";
    let freshness: FreshnessState = "NOT_APPLICABLE";
    if (providerResult !== undefined) {
      try {
        const normalized = normalizeProviderResult(providerResult, operation);
        values = normalized.values;
        limitations.push(...normalized.limitations);
        collectionState = providerResult.collectionState;
        freshness = freshnessState(
          providerResult.collectionState,
          providerResult.evaluatedAt,
          collectedAt,
          effectiveLimits.maxAgeMs,
          this.#policy.maxClockSkewMs,
        );
        if (providerResult.collectionState === "ERROR") sanitizedError = providerResult.error;
      } catch (error) {
        providerResult = undefined;
        values = [];
        collectionState = "ERROR";
        freshness = "NOT_APPLICABLE";
        sanitizedError = errorFromUnknown(error, signal);
      }
    }

    const evidenceId = this.#ids.evidenceId();
    const draft: Omit<EvidenceEnvelope, "integrity"> = {
      schemaVersion: providerResult?.sourceLineage === undefined ? "1.0.0" : "1.1.0",
      evidenceId,
      runId: request.run.runId,
      operationId: operation.operationId,
      operationDefinitionSha256: operation.definitionSha256,
      trustBundleSha256: request.run.trustBundleSha256,
      origin: request.run.origin,
      authority: operation.definition.authority,
      source: {
        provider: registration.adapter.descriptor.provider,
        sourceAlias: operation.definition.sourceAlias,
        adapterPackageId: registration.adapterPackage.packageId,
        adapterVersion: registration.adapterPackage.version,
        ...(providerResult?.sanitizedReference === undefined
          ? {}
          : { sanitizedReference: providerResult.sanitizedReference }),
        ...(providerResult?.sourceLineage === undefined
          ? {}
          : { lineage: { ...providerResult.sourceLineage } }),
      },
      scope: { ...request.run.scope },
      correlation: {
        environment: request.run.scope.environment,
        ...(request.run.scope.service === undefined ? {} : { serviceName: request.run.scope.service }),
      },
      evaluatedAt: providerResult?.evaluatedAt ?? collectedAt.toISOString(),
      collectedAt: collectedAt.toISOString(),
      window: { ...request.run.window },
      maxAcceptableAgeMs: effectiveLimits.maxAgeMs,
      collectionState,
      freshnessState: freshness,
      native: {
        resultType: providerResult?.nativeResultType ?? "ERROR",
        dimensions: providerResult === undefined ? {} : nativeDimensions(providerResult, operation),
        ...(providerResult?.nativeUnit === undefined ? {} : { unit: providerResult.nativeUnit }),
      },
      values,
      redactions,
      limitations,
      pagination: providerResult?.pagination ?? errorPagination(),
      providerWarnings: providerResult?.warnings ?? [],
      ...(sanitizedError === undefined ? {} : { error: sanitizedError }),
    };
    let envelope: EvidenceEnvelope = { ...draft, integrity: computeIntegrity(draft) };
    const completedAudited = await this.#auditEvent({
      schemaVersion: "1.0.0",
      event: collectionState === "ERROR" ? "COLLECTION_FAILED" : "COLLECTION_COMPLETED",
      at: collectedAt.toISOString(),
      runId: request.run.runId,
      operationId: operation.operationId,
      adapterPackageId: registration.adapterPackage.packageId,
      evidenceId,
      outcome: collectionState,
    });
    if (!completedAudited) {
      const revised = { ...draft, limitations: [...draft.limitations, "Audit sink unavailable after collection"] };
      envelope = { ...revised, integrity: computeIntegrity(revised) };
    }
    await this.#store.put(envelope);
    return envelope;
  }
}
