import type { JsonPrimitive, NormalizedValue, OperationSnapshot } from "@codex-production-monitoring/contracts";
import { AdapterContractError, type ProviderResult, type ProviderValue } from "@codex-production-monitoring/adapter-sdk";

export interface NormalizationOutcome {
  values: NormalizedValue[];
  limitations: string[];
}

function convertNumber(value: JsonPrimitive, from: string | undefined, to: string | undefined): JsonPrimitive {
  if (typeof value !== "number" || to === undefined || from === undefined || from === to) return value;
  if (from === "seconds" && to === "milliseconds") return value * 1000;
  if (from === "milliseconds" && to === "seconds") return value / 1000;
  if (from === "ratio" && to === "percent") return value * 100;
  if (from === "percent" && to === "ratio") return value / 100;
  throw new AdapterContractError(`Unsupported unit conversion: ${from} to ${to}`);
}

function mapDimensions(
  dimensions: Readonly<Record<string, string>>,
  operation: Readonly<OperationSnapshot>,
  limitations: string[],
): Record<string, string> {
  const mapped: Record<string, string> = {};
  for (const [providerName, value] of Object.entries(dimensions)) {
    const canonicalName = operation.definition.normalization.dimensionMappings[providerName] ?? providerName;
    if (!operation.definition.allowedDimensions.includes(canonicalName)) {
      limitations.push(`Dropped non-allowlisted dimension: ${providerName}`);
      continue;
    }
    const hasControlCharacter = [...value].some((character) => {
      const codePoint = character.codePointAt(0) ?? 0;
      return codePoint <= 31 || codePoint === 127;
    });
    if (value.length > 128 || hasControlCharacter) {
      throw new AdapterContractError(`Invalid value for dimension: ${providerName}`);
    }
    mapped[canonicalName] = value;
  }
  return mapped;
}

function normalizeValue(
  value: ProviderValue,
  operation: Readonly<OperationSnapshot>,
  limitations: string[],
): NormalizedValue {
  const expected = operation.definition.normalization.resultKind;
  if (value.kind !== expected) throw new AdapterContractError(`Provider result kind ${value.kind} does not match ${expected}`);
  const targetUnit = operation.definition.normalization.targetUnit;
  if (value.kind === "SCALAR") {
    const unit = targetUnit ?? value.unit;
    return {
      kind: "SCALAR",
      name: value.name,
      value: convertNumber(value.value, value.unit, targetUnit),
      dimensions: mapDimensions(value.dimensions, operation, limitations),
      ...(unit === undefined ? {} : { unit }),
      ...(value.observedAt === undefined ? {} : { observedAt: value.observedAt }),
    };
  }
  if (value.kind === "TIMESERIES") {
    const unit = targetUnit ?? value.unit;
    return {
      kind: "TIMESERIES",
      name: value.name,
      dimensions: mapDimensions(value.dimensions, operation, limitations),
      points: value.points.map((point) => ({
        at: point.at,
        value: point.value === null ? null : (convertNumber(point.value, value.unit, targetUnit) as number),
      })),
      ...(unit === undefined ? {} : { unit }),
    };
  }
  if (value.kind === "TABLE") return { ...value, columns: [...value.columns], rows: value.rows.map((row) => [...row]) };
  return { ...value, attributes: { ...value.attributes } };
}

export function normalizeProviderResult(
  result: Readonly<ProviderResult>,
  operation: Readonly<OperationSnapshot>,
): NormalizationOutcome {
  const limitations: string[] = [];
  return { values: result.records.map((value) => normalizeValue(value, operation, limitations)), limitations };
}
