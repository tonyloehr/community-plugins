import { execFile, spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { createHash } from "node:crypto";
import { constants, type Stats } from "node:fs";
import { chmod, lstat, mkdtemp, open, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, extname, isAbsolute, join } from "node:path";
import type { Writable } from "node:stream";
import { promisify } from "node:util";

import {
  AdapterAdmissionError,
  AdapterExecutionError,
  assertWorkerRequest,
  DEFAULT_MAX_WORKER_FRAME_BYTES,
  encodeWorkerFrame,
  parseWorkerResponsePayload,
  parseAdmittedWorkerSourceManifest,
  readVerifiedWorkerArtifactBytes,
  verifyWorkerArtifact,
  WorkerFrameDecoder,
  WorkerProtocolError,
  type AdmittedWorkerArtifact,
  type WorkerFactory,
  type WorkerRequest,
  type WorkerResponse,
  type WorkerTransport,
} from "@codex-production-monitoring/adapter-sdk";
import type { CredentialReference } from "@codex-production-monitoring/contracts";

import {
  acquireCredentialBootstrapFrame,
  assertNonEnvironmentCredentialReferences,
  type WorkerCredentialSource,
} from "./credential-bootstrap.ts";

export interface StdioWorkerOptions {
  /**
   * This host verifies and stages an artifact and provides a bounded stdio
   * protocol. It does not impose an OS filesystem, network, process, CPU, or
   * memory sandbox. Production callers must therefore use trusted code-owned
   * workers unless their deployment supplies and verifies that containment.
   */
  /** Absolute trusted runtime binary. Defaults to the current Node executable. */
  runtimePath?: string;
  /** Fixed code-owned runtime flags placed before the artifact path. */
  runtimeArguments?: readonly string[];
  /** Fixed code-owned arguments placed after the artifact path. */
  artifactArguments?: readonly string[];
  /** Fixed code-owned one-shot arguments used to validate the staged artifact before launch. */
  validationArtifactArguments?: readonly string[];
  /** Explicit allowlisted environment. The parent environment is never inherited. */
  environment?: Readonly<Record<string, string>>;
  /** Exact trusted non-environment references to deliver over the dedicated fd3 pipe. */
  credentialReferences?: readonly Readonly<CredentialReference>[];
  /** Host-managed source. It is invoked only after code and bootstrap validation succeed. */
  credentialSource?: WorkerCredentialSource;
  maxFrameBytes?: number;
  defaultRequestTimeoutMs?: number;
  shutdownGraceMs?: number;
}

interface PendingRequest {
  expectedKind: "doctor-result" | "compiled" | "result";
  resolve(response: WorkerResponse): void;
  reject(error: Error): void;
  cleanup(): void;
}

const DEFAULT_REQUEST_TIMEOUT_MS = 30_000;
const DEFAULT_SHUTDOWN_GRACE_MS = 250;
const SUPPORTED_STAGED_EXTENSIONS = new Set([".cjs", ".js", ".mjs"]);
const execFileAsync = promisify(execFile);

interface PreparedWorkerArtifact {
  artifactPath: string;
  cwd: string;
  staged: boolean;
  cleanup(): Promise<void>;
}

type WorkerArtifactLaunchMode = "VERIFIED_STAGED_COPY" | "DEVELOPMENT_TEST_DIRECT_PATH";

function sanitized(
  code: string,
  category: "TIMEOUT" | "POLICY" | "INVALID_RESPONSE" | "INTERNAL",
  message: string,
  retryable: boolean,
): AdapterExecutionError {
  return new AdapterExecutionError({ code, category, message, retryable });
}

function protocolError(error: unknown): AdapterExecutionError {
  if (error instanceof WorkerProtocolError && error.failure === "OVERSIZE") {
    return sanitized(
      "ADAPTER_WORKER_OVERSIZE",
      "INVALID_RESPONSE",
      "Adapter worker exceeded the protocol byte limit",
      false,
    );
  }
  return sanitized(
    "ADAPTER_WORKER_PROTOCOL",
    "INVALID_RESPONSE",
    "Adapter worker violated the response protocol",
    false,
  );
}

function validateArgument(value: string): void {
  if (value.length > 4096 || value.includes("\0")) {
    throw new AdapterAdmissionError("Worker launch argument is invalid");
  }
}

function minimalEnvironment(environment: Readonly<Record<string, string>> | undefined): NodeJS.ProcessEnv {
  const result: NodeJS.ProcessEnv = Object.create(null) as NodeJS.ProcessEnv;
  for (const [key, value] of Object.entries(environment ?? {})) {
    if (!/^[A-Za-z_][A-Za-z0-9_]{0,127}$/u.test(key) || value.length > 16_384 || value.includes("\0")) {
      throw new AdapterAdmissionError("Worker environment entry is invalid");
    }
    result[key] = value;
  }
  return result;
}

function delay(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function requestDeadline(message: WorkerRequest, defaultTimeoutMs: number): number {
  if (message.kind === "execute") {
    const deadline = Date.parse(message.context.deadlineAt);
    if (!Number.isFinite(deadline)) return Date.now();
    return Math.min(deadline, Date.now() + message.context.limits.timeoutMs);
  }
  return Date.now() + defaultTimeoutMs;
}

function validateOptions(options: StdioWorkerOptions): void {
  const maximumFrameBytes = options.maxFrameBytes ?? DEFAULT_MAX_WORKER_FRAME_BYTES;
  const defaultRequestTimeoutMs = options.defaultRequestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
  const shutdownGraceMs = options.shutdownGraceMs ?? DEFAULT_SHUTDOWN_GRACE_MS;
  if (!Number.isSafeInteger(maximumFrameBytes) || maximumFrameBytes < 1 || maximumFrameBytes > 0xffff_ffff) {
    throw new AdapterAdmissionError("Worker frame byte limit is invalid");
  }
  if (!Number.isSafeInteger(defaultRequestTimeoutMs) || defaultRequestTimeoutMs < 1) {
    throw new AdapterAdmissionError("Worker request timeout is invalid");
  }
  if (!Number.isSafeInteger(shutdownGraceMs) || shutdownGraceMs < 1) {
    throw new AdapterAdmissionError("Worker shutdown grace period is invalid");
  }
  let credentialReferences: readonly Readonly<CredentialReference>[];
  try {
    credentialReferences = assertNonEnvironmentCredentialReferences(options.credentialReferences ?? []);
  } catch {
    throw new AdapterAdmissionError("Worker credential references are invalid");
  }
  if (credentialReferences.length > 0 && options.credentialSource === undefined) {
    throw new AdapterAdmissionError("A worker credential source is required");
  }
}

async function closeCredentialPipe(pipe: Writable, frame: Buffer | undefined): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    let settled = false;
    const cleanup = (): void => {
      pipe.removeListener("error", onError);
    };
    const finish = (): void => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve();
    };
    const onError = (): void => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new AdapterAdmissionError("Worker credential bootstrap failed"));
    };
    pipe.once("error", onError);
    if (frame === undefined) pipe.end(finish);
    else pipe.end(frame, finish);
  });
}

function assertOwnedMode(
  metadata: Stats,
  expectedMode: number,
  kind: "directory" | "file",
): void {
  const expectedType = kind === "directory" ? metadata.isDirectory() : metadata.isFile();
  if (!expectedType || metadata.isSymbolicLink() || (metadata.mode & 0o777) !== expectedMode) {
    throw new AdapterAdmissionError(`Private worker staging ${kind} has unsafe metadata`);
  }
  if (typeof process.getuid === "function" && metadata.uid !== process.getuid()) {
    throw new AdapterAdmissionError(`Private worker staging ${kind} is not process-owned`);
  }
}

async function writeAll(handle: Awaited<ReturnType<typeof open>>, contents: Buffer): Promise<void> {
  let offset = 0;
  while (offset < contents.byteLength) {
    const { bytesWritten } = await handle.write(contents, offset, contents.byteLength - offset, offset);
    if (bytesWritten === 0) throw new AdapterAdmissionError("Verified worker artifact could not be staged");
    offset += bytesWritten;
  }
}

async function readExactSourcePart(
  sourcePath: string,
  expected: { bytes: number; sha256: string },
): Promise<Buffer> {
  const noFollow = constants.O_NOFOLLOW;
  let handle: Awaited<ReturnType<typeof open>>;
  try {
    handle = await open(sourcePath, constants.O_RDONLY | noFollow);
  } catch {
    throw new AdapterAdmissionError("Verified worker source part is unavailable");
  }
  try {
    const before = await handle.stat();
    if (!before.isFile() || before.size !== expected.bytes) {
      throw new AdapterAdmissionError("Verified worker source part metadata is invalid");
    }
    const contents = Buffer.allocUnsafe(expected.bytes);
    let offset = 0;
    while (offset < contents.byteLength) {
      const { bytesRead } = await handle.read(contents, offset, contents.byteLength - offset, offset);
      if (bytesRead === 0) throw new AdapterAdmissionError("Verified worker source part changed during admission");
      offset += bytesRead;
    }
    const trailingByte = Buffer.allocUnsafe(1);
    const [{ bytesRead: trailingBytes }, after] = await Promise.all([
      handle.read(trailingByte, 0, 1, contents.byteLength),
      handle.stat(),
    ]);
    if (trailingBytes !== 0 || after.size !== before.size || after.dev !== before.dev || after.ino !== before.ino) {
      throw new AdapterAdmissionError("Verified worker source part changed during admission");
    }
    if (createHash("sha256").update(contents).digest("hex") !== expected.sha256) {
      throw new AdapterAdmissionError("Verified worker source part digest does not match the signed loader manifest");
    }
    return contents;
  } finally {
    await handle.close().catch(() => undefined);
  }
}

async function writePrivateStagedFile(path: string, contents: Buffer): Promise<void> {
  const handle = await open(
    path,
    constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW,
    0o400,
  );
  try {
    await writeAll(handle, contents);
    await handle.sync();
  } finally {
    await handle.close().catch(() => undefined);
  }
  await chmod(path, 0o400);
  const metadata = await lstat(path);
  assertOwnedMode(metadata, 0o400, "file");
  if (metadata.size !== contents.byteLength) {
    throw new AdapterAdmissionError("Verified worker artifact staging was incomplete");
  }
}

async function prepareStagedWorkerArtifact(
  artifact: Readonly<AdmittedWorkerArtifact>,
): Promise<PreparedWorkerArtifact> {
  const extension = extname(artifact.artifactPath).toLowerCase();
  if (!SUPPORTED_STAGED_EXTENSIONS.has(extension)) {
    throw new AdapterAdmissionError("Production worker artifacts must be standalone JavaScript files");
  }
  const contents = await readVerifiedWorkerArtifactBytes(artifact);
  const sourceManifest = parseAdmittedWorkerSourceManifest(contents);
  const noFollow = constants.O_NOFOLLOW;
  if (!Number.isSafeInteger(noFollow) || noFollow === 0) {
    throw new AdapterAdmissionError("Worker artifact no-follow opens are unavailable on this platform");
  }

  let stagingRoot: string | undefined;
  try {
    stagingRoot = await mkdtemp(join(tmpdir(), "codex-pm-worker-"));
    await chmod(stagingRoot, 0o700);
    assertOwnedMode(await lstat(stagingRoot), 0o700, "directory");

    const stagedPath = join(stagingRoot, `worker${extension}`);
    await writePrivateStagedFile(stagedPath, contents);
    if (sourceManifest !== undefined) {
      const sourceParts = [];
      for (const part of sourceManifest.parts) {
        const bytes = await readExactSourcePart(join(dirname(artifact.artifactPath), part.name), part);
        sourceParts.push(bytes);
        await writePrivateStagedFile(join(stagingRoot, part.name), bytes);
      }
      const source = Buffer.concat(sourceParts);
      if (
        source.byteLength !== sourceManifest.sourceBytes
        || createHash("sha256").update(source).digest("hex") !== sourceManifest.sourceSha256
      ) {
        throw new AdapterAdmissionError("Verified worker source does not match the signed loader manifest");
      }
    }
    await verifyWorkerArtifact({
      artifactPath: stagedPath,
      artifactSha256: artifact.artifactSha256,
    });
    const ownedStagingRoot = stagingRoot;

    return {
      artifactPath: stagedPath,
      cwd: ownedStagingRoot,
      staged: true,
      async cleanup() {
        await rm(ownedStagingRoot, { force: true, maxRetries: 3, recursive: true, retryDelay: 10 });
      },
    };
  } catch (error) {
    if (stagingRoot !== undefined) {
      await rm(stagingRoot, { force: true, maxRetries: 3, recursive: true, retryDelay: 10 }).catch(() => undefined);
    }
    if (error instanceof AdapterAdmissionError) throw error;
    throw new AdapterAdmissionError("Verified worker artifact could not be staged");
  }
}

async function prepareDevelopmentTestDirectPath(
  artifact: Readonly<AdmittedWorkerArtifact>,
): Promise<PreparedWorkerArtifact> {
  await verifyWorkerArtifact(artifact);
  return {
    artifactPath: artifact.artifactPath,
    cwd: dirname(artifact.artifactPath),
    staged: false,
    async cleanup() {},
  };
}

export class StdioWorkerTransport implements WorkerTransport {
  readonly #child: ChildProcessWithoutNullStreams;
  readonly #decoder: WorkerFrameDecoder;
  readonly #launchArtifact: PreparedWorkerArtifact;
  readonly #maximumFrameBytes: number;
  readonly #defaultRequestTimeoutMs: number;
  readonly #shutdownGraceMs: number;
  readonly #pending = new Map<string, PendingRequest>();
  readonly #exitPromise: Promise<void>;
  #resolveExit!: () => void;
  #closed = false;
  #closing = false;
  #cleanupPromise: Promise<void> | undefined;
  #termination: Promise<void> | undefined;

  private constructor(
    child: ChildProcessWithoutNullStreams,
    options: StdioWorkerOptions,
    launchArtifact: PreparedWorkerArtifact,
  ) {
    this.#child = child;
    this.#launchArtifact = launchArtifact;
    this.#maximumFrameBytes = options.maxFrameBytes ?? DEFAULT_MAX_WORKER_FRAME_BYTES;
    this.#defaultRequestTimeoutMs = options.defaultRequestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
    this.#shutdownGraceMs = options.shutdownGraceMs ?? DEFAULT_SHUTDOWN_GRACE_MS;
    this.#decoder = new WorkerFrameDecoder(this.#maximumFrameBytes);
    this.#exitPromise = new Promise((resolve) => {
      this.#resolveExit = resolve;
    });
    child.stdout.on("data", (chunk: Buffer) => this.#onStdout(chunk));
    child.stdout.on("end", () => {
      try {
        this.#decoder.finish();
      } catch (error) {
        void this.#failProtocol(error);
      }
    });
    child.stderr.resume();
    child.once("error", () => {
      // A pre-spawn error has no process that can emit exit. Post-spawn errors
      // (including a failed kill) are not proof that the child has exited.
      if (child.pid === undefined) this.#onExit();
    });
    child.once("exit", () => this.#onExit());
    child.once("close", () => this.#onExit());
  }

  static async spawn(
    artifact: Readonly<AdmittedWorkerArtifact>,
    options: StdioWorkerOptions = {},
  ): Promise<StdioWorkerTransport> {
    return this.#spawn(artifact, options, "VERIFIED_STAGED_COPY");
  }

  /**
   * Test-only escape hatch for TypeScript fixtures with relative imports. It
   * remains digest checked, but intentionally does not provide pathname-race
   * protection and must never be used by a live provider runtime.
   */
  static async spawnDevelopmentTestDirectPath(
    artifact: Readonly<AdmittedWorkerArtifact>,
    options: StdioWorkerOptions = {},
  ): Promise<StdioWorkerTransport> {
    return this.#spawn(artifact, options, "DEVELOPMENT_TEST_DIRECT_PATH");
  }

  static async #spawn(
    artifact: Readonly<AdmittedWorkerArtifact>,
    options: StdioWorkerOptions,
    launchMode: WorkerArtifactLaunchMode,
  ): Promise<StdioWorkerTransport> {
    validateOptions(options);
    const runtimePath = options.runtimePath ?? process.execPath;
    if (!isAbsolute(runtimePath)) throw new AdapterAdmissionError("Worker runtime path must be absolute");
    const runtimeArguments = [...(options.runtimeArguments ?? [])];
    const artifactArguments = [...(options.artifactArguments ?? [])];
    const validationArtifactArguments = [...(options.validationArtifactArguments ?? [])];
    runtimeArguments.forEach(validateArgument);
    artifactArguments.forEach(validateArgument);
    validationArtifactArguments.forEach(validateArgument);
    const environment = minimalEnvironment(options.environment);
    const credentialReferences = assertNonEnvironmentCredentialReferences(options.credentialReferences ?? []);
    const launchArtifact = launchMode === "VERIFIED_STAGED_COPY"
      ? await prepareStagedWorkerArtifact(artifact)
      : await prepareDevelopmentTestDirectPath(artifact);
    let credentialFrame: Buffer | undefined;
    try {
      if (validationArtifactArguments.length > 0) {
        try {
          await execFileAsync(
            runtimePath,
            [...runtimeArguments, launchArtifact.artifactPath, ...validationArtifactArguments],
            {
              cwd: launchArtifact.cwd,
              encoding: "utf8",
              env: environment,
              maxBuffer: 1_024,
              timeout: options.defaultRequestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS,
              windowsHide: true,
            },
          );
        } catch {
          throw new AdapterAdmissionError("Signed worker bootstrap validation failed");
        }
      }

      if (credentialReferences.length > 0) {
        try {
          credentialFrame = await acquireCredentialBootstrapFrame(
            credentialReferences,
            options.credentialSource!,
          );
        } catch {
          throw new AdapterAdmissionError("A required worker credential is unavailable");
        }
      }

      let child: ChildProcessWithoutNullStreams;
      try {
        child = spawn(runtimePath, [...runtimeArguments, launchArtifact.artifactPath, ...artifactArguments], {
          cwd: launchArtifact.cwd,
          detached: false,
          env: environment,
          shell: false,
          stdio: ["pipe", "pipe", "pipe", "pipe"],
          windowsHide: true,
        }) as ChildProcessWithoutNullStreams;
      } catch {
        throw sanitized(
          "ADAPTER_WORKER_LAUNCH_FAILED",
          "INTERNAL",
          "Adapter worker could not be launched",
          false,
        );
      }
      const credentialPipe = child.stdio[3] as Writable | null;
      if (credentialPipe === null || typeof credentialPipe.end !== "function") {
        child.kill("SIGKILL");
        throw sanitized(
          "ADAPTER_WORKER_LAUNCH_FAILED",
          "INTERNAL",
          "Adapter worker could not be launched",
          false,
        );
      }
      const transport = new StdioWorkerTransport(child, options, launchArtifact);
      await new Promise<void>((resolve, reject) => {
        const onSpawn = (): void => {
          child.removeListener("error", onError);
          resolve();
        };
        const onError = (): void => {
          child.removeListener("spawn", onSpawn);
          reject(
            sanitized(
              "ADAPTER_WORKER_LAUNCH_FAILED",
              "INTERNAL",
              "Adapter worker could not be launched",
              false,
            ),
          );
        };
        child.once("spawn", onSpawn);
        child.once("error", onError);
      }).catch(async (error: unknown) => {
        await transport.#cleanupLaunchArtifact().catch(() => undefined);
        throw error;
      });
      try {
        await closeCredentialPipe(credentialPipe, credentialFrame);
      } catch {
        await transport.#terminate().catch(() => undefined);
        throw sanitized(
          "ADAPTER_WORKER_LAUNCH_FAILED",
          "INTERNAL",
          "Adapter worker could not be launched",
          false,
        );
      }
      return transport;
    } catch (error) {
      await launchArtifact.cleanup().catch(() => undefined);
      throw error;
    } finally {
      credentialFrame?.fill(0);
    }
  }

  get pid(): number | undefined {
    return this.#child.pid;
  }

  get closed(): boolean {
    return this.#closed;
  }

  /** Exposed for local lifecycle diagnostics and tests; it grants no launch control. */
  get stagedArtifactPath(): string | undefined {
    return this.#launchArtifact.staged ? this.#launchArtifact.artifactPath : undefined;
  }

  request(message: WorkerRequest, signal: AbortSignal): Promise<WorkerResponse> {
    if (this.#closed || this.#closing) {
      return Promise.reject(
        sanitized("ADAPTER_WORKER_CLOSED", "INTERNAL", "Adapter worker is closed", false),
      );
    }
    try {
      assertWorkerRequest(message);
    } catch {
      return Promise.reject(
        sanitized(
          "ADAPTER_WORKER_INVALID_REQUEST",
          "POLICY",
          "Adapter worker request failed protocol validation",
          false,
        ),
      );
    }
    if (this.#pending.has(message.requestId)) {
      return Promise.reject(
        sanitized(
          "ADAPTER_WORKER_DUPLICATE_REQUEST",
          "POLICY",
          "Adapter worker request ID was already in use",
          false,
        ),
      );
    }
    let frame: Buffer;
    try {
      frame = encodeWorkerFrame(message, this.#maximumFrameBytes);
    } catch (error) {
      return Promise.reject(protocolError(error));
    }
    return new Promise<WorkerResponse>((resolve, reject) => {
      let settled = false;
      const settleResolve = (response: WorkerResponse): void => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(response);
      };
      const settleReject = (error: Error): void => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(error);
      };
      const abort = (): void => {
        void this.#abortAll(
          message.requestId,
          sanitized("ADAPTER_WORKER_CANCELLED", "POLICY", "Adapter worker request was cancelled", false),
        );
      };
      const remaining = Math.max(0, requestDeadline(message, this.#defaultRequestTimeoutMs) - Date.now());
      const deadlineTimer = setTimeout(() => {
        void this.#abortAll(
          message.requestId,
          sanitized(
            "ADAPTER_WORKER_DEADLINE_EXCEEDED",
            "TIMEOUT",
            "Adapter worker request deadline exceeded",
            true,
          ),
        );
      }, remaining);
      const cleanup = (): void => {
        clearTimeout(deadlineTimer);
        signal.removeEventListener("abort", abort);
        this.#pending.delete(message.requestId);
      };
      this.#pending.set(message.requestId, {
        expectedKind: message.kind === "doctor" ? "doctor-result" : message.kind === "compile" ? "compiled" : "result",
        resolve: settleResolve,
        reject: settleReject,
        cleanup,
      });
      if (signal.aborted) {
        abort();
        return;
      }
      signal.addEventListener("abort", abort, { once: true });
      this.#child.stdin.write(frame, (error) => {
        if (error !== null && error !== undefined) {
          void this.#failAll(
            sanitized("ADAPTER_WORKER_CRASH", "INTERNAL", "Adapter worker terminated unexpectedly", true),
          );
        }
      });
    });
  }

  async close(): Promise<void> {
    if (this.#closed) {
      await this.#cleanupLaunchArtifact();
      return;
    }
    this.#closing = true;
    const pending = this.#takePending();
    try {
      this.#child.stdin.end();
    } catch {
      // Process teardown below remains authoritative.
    }
    await Promise.race([this.#exitPromise, delay(this.#shutdownGraceMs)]);
    if (!this.#closed) await this.#terminate();
    await this.#cleanupLaunchArtifact();
    const error = sanitized("ADAPTER_WORKER_CLOSED", "INTERNAL", "Adapter worker was closed", false);
    for (const request of pending) request.reject(error);
  }

  #onStdout(chunk: Buffer): void {
    if (this.#closed || this.#closing) return;
    let payloads: Buffer[];
    try {
      payloads = this.#decoder.push(chunk);
    } catch (error) {
      void this.#failProtocol(error);
      return;
    }
    for (const payload of payloads) {
      let response: WorkerResponse;
      try {
        response = parseWorkerResponsePayload(payload);
      } catch (error) {
        void this.#failProtocol(error);
        return;
      }
      const pending = this.#pending.get(response.requestId);
      if (pending === undefined) {
        void this.#failProtocol(new WorkerProtocolError("INVALID_MESSAGE"));
        return;
      }
      if (response.kind !== "error" && response.kind !== pending.expectedKind) {
        void this.#failProtocol(new WorkerProtocolError("INVALID_MESSAGE"));
        return;
      }
      if (response.kind === "error" && response.error.code === "ADAPTER_WORKER_DEADLINE_EXCEEDED") {
        // The runner and host enforce the same deadline. If the runner wins
        // that race, the worker must still be retired before the caller sees
        // the timeout; otherwise non-cooperative adapter state can survive in
        // a process the host has already reported as timed out.
        void this.#abortAll(response.requestId, new AdapterExecutionError(response.error));
        return;
      }
      pending.resolve(response);
    }
  }

  #onExit(): void {
    if (this.#closed) return;
    this.#closed = true;
    this.#resolveExit();
    if (!this.#closing && this.#termination === undefined) {
      const error = sanitized(
        "ADAPTER_WORKER_CRASH",
        "INTERNAL",
        "Adapter worker terminated unexpectedly",
        true,
      );
      const pending = this.#takePending();
      void this.#cleanupLaunchArtifact()
        .catch(() => undefined)
        .then(() => {
          for (const request of pending) request.reject(error);
        });
      return;
    }
    void this.#cleanupLaunchArtifact().catch(() => undefined);
  }

  #takePending(): PendingRequest[] {
    const requests = [...this.#pending.values()];
    this.#pending.clear();
    for (const request of requests) request.cleanup();
    return requests;
  }

  async #abortAll(requestId: string, primaryError: AdapterExecutionError): Promise<void> {
    const entries = [...this.#pending.entries()];
    this.#pending.clear();
    for (const [, request] of entries) request.cleanup();
    await this.#terminate();
    for (const [pendingId, request] of entries) {
      request.reject(
        pendingId === requestId
          ? primaryError
          : sanitized("ADAPTER_WORKER_CLOSED", "INTERNAL", "Adapter worker was closed", false),
      );
    }
  }

  async #failProtocol(error: unknown): Promise<void> {
    await this.#failAll(protocolError(error));
  }

  async #failAll(error: AdapterExecutionError): Promise<void> {
    const pending = this.#takePending();
    await this.#terminate();
    for (const request of pending) request.reject(error);
  }

  #terminate(): Promise<void> {
    if (this.#termination !== undefined) return this.#termination;
    this.#termination = (async () => {
      this.#closing = true;
      try {
        this.#child.stdin.destroy();
      } catch {
        // Ignore teardown races.
      }
      if (!this.#closed) {
        try {
          this.#child.kill("SIGTERM");
        } catch {
          // The close event may already be queued.
        }
      }
      await Promise.race([this.#exitPromise, delay(this.#shutdownGraceMs)]);
      if (!this.#closed) {
        try {
          this.#child.kill("SIGKILL");
        } catch {
          // The close event may already be queued.
        }
        await Promise.race([this.#exitPromise, delay(this.#shutdownGraceMs)]);
      }
      // Do not report a closed transport while the OS child remains alive.
      // SIGKILL is the final escalation; actual exit acknowledgement is the
      // authority to settle callers and guarantees no orphan is returned.
      if (!this.#closed) await this.#exitPromise;
      this.#child.stdout.destroy();
      this.#child.stderr.destroy();
      await this.#cleanupLaunchArtifact();
    })();
    return this.#termination;
  }

  #cleanupLaunchArtifact(): Promise<void> {
    this.#cleanupPromise ??= this.#launchArtifact.cleanup().catch(() => undefined);
    return this.#cleanupPromise;
  }
}

export function createStdioWorkerFactory(options: StdioWorkerOptions = {}): WorkerFactory {
  return {
    async create(artifact) {
      return StdioWorkerTransport.spawn(artifact, options);
    },
  };
}

/**
 * Explicit test-only factory for source TypeScript fixtures. Public and live
 * provider runtimes must use createStdioWorkerFactory's staged default.
 */
export function createDevelopmentTestDirectPathStdioWorkerFactory(
  options: StdioWorkerOptions = {},
): WorkerFactory {
  return {
    async create(artifact) {
      return StdioWorkerTransport.spawnDevelopmentTestDirectPath(artifact, options);
    },
  };
}
