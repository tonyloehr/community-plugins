import { readSync } from "node:fs";

import type { CredentialReference } from "@codex-production-monitoring/contracts";

const MAGIC = Buffer.from("PMCR", "ascii");
const PROTOCOL_VERSION = 1;
const HEADER_BYTES = 8;
const ENTRY_HEADER_BYTES = 8;
const MAX_CREDENTIALS = 16;
const MAX_CREDENTIAL_KEY_BYTES = 256;
const MAX_SECRET_BYTES = 262_144;
export const MAX_CREDENTIAL_BOOTSTRAP_BYTES = 1_048_576;
const CREDENTIAL_KEY = /^[A-Za-z][A-Za-z0-9_.:-]{0,255}$/u;

type NonEnvironmentCredentialKind = "broker" | "workload_identity";

export interface WorkerCredentialLease {
  readonly bytes: Uint8Array;
  dispose(): void;
}

export interface WorkerCredentialSource {
  /** Resolve only this exact trusted reference. Implementations must not list or search. */
  acquire(reference: Readonly<CredentialReference>): Promise<WorkerCredentialLease | undefined>;
}

export class CredentialBootstrapError extends Error {
  readonly code:
    | "INVALID_REFERENCE_SET"
    | "CREDENTIAL_UNAVAILABLE"
    | "INVALID_FRAME"
    | "OVERSIZE"
    | "READ_FAILED";

  constructor(code: CredentialBootstrapError["code"]) {
    super("Worker credential bootstrap failed");
    this.name = "CredentialBootstrapError";
    this.code = code;
  }
}

function referenceKindCode(kind: NonEnvironmentCredentialKind): number {
  return kind === "broker" ? 1 : 2;
}

function referenceKind(code: number): NonEnvironmentCredentialKind {
  if (code === 1) return "broker";
  if (code === 2) return "workload_identity";
  throw new CredentialBootstrapError("INVALID_FRAME");
}

export function credentialReferenceIdentity(reference: Readonly<CredentialReference>): string {
  return `${reference.kind}\0${reference.key}`;
}

export function assertNonEnvironmentCredentialReferences(
  references: readonly Readonly<CredentialReference>[],
): readonly Readonly<CredentialReference>[] {
  if (references.length > MAX_CREDENTIALS) throw new CredentialBootstrapError("INVALID_REFERENCE_SET");
  const identities = new Set<string>();
  const normalized = references.map((reference) => {
    if (
      (reference.kind !== "broker" && reference.kind !== "workload_identity")
      || !CREDENTIAL_KEY.test(reference.key)
      || Buffer.byteLength(reference.key, "utf8") > MAX_CREDENTIAL_KEY_BYTES
    ) {
      throw new CredentialBootstrapError("INVALID_REFERENCE_SET");
    }
    const identity = credentialReferenceIdentity(reference);
    if (identities.has(identity)) throw new CredentialBootstrapError("INVALID_REFERENCE_SET");
    identities.add(identity);
    return Object.freeze({ kind: reference.kind, key: reference.key });
  });
  return Object.freeze(normalized);
}

interface CredentialFrameEntry {
  reference: Readonly<CredentialReference>;
  secret: Uint8Array;
}

export function encodeCredentialBootstrapFrame(entries: readonly CredentialFrameEntry[]): Buffer {
  const references = assertNonEnvironmentCredentialReferences(entries.map((entry) => entry.reference));
  let totalBytes = HEADER_BYTES;
  const prepared = entries.map((entry, index) => {
    const key = Buffer.from(references[index]!.key, "utf8");
    if (entry.secret.byteLength < 1 || entry.secret.byteLength > MAX_SECRET_BYTES) {
      key.fill(0);
      throw new CredentialBootstrapError("OVERSIZE");
    }
    totalBytes += ENTRY_HEADER_BYTES + key.byteLength + entry.secret.byteLength;
    if (totalBytes > MAX_CREDENTIAL_BOOTSTRAP_BYTES) {
      key.fill(0);
      throw new CredentialBootstrapError("OVERSIZE");
    }
    return { reference: references[index]!, key, secret: entry.secret };
  });
  const frame = Buffer.alloc(totalBytes);
  MAGIC.copy(frame, 0);
  frame.writeUInt8(PROTOCOL_VERSION, 4);
  frame.writeUInt8(0, 5);
  frame.writeUInt16BE(prepared.length, 6);
  let offset = HEADER_BYTES;
  try {
    for (const entry of prepared) {
      frame.writeUInt8(referenceKindCode(entry.reference.kind as NonEnvironmentCredentialKind), offset);
      frame.writeUInt8(0, offset + 1);
      frame.writeUInt16BE(entry.key.byteLength, offset + 2);
      frame.writeUInt32BE(entry.secret.byteLength, offset + 4);
      offset += ENTRY_HEADER_BYTES;
      entry.key.copy(frame, offset);
      offset += entry.key.byteLength;
      frame.set(entry.secret, offset);
      offset += entry.secret.byteLength;
    }
    return frame;
  } catch {
    frame.fill(0);
    throw new CredentialBootstrapError("INVALID_FRAME");
  } finally {
    for (const entry of prepared) entry.key.fill(0);
  }
}

export async function acquireCredentialBootstrapFrame(
  references: readonly Readonly<CredentialReference>[],
  source: WorkerCredentialSource,
): Promise<Buffer> {
  const normalized = assertNonEnvironmentCredentialReferences(references);
  const leases: WorkerCredentialLease[] = [];
  try {
    for (const reference of normalized) {
      let lease: WorkerCredentialLease | undefined;
      try {
        lease = await source.acquire(reference);
      } catch {
        throw new CredentialBootstrapError("CREDENTIAL_UNAVAILABLE");
      }
      if (
        lease === undefined
        || !(lease.bytes instanceof Uint8Array)
        || lease.bytes.byteLength < 1
        || lease.bytes.byteLength > MAX_SECRET_BYTES
      ) {
        lease?.dispose();
        throw new CredentialBootstrapError("CREDENTIAL_UNAVAILABLE");
      }
      leases.push(lease);
    }
    return encodeCredentialBootstrapFrame(normalized.map((reference, index) => ({
      reference,
      secret: leases[index]!.bytes,
    })));
  } finally {
    for (const lease of leases) {
      try {
        lease.dispose();
      } catch {
        // The encoded frame remains independently owned and is zeroed by its caller.
      }
    }
  }
}

function fatalUtf8(bytes: Uint8Array): string {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new CredentialBootstrapError("INVALID_FRAME");
  }
}

export class DecodedWorkerCredentials {
  readonly #values: Map<string, Buffer>;
  #disposed = false;

  constructor(values: Map<string, Buffer>) {
    this.#values = values;
  }

  resolve(reference: Readonly<CredentialReference>): string | undefined {
    if (this.#disposed) return undefined;
    const value = this.#values.get(credentialReferenceIdentity(reference));
    if (value === undefined) return undefined;
    const decoded = fatalUtf8(value);
    if (decoded.length === 0 || decoded.includes("\0")) throw new CredentialBootstrapError("INVALID_FRAME");
    return decoded;
  }

  dispose(): void {
    if (this.#disposed) return;
    this.#disposed = true;
    for (const value of this.#values.values()) value.fill(0);
    this.#values.clear();
  }
}

export function decodeCredentialBootstrapFrame(
  frame: Uint8Array,
  expectedReferences: readonly Readonly<CredentialReference>[],
): DecodedWorkerCredentials {
  const expected = assertNonEnvironmentCredentialReferences(expectedReferences);
  if (
    frame.byteLength < HEADER_BYTES
    || frame.byteLength > MAX_CREDENTIAL_BOOTSTRAP_BYTES
    || !Buffer.from(frame.subarray(0, 4)).equals(MAGIC)
    || frame[4] !== PROTOCOL_VERSION
    || frame[5] !== 0
  ) {
    throw new CredentialBootstrapError(frame.byteLength > MAX_CREDENTIAL_BOOTSTRAP_BYTES ? "OVERSIZE" : "INVALID_FRAME");
  }
  const view = Buffer.from(frame.buffer, frame.byteOffset, frame.byteLength);
  const count = view.readUInt16BE(6);
  if (count !== expected.length || count > MAX_CREDENTIALS) {
    throw new CredentialBootstrapError("INVALID_REFERENCE_SET");
  }
  const values = new Map<string, Buffer>();
  let offset = HEADER_BYTES;
  try {
    for (let index = 0; index < count; index += 1) {
      if (offset + ENTRY_HEADER_BYTES > view.byteLength) throw new CredentialBootstrapError("INVALID_FRAME");
      const kind = referenceKind(view.readUInt8(offset));
      if (view.readUInt8(offset + 1) !== 0) throw new CredentialBootstrapError("INVALID_FRAME");
      const keyBytes = view.readUInt16BE(offset + 2);
      const secretBytes = view.readUInt32BE(offset + 4);
      offset += ENTRY_HEADER_BYTES;
      if (
        keyBytes < 1
        || keyBytes > MAX_CREDENTIAL_KEY_BYTES
        || secretBytes < 1
        || secretBytes > MAX_SECRET_BYTES
        || offset + keyBytes + secretBytes > view.byteLength
      ) {
        throw new CredentialBootstrapError("INVALID_FRAME");
      }
      const key = fatalUtf8(view.subarray(offset, offset + keyBytes));
      offset += keyBytes;
      if (!CREDENTIAL_KEY.test(key)) throw new CredentialBootstrapError("INVALID_FRAME");
      const identity = credentialReferenceIdentity({ kind, key });
      if (values.has(identity)) throw new CredentialBootstrapError("INVALID_REFERENCE_SET");
      values.set(identity, Buffer.from(view.subarray(offset, offset + secretBytes)));
      offset += secretBytes;
    }
    if (offset !== view.byteLength) throw new CredentialBootstrapError("INVALID_FRAME");
    const expectedIdentities = new Set(expected.map(credentialReferenceIdentity));
    if (values.size !== expectedIdentities.size || [...values.keys()].some((key) => !expectedIdentities.has(key))) {
      throw new CredentialBootstrapError("INVALID_REFERENCE_SET");
    }
    return new DecodedWorkerCredentials(values);
  } catch (error) {
    for (const value of values.values()) value.fill(0);
    values.clear();
    if (error instanceof CredentialBootstrapError) throw error;
    throw new CredentialBootstrapError("INVALID_FRAME");
  }
}

export function readCredentialBootstrapFrameFromFd(
  fd = 3,
  maximumBytes = MAX_CREDENTIAL_BOOTSTRAP_BYTES,
): Buffer {
  if (!Number.isSafeInteger(maximumBytes) || maximumBytes < HEADER_BYTES || maximumBytes > MAX_CREDENTIAL_BOOTSTRAP_BYTES) {
    throw new CredentialBootstrapError("OVERSIZE");
  }
  const contents = Buffer.alloc(maximumBytes + 1);
  let offset = 0;
  try {
    while (offset < contents.byteLength) {
      const bytesRead = readSync(fd, contents, offset, contents.byteLength - offset, null);
      if (bytesRead === 0) break;
      offset += bytesRead;
    }
    if (offset > maximumBytes) throw new CredentialBootstrapError("OVERSIZE");
    return contents.subarray(0, offset);
  } catch (error) {
    contents.fill(0);
    if (error instanceof CredentialBootstrapError) throw error;
    throw new CredentialBootstrapError("READ_FAILED");
  }
}
