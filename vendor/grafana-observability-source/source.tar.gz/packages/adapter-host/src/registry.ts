import { AdapterContractError, type EvidenceAdapter } from "@codex-production-monitoring/adapter-sdk";
import type { AdapterPackage } from "@codex-production-monitoring/contracts";

import type { AdapterRegistration, AdapterRegistry } from "./types.ts";

/** Immutable, code-owned adapter registry. It has no path- or config-based loader. */
export class StaticAdapterRegistry implements AdapterRegistry {
  readonly #registrations: ReadonlyMap<string, AdapterRegistration>;

  constructor(registrations: readonly AdapterRegistration[]) {
    const indexed = new Map<string, AdapterRegistration>();
    for (const registration of registrations) {
      const packageId = registration.adapterPackage.packageId;
      if (indexed.has(packageId)) throw new AdapterContractError(`Duplicate adapter package: ${packageId}`);
      if (registration.adapter.descriptor.packageId !== packageId) {
        throw new AdapterContractError(`Adapter descriptor/package mismatch: ${packageId}`);
      }
      if (registration.adapter.descriptor.version !== registration.adapterPackage.version) {
        throw new AdapterContractError(`Adapter version/package mismatch: ${packageId}`);
      }
      if (
        registration.adapterPackage.entrypoint.kind === "BUILTIN" &&
        registration.adapterPackage.entrypoint.registryKey.length === 0
      ) {
        throw new AdapterContractError("Built-in adapter registry key cannot be empty");
      }
      indexed.set(packageId, Object.freeze(registration));
    }
    this.#registrations = indexed;
  }

  get(packageId: string): AdapterRegistration {
    const registration = this.#registrations.get(packageId);
    if (registration === undefined) throw new AdapterContractError(`Adapter package is not registered: ${packageId}`);
    return registration;
  }
}

export function builtinRegistration(adapterPackage: AdapterPackage, adapter: EvidenceAdapter): AdapterRegistration {
  if (adapterPackage.entrypoint.kind !== "BUILTIN") {
    throw new AdapterContractError("Built-in registration requires a BUILTIN entrypoint");
  }
  return { adapterPackage, adapter };
}
