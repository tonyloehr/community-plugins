export type UnknownRecord = Record<string, unknown>;

export interface HypothesisEvidenceCount {
  kind: "supporting" | "counter" | "cited";
  count: number;
}

function boundedCountAt(source: UnknownRecord, keys: readonly string[]): number | undefined {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000) {
      return value;
    }
  }
  return undefined;
}

export function hypothesisEvidenceCounts(source: UnknownRecord): HypothesisEvidenceCount[] {
  const supporting = boundedCountAt(source, ["supportingEvidenceCount", "supportCount"]);
  const counter = boundedCountAt(source, ["contradictingEvidenceCount", "counterEvidenceCount", "contradictionCount"]);
  if (supporting !== undefined || counter !== undefined) {
    return [
      ...(supporting === undefined ? [] : [{ kind: "supporting" as const, count: supporting }]),
      ...(counter === undefined ? [] : [{ kind: "counter" as const, count: counter }]),
    ];
  }
  const cited = Array.isArray(source.evidenceRefs) ? source.evidenceRefs.length : 0;
  return [{ kind: "cited", count: cited }];
}

export interface WorkbenchSnapshotLike extends UnknownRecord {
  workspaceId: string;
  stateVersion: number;
  lifecycle: string;
}

export interface SnapshotPollResult {
  snapshot?: WorkbenchSnapshotLike;
  unchanged: boolean;
}

export type WorkbenchDisplayMode = "inline" | "pip" | "fullscreen";

export function preferredPanelDisplayMode(
  available: readonly WorkbenchDisplayMode[],
): Exclude<WorkbenchDisplayMode, "inline"> | undefined {
  if (available.includes("fullscreen")) return "fullscreen";
  if (available.includes("pip")) return "pip";
  return undefined;
}

export function canRequestWorkbenchDisplayMode(
  mode: WorkbenchDisplayMode,
  available: readonly WorkbenchDisplayMode[],
  availabilityKnown: boolean,
  bridgeAvailable: boolean,
): boolean {
  if (available.includes(mode)) return true;
  return !availabilityKnown && bridgeAvailable;
}

export async function requestWorkbenchDisplayModeThroughOneBridge(
  mode: WorkbenchDisplayMode,
  primary?: (mode: WorkbenchDisplayMode) => Promise<WorkbenchDisplayMode | undefined>,
  fallback?: (mode: WorkbenchDisplayMode) => Promise<WorkbenchDisplayMode | undefined>,
): Promise<WorkbenchDisplayMode | undefined> {
  if (primary !== undefined) return primary(mode);
  if (fallback !== undefined) return fallback(mode);
  return undefined;
}

export class AutomaticPanelRequest {
  #attempted = false;

  get attempted(): boolean {
    return this.#attempted;
  }

  consider(options: {
    connected: boolean;
    hasSnapshot: boolean;
    displayMode: WorkbenchDisplayMode;
    requestedMode?: Exclude<WorkbenchDisplayMode, "inline">;
  }): boolean {
    if (this.#attempted) return false;
    if (options.displayMode !== "inline") {
      this.#attempted = true;
      return false;
    }
    if (!options.connected || !options.hasSnapshot || options.requestedMode === undefined) return false;
    this.#attempted = true;
    return true;
  }

  suppress(): void {
    this.#attempted = true;
  }
}

export function resolveDisplayMode(
  requested: WorkbenchDisplayMode,
  granted: unknown,
  available: readonly WorkbenchDisplayMode[],
): WorkbenchDisplayMode {
  if (granted === "inline" || granted === "pip" || granted === "fullscreen") {
    return granted;
  }
  return requested === "inline" && available.includes("inline") ? "inline" : "inline";
}

export function safeWorkbenchExternalUrl(value: unknown): string | undefined {
  if (typeof value !== "string" || value.length > 2_048) return undefined;
  try {
    const parsed = new URL(value);
    const localHttp = parsed.protocol === "http:"
      && ["localhost", "127.0.0.1", "[::1]"].includes(parsed.hostname);
    if ((parsed.protocol !== "https:" && !localHttp) || parsed.username !== "" || parsed.password !== "") {
      return undefined;
    }
    return parsed.href;
  } catch {
    return undefined;
  }
}

export interface PollingScheduler {
  set(callback: () => void, delayMs: number): unknown;
  clear(handle: unknown): void;
}

export interface WorkbenchPollingOptions {
  fetchSnapshot: (afterStateVersion: number, signal: AbortSignal) => Promise<SnapshotPollResult>;
  onSnapshot: (snapshot: WorkbenchSnapshotLike) => void;
  onError?: (error: unknown) => void;
  isVisible?: () => boolean;
  scheduler?: PollingScheduler;
  minimumDelayMs?: number;
  maximumDelayMs?: number;
}

export type PatchHandoffState = "REQUESTED" | "HANDOFF_COMPLETE";

export class PatchHandoffPresentation {
  #current: { workspaceId: string; stateVersion: number; state: PatchHandoffState } | undefined;

  stateFor(snapshot: Pick<WorkbenchSnapshotLike, "workspaceId" | "stateVersion">): PatchHandoffState | undefined {
    return this.#current?.workspaceId === snapshot.workspaceId
      && this.#current.stateVersion === snapshot.stateVersion
      ? this.#current.state
      : undefined;
  }

  request(snapshot: Pick<WorkbenchSnapshotLike, "workspaceId" | "stateVersion">): boolean {
    if (this.stateFor(snapshot) !== undefined) return false;
    this.#current = { ...snapshot, state: "REQUESTED" };
    return true;
  }

  complete(snapshot: Pick<WorkbenchSnapshotLike, "workspaceId" | "stateVersion">): void {
    if (this.stateFor(snapshot) !== "REQUESTED") return;
    this.#current = { ...snapshot, state: "HANDOFF_COMPLETE" };
  }

  fail(snapshot: Pick<WorkbenchSnapshotLike, "workspaceId" | "stateVersion">): void {
    if (this.stateFor(snapshot) !== undefined) this.#current = undefined;
  }

  authorityChanged(snapshot: Pick<WorkbenchSnapshotLike, "workspaceId" | "stateVersion">): void {
    if (this.#current !== undefined && this.stateFor(snapshot) === undefined) this.#current = undefined;
  }
}

const TERMINAL_LIFECYCLES = new Set(["SEALED", "PARTIAL", "BLOCKED", "CANCELLED"]);
const WORKSPACE_ID = /^pmws_[A-Za-z0-9_-]{20,128}$/u;

export function sanitizeWorkbenchText(value: string, limit = 420): string {
  const sanitized = value.trim()
    .replaceAll(/\bpm(?:bundle|ev|h|run|ws|view|link)_[A-Za-z0-9_-]+\b/gu, "[internal reference hidden]")
    .replaceAll(/\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b/giu, "[identifier hidden]")
    .replaceAll(/\b(?:sha(?:1|256|512):?)?[0-9a-f]{40,128}\b/giu, "[integrity value hidden]")
    .replaceAll(/\b(?:sk|ghp|glpat)-[A-Za-z0-9_-]{16,}\b/gu, "[credential hidden]")
    .replaceAll(/\bBearer\s+[A-Za-z0-9._~+/-]{12,}={0,2}\b/giu, "[credential hidden]")
    .replaceAll(/\b(?:https?|file):\/\/[^\s<>]+/giu, "[source link available]")
    .replaceAll(/(?:^|\s)(?:\/[A-Za-z0-9._-]+){2,}(?=$|[\s,.;:)])/gu, " [local path hidden]")
    .replaceAll(/\b[A-Za-z]:\\(?:[^\s<>:"|?*]+\\)+[^\s<>:"|?*]*/gu, "[local path hidden]");
  return sanitized.length > limit ? `${sanitized.slice(0, limit - 1)}…` : sanitized;
}

function isRecord(value: unknown): value is UnknownRecord {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

export function readSnapshot(value: unknown): WorkbenchSnapshotLike | undefined {
  const envelope = isRecord(value) ? value : undefined;
  const nested = envelope === undefined ? undefined : envelope.snapshot;
  const candidate = isRecord(nested) ? nested : envelope;
  if (
    candidate === undefined
    || typeof candidate.workspaceId !== "string"
    || !WORKSPACE_ID.test(candidate.workspaceId)
    || !Number.isSafeInteger(candidate.stateVersion)
    || (candidate.stateVersion as number) < 1
    || typeof candidate.lifecycle !== "string"
  ) {
    return undefined;
  }
  return candidate as WorkbenchSnapshotLike;
}

export function isTerminalSnapshot(snapshot: WorkbenchSnapshotLike): boolean {
  return TERMINAL_LIFECYCLES.has(snapshot.lifecycle.toUpperCase());
}

export class MonotonicSnapshotState {
  #current: WorkbenchSnapshotLike | undefined;

  get current(): WorkbenchSnapshotLike | undefined {
    return this.#current === undefined ? undefined : structuredClone(this.#current);
  }

  isCurrentAuthority(value: Pick<WorkbenchSnapshotLike, "workspaceId" | "stateVersion">): boolean {
    return this.#current?.workspaceId === value.workspaceId
      && this.#current.stateVersion === value.stateVersion;
  }

  accept(value: unknown): boolean {
    const candidate = readSnapshot(value);
    if (candidate === undefined) return false;
    if (this.#current !== undefined) {
      if (candidate.workspaceId !== this.#current.workspaceId) return false;
      if (candidate.stateVersion <= this.#current.stateVersion) return false;
    }
    this.#current = structuredClone(candidate);
    return true;
  }
}

const browserScheduler: PollingScheduler = {
  set: (callback, delayMs) => globalThis.setTimeout(callback, delayMs),
  clear: (handle) => globalThis.clearTimeout(handle as ReturnType<typeof setTimeout>),
};

export class WorkbenchPollingController {
  readonly #fetchSnapshot: WorkbenchPollingOptions["fetchSnapshot"];
  readonly #onSnapshot: WorkbenchPollingOptions["onSnapshot"];
  readonly #onError: NonNullable<WorkbenchPollingOptions["onError"]>;
  readonly #isVisible: NonNullable<WorkbenchPollingOptions["isVisible"]>;
  readonly #scheduler: PollingScheduler;
  readonly #minimumDelayMs: number;
  readonly #maximumDelayMs: number;
  #abortController: AbortController | undefined;
  #timer: unknown;
  #stateVersion = 0;
  #terminal = false;
  #stopped = true;
  #delayMs: number;
  #requestSequence = 0;
  #appliedSequence = 0;

  constructor(options: WorkbenchPollingOptions) {
    this.#fetchSnapshot = options.fetchSnapshot;
    this.#onSnapshot = options.onSnapshot;
    this.#onError = options.onError ?? (() => undefined);
    this.#isVisible = options.isVisible ?? (() => true);
    this.#scheduler = options.scheduler ?? browserScheduler;
    this.#minimumDelayMs = options.minimumDelayMs ?? 1_500;
    this.#maximumDelayMs = options.maximumDelayMs ?? 12_000;
    if (
      !Number.isFinite(this.#minimumDelayMs)
      || !Number.isFinite(this.#maximumDelayMs)
      || this.#minimumDelayMs < 100
      || this.#maximumDelayMs < this.#minimumDelayMs
    ) {
      throw new TypeError("Polling delays are invalid");
    }
    this.#delayMs = this.#minimumDelayMs;
  }

  get stopped(): boolean {
    return this.#stopped;
  }

  get stateVersion(): number {
    return this.#stateVersion;
  }

  start(initial?: WorkbenchSnapshotLike): void {
    this.stop();
    this.#stopped = false;
    this.#terminal = false;
    this.#delayMs = this.#minimumDelayMs;
    if (initial !== undefined) this.observe(initial);
    if (!this.#terminal) this.#schedule(this.#minimumDelayMs);
  }

  observe(snapshot: WorkbenchSnapshotLike): boolean {
    if (snapshot.stateVersion <= this.#stateVersion) return false;
    this.#stateVersion = snapshot.stateVersion;
    this.#terminal = isTerminalSnapshot(snapshot);
    this.#delayMs = this.#minimumDelayMs;
    this.#onSnapshot(structuredClone(snapshot));
    if (this.#terminal) this.#clearScheduled();
    return true;
  }

  refresh(force = false): Promise<void> {
    if (this.#stopped || (this.#terminal && !force)) return Promise.resolve();
    this.#clearScheduled();
    return this.#poll(force);
  }

  visibilityChanged(): void {
    if (this.#stopped || this.#terminal) return;
    if (this.#isVisible()) {
      void this.refresh();
    } else {
      this.#abortController?.abort();
      this.#abortController = undefined;
      this.#clearScheduled();
    }
  }

  stop(): void {
    this.#stopped = true;
    this.#abortController?.abort();
    this.#abortController = undefined;
    this.#clearScheduled();
  }

  #clearScheduled(): void {
    if (this.#timer !== undefined) this.#scheduler.clear(this.#timer);
    this.#timer = undefined;
  }

  #schedule(delayMs: number): void {
    if (this.#stopped || this.#terminal || !this.#isVisible()) return;
    this.#clearScheduled();
    this.#timer = this.#scheduler.set(() => {
      this.#timer = undefined;
      void this.#poll();
    }, delayMs);
  }

  async #poll(force = false): Promise<void> {
    if (this.#stopped || (this.#terminal && !force) || !this.#isVisible()) return;
    this.#abortController?.abort();
    const controller = new AbortController();
    this.#abortController = controller;
    const sequence = ++this.#requestSequence;
    try {
      const result = await this.#fetchSnapshot(this.#stateVersion, controller.signal);
      if (controller.signal.aborted || this.#stopped || sequence < this.#appliedSequence) return;
      this.#appliedSequence = sequence;
      const accepted = result.snapshot === undefined ? false : this.observe(result.snapshot);
      if (!accepted) {
        this.#delayMs = Math.min(this.#maximumDelayMs, Math.ceil(this.#delayMs * 1.6));
      }
    } catch (error) {
      if (!controller.signal.aborted && !this.#stopped) {
        this.#onError(error);
        this.#delayMs = Math.min(this.#maximumDelayMs, Math.ceil(this.#delayMs * 2));
      }
    } finally {
      if (this.#abortController === controller) this.#abortController = undefined;
      if (sequence === this.#requestSequence) this.#schedule(this.#delayMs);
    }
  }
}
