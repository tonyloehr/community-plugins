import {
  App,
  applyDocumentTheme,
  applyHostStyleVariables,
} from "@modelcontextprotocol/ext-apps";

import {
  AutomaticPanelRequest,
  MonotonicSnapshotState,
  PatchHandoffPresentation,
  WorkbenchPollingController,
  canRequestWorkbenchDisplayMode,
  hypothesisEvidenceCounts,
  preferredPanelDisplayMode,
  readSnapshot,
  requestWorkbenchDisplayModeThroughOneBridge,
  resolveDisplayMode,
  safeWorkbenchExternalUrl,
  sanitizeWorkbenchText,
  type UnknownRecord,
  type WorkbenchSnapshotLike,
} from "./state.ts";

type DisplayMode = "inline" | "pip" | "fullscreen";
type HostContext = {
  theme?: "light" | "dark";
  displayMode?: DisplayMode;
  availableDisplayModes?: DisplayMode[];
  styles?: { variables?: Parameters<typeof applyHostStyleVariables>[0] };
};
type OpenAiHost = {
  requestDisplayMode?: (request: { mode: DisplayMode }) => Promise<{ mode?: DisplayMode }>;
  sendFollowUpMessage?: (request: { prompt: string }) => Promise<void> | void;
};

const rootCandidate = document.querySelector<HTMLElement>("#app");
if (rootCandidate === null) throw new Error("Production Monitoring workbench root is missing");
const root: HTMLElement = rootCandidate;

const state = new MonotonicSnapshotState();
const patchHandoff = new PatchHandoffPresentation();
const automaticPanelRequest = new AutomaticPanelRequest();
let app: App | undefined;
let appConnected = false;
let poller: WorkbenchPollingController | undefined;
let displayMode: DisplayMode = "inline";
let availableDisplayModes: DisplayMode[] = ["inline"];
let availableDisplayModesKnown = false;
let selectedSection = "overview";
let busyAction: string | undefined;
let asyncActionSequence = 0;
let displayModeRequestSequence = 0;
let displayModeRequestPending = false;
let displayModeAuthorityVersion = 0;
let transientMessage: string | undefined;
let panelNotice: string | undefined;
let evidenceDetail: UnknownRecord | undefined;
let evidenceDetailTitle = "Evidence detail";
let evidenceDetailLinks: Array<{ linkRef: string; label: string }> = [];
let evidenceKeys = new Map<string, string>();
let linkKeys = new Map<string, string>();

function beginAsyncAction(action: string): number {
  busyAction = action;
  asyncActionSequence += 1;
  return asyncActionSequence;
}

function continuationIsCurrent(sequence: number, snapshot: WorkbenchSnapshotLike): boolean {
  return sequence === asyncActionSequence && state.isCurrentAuthority(snapshot);
}

function invalidateAsyncActions(): void {
  asyncActionSequence += 1;
  busyAction = undefined;
  transientMessage = undefined;
}

function renderCurrentAuthority(): void {
  const current = state.current;
  if (current === undefined) renderWaiting(); else renderSnapshot(current);
}

const monitorIcon = `
  <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8">
    <path d="M3.5 12h3l2-5 3.4 10 2.8-7 1.8 2h4" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="2.5" y="3" width="19" height="18" rx="5" opacity=".34"/>
  </svg>`;

function asRecord(value: unknown): UnknownRecord | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as UnknownRecord
    : undefined;
}

function recordAt(source: UnknownRecord | undefined, key: string): UnknownRecord | undefined {
  return asRecord(source?.[key]);
}

function arrayAt(source: UnknownRecord | undefined, key: string): unknown[] {
  const candidate = source?.[key];
  return Array.isArray(candidate) ? candidate : [];
}

function stringAt(source: UnknownRecord | undefined, keys: readonly string[], limit?: number): string | undefined {
  if (source === undefined) return undefined;
  for (const key of keys) {
    const candidate = source[key];
    if (typeof candidate === "string" && candidate.trim().length > 0) {
      return sanitizeWorkbenchText(candidate, limit);
    }
  }
  return undefined;
}

function numberAt(source: UnknownRecord | undefined, keys: readonly string[]): number | undefined {
  if (source === undefined) return undefined;
  for (const key of keys) {
    const candidate = source[key];
    if (typeof candidate === "number" && Number.isFinite(candidate)) return candidate;
  }
  return undefined;
}

function escapeHtml(value: string): string {
  return value.replaceAll(/[&<>"']/gu, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#39;",
  })[character] ?? character);
}

function humanize(value: string): string {
  const normalized = value.replaceAll(/[_-]+/gu, " ").trim().toLowerCase();
  return normalized.replace(/(^|\s)\p{L}/gu, (match) => match.toUpperCase());
}

function tone(value: string | undefined): "positive" | "caution" | "critical" | "neutral" {
  const normalized = value?.toUpperCase();
  if (["AVAILABLE", "COMPLETE", "FRESH", "GOOD", "HEALTHY", "PASS", "READY", "RECOVERED", "SEALED", "SUPPORTED"].includes(normalized ?? "")) return "positive";
  if (["APPROVAL_REQUIRED", "DEGRADED", "IN_PROGRESS", "OPEN", "PARTIAL", "RECOVERING", "REQUESTED", "STALE", "WARNING", "WEAKENED"].includes(normalized ?? "")) return "caution";
  if (["ACTION_FAILED", "BLOCKED", "CANCELLED", "ERROR", "FAILED", "NOT_RECOVERED", "REJECTED", "UNAVAILABLE"].includes(normalized ?? "")) return "critical";
  return "neutral";
}

function statusPill(value: string | undefined): string {
  const label = value === undefined ? "Unknown" : humanize(value);
  return `<span class="status ${tone(value)}"><span class="status-dot" aria-hidden="true"></span>${escapeHtml(label)}</span>`;
}

function originPill(origin: string | undefined): string {
  const normalized = origin?.toUpperCase();
  if (normalized === "SIMULATED") return '<span class="origin simulated">Simulated</span>';
  if (normalized === "REPLAY") return '<span class="origin replay">Replay</span>';
  if (normalized === "LIVE") return '<span class="origin live">Live · providers read-only</span>';
  return '<span class="origin neutral">No evidence yet</span>';
}

function formatTime(value: string | undefined): string {
  if (value === undefined) return "Not yet updated";
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return sanitizeWorkbenchText(value, 80);
  return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit", second: "2-digit" }).format(date);
}

function sectionButton(id: string, label: string): string {
  return `<button id="tab-${id}" class="tab" type="button" role="tab" data-section="${id}" aria-controls="workbench-panel" aria-selected="${String(selectedSection === id)}" tabindex="${selectedSection === id ? "0" : "-1"}">${label}</button>`;
}

function compactCount(value: number | undefined): string {
  return value === undefined ? "—" : new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(value);
}

function snapshotScope(snapshot: WorkbenchSnapshotLike): { service: string; environment: string } {
  const scope = recordAt(snapshot, "scope");
  return {
    service: stringAt(scope, ["service", "serviceLabel"], 80) ?? "Service not scoped",
    environment: stringAt(scope, ["environment", "environmentLabel"], 60) ?? "Environment unknown",
  };
}

function visibleSignals(snapshot: WorkbenchSnapshotLike): UnknownRecord[] {
  return arrayAt(snapshot, "signals").flatMap((item) => {
    const record = asRecord(item);
    return record === undefined ? [] : [record];
  }).slice(0, 3);
}

function visibleHypotheses(snapshot: WorkbenchSnapshotLike): UnknownRecord[] {
  return arrayAt(snapshot, "hypotheses").flatMap((item) => {
    const record = asRecord(item);
    return record === undefined ? [] : [record];
  }).slice(0, 3);
}

function phaseRail(snapshot: WorkbenchSnapshotLike): string {
  const phases = [
    ["READINESS", "Preflight"], ["SCOPING", "Scope"], ["BASELINE", "Baseline"],
    ["COLLECTING", "Evidence"], ["COMPARING", "Compare"], ["ANALYZING", "Analysis"],
    ["FINALIZING", "Finalizing"], ["PATCHING", "Patch"], ["VERIFYING", "Verify"],
  ] as const;
  const activeIndex = Math.max(0, phases.findIndex(([value]) => value === String(snapshot.phase).toUpperCase()));
  return `<div class="phase-summary" aria-label="Current investigation phase"><span>Step ${activeIndex + 1} of ${phases.length}</span><strong>${phases[activeIndex]![1]}</strong></div><ol class="phase-rail" aria-label="Investigation progress">${phases.map(([, label], index) => {
    const stateLabel = index < activeIndex ? "complete" : index === activeIndex ? "current" : "upcoming";
    return `<li class="${stateLabel}" ${index === activeIndex ? 'aria-current="step"' : ""}><span aria-hidden="true"></span><small>${label}</small></li>`;
  }).join("")}</ol>`;
}

function statusMatrix(snapshot: WorkbenchSnapshotLike): string {
  const status = recordAt(snapshot, "status");
  const items = [
    ["Service", stringAt(status, ["service"])],
    ["Evidence", stringAt(status, ["collection", "evidence"])],
    ["Causality", stringAt(status, ["causality"])],
    ["Recovery", stringAt(status, ["recovery"])],
  ];
  return `<section class="status-matrix" aria-label="Incident status">${items.map(([label, value]) => `
    <div><span class="matrix-label">${label}</span>${statusPill(value)}</div>`).join("")}</section>`;
}

function signalCards(snapshot: WorkbenchSnapshotLike): string {
  const signals = visibleSignals(snapshot);
  if (signals.length === 0) return '<div class="empty"><strong>No incident signals yet</strong><span>Evidence appears here as reviewed operations complete.</span></div>';
  return `<ol class="signal-list">${signals.map((signal) => {
    const title = stringAt(signal, ["label", "title", "name", "summary"], 140) ?? "Reviewed signal";
    const value = stringAt(signal, ["displayValue", "value", "reading"], 80) ?? "Unavailable";
    const direction = stringAt(signal, ["direction"]);
    const detail = stringAt(signal, ["change", "changeLabel", "detail", "freshnessSummary"], 160)
      ?? (direction === undefined || direction === "UNKNOWN" ? undefined : `Direction ${humanize(direction)}`);
    const status = stringAt(signal, ["status", "freshness", "state", "severity"]);
    return `<li class="signal-card"><div class="signal-top"><span>${escapeHtml(title)}</span>${statusPill(status)}</div><strong>${escapeHtml(value)}</strong>${detail === undefined ? "" : `<small>${escapeHtml(detail)}</small>`}</li>`;
  }).join("")}</ol>`;
}

function hypothesisCards(snapshot: WorkbenchSnapshotLike): string {
  const hypotheses = visibleHypotheses(snapshot);
  if (hypotheses.length === 0) return '<div class="empty"><strong>No ranked hypotheses yet</strong><span>Codex will keep unknowns explicit until evidence supports a mechanism.</span></div>';
  return `<ol class="hypothesis-list">${hypotheses.map((hypothesis, index) => {
    const statement = stringAt(hypothesis, ["statement", "title", "summary"], 260) ?? "Hypothesis awaiting review";
    const status = stringAt(hypothesis, ["status", "state"]);
    const evidenceCounts = hypothesisEvidenceCounts(hypothesis)
      .map(({ kind, count }) => `<span>${compactCount(count)} ${kind === "cited" ? "cited evidence" : kind}</span>`)
      .join("");
    return `<li><div class="rank">${index + 1}</div><div><div class="hypothesis-title">${escapeHtml(statement)}</div><div class="hypothesis-meta">${statusPill(status)}${evidenceCounts}</div></div></li>`;
  }).join("")}</ol>`;
}

function rememberReference(map: Map<string, string>, value: unknown, pattern: RegExp): string | undefined {
  if (typeof value !== "string" || !pattern.test(value)) return undefined;
  const key = String(map.size);
  map.set(key, value);
  return key;
}

function evidenceCards(snapshot: WorkbenchSnapshotLike): string {
  const evidence = arrayAt(snapshot, "evidence").flatMap((item) => {
    const record = asRecord(item);
    return record === undefined ? [] : [record];
  }).slice(0, 32);
  if (evidence.length === 0) return '<div class="empty"><strong>No evidence collected</strong><span>Missing evidence is never treated as a healthy zero.</span></div>';
  return `<ul class="evidence-list">${evidence.map((item) => {
    const title = stringAt(item, ["label", "title", "summary", "operationLabel"], 180) ?? "Reviewed evidence";
    const source = stringAt(item, ["source", "provider", "sourceLabel", "domain"], 80) ?? "Configured source";
    const status = stringAt(item, ["status", "freshness", "state"]);
    const evidenceKey = rememberReference(evidenceKeys, item.evidenceRef ?? item.ref, /^pmwsev_[A-Za-z0-9_-]{20,128}$/u);
    return `<li><div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(source)}</span></div><div class="evidence-actions">${statusPill(status)}${evidenceKey === undefined ? "" : `<button type="button" class="text-button" data-evidence-key="${evidenceKey}">Inspect</button>`}</div></li>`;
  }).join("")}</ul>`;
}

function activityItems(snapshot: WorkbenchSnapshotLike): string {
  const items = arrayAt(snapshot, "activity").flatMap((item) => {
    const record = asRecord(item);
    return record === undefined ? [] : [record];
  }).slice(-12).reverse();
  if (items.length === 0) return '<div class="empty"><strong>No recorded activity yet</strong><span>Only meaningful lifecycle changes appear here.</span></div>';
  return `<ol class="activity-list">${items.map((item) => {
    const label = stringAt(item, ["summary", "label", "title", "phase"], 200) ?? "Workbench updated";
    const status = stringAt(item, ["status", "state"]);
    const at = stringAt(item, ["at", "time", "timestamp"], 60);
    return `<li><span class="activity-marker ${tone(status)}" aria-hidden="true"></span><div><strong>${escapeHtml(label)}</strong><small>${formatTime(at)}</small></div></li>`;
  }).join("")}</ol>`;
}

function patchPanel(snapshot: WorkbenchSnapshotLike): string {
  const patch = recordAt(snapshot, "patch");
  const authoritativeStatus = stringAt(patch, ["status", "state"]) ?? "NOT_ELIGIBLE";
  const status = patchHandoff.stateFor(snapshot) ?? authoritativeStatus;
  const summary = stringAt(patch, ["summary", "reason", "limitation"], 320)
    ?? (status === "ELIGIBLE"
      ? "A sealed, supported mechanism has enough bounded context for a local remediation handoff."
      : "Patch preparation becomes available only after a sealed incident supports a mechanism without blocking contradictions.");
  const eligible = status === "ELIGIBLE";
  const requested = ["REQUESTED", "HANDOFF_COMPLETE"].includes(status);
  return `<section class="patch-card"><div class="patch-icon" aria-hidden="true">⌁</div><div><p class="eyebrow">Local remediation handoff</p><h2>${eligible ? "Generate the smallest reviewable patch" : requested ? "Patch handoff sent to Codex" : "Patch preparation is gated"}</h2><p>${escapeHtml(summary)}</p><div class="patch-meta">${statusPill(status)}<span>No deploy · No restart · No provider write</span></div>${eligible ? `<button type="button" class="primary" data-action="generate-patch" ${busyAction === "generate-patch" ? "disabled" : ""}>${busyAction === "generate-patch" ? "Sending…" : "Generate patch"}</button>` : ""}</div></section>`;
}

function recoveryPanel(snapshot: WorkbenchSnapshotLike): string {
  const status = recordAt(snapshot, "status");
  const recovery = stringAt(status, ["recovery"]) ?? "NOT_ASSESSED";
  const limitations = arrayAt(snapshot, "limitations")
    .filter((item): item is string => typeof item === "string")
    .slice(0, 8)
    .map((item) => `<li>${escapeHtml(sanitizeWorkbenchText(item, 260))}</li>`)
    .join("");
  return `<section class="recovery-card"><div class="section-heading"><div><p class="eyebrow">Recovery contract</p><h2>${escapeHtml(humanize(recovery))}</h2></div>${statusPill(recovery)}</div><p>A passing local test does not prove production recovery. Recovery is reported only from fresh, sealed verification evidence.</p>${limitations.length === 0 ? "" : `<h3>Current limitations</h3><ul>${limitations}</ul>`}</section>`;
}

function nextAction(snapshot: WorkbenchSnapshotLike): string {
  const action = recordAt(snapshot, "nextAction");
  const label = stringAt(action, ["label", "title", "summary"], 120);
  const reason = stringAt(action, ["reason", "detail", "description"], 260);
  if (label === undefined && reason === undefined) return "";
  return `<section class="next-action"><p class="eyebrow">Smallest safe next action</p><strong>${escapeHtml(label ?? "Continue the bounded investigation")}</strong>${reason === undefined ? "" : `<span>${escapeHtml(reason)}</span>`}</section>`;
}

function coverage(snapshot: WorkbenchSnapshotLike): string {
  const progress = recordAt(snapshot, "progress");
  const completed = numberAt(progress, ["completedOperations"]);
  const required = numberAt(progress, ["requiredOperations"]);
  const evidence = arrayAt(snapshot, "evidence");
  const countBy = (values: string[]) => evidence.filter((item) => {
    const record = asRecord(item);
    const value = stringAt(record, ["status", "freshness", "state"]);
    return value !== undefined && values.includes(value.toUpperCase());
  }).length;
  const complete = countBy(["COMPLETE", "FRESH", "AVAILABLE"]);
  const limited = countBy(["EMPTY", "STALE", "CONTRADICTORY", "ERROR", "UNAVAILABLE"]);
  return `<section class="coverage"><div><span>Operations</span><strong>${compactCount(completed)} / ${compactCount(required)}</strong></div><div><span>Available evidence</span><strong>${complete}</strong></div><div><span>Limited evidence</span><strong>${limited}</strong></div></section>`;
}

function detailDrawer(): string {
  if (evidenceDetail === undefined) return "";
  const summary = stringAt(evidenceDetail, ["summary", "statement", "detail", "message"], 700) ?? "No additional normalized detail is available.";
  const source = recordAt(evidenceDetail, "source");
  const provider = stringAt(evidenceDetail, ["provider", "sourceLabel"], 100)
    ?? stringAt(source, ["provider", "sourceAlias"], 100);
  const status = stringAt(evidenceDetail, ["status", "freshness", "state"]);
  const values = arrayAt(evidenceDetail, "values").slice(0, 8).flatMap((item) => {
    const value = asRecord(item);
    if (value === undefined) return [];
    const kind = stringAt(value, ["kind"]);
    const label = stringAt(value, ["label", "summary"], 140) ?? "Normalized value";
    const raw = value.value;
    const unit = stringAt(value, ["unit"], 32);
    const rendered = typeof raw === "number" && unit?.toLowerCase() === "ratio"
      ? `${new Intl.NumberFormat(undefined, { style: "percent", maximumFractionDigits: 2 }).format(raw)}`
      : typeof raw === "number" && unit !== undefined
        ? `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 3 }).format(raw)} ${unit}`
        : typeof raw === "string"
          ? sanitizeWorkbenchText(raw, 160)
          : typeof raw === "number" || typeof raw === "boolean" || raw === null
            ? String(raw ?? "Unavailable")
            : kind === "EVENT"
              ? formatTime(stringAt(value, ["at"], 80))
              : `${arrayAt(value, "points").length} bounded points`;
    return [`<li><span>${escapeHtml(label)}</span><strong>${escapeHtml(rendered)}</strong></li>`];
  }).join("");
  const sourceLinks = evidenceDetailLinks.flatMap(({ linkRef, label }) => {
    const key = rememberReference(linkKeys, linkRef, /^pmwslnk_[A-Za-z0-9_-]{20,128}$/u);
    return key === undefined
      ? []
      : [`<button type="button" class="secondary" data-link-key="${key}">${escapeHtml(label)}</button>`];
  }).join("");
  return `<aside class="drawer" role="dialog" aria-modal="true" aria-labelledby="drawer-title"><div class="drawer-head"><div><p class="eyebrow">Normalized, bounded evidence</p><h2 id="drawer-title">${escapeHtml(evidenceDetailTitle)}</h2></div><button type="button" class="icon-button" data-action="close-drawer" aria-label="Close evidence detail">×</button></div><div class="drawer-body">${statusPill(status)}${provider === undefined ? "" : `<p class="drawer-source">Source: ${escapeHtml(provider)}</p>`}<p>${escapeHtml(summary)}</p>${values.length === 0 ? "" : `<ul class="drawer-values">${values}</ul>`}${sourceLinks.length === 0 ? "" : `<div class="drawer-links" aria-label="Available reviewed source links">${sourceLinks}</div>`}<p class="drawer-note">Raw payloads, credentials, internal references, local paths, and integrity values are withheld.</p></div></aside><button class="scrim" type="button" data-action="close-drawer" aria-label="Close evidence detail"></button>`;
}

function sectionContent(snapshot: WorkbenchSnapshotLike): string {
  if (selectedSection === "evidence") return `<section class="panel-section"><div class="section-heading"><div><p class="eyebrow">Evidence</p><h2>Reviewed source coverage</h2></div></div>${coverage(snapshot)}${evidenceCards(snapshot)}</section>`;
  if (selectedSection === "hypotheses") return `<section class="panel-section"><div class="section-heading"><div><p class="eyebrow">Hypotheses</p><h2>Ranked explanations</h2></div></div>${hypothesisCards(snapshot)}<p class="section-note">Supported means the cited evidence fits the mechanism. It is not a claim of absolute root cause.</p></section>`;
  if (selectedSection === "patch") return patchPanel(snapshot);
  if (selectedSection === "recovery") return recoveryPanel(snapshot);
  return `<section class="overview-grid"><div class="panel-section"><div class="section-heading"><div><p class="eyebrow">Incident pulse</p><h2>What changed</h2></div></div>${signalCards(snapshot)}</div><div class="panel-section"><div class="section-heading"><div><p class="eyebrow">Top explanations</p><h2>What the evidence supports</h2></div></div>${hypothesisCards(snapshot)}</div></section>${coverage(snapshot)}${nextAction(snapshot)}<details class="activity"><summary>Technical activity <span>${arrayAt(snapshot, "activity").length}</span></summary>${activityItems(snapshot)}</details>`;
}

function actionButtons(): string {
  const pip = canRequestPanel();
  const sidePanelMode = panelDisplayMode();
  const fullscreen = sidePanelMode !== "fullscreen" && canRequestDisplayMode("fullscreen");
  const modeDisabled = displayModeDisabledAttribute();
  const refresh = state.current === undefined
    ? ""
    : `<button type="button" class="icon-button" data-action="refresh" aria-label="Refresh verified workbench state" title="Refresh" ${busyAction === "refresh" ? "disabled" : ""}>↻</button>`;
  if (refresh.length === 0 && !pip && !fullscreen) return "";
  return `<div class="display-actions">${refresh}${pip ? `<button type="button" class="icon-button" data-mode="${sidePanelMode}" aria-label="Open Production Monitoring side panel" title="Open side panel"${modeDisabled}>⌑</button>` : ""}${fullscreen ? `<button type="button" class="icon-button" data-mode="fullscreen" aria-label="Open fullscreen workbench" title="Open fullscreen"${modeDisabled}>↗</button>` : ""}</div>`;
}

function displayModeDisabledAttribute(): string {
  return displayModeRequestPending ? " disabled" : "";
}

function renderSnapshot(snapshot: WorkbenchSnapshotLike): void {
  evidenceKeys = new Map();
  linkKeys = new Map();
  const scope = snapshotScope(snapshot);
  const status = recordAt(snapshot, "status");
  const serviceStatus = stringAt(status, ["service"]) ?? snapshot.lifecycle;
  const origin = stringAt(snapshot, ["origin"]);
  const phase = stringAt(snapshot, ["phase"]) ?? "READINESS";
  const modeDisabled = displayModeDisabledAttribute();
  const sidePanelMode = panelDisplayMode();
  root.dataset.mode = displayMode;
  document.documentElement.dataset.displayMode = displayMode;
  root.innerHTML = `
    <article class="workbench">
      <header class="workbench-header">
        <div class="identity"><span class="brand-mark">${monitorIcon}</span><div><p class="eyebrow">Production Monitoring</p><h1>${escapeHtml(scope.service)}</h1><p>${escapeHtml(scope.environment)} · ${escapeHtml(humanize(phase))}</p></div></div>
        <div class="header-right"><div class="header-badges">${originPill(origin)}${statusPill(serviceStatus)}</div>${actionButtons()}</div>
      </header>
      <div class="freshness"><span class="pulse ${tone(serviceStatus)}" aria-hidden="true"></span><span>Updated ${escapeHtml(formatTime(stringAt(snapshot, ["asOf"], 80)))}</span><span aria-hidden="true">·</span><span>Version ${snapshot.stateVersion}</span></div>
      <div class="inline-summary"><div>${statusMatrix(snapshot)}</div>${panelNotice === undefined ? "" : `<p class="panel-notice" role="status">${escapeHtml(panelNotice)}</p>`}<div class="inline-actions">${canRequestPanel() ? `<button type="button" class="primary" data-mode="${sidePanelMode}"${modeDisabled}>Open side panel</button>` : ""}${sidePanelMode !== "fullscreen" && canRequestDisplayMode("fullscreen") ? `<button type="button" class="secondary" data-mode="fullscreen"${modeDisabled}>Open workbench</button>` : ""}</div></div>
      <div class="expanded-workbench">
        ${phaseRail(snapshot)}
        ${statusMatrix(snapshot)}
        <nav class="tabs" role="tablist" aria-label="Workbench sections">${sectionButton("overview", "Overview")}${sectionButton("evidence", "Evidence")}${sectionButton("hypotheses", "Hypotheses")}${sectionButton("patch", "Patch")}${sectionButton("recovery", "Recovery")}</nav>
        <main class="workbench-content" id="workbench-panel" role="tabpanel" aria-labelledby="tab-${selectedSection}" tabindex="0">${sectionContent(snapshot)}</main>
      </div>
      <footer><span>Evidence-driven · Missing data stays unknown</span><span>No production mutations</span></footer>
      <div class="announcer" aria-live="polite">${transientMessage === undefined ? "" : escapeHtml(transientMessage)}</div>
    </article>${detailDrawer()}`;
}

function renderWaiting(message = "Open the workbench from a monitoring profile to bind a read-only incident view."): void {
  root.dataset.mode = displayMode;
  root.innerHTML = `<article class="workbench waiting"><header class="workbench-header"><div class="identity"><span class="brand-mark">${monitorIcon}</span><div><p class="eyebrow">Production Monitoring</p><h1>Incident workbench</h1><p>Read-only monitoring evidence and Codex reasoning</p></div></div>${actionButtons()}</header><section class="waiting-body"><span class="waiting-ring" aria-hidden="true"></span><h2>Waiting for a bounded workspace</h2><p>${escapeHtml(message)}</p></section><footer><span>Providers stay read-only</span><span>Missing evidence is explicit</span></footer></article>`;
}

function applyHostContext(context: HostContext | undefined): void {
  if (context?.theme !== undefined) applyDocumentTheme(context.theme);
  if (context?.styles?.variables !== undefined) applyHostStyleVariables(context.styles.variables);
  if (context?.displayMode !== undefined) {
    displayMode = context.displayMode;
    displayModeAuthorityVersion += 1;
  }
  if (context?.availableDisplayModes !== undefined) {
    availableDisplayModes = context.availableDisplayModes.filter((mode): mode is DisplayMode => ["inline", "pip", "fullscreen"].includes(mode));
    availableDisplayModesKnown = true;
  }
  if (panelNotice !== undefined) {
    panelNotice = displayMode === "inline" ? inlinePanelNotice() : undefined;
  }
  const snapshot = state.current;
  if (snapshot === undefined) renderWaiting(); else renderSnapshot(snapshot);
  maybeRequestAutomaticPanel();
}

function handleIncoming(value: unknown): void {
  const snapshot = readSnapshot(value);
  if (snapshot === undefined) return;
  const accepted = state.accept(snapshot);
  if (accepted) {
    invalidateAsyncActions();
    patchHandoff.authorityChanged(snapshot);
    evidenceDetail = undefined;
    evidenceDetailLinks = [];
    renderSnapshot(state.current!);
    if (poller === undefined && app !== undefined) startPolling(state.current!);
    else poller?.observe(state.current!);
    maybeRequestAutomaticPanel();
  }
}

function startPolling(initial: WorkbenchSnapshotLike): void {
  if (app === undefined) return;
  poller?.stop();
  poller = new WorkbenchPollingController({
    isVisible: () => document.visibilityState !== "hidden",
    fetchSnapshot: async (afterStateVersion, signal) => {
      const result = await app!.callServerTool({
        name: "monitoring_workbench_snapshot",
        arguments: { workspaceId: initial.workspaceId, afterStateVersion },
      }, { signal });
      if (result.isError) throw new Error("Snapshot refresh was rejected");
      const envelope = asRecord(result.structuredContent);
      return {
        unchanged: envelope?.changed === false,
        snapshot: readSnapshot(envelope),
      };
    },
    onSnapshot: (snapshot) => {
      if (state.accept(snapshot)) {
        invalidateAsyncActions();
        patchHandoff.authorityChanged(snapshot);
        evidenceDetail = undefined;
        evidenceDetailLinks = [];
        renderSnapshot(state.current!);
      }
    },
    onError: () => {
      transientMessage = "Live refresh paused. The last verified state remains visible.";
      if (state.current !== undefined) renderSnapshot(state.current);
    },
  });
  poller.start(initial);
}

function hostExtension(): OpenAiHost | undefined {
  return (window as Window & { openai?: OpenAiHost }).openai;
}

function canRequestDisplayMode(mode: DisplayMode): boolean {
  return canRequestWorkbenchDisplayMode(
    mode,
    availableDisplayModes,
    availableDisplayModesKnown,
    appConnected || hostExtension()?.requestDisplayMode !== undefined || window.parent === window,
  );
}

function panelDisplayMode(): Exclude<DisplayMode, "inline"> {
  return preferredPanelDisplayMode(availableDisplayModes) ?? "fullscreen";
}

function canRequestPanel(): boolean {
  return preferredPanelDisplayMode(availableDisplayModes) !== undefined
    || (!availableDisplayModesKnown && (
      appConnected
      || hostExtension()?.requestDisplayMode !== undefined
      || window.parent === window
    ));
}

function inlinePanelNotice(): string {
  return canRequestPanel()
    ? "The host kept the workbench inline. Select Open side panel to retry."
    : "This host currently supports the inline workbench only.";
}

function maybeRequestAutomaticPanel(): void {
  if (displayModeRequestPending) return;
  const requestedMode = preferredPanelDisplayMode(availableDisplayModes);
  if (!automaticPanelRequest.consider({
    connected: appConnected || hostExtension()?.requestDisplayMode !== undefined,
    hasSnapshot: state.current !== undefined,
    displayMode,
    requestedMode,
  })) return;
  void requestDisplayMode(requestedMode!, "automatic");
}

async function requestDisplayMode(mode: DisplayMode, trigger: "automatic" | "user" = "user"): Promise<void> {
  if (displayModeRequestPending) return;
  if (trigger === "user") automaticPanelRequest.suppress();
  const sequence = ++displayModeRequestSequence;
  const authorityVersion = displayModeAuthorityVersion;
  const previousMode = displayMode;
  displayModeRequestPending = true;
  transientMessage = trigger === "automatic" ? "Opening the Production Monitoring side panel…" : undefined;
  renderCurrentAuthority();
  try {
    const extension = hostExtension();
    const actual = await requestWorkbenchDisplayModeThroughOneBridge(
      mode,
      app !== undefined && appConnected
        ? async (requested) => (await app!.requestDisplayMode({ mode: requested })).mode
        : undefined,
      extension?.requestDisplayMode !== undefined
        ? async (requested) => (await extension.requestDisplayMode!({ mode: requested })).mode
        : window.parent === window
          ? async (requested) => requested
          : undefined,
    );
    if (sequence !== displayModeRequestSequence || authorityVersion !== displayModeAuthorityVersion) return;
    displayMode = resolveDisplayMode(mode, actual, availableDisplayModes);
    if (displayMode !== "inline") {
      panelNotice = undefined;
      transientMessage = displayMode === mode
        ? undefined
        : `Opened the workbench in ${humanize(displayMode)} mode.`;
    } else {
      panelNotice = inlinePanelNotice();
      transientMessage = `${humanize(mode)} is unavailable in this host. Kept the current workbench open.`;
    }
  } catch {
    if (sequence === displayModeRequestSequence && authorityVersion === displayModeAuthorityVersion) {
      displayMode = previousMode;
      if (previousMode === "inline") {
        panelNotice = inlinePanelNotice();
      }
      transientMessage = `${humanize(mode)} is unavailable in this host. Kept the current workbench open.`;
    }
  } finally {
    if (sequence === displayModeRequestSequence && authorityVersion !== displayModeAuthorityVersion) {
      transientMessage = undefined;
      if (displayMode !== "inline") {
        panelNotice = undefined;
      } else {
        panelNotice = inlinePanelNotice();
      }
    }
    if (sequence === displayModeRequestSequence) displayModeRequestPending = false;
    renderCurrentAuthority();
  }
}

async function inspectEvidence(key: string): Promise<void> {
  const snapshot = state.current;
  const evidenceRef = evidenceKeys.get(key);
  if (app === undefined || snapshot === undefined || evidenceRef === undefined || busyAction !== undefined) return;
  const sequence = beginAsyncAction(`evidence-${key}`);
  transientMessage = "Loading bounded evidence detail…";
  renderSnapshot(snapshot);
  try {
    const result = await app.callServerTool({
      name: "monitoring_workbench_evidence",
      arguments: { workspaceId: snapshot.workspaceId, evidenceRef },
    });
    if (!continuationIsCurrent(sequence, snapshot)) return;
    if (result.isError) throw new Error("Evidence request rejected");
    const envelope = asRecord(result.structuredContent);
    const detail = recordAt(envelope, "evidence") ?? envelope;
    const detailTitle = stringAt(detail, ["label", "title"], 120) ?? "Evidence detail";
    const refs = arrayAt(detail, "linkRefs")
      .filter((ref): ref is string => typeof ref === "string" && /^pmwslnk_[A-Za-z0-9_-]{20,128}$/u.test(ref))
      .slice(0, 4);
    const resolvedLinks = await Promise.all(refs.map(async (ref) => {
      try {
        const linkResult = await app!.callServerTool({
          name: "monitoring_workbench_resolve_link",
          arguments: { workspaceId: snapshot.workspaceId, linkRef: ref },
        });
        if (linkResult.isError) return undefined;
        const resolved = asRecord(linkResult.structuredContent);
        if (resolved?.mode !== "OPEN_EXTERNAL" || safeWorkbenchExternalUrl(resolved.url) === undefined) return undefined;
        return {
          linkRef: ref,
          label: stringAt(resolved, ["label"], 80) ?? "Open reviewed source",
        };
      } catch {
        return undefined;
      }
    }));
    if (!continuationIsCurrent(sequence, snapshot)) return;
    evidenceDetail = detail;
    evidenceDetailTitle = detailTitle;
    evidenceDetailLinks = resolvedLinks.filter((link): link is { linkRef: string; label: string } => link !== undefined);
    transientMessage = undefined;
  } catch {
    if (continuationIsCurrent(sequence, snapshot)) {
      transientMessage = "That evidence detail is unavailable or no longer belongs to this workbench.";
    }
  } finally {
    if (sequence === asyncActionSequence) busyAction = undefined;
    renderCurrentAuthority();
  }
}

async function openEvidenceLink(key: string): Promise<void> {
  const snapshot = state.current;
  const linkRef = linkKeys.get(key);
  if (app === undefined || snapshot === undefined || linkRef === undefined || busyAction !== undefined) return;
  const sequence = beginAsyncAction(`link-${key}`);
  transientMessage = "Resolving a reviewed source link…";
  renderSnapshot(snapshot);
  try {
    const result = await app.callServerTool({
      name: "monitoring_workbench_resolve_link",
      arguments: { workspaceId: snapshot.workspaceId, linkRef },
    });
    if (!continuationIsCurrent(sequence, snapshot)) return;
    if (result.isError) throw new Error("Link request rejected");
    const resolved = asRecord(result.structuredContent);
    if (resolved?.mode === "OPEN_EXTERNAL") {
      const href = safeWorkbenchExternalUrl(resolved?.href ?? resolved?.url);
      if (href === undefined) throw new Error("Unsafe source link rejected");
      if (!continuationIsCurrent(sequence, snapshot)) return;
      await app.openLink({ url: href });
      if (continuationIsCurrent(sequence, snapshot)) {
        transientMessage = "Opened the reviewed evidence source.";
      }
    } else {
      throw new Error("Unsupported source-link mode");
    }
  } catch {
    if (continuationIsCurrent(sequence, snapshot)) {
      transientMessage = "The source link was unavailable or failed the safe-link policy.";
    }
  } finally {
    if (sequence === asyncActionSequence) busyAction = undefined;
    renderCurrentAuthority();
  }
}

async function generatePatch(): Promise<void> {
  const snapshot = state.current;
  if (snapshot === undefined || busyAction !== undefined) return;
  const patch = recordAt(snapshot, "patch");
  if (stringAt(patch, ["status", "state"]) !== "ELIGIBLE") return;
  const eligibleIssue = arrayAt(snapshot, "issues")
    .map((candidate) => asRecord(candidate))
    .find((candidate) => {
      const issuePatch = recordAt(candidate, "patch");
      return stringAt(issuePatch, ["state", "status"]) === "ELIGIBLE";
    });
  const issueRef = stringAt(eligibleIssue, ["issueRef"], 160);
  const hypothesisRef = arrayAt(eligibleIssue, "hypothesisRefs")
    .flatMap((candidate) => typeof candidate === "string" ? [sanitizeWorkbenchText(candidate, 160)] : [])
    .find((candidate) => candidate.length > 0);
  if (issueRef === undefined || hypothesisRef === undefined) {
    transientMessage = "The eligible issue link is unavailable. Refresh the sealed workbench before requesting a patch.";
    renderSnapshot(snapshot);
    return;
  }
  if (!patchHandoff.request(snapshot)) return;
  const sequence = beginAsyncAction("generate-patch");
  transientMessage = "Sending a bounded remediation request to Codex…";
  renderSnapshot(snapshot);
  const prompt = `Use $prepare-production-remediation for Production Monitoring workbench ${snapshot.workspaceId}. Call monitoring_workbench_patch_context with workspaceId ${snapshot.workspaceId}, issueRef ${issueRef}, hypothesisRef ${hypothesisRef}, and expectedStateVersion ${snapshot.stateVersion}; prepare the smallest local source-and-test patch from exactly that bounded sealed context, preserve unrelated work, run only relevant local tests, and stop for explicit approval before any runtime-changing action.`;
  try {
    if (!continuationIsCurrent(sequence, snapshot)) return;
    if (hostExtension()?.sendFollowUpMessage !== undefined) {
      await hostExtension()!.sendFollowUpMessage!({ prompt });
    } else if (app !== undefined) {
      const result = await app.sendMessage({ role: "user", content: [{ type: "text", text: prompt }] });
      if (result.isError === true) throw new Error("Host rejected follow-up");
    } else {
      throw new Error("Follow-up is unavailable");
    }
    if (!continuationIsCurrent(sequence, snapshot)) return;
    patchHandoff.complete(snapshot);
    transientMessage = "Patch handoff sent. Review the exact diff and local test result in this Codex task.";
  } catch {
    if (continuationIsCurrent(sequence, snapshot)) {
      patchHandoff.fail(snapshot);
      transientMessage = "This host could not send the remediation handoff. The incident evidence remains unchanged.";
    }
  } finally {
    if (sequence === asyncActionSequence) busyAction = undefined;
    renderCurrentAuthority();
  }
}

root.addEventListener("click", (event) => {
  const button = (event.target as Element | null)?.closest<HTMLButtonElement>("button");
  if (button === null || button === undefined) return;
  const section = button.dataset.section;
  if (section !== undefined) {
    selectedSection = section;
    evidenceDetail = undefined;
    evidenceDetailLinks = [];
    if (state.current !== undefined) renderSnapshot(state.current);
    document.querySelector<HTMLElement>("#workbench-panel")?.focus();
    return;
  }
  const mode = button.dataset.mode;
  if (mode === "inline" || mode === "pip" || mode === "fullscreen") {
    void requestDisplayMode(mode);
    return;
  }
  const evidenceKey = button.dataset.evidenceKey;
  if (evidenceKey !== undefined) {
    void inspectEvidence(evidenceKey);
    return;
  }
  const linkKey = button.dataset.linkKey;
  if (linkKey !== undefined) {
    void openEvidenceLink(linkKey);
    return;
  }
  if (button.dataset.action === "generate-patch") void generatePatch();
  if (button.dataset.action === "refresh" && busyAction === undefined) {
    const sequence = beginAsyncAction("refresh");
    transientMessage = "Refreshing verified state…";
    renderCurrentAuthority();
    const refresh = poller?.refresh(true);
    if (refresh === undefined) {
      if (sequence === asyncActionSequence) {
        busyAction = undefined;
        transientMessage = "Live refresh is available when the workbench is embedded in Codex.";
      }
      renderCurrentAuthority();
    } else {
      void refresh.finally(() => {
        if (sequence === asyncActionSequence) busyAction = undefined;
        renderCurrentAuthority();
      });
    }
  }
  if (button.dataset.action === "close-drawer") {
    evidenceDetail = undefined;
    evidenceDetailLinks = [];
    if (state.current !== undefined) renderSnapshot(state.current);
  }
});

root.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && evidenceDetail !== undefined) {
    evidenceDetail = undefined;
    evidenceDetailLinks = [];
    if (state.current !== undefined) renderSnapshot(state.current);
    return;
  }
  const tab = (event.target as Element | null)?.closest<HTMLButtonElement>('[role="tab"]');
  if (tab === null || tab === undefined || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
  const tabs = [...root.querySelectorAll<HTMLButtonElement>('[role="tab"]')];
  const current = tabs.indexOf(tab);
  if (current < 0) return;
  event.preventDefault();
  const next = event.key === "Home"
    ? 0
    : event.key === "End"
      ? tabs.length - 1
      : (current + (event.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length;
  const nextSection = tabs[next]?.dataset.section;
  if (nextSection === undefined || state.current === undefined) return;
  selectedSection = nextSection;
  evidenceDetail = undefined;
  evidenceDetailLinks = [];
  renderSnapshot(state.current);
  root.querySelector<HTMLButtonElement>(`#tab-${nextSection}`)?.focus();
});

document.addEventListener("visibilitychange", () => poller?.visibilityChanged());
window.addEventListener("pagehide", () => poller?.stop(), { once: true });

const previewSnapshot: WorkbenchSnapshotLike = {
  schemaVersion: "1.1.0",
  workspaceId: "pmws_previewonlyreference000000000",
  stateVersion: 12,
  asOf: new Date().toISOString(),
  lifecycle: "SEALED",
  phase: "FINALIZING",
  origin: "SIMULATED",
  scope: { service: "checkout-api", environment: "staging" },
  status: { service: "DEGRADED", collection: "COMPLETE", causality: "SUPPORTED", recovery: "NOT_ASSESSED", audit: "HEALTHY" },
  progress: { completedOperations: 8, requiredOperations: 8, sourceStates: { COMPLETE: 8 } },
  signals: [
    { label: "Checkout timeout rate", displayValue: "20%", status: "FRESH", changeLabel: "+20 percentage points" },
    { label: "Affected seeded requests", displayValue: "1 of 5", status: "FRESH", detail: "Only the v2 path is affected" },
    { label: "Upstream provider latency", displayValue: "Within baseline", status: "COMPLETE" },
  ],
  hypotheses: [
    { hypothesisRef: "hypothesis.preview-timeout", statement: "The v2 timeout conversion applies milliseconds as seconds.", status: "SUPPORTED", supportingEvidenceCount: 4, contradictingEvidenceCount: 0 },
    { hypothesisRef: "hypothesis.preview-upstream", statement: "The payment provider is degraded.", status: "REJECTED", supportingEvidenceCount: 0, contradictingEvidenceCount: 2 },
  ],
  issues: [
    {
      issueRef: "pmwsiss_previewissue000000000000001",
      kind: "REGRESSION",
      severity: "WARNING",
      status: "SUPPORTED",
      classification: "DEVIATION",
      title: "Checkout timeout regression",
      summary: "Exactly one seeded v2 checkout request exceeds the reviewed timeout boundary.",
      evidenceRefs: ["pmwsev_previewevidence000000000001", "pmwsev_previewevidence000000000002"],
      hypothesisRefs: ["hypothesis.preview-timeout"],
      patch: { schemaVersion: "1.0.0", state: "ELIGIBLE", eligible: true, updatedAt: new Date().toISOString(), title: "Prepare a bounded local patch", reason: "This exact issue is linked to the one supported local-source hypothesis.", evidenceRefs: ["pmwsev_previewevidence000000000002"], limitations: ["No runtime-changing action is authorized."] },
    },
  ],
  evidence: [
    { evidenceRef: "pmwsev_previewevidence000000000001", label: "Checkout request outcomes", source: "Prometheus", status: "FRESH" },
    { evidenceRef: "pmwsev_previewevidence000000000002", label: "v2 timeout configuration", source: "Reviewed source", status: "COMPLETE" },
    { evidenceRef: "pmwsev_previewevidence000000000003", label: "Upstream latency", source: "Grafana", status: "COMPLETE" },
  ],
  activity: [
    { summary: "Collected the current incident window", status: "COMPLETE", at: new Date(Date.now() - 120_000).toISOString() },
    { summary: "Compared against the healthy baseline", status: "COMPLETE", at: new Date(Date.now() - 60_000).toISOString() },
    { summary: "Sealed the evidence-backed incident", status: "SEALED", at: new Date().toISOString() },
  ],
  patch: { status: "ELIGIBLE", summary: "A supported mechanism and complete sealed evidence are available for a local patch handoff." },
  nextAction: { label: "Review a minimal local patch", reason: "Production remains unchanged until a separately approved runtime action." },
  limitations: ["This is a synthetic demo incident.", "Local tests do not establish production recovery."],
};

const query = new URLSearchParams(window.location.search);
const standalone = window.parent === window || query.has("preview");
if (standalone) {
  const theme = query.get("theme");
  if (theme === "light" || theme === "dark") applyDocumentTheme(theme);
  const requestedMode = query.get("mode");
  const requestedSection = query.get("section");
  displayMode = requestedMode === "pip" || requestedMode === "fullscreen" ? requestedMode : "inline";
  if (["overview", "evidence", "hypotheses", "patch", "recovery"].includes(requestedSection ?? "")) {
    selectedSection = requestedSection!;
  }
  availableDisplayModes = ["inline", "pip", "fullscreen"];
  availableDisplayModesKnown = true;
  state.accept(previewSnapshot);
  renderSnapshot(previewSnapshot);
  maybeRequestAutomaticPanel();
} else {
  renderWaiting();
  app = new App(
    { name: "Production Monitoring Workbench", version: "2.1.0" },
    { availableDisplayModes: ["inline", "pip", "fullscreen"] },
    { allowUnsafeEval: false, autoResize: true, strict: true },
  );
  app.addEventListener("toolresult", (result) => handleIncoming(result.structuredContent));
  app.addEventListener("hostcontextchanged", (context) => applyHostContext(context as HostContext));
  app.onteardown = () => {
    appConnected = false;
    poller?.stop();
    return {};
  };
  void app.connect()
    .then(() => {
      appConnected = true;
      applyHostContext(app?.getHostContext() as HostContext | undefined);
      if (state.current !== undefined) startPolling(state.current);
      maybeRequestAutomaticPanel();
    })
    .catch(() => renderWaiting("The host could not establish the embedded read-only workbench."));
}
