import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import type { CallToolResult, ToolAnnotations } from "@modelcontextprotocol/sdk/types.js";
import { registerAppTool } from "@modelcontextprotocol/ext-apps/server";
import * as z from "zod/v4";

import type {
  EvidenceId,
  MonitoringWorkspaceSnapshot,
  MonitoringWorkspaceId,
  RunHandle,
  WorkbenchEvidenceRef,
  WorkbenchLinkRef,
  WorkbenchIssueRef,
} from "@codex-production-monitoring/contracts";
import type { MonitoringRuntime } from "@codex-production-monitoring/evidence-server";

import {
  PRODUCTION_MONITORING_MODEL_ONLY_META,
  PRODUCTION_MONITORING_APP_ONLY_META,
  PRODUCTION_MONITORING_WORKSPACE_META,
  PRODUCTION_MONITORING_WORKSPACE_RESULT_META,
  registerProductionMonitoringAppResource,
} from "./app-resource.ts";

export const PRODUCTION_MONITORING_MCP_VERSION = "0.3.0";

export const PRODUCTION_MONITORING_TOOL_NAMES = [
  "monitoring_open_workbench",
  "monitoring_open_workspace",
  "monitoring_workbench_snapshot",
  "monitoring_workbench_evidence",
  "monitoring_workbench_resolve_link",
  "monitoring_workbench_patch_context",
  "monitoring_doctor",
  "monitoring_list_capabilities",
  "monitoring_list_operations",
  "monitoring_resolve_scope",
  "monitoring_begin_run",
  "monitoring_resume_run",
  "monitoring_collect",
  "monitoring_compare",
  "monitoring_get_evidence",
  "monitoring_audit_status",
  "monitoring_finalize_run",
  "monitoring_cancel_run",
] as const;

type ProductionMonitoringToolName = typeof PRODUCTION_MONITORING_TOOL_NAMES[number];

function annotations(options: {
  openWorld?: boolean;
  destructive?: boolean;
  readOnly?: boolean;
  idempotent?: boolean;
}): Readonly<ToolAnnotations> {
  return Object.freeze({
    readOnlyHint: options.readOnly ?? false,
    openWorldHint: options.openWorld ?? false,
    destructiveHint: options.destructive ?? false,
    idempotentHint: options.idempotent ?? false,
  });
}

export const PRODUCTION_MONITORING_TOOL_ANNOTATIONS: Readonly<Record<ProductionMonitoringToolName, Readonly<ToolAnnotations>>> =
  Object.freeze({
    monitoring_open_workbench: annotations({ readOnly: true, idempotent: true }),
    monitoring_open_workspace: annotations({ readOnly: true, idempotent: true }),
    monitoring_workbench_snapshot: annotations({ readOnly: true, idempotent: true }),
    monitoring_workbench_evidence: annotations({ readOnly: true, idempotent: true }),
    monitoring_workbench_resolve_link: annotations({ readOnly: true, idempotent: true }),
    monitoring_workbench_patch_context: annotations({ readOnly: true, idempotent: true }),
    monitoring_doctor: annotations({ openWorld: true }),
    monitoring_list_capabilities: annotations({}),
    monitoring_list_operations: annotations({}),
    monitoring_resolve_scope: annotations({}),
    monitoring_begin_run: annotations({}),
    monitoring_resume_run: annotations({ destructive: true }),
    monitoring_collect: annotations({ openWorld: true }),
    monitoring_compare: annotations({ openWorld: true }),
    monitoring_get_evidence: annotations({}),
    monitoring_audit_status: annotations({}),
    monitoring_finalize_run: annotations({ destructive: true }),
    monitoring_cancel_run: annotations({ destructive: true }),
  });

const alias = z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u);
const runHandle = z.string().regex(/^pmh_[A-Za-z0-9_-]{43}$/u);
const evidenceId = z.string().regex(/^pmev_[A-Za-z0-9_-]{20,128}$/u);
const workspaceId = z.string().regex(/^pmws_[A-Za-z0-9_-]{20,128}$/u);
const workbenchEvidenceRef = z.string().regex(/^pmwsev_[A-Za-z0-9_-]{20,128}$/u);
const workbenchLinkRef = z.string().regex(/^pmwslnk_[A-Za-z0-9_-]{20,128}$/u);
const workbenchIssueRef = z.string().regex(/^pmwsiss_[A-Za-z0-9_-]{20,128}$/u);
const stateVersion = z.number().int().positive();
const revision = z.number().int().positive();
const timeWindow = z.strictObject({
  start: z.iso.datetime({ offset: true }),
  end: z.iso.datetime({ offset: true }),
});
const workflowRequest = z.strictObject({
  schemaVersion: z.literal("1.0.0"),
  idempotencyKey: alias,
  workflow: z.enum(["triage", "investigate", "deep", "change-review", "verify"]),
  profileAlias: alias,
  scopeAlias: alias,
  origin: z.enum(["LIVE", "REPLAY", "SIMULATED"]),
  window: timeWindow,
  baselineWindow: timeWindow.optional(),
  incidentAlias: alias.optional(),
  parentRunId: z.string().regex(/^pmrun_[A-Za-z0-9_-]{20,128}$/u).optional(),
  verificationPolicyAlias: alias.optional(),
  requiredOperations: z.array(alias).min(1).max(128).optional(),
  requiredCapabilityPacks: z.array(alias).min(1).max(32).optional(),
  artifactPolicy: z.strictObject({ mode: z.enum(["required", "best_effort"]) }),
  failOn: z.enum(["none", "partial", "error"]),
}).superRefine((request, context) => {
  if (
    request.workflow === "deep" &&
    request.requiredOperations === undefined &&
    request.requiredCapabilityPacks === undefined
  ) {
    context.addIssue({
      code: "custom",
      message: "deep requires an explicit operation or capability-pack ledger",
      path: ["requiredOperations"],
    });
  }
  if (request.workflow === "verify" && request.verificationPolicyAlias !== undefined) {
    context.addIssue({
      code: "custom",
      message: "verify derives its policy from the sealed parent",
      path: ["verificationPolicyAlias"],
    });
  }
});
const text = z.string().min(1).max(4096);
const citedEvidence = z.array(evidenceId).max(128);
const observation = z.strictObject({ observationId: alias, statement: text, evidenceIds: citedEvidence.min(1) });
const inference = z.strictObject({
  inferenceId: alias,
  statement: text,
  confidence: z.number().min(0).max(1),
  rationale: text,
  supportingEvidenceIds: citedEvidence.min(1),
  contradictingEvidenceIds: citedEvidence,
});
const hypothesis = z.strictObject({
  hypothesisId: alias,
  rank: z.number().int().positive().max(256),
  statement: text,
  status: z.enum(["OPEN", "SUPPORTED", "WEAKENED", "REJECTED"]),
  rationale: text,
  supportingEvidenceIds: citedEvidence.min(1),
  contradictingEvidenceIds: citedEvidence,
  nextCheck: text.optional(),
});
const analysisDraft = z.strictObject({
  schemaVersion: z.literal("1.0.0"),
  observations: z.array(observation).max(1000),
  inferences: z.array(inference).max(1000),
  hypotheses: z.array(hypothesis).max(256),
  checksPerformed: z.array(text).max(256),
  missingEvidence: z.array(text).max(256),
  smallestSafeNextStep: text,
  approvalRequired: z.boolean(),
  remainingUncertainty: z.array(text).max(256),
  owners: z.array(text).max(256),
});

function jsonResult(value: unknown, renderWorkspace = false): CallToolResult {
  const safe = JSON.parse(JSON.stringify(value)) as Record<string, unknown>;
  return {
    content: [{ type: "text", text: JSON.stringify(safe) }],
    structuredContent: safe,
    ...(renderWorkspace ? { _meta: PRODUCTION_MONITORING_WORKSPACE_RESULT_META } : {}),
  };
}

function sanitizedError(error: unknown, renderWorkspace = false): CallToolResult {
  const candidate = error as { code?: unknown; name?: unknown };
  const code = typeof candidate.code === "string"
    ? candidate.code
    : typeof candidate.name === "string"
      ? candidate.name.replaceAll(/[^A-Za-z0-9]+/gu, "_").toUpperCase()
      : "MONITORING_ERROR";
  return {
    isError: true,
    content: [{ type: "text", text: JSON.stringify({ code, message: "The monitoring request was rejected" }) }],
    structuredContent: { code, message: "The monitoring request was rejected" },
    ...(renderWorkspace ? { _meta: PRODUCTION_MONITORING_WORKSPACE_RESULT_META } : {}),
  };
}

function guarded<T>(callback: () => T | Promise<T>, renderWorkspace = false): Promise<CallToolResult> {
  return Promise.resolve()
    .then(callback)
    .then(
      (value) => jsonResult(value, renderWorkspace),
      (error: unknown) => sanitizedError(error, renderWorkspace),
    );
}

function workbenchResult(snapshot: MonitoringWorkspaceSnapshot): CallToolResult {
  const safe = JSON.parse(JSON.stringify(snapshot)) as unknown as MonitoringWorkspaceSnapshot;
  const scope = safe.scope === undefined
    ? "No incident is scoped yet"
    : `${safe.scope.service ?? "Service"} in ${safe.scope.environment}`;
  const origin = safe.origin === undefined ? "no evidence origin yet" : `${safe.origin} evidence`;
  return {
    content: [{
      type: "text",
      text: `Production Monitoring workbench opened. ${scope}; ${origin}; ${safe.phase.toLowerCase()} phase. The panel holds bounded evidence, hypotheses, patch eligibility, and recovery state.`,
    }],
    structuredContent: safe as unknown as Record<string, unknown>,
    _meta: PRODUCTION_MONITORING_WORKSPACE_RESULT_META,
  };
}

function guardedWorkspace(
  callback: () => MonitoringWorkspaceSnapshot | Promise<MonitoringWorkspaceSnapshot>,
): Promise<CallToolResult> {
  return Promise.resolve()
    .then(callback)
    .then(workbenchResult, (error: unknown) => sanitizedError(error, true));
}

export function createProductionMonitoringMcpServer(runtime: MonitoringRuntime): McpServer {
  const server = new McpServer({
    name: "production-monitoring",
    version: PRODUCTION_MONITORING_MCP_VERSION,
  });

  registerProductionMonitoringAppResource(server);

  registerAppTool(server, "monitoring_open_workbench", {
    title: "Open Production Monitoring Workbench",
    description: "Open the persistent read-only incident pulse for the latest run owned by one active monitoring profile.",
    inputSchema: z.strictObject({ profileAlias: alias }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_open_workbench,
    _meta: PRODUCTION_MONITORING_WORKSPACE_META,
  }, ({ profileAlias }) => guardedWorkspace(() => runtime.openWorkbench(profileAlias)));

  registerAppTool(server, "monitoring_open_workspace", {
    title: "Open Production Monitoring (compatibility)",
    description: "Compatibility alias for opening the persistent read-only Production Monitoring workbench.",
    inputSchema: z.strictObject({ profileAlias: alias }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_open_workspace,
    _meta: PRODUCTION_MONITORING_WORKSPACE_META,
  }, ({ profileAlias }) => guardedWorkspace(() => runtime.openWorkbench(profileAlias)));

  registerAppTool(server, "monitoring_workbench_snapshot", {
    title: "Read Production Monitoring Workbench State",
    description: "App-only version-aware read of one owned sanitized workbench; it never accepts a run handle or provider input.",
    inputSchema: z.strictObject({ workspaceId, afterStateVersion: stateVersion.optional() }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_workbench_snapshot,
    _meta: PRODUCTION_MONITORING_APP_ONLY_META,
  }, ({ workspaceId: id, afterStateVersion }) => guarded(
    () => runtime.workspaceSnapshot(id as MonitoringWorkspaceId, afterStateVersion),
  ));

  registerAppTool(server, "monitoring_workbench_evidence", {
    title: "Read Production Monitoring Evidence Detail",
    description: "App-only ownership-checked read of bounded normalized detail behind one opaque evidence reference.",
    inputSchema: z.strictObject({ workspaceId, evidenceRef: workbenchEvidenceRef }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_workbench_evidence,
    _meta: PRODUCTION_MONITORING_APP_ONLY_META,
  }, ({ workspaceId: id, evidenceRef: ref }) => guarded(
    () => runtime.workspaceEvidence(id as MonitoringWorkspaceId, ref as WorkbenchEvidenceRef),
  ));

  registerAppTool(server, "monitoring_workbench_resolve_link", {
    title: "Resolve Production Monitoring Evidence Link",
    description: "App-only ownership-checked resolution of one server-derived opaque source link; URLs, queries, and paths are never accepted.",
    inputSchema: z.strictObject({ workspaceId, linkRef: workbenchLinkRef }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_workbench_resolve_link,
    _meta: PRODUCTION_MONITORING_APP_ONLY_META,
  }, ({ workspaceId: id, linkRef: ref }) => guarded(
    () => runtime.resolveWorkspaceLink(id as MonitoringWorkspaceId, ref as WorkbenchLinkRef),
  ));

  registerAppTool(server, "monitoring_workbench_patch_context", {
    title: "Read Production Monitoring Patch Context",
    description: "Return bounded sealed rationale for the model-side remediation skill; this read-only tool cannot modify files or production.",
    inputSchema: z.strictObject({
      workspaceId,
      issueRef: workbenchIssueRef,
      hypothesisRef: alias,
      expectedStateVersion: stateVersion,
    }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_workbench_patch_context,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ workspaceId: id, issueRef, hypothesisRef, expectedStateVersion }) => guarded(
    () => runtime.workspacePatchContext(
      id as MonitoringWorkspaceId,
      issueRef as WorkbenchIssueRef,
      hypothesisRef,
      expectedStateVersion,
    ),
  ));

  registerAppTool(server, "monitoring_doctor", {
    title: "Check Monitoring Readiness",
    description: "Validate one active monitoring profile and record a sanitized diagnostic audit event.",
    inputSchema: z.strictObject({ profileAlias: alias }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_doctor,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ profileAlias }) => guarded(() => runtime.doctor(profileAlias)));

  registerAppTool(server, "monitoring_list_capabilities", {
    title: "List Monitoring Capabilities",
    description: "List admitted evidence domains, adapters, active route, and topology limitations for a profile.",
    inputSchema: z.strictObject({ profileAlias: alias }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_list_capabilities,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ profileAlias }) => guarded(() => runtime.listCapabilities(profileAlias)));

  registerAppTool(server, "monitoring_list_operations", {
    title: "List Reviewed Operations",
    description: "List reviewed semantic operation IDs; provider queries and URLs are never accepted.",
    inputSchema: z.strictObject({
      profileAlias: alias,
      domain: z.enum(["METRICS", "ALERTS", "LOGS", "TRACES", "RUNTIME", "CHANGES", "RUNBOOKS"]).optional(),
    }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_list_operations,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ profileAlias, domain }) => guarded(() => ({
    operations: runtime.listOperations(profileAlias, domain),
  })));

  registerAppTool(server, "monitoring_resolve_scope", {
    title: "Resolve Monitoring Scope",
    description: "Resolve one configured scope alias without accepting an endpoint, tenant, path, or header.",
    inputSchema: z.strictObject({ profileAlias: alias, scopeAlias: alias }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_resolve_scope,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ profileAlias, scopeAlias }) => guarded(() => runtime.resolveScope(profileAlias, scopeAlias)));

  registerAppTool(server, "monitoring_begin_run", {
    title: "Begin Monitoring Run",
    description: "Authorize a versioned workflow request, seal reviewed operations, and issue an opaque run handle.",
    inputSchema: z.strictObject({
      request: workflowRequest,
      idempotencyKey: alias,
    }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_begin_run,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ request, idempotencyKey }) => guarded(() => {
    if (request.idempotencyKey !== idempotencyKey) {
      throw new TypeError("MCP idempotency policy conflicts with the canonical workflow request");
    }
    return runtime.beginRun(request, idempotencyKey);
  }));

  registerAppTool(server, "monitoring_resume_run", {
    title: "Resume Monitoring Run",
    description: "Reauthenticate and rotate an unexpired run handle after its prior lease is no longer active.",
    inputSchema: z.strictObject({ runHandle, expectedRevision: revision }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_resume_run,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ runHandle: handle, expectedRevision }) => guarded(
    () => runtime.resumeRun(handle as RunHandle, expectedRevision),
  ));

  registerAppTool(server, "monitoring_collect", {
    title: "Collect Monitoring Evidence",
    description: "Collect bounded normalized evidence through reviewed snapshotted operation IDs only.",
    inputSchema: z.strictObject({
      runHandle,
      expectedRevision: revision,
      operationIds: z.array(alias).min(1).max(16),
      window: z.enum(["CURRENT", "BASELINE"]).default("CURRENT"),
    }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_collect,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ runHandle: handle, expectedRevision, operationIds, window }, extra) => guarded(
    () => runtime.collect(handle as RunHandle, expectedRevision, operationIds, window, extra.signal),
  ));

  registerAppTool(server, "monitoring_compare", {
    title: "Compare Monitoring Windows",
    description: "Collect the same reviewed operation across the sealed current and baseline windows.",
    inputSchema: z.strictObject({ runHandle, expectedRevision: revision, operationId: alias }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_compare,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ runHandle: handle, expectedRevision, operationId }, extra) => guarded(
    () => runtime.compare(handle as RunHandle, expectedRevision, operationId, extra.signal),
  ));

  registerAppTool(server, "monitoring_get_evidence", {
    title: "Get Monitoring Evidence",
    description: "Retrieve one normalized evidence record owned by the authenticated run; paths and URLs are rejected.",
    inputSchema: z.strictObject({ runHandle, expectedRevision: revision, evidenceId }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_get_evidence,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ runHandle: handle, expectedRevision, evidenceId: id }) => guarded(
    () => runtime.getEvidence(handle as RunHandle, expectedRevision, id as EvidenceId),
  ));

  registerAppTool(server, "monitoring_audit_status", {
    title: "Check Monitoring Audit Status",
    description: "Report whether required run audit events are durable.",
    inputSchema: z.strictObject({ runHandle, expectedRevision: revision }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_audit_status,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ runHandle: handle, expectedRevision }) => guarded(
    () => runtime.auditStatus(handle as RunHandle, expectedRevision),
  ));

  registerAppTool(server, "monitoring_finalize_run", {
    title: "Finalize Monitoring Incident",
    description: "Validate an optional bounded evidence-linked analysis, seal an immutable bundle, and invalidate the run handle. Omission produces a PARTIAL evidence-only artifact.",
    inputSchema: z.strictObject({ runHandle, expectedRevision: revision, analysisDraft: analysisDraft.optional() }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_finalize_run,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ runHandle: handle, expectedRevision, analysisDraft: draft }) => guarded(
    () => runtime.finalizeRun(handle as RunHandle, expectedRevision, draft),
  ));

  registerAppTool(server, "monitoring_cancel_run", {
    title: "Cancel Monitoring Run",
    description: "Cancel bounded work while retaining truthful owned partial evidence and receipts.",
    inputSchema: z.strictObject({
      runHandle,
      expectedRevision: revision,
      reason: z.enum(["USER_REQUEST", "INTERRUPTED", "BUDGET_EXCEEDED", "PROVIDER_UNAVAILABLE"]),
    }),
    annotations: PRODUCTION_MONITORING_TOOL_ANNOTATIONS.monitoring_cancel_run,
    _meta: PRODUCTION_MONITORING_MODEL_ONLY_META,
  }, ({ runHandle: handle, expectedRevision, reason }) => guarded(
    () => runtime.cancelRun(handle as RunHandle, expectedRevision, reason),
  ));

  return server;
}
