import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import {
  createServer as createHttpsServer,
  type Server as HttpsServer,
  type ServerOptions as HttpsServerOptions,
} from "node:https";
import type { IncomingMessage, ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";
import type { TLSSocket } from "node:tls";

import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";

import type { MonitoringRuntime } from "@codex-production-monitoring/evidence-server";

import { createProductionMonitoringMcpServer } from "./server.ts";

export const CUSTOMER_VPC_MCP_PATH = "/mcp";

const DEFAULT_LIMITS: Readonly<Required<CustomerVpcGatewayLimits>> = Object.freeze({
  maxBodyBytes: 128 * 1024,
  maxSessions: 100,
  maxConcurrentRequests: 32,
  maxConcurrentRequestsPerSession: 4,
  sessionIdleMs: 15 * 60 * 1_000,
  requestTimeoutMs: 30_000,
  headerTimeoutMs: 10_000,
  keepAliveTimeoutMs: 5_000,
  maxHeaderBytes: 16 * 1024,
});

const PROXY_AUTHORITY_HEADERS = [
  "forwarded",
  "x-forwarded-for",
  "x-forwarded-host",
  "x-forwarded-port",
  "x-forwarded-proto",
  "x-original-host",
  "x-real-ip",
] as const;

export interface CustomerVpcPrincipal {
  issuerAlias: string;
  subject: string;
  tenant: string;
}

export interface CustomerVpcClientMapping {
  /** SHA-256 digest of the DER client certificate, with or without colon separators. */
  fingerprintSha256: string;
  /** Administrator-owned authority. Certificate subject fields never supply these values. */
  principal: CustomerVpcPrincipal;
}

export interface CustomerVpcGatewayLimits {
  maxBodyBytes?: number;
  maxSessions?: number;
  maxConcurrentRequests?: number;
  maxConcurrentRequestsPerSession?: number;
  sessionIdleMs?: number;
  requestTimeoutMs?: number;
  headerTimeoutMs?: number;
  keepAliveTimeoutMs?: number;
  maxHeaderBytes?: number;
}

export interface CustomerVpcGatewayPolicy {
  /** Exact HTTP Host header values, including a port when the client sends one. */
  allowedHosts: readonly string[];
  /** Exact HTTPS origins. An Origin header is mandatory on every request. */
  allowedOrigins: readonly string[];
  clients: readonly CustomerVpcClientMapping[];
  limits?: CustomerVpcGatewayLimits;
}

export interface CustomerVpcRuntimeContext {
  /** Fully server-derived identity. The opaque session is never accepted from request input. */
  principal: CustomerVpcPrincipal & { session: string };
  clientCertificateFingerprintSha256: string;
  surface: "customer-vpc";
}

export interface CustomerVpcMcpServerOptions extends CustomerVpcGatewayPolicy {
  tls: {
    key: HttpsServerOptions["key"];
    cert: HttpsServerOptions["cert"];
    ca: HttpsServerOptions["ca"];
  };
  runtimeFactory: (
    context: Readonly<CustomerVpcRuntimeContext>,
  ) => MonitoringRuntime | Promise<MonitoringRuntime>;
  /** Testability hook. Production callers should use the default system clock. */
  now?: () => number;
}

export interface CustomerVpcListenOptions {
  host: string;
  port: number;
}

export interface CustomerVpcListeningAddress {
  host: string;
  port: number;
  family: string;
  path: typeof CUSTOMER_VPC_MCP_PATH;
}

interface CompiledClientMapping {
  fingerprintSha256: string;
  fingerprintBytes: Buffer;
  principal: Readonly<CustomerVpcPrincipal>;
}

interface CompiledPolicy {
  allowedHosts: ReadonlySet<string>;
  allowedOrigins: ReadonlySet<string>;
  clients: readonly CompiledClientMapping[];
  limits: Readonly<Required<CustomerVpcGatewayLimits>>;
}

interface ActiveSession {
  id: string;
  fingerprintSha256: string;
  transport: StreamableHTTPServerTransport;
  mcpServer: ReturnType<typeof createProductionMonitoringMcpServer>;
  runtime: MonitoringRuntime;
  lastUsedAt: number;
  activeRequests: number;
  activeStreams: number;
  initialized: boolean;
  closing: boolean;
}

type ListenerState = "idle" | "starting" | "listening" | "closed";

function boundedInteger(value: number | undefined, fallback: number, name: string, maximum: number): number {
  const selected = value ?? fallback;
  if (!Number.isSafeInteger(selected) || selected < 1 || selected > maximum) {
    throw new TypeError(`${name} must be a positive safe integer no greater than ${maximum}`);
  }
  return selected;
}

function exactUnique(values: readonly string[], name: string, validator: (value: string) => boolean): Set<string> {
  if (!Array.isArray(values) || values.length === 0 || values.length > 128) {
    throw new TypeError(`${name} must contain between 1 and 128 exact values`);
  }
  const compiled = new Set<string>();
  for (const value of values) {
    if (typeof value !== "string" || !validator(value) || compiled.has(value)) {
      throw new TypeError(`${name} contains an invalid or duplicate value`);
    }
    compiled.add(value);
  }
  return compiled;
}

function validHost(value: string): boolean {
  if (value.length < 1 || value.length > 253 || value !== value.trim() || value.includes("*")) return false;
  try {
    const parsed = new URL(`https://${value}/`);
    const hostname = parsed.hostname;
    const validHostname = hostname.startsWith("[")
      ? /^\[[0-9a-f:.]+\]$/u.test(hostname)
      : hostname.split(".").every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/u.test(label));
    return validHostname
      && parsed.host === value
      && parsed.username === ""
      && parsed.password === ""
      && parsed.pathname === "/"
      && parsed.search === ""
      && parsed.hash === "";
  } catch {
    return false;
  }
}

function validOrigin(value: string): boolean {
  if (value.length > 512 || value !== value.trim() || value.includes("*")) return false;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:"
      && parsed.origin === value
      && parsed.username === ""
      && parsed.password === "";
  } catch {
    return false;
  }
}

function validPrincipalField(value: string, name: string): boolean {
  const hasControlCharacter = [...value].some((character) => {
    const codePoint = character.codePointAt(0) ?? 0;
    return codePoint <= 31 || codePoint === 127;
  });
  if (value.length < 1 || value.length > 256 || value !== value.trim() || hasControlCharacter) {
    return false;
  }
  if (name !== "subject" && !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u.test(value)) return false;
  return true;
}

/** Canonicalize an administrator-supplied SHA-256 certificate fingerprint. */
export function canonicalCertificateFingerprintSha256(value: string): string {
  if (typeof value !== "string") throw new TypeError("certificate fingerprint must be a string");
  const canonical = value.replaceAll(":", "").toLowerCase();
  if (!/^[a-f0-9]{64}$/u.test(canonical)) {
    throw new TypeError("certificate fingerprint must be exactly one SHA-256 digest");
  }
  return canonical;
}

function compilePolicy(policy: CustomerVpcGatewayPolicy): CompiledPolicy {
  if (policy === null || typeof policy !== "object") throw new TypeError("customer VPC policy is required");
  const allowedHosts = exactUnique(policy.allowedHosts, "allowedHosts", validHost);
  const allowedOrigins = exactUnique(policy.allowedOrigins, "allowedOrigins", validOrigin);
  if (!Array.isArray(policy.clients) || policy.clients.length < 1 || policy.clients.length > 1_024) {
    throw new TypeError("clients must contain between 1 and 1024 certificate mappings");
  }
  const fingerprints = new Set<string>();
  const clients = policy.clients.map((mapping): CompiledClientMapping => {
    if (mapping === null || typeof mapping !== "object" || mapping.principal === null || typeof mapping.principal !== "object") {
      throw new TypeError("each client mapping must include a principal");
    }
    const fingerprintSha256 = canonicalCertificateFingerprintSha256(mapping.fingerprintSha256);
    if (fingerprints.has(fingerprintSha256)) throw new TypeError("client certificate fingerprints must be unique");
    fingerprints.add(fingerprintSha256);
    const { issuerAlias, subject, tenant } = mapping.principal;
    if (!validPrincipalField(issuerAlias, "issuerAlias")
      || !validPrincipalField(subject, "subject")
      || !validPrincipalField(tenant, "tenant")) {
      throw new TypeError("client principal fields are invalid");
    }
    return Object.freeze({
      fingerprintSha256,
      fingerprintBytes: Buffer.from(fingerprintSha256, "hex"),
      principal: Object.freeze({ issuerAlias, subject, tenant }),
    });
  });
  const input = policy.limits ?? {};
  const limits = Object.freeze({
    maxBodyBytes: boundedInteger(input.maxBodyBytes, DEFAULT_LIMITS.maxBodyBytes, "maxBodyBytes", 16 * 1024 * 1024),
    maxSessions: boundedInteger(input.maxSessions, DEFAULT_LIMITS.maxSessions, "maxSessions", 1_024),
    maxConcurrentRequests: boundedInteger(
      input.maxConcurrentRequests,
      DEFAULT_LIMITS.maxConcurrentRequests,
      "maxConcurrentRequests",
      10_000,
    ),
    maxConcurrentRequestsPerSession: boundedInteger(
      input.maxConcurrentRequestsPerSession,
      DEFAULT_LIMITS.maxConcurrentRequestsPerSession,
      "maxConcurrentRequestsPerSession",
      1_000,
    ),
    sessionIdleMs: boundedInteger(input.sessionIdleMs, DEFAULT_LIMITS.sessionIdleMs, "sessionIdleMs", 7 * 24 * 60 * 60 * 1_000),
    requestTimeoutMs: boundedInteger(input.requestTimeoutMs, DEFAULT_LIMITS.requestTimeoutMs, "requestTimeoutMs", 60 * 60 * 1_000),
    headerTimeoutMs: boundedInteger(input.headerTimeoutMs, DEFAULT_LIMITS.headerTimeoutMs, "headerTimeoutMs", 5 * 60 * 1_000),
    keepAliveTimeoutMs: boundedInteger(input.keepAliveTimeoutMs, DEFAULT_LIMITS.keepAliveTimeoutMs, "keepAliveTimeoutMs", 5 * 60 * 1_000),
    maxHeaderBytes: boundedInteger(input.maxHeaderBytes, DEFAULT_LIMITS.maxHeaderBytes, "maxHeaderBytes", 1024 * 1024),
  });
  if (limits.maxConcurrentRequestsPerSession > limits.maxConcurrentRequests) {
    throw new TypeError("maxConcurrentRequestsPerSession cannot exceed maxConcurrentRequests");
  }
  if (limits.headerTimeoutMs > limits.requestTimeoutMs) {
    throw new TypeError("headerTimeoutMs cannot exceed requestTimeoutMs");
  }
  return Object.freeze({ allowedHosts, allowedOrigins, clients: Object.freeze(clients), limits });
}

/** Validate policy without creating a listener or loading TLS private key material. */
export function validateCustomerVpcGatewayPolicy(policy: CustomerVpcGatewayPolicy): void {
  compilePolicy(policy);
}

function peerFingerprint(socket: TLSSocket): { digest: string; bytes: Buffer } | undefined {
  if (!socket.authorized || socket.getProtocol() !== "TLSv1.3") return undefined;
  const certificate = socket.getPeerCertificate();
  if (certificate.raw === undefined || certificate.raw.length === 0) return undefined;
  const bytes = createHash("sha256").update(certificate.raw).digest();
  return { digest: bytes.toString("hex"), bytes };
}

function findClient(policy: CompiledPolicy, fingerprint: Buffer): CompiledClientMapping | undefined {
  return policy.clients.find((candidate) => timingSafeEqual(candidate.fingerprintBytes, fingerprint));
}

function singleHeader(request: IncomingMessage, name: string): string | undefined {
  const value = request.headers[name];
  return typeof value === "string" ? value : undefined;
}

function hasProxyAuthorityHeader(request: IncomingMessage): boolean {
  return PROXY_AUTHORITY_HEADERS.some((name) => request.headers[name] !== undefined);
}

function reject(response: ServerResponse, status: number): void {
  if (response.writableEnded || response.destroyed) return;
  if (response.headersSent) {
    response.destroy();
    return;
  }
  const payload = JSON.stringify({ error: "request_rejected" });
  response.writeHead(status, {
    "cache-control": "no-store",
    "content-length": Buffer.byteLength(payload),
    "content-type": "application/json; charset=utf-8",
    "x-content-type-options": "nosniff",
  });
  response.end(payload);
}

function isJsonContentType(value: string | undefined): boolean {
  return value !== undefined && /^application\/json(?:;\s*charset=utf-8)?$/iu.test(value);
}

function acceptedMediaTypes(value: string | undefined): Set<string> {
  if (value === undefined || value.length > 512) return new Set();
  return new Set(value.split(",").map((entry) => entry.split(";", 1)[0]!.trim().toLowerCase()));
}

function isInitializeMessage(value: unknown): boolean {
  return value !== null
    && typeof value === "object"
    && !Array.isArray(value)
    && (value as { jsonrpc?: unknown }).jsonrpc === "2.0"
    && (value as { method?: unknown }).method === "initialize"
    && (typeof (value as { id?: unknown }).id === "string" || typeof (value as { id?: unknown }).id === "number");
}

async function readBoundedJson(request: IncomingMessage, maximumBytes: number): Promise<unknown> {
  const length = singleHeader(request, "content-length");
  if (length !== undefined) {
    if (!/^\d+$/u.test(length) || Number(length) > maximumBytes) throw new RangeError("body limit exceeded");
  }
  const chunks: Buffer[] = [];
  let total = 0;
  for await (const chunk of request) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk as Uint8Array);
    total += bytes.length;
    if (total > maximumBytes) throw new RangeError("body limit exceeded");
    chunks.push(bytes);
  }
  if (total === 0) throw new SyntaxError("JSON body is required");
  return JSON.parse(Buffer.concat(chunks, total).toString("utf8")) as unknown;
}

function newSessionId(): string {
  return randomBytes(32).toString("base64url");
}

async function closeRuntime(runtime: MonitoringRuntime): Promise<void> {
  const close = (runtime as MonitoringRuntime & { close?: () => void | Promise<void> }).close;
  if (typeof close !== "function") return;
  try {
    await close.call(runtime);
  } catch {
    // Session authority is already revoked. Runtime cleanup is best effort here.
  }
}

/**
 * Stateful Streamable HTTP MCP listener for a customer-operated VPC.
 *
 * It intentionally implements only administrator-mapped mTLS authentication. It
 * does not implement or claim OAuth, publisher-hosted, or customer-relay routes.
 */
export class CustomerVpcMcpServer {
  readonly #policy: CompiledPolicy;
  readonly #runtimeFactory: CustomerVpcMcpServerOptions["runtimeFactory"];
  readonly #now: () => number;
  readonly #server: HttpsServer;
  readonly #sessions = new Map<string, ActiveSession>();
  readonly #pendingInitializations = new Set<Promise<void>>();
  readonly #sweepTimer: NodeJS.Timeout;
  #activeRequests = 0;
  #pendingSessions = 0;
  #listenerState: ListenerState = "idle";
  #listenTarget: CustomerVpcListenOptions | undefined;
  #listenPromise: Promise<CustomerVpcListeningAddress> | undefined;
  #closing = false;
  #closePromise: Promise<void> | undefined;

  constructor(options: CustomerVpcMcpServerOptions) {
    if (options.tls === null || typeof options.tls !== "object"
      || options.tls.key === undefined || options.tls.cert === undefined || options.tls.ca === undefined) {
      throw new TypeError("TLS key, certificate, and client CA are required");
    }
    if (typeof options.runtimeFactory !== "function") throw new TypeError("runtimeFactory is required");
    this.#policy = compilePolicy(options);
    this.#runtimeFactory = options.runtimeFactory;
    this.#now = options.now ?? Date.now;
    this.#server = createHttpsServer({
      key: options.tls.key,
      cert: options.tls.cert,
      ca: options.tls.ca,
      minVersion: "TLSv1.3",
      maxVersion: "TLSv1.3",
      requestCert: true,
      rejectUnauthorized: true,
      maxHeaderSize: this.#policy.limits.maxHeaderBytes,
    }, (request, response) => {
      void this.#handle(request, response);
    });
    this.#server.requestTimeout = this.#policy.limits.requestTimeoutMs;
    this.#server.headersTimeout = this.#policy.limits.headerTimeoutMs;
    this.#server.keepAliveTimeout = this.#policy.limits.keepAliveTimeoutMs;
    this.#server.maxRequestsPerSocket = 1_000;
    this.#server.on("clientError", (_error, socket) => {
      socket.destroy();
    });
    const sweepEvery = Math.max(1_000, Math.min(30_000, Math.floor(this.#policy.limits.sessionIdleMs / 2)));
    this.#sweepTimer = setInterval(() => void this.expireIdleSessions(), sweepEvery);
    this.#sweepTimer.unref();
  }

  get sessionCount(): number {
    return this.#sessions.size;
  }

  /** Aggregate only; it intentionally reveals no session or certificate identifiers. */
  get activeEventStreamCount(): number {
    return [...this.#sessions.values()].reduce((total, session) => total + session.activeStreams, 0);
  }

  listen(options: CustomerVpcListenOptions): Promise<CustomerVpcListeningAddress> {
    if (typeof options.host !== "string" || options.host.length === 0 || !Number.isInteger(options.port)
      || options.port < 0 || options.port > 65_535) {
      return Promise.reject(new TypeError("listen requires an explicit host and valid TCP port"));
    }
    if (this.#closing || this.#listenerState === "closed") {
      return Promise.reject(new Error("customer VPC server cannot listen in its current state"));
    }
    if (this.#listenerState === "starting") {
      if (
        this.#listenTarget?.host === options.host &&
        this.#listenTarget.port === options.port &&
        this.#listenPromise !== undefined
      ) return this.#listenPromise;
      return Promise.reject(new Error("customer VPC server is already starting on another address"));
    }
    if (this.#listenerState === "listening") {
      return Promise.reject(new Error("customer VPC server cannot listen in its current state"));
    }

    this.#listenerState = "starting";
    this.#listenTarget = { host: options.host, port: options.port };
    const attempt = new Promise<CustomerVpcListeningAddress>((resolve, rejectPromise) => {
      const onError = (error: Error): void => {
        if (!this.#closing) {
          this.#listenerState = "idle";
          this.#listenTarget = undefined;
          this.#listenPromise = undefined;
        }
        rejectPromise(error);
      };
      this.#server.once("error", onError);
      try {
        this.#server.listen(options.port, options.host, () => {
          this.#server.off("error", onError);
          this.#listenerState = "listening";
          const address = this.#server.address();
          if (address === null || typeof address === "string") {
            rejectPromise(new Error("customer VPC listener did not return a TCP address"));
            return;
          }
          if (this.#closing) {
            rejectPromise(new Error("customer VPC server closed while the listener was starting"));
            return;
          }
          const tcp = address as AddressInfo;
          resolve({ host: tcp.address, port: tcp.port, family: tcp.family, path: CUSTOMER_VPC_MCP_PATH });
        });
      } catch (error) {
        this.#server.off("error", onError);
        onError(error as Error);
      }
    });
    this.#listenPromise = attempt;
    return attempt;
  }

  async #handle(request: IncomingMessage, response: ServerResponse): Promise<void> {
    if (this.#closing) {
      reject(response, 503);
      return;
    }
    // One passive SSE is separately bounded by each admitted session. It must not
    // consume the command concurrency pool and make a max=1 policy unusable.
    const countsTowardRequestLimit = request.method !== "GET";
    if (countsTowardRequestLimit && this.#activeRequests >= this.#policy.limits.maxConcurrentRequests) {
      reject(response, 503);
      return;
    }
    if (countsTowardRequestLimit) this.#activeRequests += 1;
    try {
      const fingerprint = peerFingerprint(request.socket as TLSSocket);
      const client = fingerprint === undefined ? undefined : findClient(this.#policy, fingerprint.bytes);
      if (fingerprint === undefined || client === undefined) {
        reject(response, 403);
        return;
      }
      if (request.url !== CUSTOMER_VPC_MCP_PATH) {
        reject(response, 404);
        return;
      }
      if (!this.#policy.allowedHosts.has(singleHeader(request, "host") ?? "")) {
        reject(response, 421);
        return;
      }
      if (!this.#policy.allowedOrigins.has(singleHeader(request, "origin") ?? "")) {
        reject(response, 403);
        return;
      }
      if (hasProxyAuthorityHeader(request)) {
        reject(response, 400);
        return;
      }
      if (request.method !== "POST" && request.method !== "GET" && request.method !== "DELETE") {
        reject(response, 405);
        return;
      }

      const sessionId = singleHeader(request, "mcp-session-id");
      if (request.headers["mcp-session-id"] !== undefined
        && (sessionId === undefined || !/^[A-Za-z0-9_-]{43}$/u.test(sessionId))) {
        reject(response, 400);
        return;
      }
      if (request.method === "POST") {
        if (!isJsonContentType(singleHeader(request, "content-type"))) {
          reject(response, 415);
          return;
        }
        if (request.headers["content-encoding"] !== undefined
          && singleHeader(request, "content-encoding")?.toLowerCase() !== "identity") {
          reject(response, 415);
          return;
        }
        const accepted = acceptedMediaTypes(singleHeader(request, "accept"));
        if (!accepted.has("application/json") || !accepted.has("text/event-stream")) {
          reject(response, 406);
          return;
        }
        let parsedBody: unknown;
        try {
          parsedBody = await readBoundedJson(request, this.#policy.limits.maxBodyBytes);
        } catch (error: unknown) {
          reject(response, error instanceof RangeError ? 413 : 400);
          return;
        }
        if (sessionId === undefined) {
          if (!isInitializeMessage(parsedBody)) {
            reject(response, 400);
            return;
          }
          if (this.#closing) {
            reject(response, 503);
            return;
          }
          const initialization = this.#initializeSession(client, fingerprint.digest, request, response, parsedBody);
          this.#pendingInitializations.add(initialization);
          try {
            await initialization;
          } finally {
            this.#pendingInitializations.delete(initialization);
          }
          return;
        }
        const session = this.#boundSession(sessionId, fingerprint.digest);
        if (session === undefined) {
          reject(response, 404);
          return;
        }
        await this.#dispatch(session, request, response, parsedBody);
        return;
      }

      if (sessionId === undefined) {
        reject(response, 400);
        return;
      }
      const session = this.#boundSession(sessionId, fingerprint.digest);
      if (session === undefined) {
        reject(response, 404);
        return;
      }
      if (request.method === "GET") {
        if (!acceptedMediaTypes(singleHeader(request, "accept")).has("text/event-stream")) {
          reject(response, 406);
          return;
        }
      } else if ((singleHeader(request, "content-length") ?? "0") !== "0"
        || request.headers["transfer-encoding"] !== undefined) {
        reject(response, 400);
        return;
      }
      await this.#dispatch(session, request, response);
      if (request.method === "DELETE") await this.#destroySession(session.id);
    } catch {
      reject(response, 500);
    } finally {
      if (countsTowardRequestLimit) this.#activeRequests -= 1;
    }
  }

  #boundSession(sessionId: string, fingerprintSha256: string): ActiveSession | undefined {
    const session = this.#sessions.get(sessionId);
    if (session === undefined || !session.initialized || session.closing) return undefined;
    const left = Buffer.from(session.fingerprintSha256, "hex");
    const right = Buffer.from(fingerprintSha256, "hex");
    return timingSafeEqual(left, right) ? session : undefined;
  }

  async #initializeSession(
    client: CompiledClientMapping,
    fingerprintSha256: string,
    request: IncomingMessage,
    response: ServerResponse,
    parsedBody: unknown,
  ): Promise<void> {
    if (this.#closing) {
      reject(response, 503);
      return;
    }
    if (this.#sessions.size + this.#pendingSessions >= this.#policy.limits.maxSessions) {
      reject(response, 503);
      return;
    }
    this.#pendingSessions += 1;
    const id = newSessionId();
    let session: ActiveSession | undefined;
    let runtime: MonitoringRuntime | undefined;
    try {
      runtime = await this.#runtimeFactory(Object.freeze({
        principal: Object.freeze({ ...client.principal, session: id }),
        clientCertificateFingerprintSha256: fingerprintSha256,
        surface: "customer-vpc" as const,
      }));
      if (this.#closing) {
        await closeRuntime(runtime);
        reject(response, 503);
        return;
      }
      const transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => id,
        enableJsonResponse: true,
        allowedHosts: [...this.#policy.allowedHosts],
        allowedOrigins: [...this.#policy.allowedOrigins],
        enableDnsRebindingProtection: true,
        onsessioninitialized: (initializedId) => {
          if (initializedId !== id || session === undefined) throw new Error("session initialization mismatch");
          session.initialized = true;
        },
      });
      const mcpServer = createProductionMonitoringMcpServer(runtime);
      session = {
        id,
        fingerprintSha256,
        transport,
        mcpServer,
        runtime,
        lastUsedAt: this.#now(),
        activeRequests: 0,
        activeStreams: 0,
        initialized: false,
        closing: false,
      };
      this.#sessions.set(id, session);
      await mcpServer.connect(transport);
      await this.#dispatch(session, request, response, parsedBody);
      if (!session.initialized) await this.#destroySession(id);
    } catch {
      if (session !== undefined) await this.#destroySession(session.id);
      else if (runtime !== undefined) await closeRuntime(runtime);
      reject(response, 500);
    } finally {
      this.#pendingSessions -= 1;
    }
  }

  async #dispatch(
    session: ActiveSession,
    request: IncomingMessage,
    response: ServerResponse,
    parsedBody?: unknown,
  ): Promise<void> {
    const isEventStream = request.method === "GET";
    if ((isEventStream && session.activeStreams >= 1)
      || (!isEventStream && session.activeRequests >= this.#policy.limits.maxConcurrentRequestsPerSession)) {
      reject(response, 429);
      return;
    }
    if (isEventStream) session.activeStreams += 1;
    else session.activeRequests += 1;
    session.lastUsedAt = this.#now();
    let timedOut = false;
    const timer = isEventStream ? undefined : setTimeout(() => {
        timedOut = true;
        reject(response, 504);
        void this.#destroySession(session.id);
      }, this.#policy.limits.requestTimeoutMs);
    timer?.unref();
    try {
      await session.transport.handleRequest(request, response, parsedBody);
    } catch {
      if (!timedOut) reject(response, 500);
    } finally {
      if (timer !== undefined) clearTimeout(timer);
      if (isEventStream) session.activeStreams -= 1;
      else session.activeRequests -= 1;
      session.lastUsedAt = this.#now();
    }
  }

  /**
   * Close sessions with no active command whose last inbound activity exceeded
   * the bound. A passive standalone SSE stream does not keep authority alive.
   */
  async expireIdleSessions(): Promise<number> {
    const cutoff = this.#now() - this.#policy.limits.sessionIdleMs;
    const expired = [...this.#sessions.values()]
      .filter((session) => !session.closing && session.activeRequests === 0 && session.lastUsedAt <= cutoff)
      .map((session) => session.id);
    await Promise.all(expired.map((id) => this.#destroySession(id)));
    return expired.length;
  }

  async #destroySession(id: string): Promise<void> {
    const session = this.#sessions.get(id);
    if (session === undefined || session.closing) return;
    session.closing = true;
    this.#sessions.delete(id);
    try {
      await session.mcpServer.close();
    } catch {
      try {
        await session.transport.close();
      } catch {
        // Closing is best effort; authority was already removed from the session map.
      }
    } finally {
      await closeRuntime(session.runtime);
    }
  }

  close(): Promise<void> {
    this.#closePromise ??= this.#closeAll();
    return this.#closePromise;
  }

  async #closeAll(): Promise<void> {
    this.#closing = true;
    clearInterval(this.#sweepTimer);
    const listenAttempt = this.#listenPromise;
    if (listenAttempt !== undefined) await Promise.allSettled([listenAttempt]);
    let listenerClosed: Promise<void> | undefined;
    if (this.#server.listening) {
      // Stop admission immediately, but let already-admitted initialization
      // reach its explicit 503/cleanup path before severing connections.
      listenerClosed = new Promise<void>((resolve) => {
        this.#server.close(() => resolve());
      });
    }
    await Promise.all([...this.#sessions.keys()].map((id) => this.#destroySession(id)));
    await Promise.allSettled([...this.#pendingInitializations]);
    // A session admitted immediately before closing is either in the first
    // snapshot or finishes initialization under the closing guard. Scan once
    // more so close() resolves only after every runtime is torn down.
    await Promise.all([...this.#sessions.keys()].map((id) => this.#destroySession(id)));
    if (listenerClosed !== undefined) {
      this.#server.closeAllConnections();
      await listenerClosed;
    }
    this.#listenerState = "closed";
    this.#listenTarget = undefined;
  }
}
