import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import {
  RESOURCE_MIME_TYPE,
  registerAppResource,
} from "@modelcontextprotocol/ext-apps/server";

export const PRODUCTION_MONITORING_LEGACY_APP_VERSION = "1.0.0";
export const PRODUCTION_MONITORING_LEGACY_APP_URI =
  `ui://production-monitoring/${PRODUCTION_MONITORING_LEGACY_APP_VERSION}/workspace.html`;
export const PRODUCTION_MONITORING_PREVIOUS_APP_VERSION = "2.0.0";
export const PRODUCTION_MONITORING_PREVIOUS_APP_URI =
  `ui://production-monitoring/${PRODUCTION_MONITORING_PREVIOUS_APP_VERSION}/workbench.html`;
export const PRODUCTION_MONITORING_APP_VERSION = "2.1.0";
export const PRODUCTION_MONITORING_APP_URI =
  `ui://production-monitoring/${PRODUCTION_MONITORING_APP_VERSION}/workbench.html`;

export const PRODUCTION_MONITORING_APP_RESOURCE_META = {
  csp: {
    connectDomains: [],
    resourceDomains: [],
  },
  prefersBorder: true,
} as const;

export const PRODUCTION_MONITORING_MODEL_ONLY_META = {
  ui: {
    visibility: ["model"],
  },
} as const;

export const PRODUCTION_MONITORING_WORKSPACE_META = {
  ui: {
    resourceUri: PRODUCTION_MONITORING_APP_URI,
    visibility: ["model"],
  },
  "openai/outputTemplate": PRODUCTION_MONITORING_APP_URI,
  "openai/widgetAccessible": true,
} as const;

export const PRODUCTION_MONITORING_APP_ONLY_META = {
  ui: {
    visibility: ["app"],
  },
} as const;

export const PRODUCTION_MONITORING_WORKSPACE_RESULT_META = {
  ui: {
    resourceUri: PRODUCTION_MONITORING_APP_URI,
  },
  "ui/resourceUri": PRODUCTION_MONITORING_APP_URI,
  "openai/outputTemplate": PRODUCTION_MONITORING_APP_URI,
};

interface GeneratedSourceManifest {
  schemaVersion: 1;
  sourceBytes: number;
  sourceSha256: string;
  parts: Array<{ name: string; bytes: number; sha256: string }>;
}

const GENERATED_SOURCE_MANIFEST = /^__PM_SOURCE_PARTS__=(\{[^\n]+\});\n?$/u;
const SHA256 = /^[a-f0-9]{64}$/u;
const WORKSPACE_PART = /^workspace\.html\.source\.part-(\d{3})$/u;

function parseWorkspaceManifest(value: string): GeneratedSourceManifest {
  const match = GENERATED_SOURCE_MANIFEST.exec(value);
  if (match?.[1] === undefined) throw new Error("The bundled Production Monitoring workspace manifest is invalid");
  let manifest: unknown;
  try {
    manifest = JSON.parse(match[1]);
  } catch {
    throw new Error("The bundled Production Monitoring workspace manifest is invalid");
  }
  if (
    manifest === null
    || typeof manifest !== "object"
    || (manifest as Partial<GeneratedSourceManifest>).schemaVersion !== 1
    || !Number.isSafeInteger((manifest as Partial<GeneratedSourceManifest>).sourceBytes)
    || (manifest as Partial<GeneratedSourceManifest>).sourceBytes! < 1
    || !SHA256.test((manifest as Partial<GeneratedSourceManifest>).sourceSha256 ?? "")
    || !Array.isArray((manifest as Partial<GeneratedSourceManifest>).parts)
    || (manifest as Partial<GeneratedSourceManifest>).parts!.length < 1
  ) {
    throw new Error("The bundled Production Monitoring workspace manifest is invalid");
  }
  const parsed = manifest as GeneratedSourceManifest;
  for (const [index, part] of parsed.parts.entries()) {
    const nameMatch = WORKSPACE_PART.exec(part.name);
    if (
      nameMatch?.[1] !== String(index).padStart(3, "0")
      || !Number.isSafeInteger(part.bytes)
      || part.bytes < 1
      || part.bytes > 140_000
      || !SHA256.test(part.sha256)
    ) {
      throw new Error("The bundled Production Monitoring workspace manifest is invalid");
    }
  }
  return parsed;
}

function sha256(value: Uint8Array): string {
  return createHash("sha256").update(value).digest("hex");
}

export async function readGeneratedWorkspaceHtml(manifestUrl: URL): Promise<string> {
  const manifest = parseWorkspaceManifest(await readFile(manifestUrl, "utf8"));
  const parts = await Promise.all(manifest.parts.map(async (part) => {
    const contents = await readFile(new URL(part.name, manifestUrl));
    if (contents.byteLength !== part.bytes || sha256(contents) !== part.sha256) {
      throw new Error("The bundled Production Monitoring workspace part failed integrity verification");
    }
    return contents;
  }));
  const source = Buffer.concat(parts);
  if (source.byteLength !== manifest.sourceBytes || sha256(source) !== manifest.sourceSha256) {
    throw new Error("The bundled Production Monitoring workspace failed integrity verification");
  }
  return source.toString("utf8");
}

async function readProductionMonitoringAppHtml(): Promise<string> {
  const candidates = [
    new URL("./workspace.html", import.meta.url),
    new URL("../../../plugins/production-monitoring/mcp/workspace.html", import.meta.url),
  ];
  for (const candidate of candidates) {
    try {
      return await readGeneratedWorkspaceHtml(candidate);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
  }
  throw new Error("The bundled Production Monitoring workspace is unavailable");
}

export function registerProductionMonitoringAppResource(server: McpServer): void {
  const register = (name: string, uri: string, description: string) => {
    registerAppResource(server, name, uri, {
      title: name,
      description,
      _meta: { ui: PRODUCTION_MONITORING_APP_RESOURCE_META },
    }, async () => ({
      contents: [{
        uri,
        mimeType: RESOURCE_MIME_TYPE,
        text: await readProductionMonitoringAppHtml(),
        _meta: { ui: PRODUCTION_MONITORING_APP_RESOURCE_META },
      }],
    }));
  };
  register(
    "Production Monitoring Workbench",
    PRODUCTION_MONITORING_APP_URI,
    "Persistent read-only incident side panel, evidence, hypotheses, patch handoff, and recovery workbench.",
  );
  register(
    "Production Monitoring Workbench (2.0 compatibility)",
    PRODUCTION_MONITORING_PREVIOUS_APP_URI,
    "Compatibility resource for Production Monitoring 2.0 workbench links.",
  );
  register(
    "Production Monitoring Workspace (legacy)",
    PRODUCTION_MONITORING_LEGACY_APP_URI,
    "Compatibility resource for Production Monitoring 1.x workspace links.",
  );
}
