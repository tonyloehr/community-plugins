import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { URL } from "node:url";

import {
  createRuntimeFromEnvironment,
} from "@codex-production-monitoring/evidence-server";
import {
  HashPinnedMacOsKeychainLoader,
  NativeGrafanaKeyringBackend,
  type GrafanaKeyringBackend,
  type NativeKeyringModuleLoader,
} from "../../grafana-credential-profile/src/index.ts";

import { createProductionMonitoringMcpServer } from "./server.ts";

export const BUNDLED_PRODUCTION_MACOS_KEYCHAIN_ASSETS = Object.freeze({
  arm64: Object.freeze({
    bytes: 491_232,
    sha256: "9627560bd2490b8495504df6b48dafe0153883aab09fd8eee976f826c74a6fff",
  }),
  x64: Object.freeze({
    bytes: 516_004,
    sha256: "3ad3b083cab321be04223e7fa1a22a8258c32c4da0883886683e25dcba9d03cc",
  }),
});

export const PRODUCTION_MONITORING_ARTIFACT_PRODUCER = Object.freeze({
  pluginVersion: "0.3.0",
  contractsVersion: "0.3.0",
  reportProjectionVersion: "1.1.0",
});

export const PRODUCTION_MONITORING_RUNTIME_NAMESPACE = "production-monitoring" as const;

export function createBundledProductionMacOsKeychainLoader(options: {
  platform?: NodeJS.Platform;
  architecture?: NodeJS.Architecture;
} = {}): NativeKeyringModuleLoader {
  const platform = options.platform ?? process.platform;
  const architecture = options.architecture ?? process.arch;
  if (architecture === "arm64") {
    return new HashPinnedMacOsKeychainLoader({
      platform,
      architecture,
      asset: {
        fileUrl: new URL("../native/keyring.darwin-arm64.node", import.meta.url),
        ...BUNDLED_PRODUCTION_MACOS_KEYCHAIN_ASSETS.arm64,
      },
    });
  }
  if (architecture === "x64") {
    return new HashPinnedMacOsKeychainLoader({
      platform,
      architecture,
      asset: {
        fileUrl: new URL("../native/keyring.darwin-x64.node", import.meta.url),
        ...BUNDLED_PRODUCTION_MACOS_KEYCHAIN_ASSETS.x64,
      },
    });
  }
  return new HashPinnedMacOsKeychainLoader({
    platform,
    architecture,
    asset: {
      fileUrl: new URL("../native/keyring.darwin-arm64.node", import.meta.url),
      ...BUNDLED_PRODUCTION_MACOS_KEYCHAIN_ASSETS.arm64,
    },
  });
}

export function createProductionMonitoringRuntimeFromEnvironment(
  environment: NodeJS.ProcessEnv = process.env,
  dependencies: {
    grafanaKeyringBackend?: GrafanaKeyringBackend;
    platform?: NodeJS.Platform;
    architecture?: NodeJS.Architecture;
  } = {},
) {
  const platform = dependencies.platform ?? process.platform;
  const architecture = dependencies.architecture ?? process.arch;
  let grafanaKeyringBackend = dependencies.grafanaKeyringBackend;
  if (
    grafanaKeyringBackend === undefined
    && platform === "darwin"
    && (architecture === "arm64" || architecture === "x64")
  ) {
    grafanaKeyringBackend = new NativeGrafanaKeyringBackend({
      platform,
      loader: createBundledProductionMacOsKeychainLoader({ platform, architecture }),
    });
  }
  return createRuntimeFromEnvironment(environment, {
    artifactProducer: PRODUCTION_MONITORING_ARTIFACT_PRODUCER,
    runtimeNamespace: PRODUCTION_MONITORING_RUNTIME_NAMESPACE,
    ...(grafanaKeyringBackend === undefined ? {} : { grafanaKeyringBackend }),
  });
}

interface AsyncCloseOwner {
  close(): Promise<void>;
}

/**
 * Close the stdio transport before relinquishing runtime authority. The queued
 * microtask makes the promise observable before either close can re-enter via
 * a transport callback, and a failed transport close must never skip runtime
 * teardown.
 */
export function createStdioShutdown(
  server: AsyncCloseOwner,
  runtime: AsyncCloseOwner,
): () => Promise<void> {
  let shutdownPromise: Promise<void> | undefined;
  return () => {
    shutdownPromise ??= Promise.resolve().then(async () => {
      try {
        await server.close();
      } finally {
        await runtime.close();
      }
    });
    return shutdownPromise;
  };
}

/** Connect failure owns the same terminal cleanup path as signals and EOF. */
export async function connectWithStdioShutdown(
  connect: () => Promise<void>,
  shutdown: () => Promise<void>,
): Promise<void> {
  try {
    await connect();
  } catch (connectError) {
    try {
      await shutdown();
    } catch (shutdownError) {
      throw new AggregateError(
        [connectError, shutdownError],
        "Production monitoring stdio connection and shutdown both failed",
      );
    }
    throw connectError;
  }
}

function reportFailure(prefix: string, error: unknown): void {
  const name = error instanceof Error ? error.name : "Error";
  const code = typeof error === "object" && error !== null && "code" in error
    ? String(error.code)
    : "NO_CODE";
  const message = error instanceof Error ? error.message : "Unknown error";
  console.error(`${prefix}: ${name}:${code}:${message}`);
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length !== 1 || args[0] !== "--stdio") {
    throw new Error("Usage: server.mjs --stdio");
  }
  const runtime = createProductionMonitoringRuntimeFromEnvironment();
  const server = createProductionMonitoringMcpServer(runtime);
  const transport = new StdioServerTransport();
  const shutdown = createStdioShutdown(server, runtime);
  let terminalExitPromise: Promise<void> | undefined;
  const requestTerminalExit = (): void => {
    terminalExitPromise ??= shutdown().then(
      () => {
        process.exitCode = 0;
      },
      (error: unknown) => {
        reportFailure("Production monitoring server shutdown failed", error);
        process.exitCode = 1;
      },
    );
    void terminalExitPromise;
  };
  process.once("SIGINT", requestTerminalExit);
  process.once("SIGTERM", requestTerminalExit);
  process.stdin.once("end", requestTerminalExit);
  await connectWithStdioShutdown(() => server.connect(transport), shutdown);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error: unknown) => {
    reportFailure("Production monitoring server failed to start", error);
    process.exitCode = 1;
  });
}
