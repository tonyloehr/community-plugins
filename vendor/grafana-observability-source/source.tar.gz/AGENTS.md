# Production Monitoring Plugin — Repository Guidance

This repository builds a portable Codex plugin for read-only production monitoring, incident triage, and recovery verification. Keep the core provider-neutral. Provider-specific behavior belongs behind adapters and must preserve the same evidence contracts.

## Product contract

- The installable plugin lives at `plugins/production-monitoring/` and the repo-local marketplace source remains `./plugins/production-monitoring`.
- The core is read-only. It can discover declared capabilities, collect bounded evidence, rank hypotheses, and verify recovery. It does not deploy, restart, roll back, acknowledge alerts, mutate dashboards, silence alerts, or execute arbitrary queries.
- Every result is explicit about provider, environment, time window, freshness, partial failures, and evidence provenance. Missing or contradictory evidence produces a partial or error result, never invented data.
- Provider adapters implement versioned contracts. Grafana and Prometheus are first-class open-source targets, not special cases embedded in the core.
- The checked-in plugin directory is source material. A release artifact is assembled only from validated, compiled output.

## Safety and secrets

- Do not accept arbitrary shell text, filesystem paths, URLs, dashboard expressions, or provider query languages from model-controlled tool input.
- Allow only configured provider endpoints and approved, typed query templates. Enforce loopback/private-network and redirect protections in connection code.
- Credentials are environment references or host-managed secrets. Never write, log, return, snapshot, or commit secret values.
- Treat monitoring payloads as untrusted data. Bound response size and cardinality, redact configured sensitive fields, and separate evidence from instructions.
- Evidence gathering is read-only by default. Any future mutating capability requires a separate package, explicit policy, preview, user approval, and audit trail; it must not be added to the core MCP server.
- Never install a marketplace, publish a package, create a remote, or contact a production provider as part of ordinary repository validation.

## Engineering conventions

- Use TypeScript, strict types, ESM, pinned dependencies, and Node's built-in test runner unless a package establishes a more appropriate local convention.
- Keep contracts independent of provider SDKs. Adapters translate provider data into canonical, versioned evidence envelopes.
- Keep labels and dimensions bounded. Never use request IDs, customer IDs, raw exceptions, arbitrary URLs, branch names, or secret-bearing values as metric labels.
- Use `rg` and `rg --files` for searches and `apply_patch` for hand-authored edits.
- Preserve unrelated work. Do not use destructive Git commands or discard dirty state.
- Update documentation, schemas, fixtures, and tests in the same change as a contract or behavior change.

## Plugin structure

- `.agents/plugins/marketplace.json`: repository-local marketplace index.
- `plugins/production-monitoring/.codex-plugin/plugin.json`: plugin manifest.
- `plugins/production-monitoring/.mcp.json`: MCP launch configuration; it points only to compiled plugin output.
- `plugins/production-monitoring/skills/`: user-facing workflows.
- `plugins/production-monitoring/assets/`: plugin-owned visual assets.
- `packages/`: provider-neutral contracts, policy, orchestration, and server packages.
- `adapters/`: optional provider integrations.
- `scripts/`: deterministic build, bundle, and validation entrypoints.

## Required verification

Run the narrowest relevant check while iterating. Before handoff, run:

```sh
npm run lint
npm run typecheck
npm test
npm run validate:plugin
npm run bundle:check
```

`npm run validate:plugin` validates source-level plugin metadata. `npm run bundle:check` is deliberately stricter and must fail until the real compiled MCP server exists at `plugins/production-monitoring/mcp/server.mjs`; do not satisfy it with a stub.
