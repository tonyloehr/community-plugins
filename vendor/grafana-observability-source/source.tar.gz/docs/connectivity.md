# Connectivity and deployment surfaces

Connectivity is a property of the active deployment surface and administrator
policy, not of the plugin name. Capability discovery must report the active
surface, route, provider availability, limitations, and one of
`HOST_DEPENDENT`, `VPC_ONLY`, `RELAY_ONLY`, `NONE`, or `NOT_APPLICABLE`.
Reachability on one surface never implies reachability on another.

<!-- connectivity-matrix:v1 -->
| Surface ID | Current implementation status | Permitted reachability | Explicit non-claim |
| --- | --- | --- | --- |
| `FIXTURE` | `IMPLEMENTED` | No provider network request; credential-free deterministic replay/simulation. | It is not live evidence and cannot authorize production conclusions or actions. |
| `LOCAL_STDIO` | `IMPLEMENTED` | The bundled runtime admits only its exact release-code-owned first-party child worker. Its trusted HTTP client validates administrator-approved endpoints before each direct socket. `direct` uses ordinary host routing; `host_vpn` uses the same transport after the owner connects the host to the approved VPN. | The child process is not an OS egress/filesystem/resource sandbox. A compromised worker could use ambient host authority, so third-party workers are not admitted. It does not start a VPN, configure a proxy, or grant another surface private reachability. `application_proxy` is `NOT_IMPLEMENTED`. |
| `CUSTOMER_VPC` | `IMPLEMENTED_REFERENCE` | The reference Streamable HTTP server accepts TLS 1.3 mutual-TLS clients mapped by administrator-pinned certificate fingerprint to one principal and tenant, then uses the same production-read-only runtime inside the customer deployment. | Passing the deterministic mTLS test is not a deployed or approved customer route. No publisher-hosted or other tenant reachability is implied. |
| `CUSTOMER_RELAY` | `NOT_IMPLEMENTED` | Design target: outbound-only relay for signed operation IDs to fixed customer endpoints. | It is not a general proxy and accepts no URL, query, path, header, credential, or shell text. |
| `PUBLISHER_HOSTED` | `NOT_IMPLEMENTED` | Future public provider APIs explicitly approved for that service, or a separately reviewed customer route. | It cannot reach a user's localhost, laptop VPN, or private VPC by default. |

## Route controls

- The model chooses profile, scope, operation, and run aliases only. The active
  trust root supplies endpoints and credentials.
- Endpoint authentication is a closed choice: `NONE`, `BEARER` with
  `tokenRef`, `BASIC` with separate `usernameRef` and `passwordRef`, or `MTLS`
  with separate `certificateRef` and `privateKeyRef`. Each reference names an
  environment entry, workload identity, or approved broker; it is never the
  credential value.
- HTTPS is required except for explicitly approved loopback HTTP. URLs cannot
  embed credentials, fragments, or request-time query data. Each endpoint pins
  `tls.minimumVersion` to `TLSv1.2` or `TLSv1.3`; `tls.caRef` optionally names a
  custom CA and `tls.serverName` pins the SNI/certificate verification name.
- `networkClass` is exactly `loopback`, `private`, or `public`. Before opening a
  socket, the runtime checks every DNS address it may select against that class,
  pins one approved address, and then verifies the connected socket peer is the
  same address and class. Empty, mixed, rebinding, or wrong-class results fail
  closed.
- `direct` and `host_vpn` are both direct-socket routes. `host_vpn` means the
  administrator already established host routing to a private destination; the
  plugin neither creates nor controls the VPN. `application_proxy` is a reserved
  contract value that fails with `APPLICATION_PROXY_NOT_IMPLEMENTED`; ambient
  proxy environment variables do not turn it into a supported route.
- Redirects are denied. A 3xx response is returned to the fixed adapter for
  classification and its `Location` is never followed to another destination.
- Tenant headers and auth are fixed host-managed bindings. They never appear in
  compiled operations, evidence, links, logs, or model-visible errors.
- Endpoint and connected-peer checks are application controls inside the
  trusted bundled worker, not an OS egress firewall. Deployments that require
  defense in depth must add and verify an external deny-default network policy.
- Git is a local configured-workspace read and opens no provider network route.
- A missing route or registration is `UNAVAILABLE`, `UNSUPPORTED`, or `BLOCKED`.
  It never falls back to another tenant, a synthetic live result, or an
  unreviewed proxy.

## Surface acceptance gate

Before changing a status to implemented/supported, test authentication,
authorization, TLS/mTLS/OAuth, proxies, DNS and connected-peer enforcement,
redirect denial, endpoint/tenant pinning, timeouts, cancellation, rate limits,
audit durability, residency/retention, restart behavior, and sanitized failure
output on that exact surface. Record an owner and support/rollback procedure.

`IMPLEMENTED_REFERENCE` means the source, protocol policy, and real local mTLS
integration test exist. A customer-VPC surface becomes supported only after its
customer-owned deployment, certificate lifecycle, IAM, ingress/egress,
residency, audit, support, and rollback controls are separately reviewed and
recorded. The repository has not performed that deployment or approval.
