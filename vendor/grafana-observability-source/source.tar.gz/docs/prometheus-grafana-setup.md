# Prometheus and Grafana setup

Prometheus-compatible metrics and Grafana read metadata are first-class adapter
targets. Setup is production-read-only: it may read administrator-approved
operations but cannot edit dashboards, data sources, alerts, annotations, or
silences.

## 1. Record an untrusted proposal

Copy the bundled proposal example into a review branch only if the repository
owner wants a proposal file. It contains aliases, not endpoints or credentials.
Do not try to compile it against the fixture profile: the aliases intentionally
do not exist there.

After an administrator has created a matching trust root outside the checkout,
validate it and create a separate owner-only activation receipt. These commands
perform no provider request:

```sh
install -d -m 700 /absolute/operator-state/production-monitoring
node ./plugins/production-monitoring/scripts/pmctl.mjs admin validate-root \
  --root /absolute/admin-owned/production-monitoring-root --json
node ./plugins/production-monitoring/scripts/pmctl.mjs admin activate \
  --root /absolute/admin-owned/production-monitoring-root \
  --receipt /absolute/operator-state/production-monitoring/active-root.json \
  --expected-root-manifest-sha256 REVIEWED_ROOT_MANIFEST_SHA256 \
  --expected-trust-bundle-sha256 REVIEWED_TRUST_BUNDLE_SHA256 \
  --json
```

The two expected digests must be copied from the preceding validation output;
activation fails if the reviewed material changed.

The trusted launcher supplies both absolute paths for a no-network compilation
preview:

```sh
PRODUCTION_MONITORING_MODE=live \
PRODUCTION_MONITORING_TRUST_ROOT=/absolute/admin-owned/production-monitoring-root \
PRODUCTION_MONITORING_ACTIVATION_RECEIPT=/absolute/operator-state/production-monitoring/active-root.json \
node ./plugins/production-monitoring/scripts/pmctl.mjs setup dry-run \
  --proposal ./plugins/production-monitoring/examples/profiles/prometheus-grafana-proposal.yaml \
  --json
```

The proposal cannot activate access, and the command performs no provider
request. If no matching trusted root exists, stop after reviewing the aliases;
do not weaken the fixture or invent production connectivity.

See [operator setup and activation](./operator-activation.md) for receipt
replacement, digest binding, and startup failure behavior.

## 2. Define endpoint and credential references

An administrator binds each endpoint alias to one canonical URL, adapter,
authentication policy, TLS policy, network class, route, and tenant policy.
Store only the credential reference name, never the
credential value. For example, an
administrator-reviewed endpoint entry using a bearer and a custom CA can use:

```yaml
endpointId: prometheus-primary
adapterId: prometheus
baseUrl: https://prometheus.monitoring.example/
authentication:
  mode: BEARER
  tokenRef:
    kind: env
    key: PROMETHEUS_READ_TOKEN
tls:
  minimumVersion: TLSv1.2
  caRef:
    kind: env
    key: PROMETHEUS_CA_CERTIFICATE
  serverName: prometheus.monitoring.example
network:
  followRedirects: false
  allowLoopbackHttp: false
  allowedHosts:
    - prometheus.monitoring.example
  networkClass: public
  routeMode: direct
```

Grafana uses a different least-privilege identity and reference such as
`GRAFANA_READ_TOKEN`. Never put either value in YAML, chat, commands, Git,
screenshots, logs, or artifacts. Prefer workload identity or an approved secret
broker when the deployment supports it.

The current signed local-worker launcher resolves only the manifest-enumerated
`env` references. A `workload_identity` or `broker` reference fails closed with
`CREDENTIAL_RESOLVER_NOT_CONFIGURED` unless that deployment supplies an explicit
resolver integration; a same-named environment variable is never a substitute.

Authentication is a closed tagged union:

- `NONE` has no credential reference.
- `BEARER` requires `tokenRef`.
- `BASIC` requires distinct `usernameRef` and `passwordRef`.
- `MTLS` requires distinct `certificateRef` and `privateKeyRef` and an HTTPS
  endpoint.

Every credential member is an `env`, `workload_identity`, or `broker` reference.
`tls.caRef` uses the same reference shape and is independent of the authentication
mode. `tls.minimumVersion` is exactly `TLSv1.2` or `TLSv1.3`, while
`tls.serverName` supplies the reviewed SNI and certificate verification name.
Omit `caRef` when the endpoint uses the deployment's approved system trust store.

The URL above is documentation-only. Replace it in the administrator-owned
trust root, not in model input. HTTPS is required except for an explicitly
approved loopback endpoint. Redirects stay disabled. The declared `loopback`,
`private`, or `public` network class must match the resolved DNS address selected
for the connection and the connected socket peer; mismatches and rebinding fail
closed.

`direct` and `host_vpn` both open a direct socket. `host_vpn` is restricted to a
private destination and assumes an administrator has already connected and
routed the host through the approved VPN; it does not start or manage that VPN.
`application_proxy` is recognized only to return
`APPLICATION_PROXY_NOT_IMPLEMENTED`. Do not configure it or rely on ambient
HTTP(S) proxy variables.

## 3. Bind reviewed semantic operations

The model selects operation IDs such as service health, latency, error ratio,
alert state, dashboard metadata, or change annotations. Administrators map those
IDs to fixed PromQL templates and fixed Grafana routes. Do not expose arbitrary
PromQL, dashboard expressions, data source proxy paths, URLs, headers, tenant
values, or time-unbounded queries.

Keep labels bounded. Do not use request IDs, customer IDs, raw exceptions,
arbitrary URLs, branch names, or secret-bearing strings as metric labels.

### Reviewed workbench navigation

Workbench source links do not widen these bindings. Evidence cards carry only
opaque link references. On a user click, the server rechecks the principal,
workspace, evidence source, endpoint alias, adapter, and allowed same-origin
host before it returns a navigation target. The widget cannot supply a Grafana
route, PromQL expression, provider URL, or redirect.

A safe adapter-provided Grafana path may open through the standard MCP Apps
external-navigation flow; otherwise navigation is limited to the approved
Grafana root or fixed Prometheus `/graph` surface. These are reviewed provider
destinations, not guaranteed incident query/window permalinks. Exact query and
time-window links are deferred until the operation snapshot can bind both. If a
safe target cannot be constructed, the evidence remains visible and the link is
unavailable. Never add an access-bearing URL or credential-bearing query
parameter merely to make a workbench link appear.

## 4. Preflight without revealing credentials

After activation by an authorized administrator, run local checks from a surface
that already has the approved network route:

```sh
node ./plugins/production-monitoring/scripts/pmctl.mjs preview-access \
  --profile production-read \
  --json
```

This preview performs no provider I/O or credential resolution and returns no
secret values. It confirms the activated destinations, reference names, routes,
and manifest-sealed exact scope admission before `doctor` opens a health route.

```sh
node ./plugins/production-monitoring/scripts/pmctl.mjs doctor \
  --profile production-read \
  --json
```

```sh
node ./plugins/production-monitoring/scripts/pmctl.mjs capabilities \
  --profile production-read \
  --json
```

`doctor` reports readiness and sanitized reasons. It must not print a token,
private endpoint, raw provider body, or signed link. A local Desktop/CLI process
may use an approved host/VPN route; a publisher-hosted service cannot thereby
reach that host, VPN, loopback, or private VPC.

## 5. Prove live behavior deliberately

Live connection checks require the operator to name the exact tenant,
environment, service, route, time window, and approved operations. Start with one
short known operation. Treat absent, stale, empty, truncated, contradictory, or
unavailable evidence as a partial/error result—not as healthy. Keep Prometheus
and Grafana independently inspectable as the authoritative evidence sources.
