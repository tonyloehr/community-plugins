# Security and privacy threat model

## Scope and security objective

The core plugin gathers bounded production evidence and writes only plugin-owned
run, audit, and artifact state. It has no provider mutation operation. The
security objective is to prevent model-controlled input, provider-controlled
payloads, repository files, or one tenant from expanding the administrator's
approved provider, operation, endpoint, scope, or data-retention authority.

The Codex sandbox is defense in depth; it is not an identity, authorization, or
network boundary. Existing monitoring systems and incident procedures remain
authoritative if the plugin is unavailable.

## Assets

- provider credentials, workload identity, and endpoint/tenant bindings;
- production metrics, alerts, logs, traces, runtime state, source context, and
  incident artifacts;
- the administrator-owned trust root, operation catalog, signing keys, adapter
  packages, and revocation state;
- opaque run handles, principal bindings, leases, audit records, and integrity
  receipts.

## Trust boundaries

1. Model or automation client to the MCP/headless input schema.
2. Untrusted repository proposal to the administrator-owned active trust root.
3. Evidence server to adapter host, credential broker, audit sink, and artifact
   store.
4. Release-code-owned adapter child process to its approved provider endpoint.
   The application transport enforces that binding inside trusted first-party
   code; the child process is not an OS network or filesystem sandbox.
5. Provider-controlled payload to normalized evidence.
6. One principal, tenant, run, or child verification run to another.
7. Local stdio, customer-VPC, relay, and publisher-hosted surfaces; reachability
   on one surface never implies reachability on another.
8. Durable state directories are private to one cooperative OS account. Another
   process already running as that account is an owner compromise, not an
   adversary the pathname-based state primitive can isolate from.

## Threats and controls

| Threat | Control and fail-closed behavior | Deterministic evidence |
| --- | --- | --- |
| Arbitrary URL, SSRF, redirect, or DNS rebinding | Model tools accept aliases and operation IDs only. The active endpoint registry supplies destinations; adapters expose fixed typed routes. Redirects default off. A transport must recheck the resolved and connected peer under its network policy. | Closed provider-definition conformance and URL/query/path/header fuzz tests. Transport penetration tests remain topology-specific. |
| Arbitrary query, path, header, tenant, or shell input | `compile` accepts an exact hash-bound catalog reference (or exact fixed binding ID). Git uses only administrator-reviewed path scopes and fixed no-shell argv; provider-enumerated paths are containment checked before bounded reads. Unknown fields fail. | `CORE_READ` vectors for all current adapters plus 96 deterministic hostile-input cases and real-repository Git scope/link/race tests. |
| Misleading or raced source snapshot | Git status includes non-ignored untracked files, binds full HEAD or explicit `UNBORN`, index/status digests, and bounded regular-file content receipts into one canonical snapshot hash. It rereads receipts and Git state, rejects links/special files and changes during collection, and labels ignored files `EXCLUDED`. | Clean, modified, staged, deleted, unborn/all-untracked, path-isolation, digest-change, link, limit, and in-flight mutation tests. |
| Malicious repository configuration | Repository configuration is only a proposal. Activation requires an owner/signature-verified root outside the checkout; a run snapshots approved hashes. | Config trust-root and proposal tests; the conformance kit never reads repository configuration. |
| Credential or sensitive-data leakage | Credentials stay behind environment/workload/broker references. Secret-bearing keys and values are discarded before normalization; errors are classified and sanitized. | Secret fixtures, unknown-exception canaries, and sanitized provider-error probes. |
| Prompt injection in telemetry or source | Provider text is data, never an instruction channel. Instruction-like text is detected; strict profiles discard matching payloads. Workflows cite evidence IDs and never execute embedded text. | Injection fixture with a rejecting redaction policy proves the raw instruction does not cross the host boundary. |
| Cross-tenant or cross-scope evidence | Expected tenant, environment, and service are pinned in run context and checked against provider claims. Mismatch discards the entire payload and returns a generic error. | Cross-tenant fixture and per-adapter scope vectors. |
| Cardinality, size, cost, or timeout exhaustion | Operation and run budgets bound bytes, rows, series, points, lookback, timeout, per-source request quotas, deterministic non-monetary resource cost, and concurrency. Provider rate-limit responses force same-source deferral and serial fallback. Both adapters and the host enforce bounds; cancellation is propagated. | Row/byte/series/point adversarial tests, quota/cost exhaustion, provider rate-limit lane isolation, and cancellation probes. |
| Provider or schema drift | Critical schema/state/type changes fail validation. Missing evidence is `EMPTY`, `ERROR`, `PARTIAL`, or `BLOCKED`, never healthy data. | Schema-drift fixture and provider-specific malformed-response suites. |
| Adapter replacement or child-process escape | The current pre-1.0 runtime admits only the exact first-party and fixture package IDs compiled into the release-owned provider worker, with an approved signature/digest, fixed artifact mapping, bounded protocol, and minimal environment. A model cannot select a path or install an adapter. Signing and a child process do **not** enforce filesystem, network, subprocess, CPU, or memory isolation; application-level endpoint checks are trusted only because third-party worker code is rejected. A future third-party runtime must fail closed unless its deployment actually supplies and verifies those OS containment controls. | Configuration and runtime tests reject third-party package identities (including a forged loaded root); worker admission tests cover signature, digest, fixed path, protocol, environment, crash, cancellation, and deadlines. Release certification reruns first-party vectors through the code-owned child worker. |
| Run confusion, replay, or durable-state exhaustion | Server-issued handles are principal-bound, expiring, lease-protected, revisioned, and distinct from public run IDs. Operations are authorized by snapshotted hashes. Durable authority uses a small integrity-protected coordinator and 256 deterministic bounded A/B buckets, so retained history cannot exhaust one global state file; ordinary mutations rewrite only the affected bucket plus coordinator. Every restart validates exact bucket generations, hashes, and counts. Ordinary reads hold the coordinator lock and scan all active buckets for a consistent view but do not rewrite the coordinator or take redundant per-bucket recovery guards; each bucket remains capped at 32 MiB. Process memory is bounded independently: runtime sessions default to 128 (hard maximum 4,096), durable no-lease sessions may be evicted and reconstructed from integrity-protected checkpoints, and volatile capacity fails closed. Runtime and gateway close are terminal and wait for admitted initialization. | Run-store lease, idempotency, expiry, ownership, child-verification, migration, bucket-boundary, no-op-read, stale-lock, missing/corrupt bucket, restart, session-capacity, durable-reconstruction, and terminal-close tests. |
| Artifact path or destructive-cleanup attack | Private owned root, canonical containment, atomic sealing, and manifest-last integrity. Explicit whole-root cleanup refuses unknown/unreceipted entries, rechecks exact path/device/inode identities, removes only enumerated entries, and removes the ownership marker last. Raw provider retention is fixed to `NONE`; the core has no scheduled or per-bundle deletion service. | Artifact finalization, symlink/hardlink/containment, unknown-entry refusal, identity recheck, marker-last cleanup, and deletion-receipt tests. |
| Audit outage, corruption, or unbounded rewrite | Required-audit profiles stop before evidence collection; optional audit failure becomes an explicit limitation. Durable audit entries are a global JCS hash chain split into immutable owner-only segments of at most 128 entries/1 MiB plus one equivalently bounded active tail in the integrity-protected head. Ordinary append rewrites only the head; rotation publishes the exact tail and then clears it from the head. Construction and explicit full snapshot verify the complete chain. Hot per-run queries verify exact numbered segments and use a discardable global LRU bounded to 64 runs, 1,024 events, and 4 MiB by default, so durable history is not retained indefinitely in memory. Only one exact post-segment/pre-head crash tail is reconciled. Volatile audit fails closed at 4,096 events or 8 MiB instead of evicting accepted authority. | Evidence-host audit failure plus envelope-boundary, rotation, restart, bounded-cache/cold-history, incremental-read, append-only legacy migration, crash-before/after-head, missing/corrupt/reordered/excess segment tests. |
| Simulated data shown as live | Origin is mandatory and fixture profiles allow only `SIMULATED`/`REPLAY`. Simulated evidence cannot authorize a live completion claim. | Fixture runtime profile and MCP/headless tests. |

## Data minimization

Adapters return normalized aggregates, bounded events, and sanitized references.
High-cardinality request/customer IDs, raw exception objects, arbitrary URLs,
query text, credentials, and signed links do not become dimensions or portable
report content. Diagnostic telemetry is local/off by default and may contain
operation names, counts, duration, budget use, adapter version, redaction count,
and sanitized error class—never provider payloads. The canonical retention mode
is `NONE`; accepting a duration without implementing raw-payload storage would be
a false contract and therefore fails validation.

## Residual risks and release gates

- Instruction detection is not semantic proof of safety. Strict environments
  should reject instruction-like free text or expose only deterministic fields.
- Direct in-process conformance proves the adapter contract, not production
  admission or OS isolation. A `SIGNED_HOST` receipt proves the signed stdio
  host path only; it does not prove filesystem, network, subprocess, CPU, or
  memory containment. First-party production adapters must also pass the same
  vectors through the release-code-owned child-worker launcher. Third-party
  packages have no v0.1 production activation path.
- TLS, proxy, DNS, connected-peer, workload-identity, and residency controls are
  deployment properties. Each claimed topology needs its own penetration and
  operations review.
- Provider version ranges in the compatibility matrix are declared support
  targets backed by local contract fixtures, not evidence that every patch
  version was exercised against a live provider.
- Run TTL and `sweepExpired()` revoke execution authority; they are not data
  erasure. The core has no automatic retention/deletion service for sealed
  artifacts, durable audit state, or checkpoints. A deployment owner must supply
  and verify that lifecycle before making a timed-deletion claim.
- Run buckets remove the former single-file growth ceiling, not all capacity
  planning. Reads validate all current buckets, one adversarially concentrated
  bucket can still reach its 32 MiB bound, and immutable audit segments continue
  to consume disk until the deployment owner's separately approved retention
  lifecycle acts. Capacity and disk alerts therefore remain deployment duties.
- Process caches are optimizations, not audit authority. Durable audit startup
  and explicit global snapshot verify the complete owner-only inventory and
  hash chain; cold per-run reads verify every committed numbered segment.
  Durable session eviction is allowed only without an active lease and resumes
  from integrity-protected checkpoints. The explicit global-audit snapshot API
  intentionally materializes the complete requested history, and cold per-run
  scans remain O(total committed segments) without a trusted per-run disk
  index. Deployment-wide admission and memory limits remain infrastructure
  duties in multi-process topologies.
- Atomic state lock acquisition, dead-main-lock recovery, and release serialize
  through an exact owner-only reclaim guard. A dead or malformed guard is not
  automatically removed: the store fails closed until an operator verifies and
  removes that exact receipt. This narrow crash-availability tradeoff prevents
  two compliant reclaimers from deleting replacement lock authority.
- If a state write commits but guard contention prevents main-lock release, the
  caller receives `STATE_LOCKED` and both receipts remain. After the writer exits,
  an operator must verify/remove only the stale guard; the next transaction then
  reclaims the dead main lock and observes the committed generation. Exact
  device/inode/nonce checks protect compliant processes, but POSIX pathname
  unlink has no compare-and-swap primitive: a malicious same-owner process could
  replace a lock between final check and unlink. Protecting the private state
  directory from untrusted same-UID processes is therefore a deployment duty.
- v1-to-v2 migration holds the legacy authority lock continuously through the
  retained snapshot, staged shards/segments, and tombstone; the v2 coordinator
  commits last. A compliant old binary therefore cannot replace legacy
  authority during migration. Quiesce all plugin processes before operator
  recovery of a dead guard; never remove a live or uncertain receipt.

Report a suspected tenant crossover, credential exposure, trust-root compromise,
or adapter-signing compromise as a security incident. Revoke the relevant
identity/key/package, block new runs, preserve sanitized audit receipts, and do
not retain the leaked provider payload.
