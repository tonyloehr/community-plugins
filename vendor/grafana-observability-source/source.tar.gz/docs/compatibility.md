# Compatibility matrix

This matrix describes the current source tree. Declared provider ranges are
admission constraints and contract-test targets; they are not a claim that every
patch release has been tested against a live production system.

## Runtime and contracts

| Component | Current version/range | Verification status |
| --- | --- | --- |
| Production Monitoring plugin manifest | `0.3.0` | Source metadata validation; release execution remains approval-gated |
| Grafana Observability plugin manifest | `0.1.0` | Independently versioned source metadata validation; skills/tools only |
| Shared package train | `0.3.0` | Exact workspace dependency pins and lockfile validation |
| Node.js | `>=22.19.0` | Full release CI is configured serially for exact `22.19.0` and `26.0.0`; the macOS sandbox eval is exact `22.19.0` |
| npm | `>=10` | Repository engine constraint |
| MCP TypeScript SDK | `1.30.0` | Locked dependency; local stdio source tests |
| Core JSON schemas | `1.0.0` and additive `1.1.0` readers | Draft 2020-12 schema, dual-reader, and canonicalization tests |
| Adapter protocol | `1.0` / `PM_ADAPTER_STDIO_V1` | Signed admission, protocol, doctor, cancellation, crash, budget, and release-shaped first-party child-worker tests; no OS-sandbox claim |
| Provider result schema | `1.0.0` | Exercised by all current `CORE_READ` vectors |
| Workflow request/result | `1.0.0` | Schema, durable lifecycle, and headless JSONL tests; fresh-context usefulness remains a human evaluation gate |
| Workbench snapshot / UI resource | `1.0.0` + `1.1.0` / `ui://production-monitoring/2.1.0/workbench.html` | Dual-reader projection; `1.1.0` adds provider-neutral issues and exact issue/hypothesis patch binding; interactive-decoupled MCP App requests one host panel after its first verified snapshot, with 2.0 and 1.0 resource aliases plus inline fallback; no native-sidebar compatibility claim |
| Local stdio fixture surface | implemented | Deterministic, no-network bundled MCP/CLI tests |
| Live local surface | implemented source and bundle | Administrator-owned trust root, exact code-owned first-party child worker, hardened application GET transport, and fail-closed doctor; live provider authorization remains environment-specific; no filesystem/egress/CPU/memory sandbox is supplied |
| Customer-VPC surface | reference implementation | TLS 1.3 mutual-TLS policy and real local certificate/session integration tests; customer deployment and approval are not implied |
| Relay/publisher-hosted surfaces | not implemented | No compatibility or private-network reachability claim |

## Adapters

| Adapter package | Version | Declared provider range | Domains | Current conformance evidence |
| --- | --- | --- | --- | --- |
| `adapter.fixture.v1` | `1.0.0` | fixture `1.x` | metrics | Direct `CORE_READ`; passing direct `METRICS` receipt; signed child-worker boundary; all fifteen deterministic scenarios |
| `adapter.prometheus.v1` | `1.0.0` | Prometheus `>=2.45 <4` | metrics, alerts | Direct `CORE_READ`; passing direct `METRICS` and `ALERTS` receipts; instant/range/alerts/rules fixtures |
| `adapter.grafana.v1` | `1.1.0` | Grafana `>=10 <14` | alerts, runtime, changes, runbooks, metrics, logs, traces | Existing read-only metadata/deep-link routes plus one catalog-bound `/api/ds/query` target; discovery and per-query health preflight reject unsupported versions before query I/O, Grafana 13 carries a legacy-API deprecation warning, and 14+ fails closed; passing direct receipts for every declared domain; arbitrary runtime query text remains rejected |
| `adapter.git.v1` | `1.0.0` | Git `>=2.30` | changes | Direct `CORE_READ`; passing direct `CHANGES` receipt through a real temporary-repository status snapshot; fixed no-shell argv and bounded content receipts |
| `adapter.alertmanager.v1` | `1.0.0` | Alertmanager `>=0.25 <1` | alerts, runtime | Direct `CORE_READ`; passing direct `ALERTS` and `RUNTIME` receipts; fixed GET route fixtures |
| `adapter.loki.v1` | `1.0.0` | Loki `>=2.9 <4` | logs | Direct `CORE_READ`; passing direct `LOGS` receipt; bounded query-range fixtures |
| `adapter.tempo.v1` | `1.0.0` | Tempo `>=2.4 <3` | traces | Direct `CORE_READ`; passing direct `TRACES` receipt; search and pinned-trace fixtures |
| `adapter.kubernetes.v1` | `1.0.0` | Kubernetes `>=1.28 <2` | runtime | Direct `CORE_READ`; passing direct `RUNTIME` receipt; GET/LIST-only resource fixtures |

The domain receipts above are `DIRECT_IN_PROCESS`; the existing signed-child
`CORE_READ` gate does not automatically make them signed-host domain receipts.
Adapters in this table are not automatically active. The public SDK and these
receipts support authoring/testing, but the current pre-1.0 production runtime admits only
the exact listed first-party and fixture package IDs backed by its one
release-code-owned provider worker. Activation also requires administrator
admission, application endpoint and credential bindings, a trusted package
signer or pinned digest, and successful child-worker conformance. The child is
not an OS sandbox, so third-party activation is unsupported unless a future
deployment actually implements and verifies filesystem, egress, subprocess,
CPU, and memory containment. Prometheus-compatible Mimir, Thanos, and VictoriaMetrics
need provider-specific auth, tenant, and API-deviation vectors before they can be
listed as certified. Jaeger, Argo CD, Flux, and commercial providers are not
implemented in this source tree.

## Change policy

Additive fields use a minor version only when older consumers can safely ignore
them. Breaking schema, tool, lifecycle, protocol, or semantic changes require a
major version, migration/dry-run instructions, upgrade and downgrade fixtures,
and rollback evidence. Capability negotiation—not a provider's `latest`
label—selects behavior. Unknown critical enums or semantics fail closed.

The matrix records configured compatibility gates, not publication or upgrade
history. Each CI run must produce its own result and archived candidate
evidence; a source declaration alone is not proof that a release passed.
