const TARGET_PLATFORMS = new Set(["darwin", "linux"]);
const TARGET_ARCHITECTURES = new Set(["arm64", "x64"]);
const RELEASE_KINDS = new Set(["NATIVE_CANDIDATE", "SOURCE_ONLY"]);

/**
 * @typedef {{
 *   schemaVersion: "1.0.0",
 *   kind: "NATIVE_CANDIDATE" | "SOURCE_ONLY",
 *   platform: "darwin" | "linux",
 *   architecture: "arm64" | "x64",
 *   id: string,
 * }} ReleaseTarget
 */

/** @param {readonly string[]} argv @param {string} name */
function option(argv, name) {
  const index = argv.indexOf(name);
  if (index === -1) return undefined;
  const value = argv[index + 1];
  if (value === undefined || value.startsWith("--")) {
    throw new Error(`Release target option ${name} requires one value`);
  }
  if (argv.indexOf(name, index + 1) !== -1) {
    throw new Error(`Release target option ${name} must not be repeated`);
  }
  return value;
}

/** @param {string | undefined} value */
function releaseKind(value) {
  if (value === undefined) return undefined;
  const normalized = value.replaceAll("-", "_").toUpperCase();
  return RELEASE_KINDS.has(normalized) ? normalized : value;
}

/**
 * Resolve one exact release target. Ordinary local commands safely default to
 * the current host. CI and release callers can bind the same contract through
 * flags or the three PM_RELEASE_* environment variables.
 *
 * @param {{
 *   argv?: readonly string[],
 *   environment?: NodeJS.ProcessEnv,
 *   hostPlatform?: NodeJS.Platform,
 *   hostArchitecture?: NodeJS.Architecture,
 *   requireExplicit?: boolean,
 * }} [options]
 * @returns {Readonly<ReleaseTarget>}
 */
export function resolveReleaseTarget(options = {}) {
  const argv = options.argv ?? [];
  const environment = options.environment ?? process.env;
  const hostPlatform = options.hostPlatform ?? process.platform;
  const hostArchitecture = options.hostArchitecture ?? process.arch;
  const flagPlatform = option(argv, "--target-platform");
  const flagArchitecture = option(argv, "--target-architecture");
  const flagKind = option(argv, "--release-kind");
  const environmentPlatform = environment.PM_RELEASE_TARGET_PLATFORM;
  const environmentArchitecture = environment.PM_RELEASE_TARGET_ARCHITECTURE;
  const environmentKind = environment.PM_RELEASE_KIND;

  if (flagPlatform !== undefined && environmentPlatform !== undefined && flagPlatform !== environmentPlatform) {
    throw new Error("Release target platform flag conflicts with PM_RELEASE_TARGET_PLATFORM");
  }
  if (
    flagArchitecture !== undefined
    && environmentArchitecture !== undefined
    && flagArchitecture !== environmentArchitecture
  ) {
    throw new Error("Release target architecture flag conflicts with PM_RELEASE_TARGET_ARCHITECTURE");
  }
  const normalizedFlagKind = releaseKind(flagKind);
  const normalizedEnvironmentKind = releaseKind(environmentKind);
  if (
    normalizedFlagKind !== undefined
    && normalizedEnvironmentKind !== undefined
    && normalizedFlagKind !== normalizedEnvironmentKind
  ) {
    throw new Error("Release kind flag conflicts with PM_RELEASE_KIND");
  }

  const explicitPlatform = flagPlatform ?? environmentPlatform;
  const explicitArchitecture = flagArchitecture ?? environmentArchitecture;
  const explicitKind = normalizedFlagKind ?? normalizedEnvironmentKind;
  const explicitValues = [explicitPlatform, explicitArchitecture, explicitKind];
  if (explicitValues.some((value) => value !== undefined) && explicitValues.some((value) => value === undefined)) {
    throw new Error("Release target platform, architecture, and kind must be declared together");
  }
  if (options.requireExplicit === true && explicitPlatform === undefined) {
    throw new Error("Release qualification requires an explicit platform, architecture, and kind");
  }

  const platform = explicitPlatform ?? hostPlatform;
  const architecture = explicitArchitecture ?? hostArchitecture;
  const kind = explicitKind ?? (platform === "darwin" ? "NATIVE_CANDIDATE" : "SOURCE_ONLY");
  if (!TARGET_PLATFORMS.has(platform)) throw new Error(`Unsupported release target platform: ${platform}`);
  if (!TARGET_ARCHITECTURES.has(architecture)) {
    throw new Error(`Unsupported release target architecture: ${architecture}`);
  }
  if (!RELEASE_KINDS.has(kind)) throw new Error(`Unsupported release target kind: ${kind}`);
  if (platform === "darwin" && kind !== "NATIVE_CANDIDATE") {
    throw new Error("Darwin release targets must be native candidates");
  }
  if (platform === "linux" && kind !== "SOURCE_ONLY") {
    throw new Error("Linux release targets are source-only and must not claim a native candidate");
  }

  return Object.freeze({
    schemaVersion: "1.0.0",
    kind: /** @type {ReleaseTarget["kind"]} */ (kind),
    platform: /** @type {ReleaseTarget["platform"]} */ (platform),
    architecture: /** @type {ReleaseTarget["architecture"]} */ (architecture),
    id: `${platform}-${architecture}`,
  });
}

/**
 * Cross-building native candidates is not admitted: npm's locked optional
 * dependency set is host-filtered and the native bytes must be qualified on the
 * architecture that will consume them.
 * @param {Readonly<ReleaseTarget>} target
 * @param {{ platform?: NodeJS.Platform, architecture?: NodeJS.Architecture }} [host]
 * @returns {Readonly<ReleaseTarget>}
 */
export function assertReleaseTargetMatchesHost(target, host = {}) {
  const platform = host.platform ?? process.platform;
  const architecture = host.architecture ?? process.arch;
  if (target.platform !== platform || target.architecture !== architecture) {
    throw new Error(
      `Release target ${target.id} does not match builder host ${platform}-${architecture}`,
    );
  }
  return target;
}

/**
 * @param {Readonly<ReleaseTarget>} target
 * @param {NodeJS.ProcessEnv} [base]
 */
export function releaseTargetEnvironment(target, base = process.env) {
  return {
    ...base,
    PM_RELEASE_KIND: target.kind,
    PM_RELEASE_TARGET_PLATFORM: target.platform,
    PM_RELEASE_TARGET_ARCHITECTURE: target.architecture,
  };
}
