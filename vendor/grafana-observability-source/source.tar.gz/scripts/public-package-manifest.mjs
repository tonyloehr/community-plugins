import { existsSync, readFileSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";

const VERSION_RE = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/u;
const LIFECYCLE_SCRIPTS = new Set([
  "preinstall", "install", "postinstall", "prepack", "prepare",
  "prepublish", "prepublishOnly", "publish", "postpublish",
]);

/** @param {unknown} value @returns {string[]} */
export function runtimeExportStrings(value) {
  if (typeof value === "string") return [value];
  if (Array.isArray(value)) return value.flatMap(runtimeExportStrings);
  if (value !== null && typeof value === "object") return Object.values(value).flatMap(runtimeExportStrings);
  return [];
}

/** @param {Record<string, any>} manifest @param {string} key */
export function assertPublicSourceManifest(manifest, key) {
  if (manifest.private === true) throw new Error(`${key} is still private`);
  if (typeof manifest.name !== "string" || !manifest.name.startsWith("@codex-production-monitoring/")) {
    throw new Error(`${key} has an unexpected public package name`);
  }
  if (!VERSION_RE.test(manifest.version ?? "")) throw new Error(`${key} has an invalid semantic version`);
  if (manifest.license !== "Apache-2.0") throw new Error(`${key} does not declare Apache-2.0`);
  if (manifest.type !== "module" || manifest.sideEffects !== false) {
    throw new Error(`${key} must be side-effect-free ESM`);
  }
  if (manifest.engines?.node !== ">=22.19.0") throw new Error(`${key} must require Node >=22.19.0`);
  if (manifest.publishConfig?.access !== "public" || manifest.publishConfig?.provenance !== true) {
    throw new Error(`${key} must require public access and npm provenance`);
  }
  if (!Array.isArray(manifest.files) || new Set(manifest.files).size !== manifest.files.length) {
    throw new Error(`${key} must declare a unique files allowlist`);
  }
  for (const required of ["dist", "README.md", "LICENSE"]) {
    if (!manifest.files.includes(required)) throw new Error(`${key} files omit ${required}`);
  }
  if (manifest.files.some((path) => path === "src" || path.startsWith("src/"))) {
    throw new Error(`${key} files include source TypeScript`);
  }
  const exports = runtimeExportStrings(manifest.exports);
  if (exports.some((value) => value.endsWith(".ts") && !value.endsWith(".d.ts"))) {
    throw new Error(`${key} contains a runtime TypeScript export`);
  }
  if (!exports.includes("./dist/index.js") || !exports.includes("./dist/index.d.ts")) {
    throw new Error(`${key} does not export compiled JavaScript and declarations`);
  }
  const scripts = manifest.scripts ?? {};
  const lifecycle = Object.keys(scripts).filter((name) => LIFECYCLE_SCRIPTS.has(name));
  if (lifecycle.length > 0) throw new Error(`${key} declares publish/install lifecycle scripts`);
  for (const [name, version] of Object.entries(manifest.dependencies ?? {})) {
    if (!name.startsWith("@codex-production-monitoring/") || !VERSION_RE.test(String(version))) {
      throw new Error(`${key} dependency ${name} must be an exact internal release version`);
    }
  }
}

/** @param {Record<string, any>} manifest @param {string} key */
export function createPublishedManifest(manifest, key) {
  assertPublicSourceManifest(manifest, key);
  const published = { ...manifest };
  delete published.scripts;
  delete published.devDependencies;
  assertPublishedManifest(published, key);
  return published;
}

/** @param {Record<string, any>} manifest @param {string} key */
export function assertPublishedManifest(manifest, key) {
  assertPublicSourceManifest(manifest, key);
  if (manifest.scripts !== undefined) throw new Error(`${key} published manifest must not expose repository scripts`);
  if (manifest.devDependencies !== undefined) throw new Error(`${key} published manifest must not expose devDependencies`);
}

/** @param {string} packageRoot @param {Iterable<string>} [packedPaths] */
export function assertPackagedMarkdownLinks(packageRoot, packedPaths) {
  const readme = resolve(packageRoot, "README.md");
  const text = readFileSync(readme, "utf8");
  const packed = packedPaths === undefined ? null : new Set(packedPaths);
  for (const match of text.matchAll(/\[[^\]]+\]\(([^)]+)\)/gu)) {
    const target = match[1].split("#", 1)[0];
    if (target.length === 0 || /^(?:https?:|mailto:)/u.test(target)) continue;
    const absolute = resolve(dirname(readme), target);
    const packagedPath = relative(packageRoot, absolute).split(sep).join("/");
    if (packagedPath === ".." || packagedPath.startsWith("../") || absolute === packageRoot) {
      throw new Error(`Published README link escapes the package: ${target}`);
    }
    if (!existsSync(absolute)) {
      throw new Error(`Published README link is missing from the package: ${target}`);
    }
    if (
      packed !== null
      && !packed.has(packagedPath)
      && ![...packed].some((path) => path.startsWith(`${packagedPath}/`))
    ) {
      throw new Error(`Published README link is omitted from the tarball: ${target}`);
    }
  }
}
