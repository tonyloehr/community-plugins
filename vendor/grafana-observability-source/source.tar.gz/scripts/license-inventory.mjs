import { createHash } from "node:crypto";
import {
  existsSync,
  lstatSync,
  readFileSync,
  readdirSync,
  writeFileSync,
} from "node:fs";
import { basename, isAbsolute, relative, resolve, sep } from "node:path";

const licenseFileName = /^(?:licen[cs]e|copying|notice)(?:[-.].*)?$/iu;
export const permissiveLicenseExpression = /^(?:0BSD|Apache-2\.0|BlueOak-1\.0\.0|BSD-2-Clause|BSD-3-Clause|ISC|MIT|Python-2\.0|CC0-1\.0|Unlicense)(?: OR (?:MIT|Apache-2\.0|BSD-2-Clause|BSD-3-Clause|ISC))*$/u;

const vendoredLegalInputDefinitions = [{
  packagePath: "node_modules/pgsql-ast-parser",
  packageName: "pgsql-ast-parser",
  packageVersion: "12.0.2",
  license: "MIT",
  declaredAuthor: "Olivier Guimbal",
  copyrightNoticeStatus: "NOT_PROVIDED_UPSTREAM",
  legalTextProvenance: "CODE_OWNED_LOCAL_REPRESENTATION",
  metadataPath: "scripts/legal-assets/pgsql-ast-parser-12.0.2.json",
  licenseTextPath: "scripts/legal-assets/pgsql-ast-parser-12.0.2.LICENSE.txt",
  upstreamPackageManifestUrl: "https://raw.githubusercontent.com/oguimbal/pgsql-ast-parser/12.0.2/package.json",
  upstreamPackageManifestSha256: "33be93687189508793ed46b0d76a822adad08f43778f21aca9be88af44d1338c",
  licenseTermsReferenceUrl: "https://raw.githubusercontent.com/spdx/license-list-data/v3.27.0/text/MIT.txt",
  licenseTextSha256: "5a3bc541c5a7d4746b360773618f8483a02e85a3b147aa48ecd7b4fec092b591",
}];

/** @param {Buffer | string} value */
function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

/** @param {string} repositoryRoot @param {typeof vendoredLegalInputDefinitions[number]} definition */
function readVendoredLegalInput(repositoryRoot, definition) {
  const metadataBytes = readFileSync(resolve(repositoryRoot, definition.metadataPath));
  const metadata = JSON.parse(metadataBytes.toString("utf8"));
  if (
    metadata.schemaVersion !== "1.1.0"
    || metadata.packageName !== definition.packageName
    || metadata.packageVersion !== definition.packageVersion
    || metadata.license !== definition.license
    || metadata.declaredAuthor !== definition.declaredAuthor
    || metadata.copyrightNoticeStatus !== definition.copyrightNoticeStatus
    || metadata.legalTextProvenance !== definition.legalTextProvenance
    || metadata.upstreamPackageManifestUrl !== definition.upstreamPackageManifestUrl
    || metadata.upstreamPackageManifestSha256 !== definition.upstreamPackageManifestSha256
    || metadata.licenseTermsReferenceUrl !== definition.licenseTermsReferenceUrl
    || metadata.licenseTextSha256 !== definition.licenseTextSha256
    || metadata.licenseTextPath !== definition.licenseTextPath
    || typeof metadata.reason !== "string"
    || metadata.reason.length < 40
  ) {
    throw new Error(`Vendored legal metadata differs from its code-owned pin: ${definition.metadataPath}`);
  }
  const licensePath = resolve(repositoryRoot, definition.licenseTextPath);
  const licenseMetadata = lstatSync(licensePath);
  const text = readFileSync(licensePath);
  if (
    !licenseMetadata.isFile()
    || licenseMetadata.isSymbolicLink()
    || sha256(text) !== definition.licenseTextSha256
  ) {
    throw new Error(`Vendored legal text differs from its code-owned pin: ${definition.licenseTextPath}`);
  }
  return {
    packagePath: definition.packagePath,
    packageName: definition.packageName,
    packageVersion: definition.packageVersion,
    license: definition.license,
    declaredAuthor: definition.declaredAuthor,
    copyrightNoticeStatus: definition.copyrightNoticeStatus,
    legalTextProvenance: definition.legalTextProvenance,
    metadataPath: definition.metadataPath,
    metadataSha256: sha256(metadataBytes),
    licenseTextPath: definition.licenseTextPath,
    licenseTermsReferenceUrl: definition.licenseTermsReferenceUrl,
    licenseTextSha256: definition.licenseTextSha256,
    upstreamPackageManifestUrl: definition.upstreamPackageManifestUrl,
    upstreamPackageManifestSha256: definition.upstreamPackageManifestSha256,
    text: text.toString("utf8"),
  };
}

/** @param {string} repositoryRoot */
export function vendoredPackageLicenseInventory(repositoryRoot) {
  const lock = readJson(resolve(repositoryRoot, "package-lock.json"));
  return vendoredLegalInputDefinitions.map((definition) => {
    const locked = lock.packages?.[definition.packagePath];
    const installed = readJson(resolve(repositoryRoot, definition.packagePath, "package.json"));
    if (
      locked?.version !== definition.packageVersion
      || locked?.license !== definition.license
      || installed.name !== definition.packageName
      || installed.version !== definition.packageVersion
      || installed.license !== definition.license
      || installed.author !== definition.declaredAuthor
    ) {
      throw new Error(`Vendored legal input is not bound to the exact installed package: ${definition.packageName}`);
    }
    return readVendoredLegalInput(repositoryRoot, definition);
  });
}

/** @param {string} path */
function readJson(path) {
  return JSON.parse(readFileSync(path, "utf8"));
}

/** @param {string} path */
function packageNameFromLockPath(path) {
  return path.slice(path.lastIndexOf("node_modules/") + "node_modules/".length);
}

/**
 * Return the canonical third-party license inventory from package-lock.json.
 * Release receipts are deliberately not an input, so this inventory can also
 * drive legal artifacts that are themselves included in the release tree.
 *
 * @param {string} repositoryRoot
 */
export function lockedPackageLicenseInventory(repositoryRoot) {
  const lock = readJson(resolve(repositoryRoot, "package-lock.json"));
  return Object.entries(lock.packages ?? {})
    .filter(([path, value]) => (
      path.includes("node_modules/")
      && value !== null
      && typeof value === "object"
      && value.link !== true
    ))
    .map(([path, value]) => ({
      path,
      name: value.name ?? packageNameFromLockPath(path),
      version: value.version ?? "unknown",
      license: value.license ?? "UNKNOWN",
    }))
    .sort((left, right) => (
      left.name.localeCompare(right.name)
      || left.version.localeCompare(right.version)
      || left.path.localeCompare(right.path)
    ));
}

/** @param {string} repositoryRoot @param {string} inputPath */
function lockPathForBundledInput(repositoryRoot, inputPath) {
  const absoluteInput = isAbsolute(inputPath)
    ? inputPath
    : resolve(repositoryRoot, inputPath);
  const relativeInput = relative(repositoryRoot, absoluteInput);
  if (
    relativeInput === ".."
    || relativeInput.startsWith(`..${sep}`)
    || isAbsolute(relativeInput)
  ) {
    throw new Error(`Bundled input is outside the repository: ${inputPath}`);
  }

  const normalized = relativeInput.split(sep).join("/");
  const marker = "node_modules/";
  const markerIndex = normalized.lastIndexOf(marker);
  if (markerIndex === -1) return undefined;
  const packagePathPrefix = normalized.slice(0, markerIndex + marker.length);
  const packageSegments = normalized.slice(markerIndex + marker.length).split("/");
  const packageSegmentCount = packageSegments[0]?.startsWith("@") ? 2 : 1;
  if (
    packageSegments.length < packageSegmentCount
    || packageSegments.slice(0, packageSegmentCount).some((segment) => segment.length === 0)
  ) {
    throw new Error(`Bundled input has an invalid package path: ${inputPath}`);
  }
  return `${packagePathPrefix}${packageSegments.slice(0, packageSegmentCount).join("/")}`;
}

/** @param {string} repositoryRoot @param {string} packagePath */
function packageLicenseTexts(repositoryRoot, packagePath, licensePackagePath = packagePath) {
  const packageRoot = resolve(repositoryRoot, licensePackagePath);
  const candidates = readdirSync(packageRoot, { withFileTypes: true })
    .filter((entry) => licenseFileName.test(entry.name))
    .sort((left, right) => left.name.localeCompare(right.name));
  if (candidates.length === 0) {
    const definition = vendoredLegalInputDefinitions.find(
      (candidate) => candidate.packagePath === licensePackagePath,
    );
    if (definition !== undefined) {
      const vendored = readVendoredLegalInput(repositoryRoot, definition);
      return [{
        file: basename(vendored.licenseTextPath),
        sourcePath: vendored.licenseTextPath.slice(0, vendored.licenseTextPath.lastIndexOf("/")),
        provenance: vendored.legalTextProvenance,
        termsReferenceUrl: vendored.licenseTermsReferenceUrl,
        declarationAndAuthorSourceUrl: vendored.upstreamPackageManifestUrl,
        sha256: vendored.licenseTextSha256,
        text: vendored.text,
      }];
    }
    throw new Error(`Bundled package ${packagePath} has no top-level license or notice file and no admitted hash-pinned vendored legal input`);
  }
  return candidates.map((entry) => {
    const path = resolve(packageRoot, entry.name);
    const metadata = lstatSync(path);
    if (!entry.isFile() || metadata.isSymbolicLink()) {
      throw new Error(`Bundled package legal artifact is not a regular file: ${licensePackagePath}/${entry.name}`);
    }
    const text = readFileSync(path, "utf8")
      .replace(/\r\n?/gu, "\n")
      .replace(/\n*$/u, "\n");
    return {
      file: entry.name,
      sourcePath: licensePackagePath,
      provenance: undefined,
      termsReferenceUrl: undefined,
      declarationAndAuthorSourceUrl: undefined,
      sha256: sha256(text),
      text,
    };
  });
}

/**
 * Resolve only the third-party packages whose source bytes contributed to an
 * esbuild output. Workspace links are first-party inputs and are excluded.
 *
 * @param {string} repositoryRoot
 * @param {Array<{ outputs?: Record<string, { inputs?: Record<string, { bytesInOutput?: number }> }> }>} metafiles
 * @param {Array<{ packagePath: string, licensePackagePath: string }>} [additionalPackages]
 */
export function bundledPackageLicenseInventory(repositoryRoot, metafiles, additionalPackages = []) {
  const lock = readJson(resolve(repositoryRoot, "package-lock.json"));
  const packagePaths = new Set();
  for (const metafile of metafiles) {
    for (const output of Object.values(metafile.outputs ?? {})) {
      for (const [inputPath, contribution] of Object.entries(output.inputs ?? {})) {
        if ((contribution.bytesInOutput ?? 0) <= 0) continue;
        const packagePath = lockPathForBundledInput(repositoryRoot, inputPath);
        if (packagePath !== undefined) packagePaths.add(packagePath);
      }
    }
  }
  const additionalByPath = new Map();
  for (const record of additionalPackages) {
    if (
      record === null
      || typeof record !== "object"
      || typeof record.packagePath !== "string"
      || typeof record.licensePackagePath !== "string"
      || additionalByPath.has(record.packagePath)
    ) {
      throw new Error("Additional bundled-package license input is invalid or duplicated");
    }
    additionalByPath.set(record.packagePath, record.licensePackagePath);
    packagePaths.add(record.packagePath);
  }

  return [...packagePaths]
    .map((packagePath) => {
      const value = lock.packages?.[packagePath];
      if (value?.link === true) return undefined;
      if (value === null || typeof value !== "object") {
        throw new Error(`Bundled package is absent from package-lock.json: ${packagePath}`);
      }
      if (
        typeof value.version !== "string"
        || typeof value.license !== "string"
        || value.version.length === 0
        || value.license.length === 0
      ) {
        throw new Error(`Bundled package has incomplete locked license metadata: ${packagePath}`);
      }
      if (!permissiveLicenseExpression.test(value.license)) {
        throw new Error(`Bundled package has a disallowed license expression: ${packagePath}`);
      }
      const manifest = readJson(resolve(repositoryRoot, packagePath, "package.json"));
      const name = value.name ?? packageNameFromLockPath(packagePath);
      if (
        manifest.name !== name
        || manifest.version !== value.version
        || manifest.license !== value.license
      ) {
        throw new Error(`Bundled package manifest differs from package-lock.json: ${packagePath}`);
      }
      const licensePackagePath = additionalByPath.get(packagePath) ?? packagePath;
      const licenseManifest = readJson(resolve(repositoryRoot, licensePackagePath, "package.json"));
      if (licenseManifest.license !== value.license) {
        throw new Error(`Bundled package license source differs from package-lock.json: ${packagePath}`);
      }
      return {
        path: packagePath,
        name,
        version: value.version,
        license: value.license,
        legalFiles: packageLicenseTexts(repositoryRoot, packagePath, licensePackagePath),
      };
    })
    .filter((record) => record !== undefined)
    .sort((left, right) => (
      left.name.localeCompare(right.name)
      || left.version.localeCompare(right.version)
      || left.path.localeCompare(right.path)
    ));
}

/**
 * @param {ReturnType<typeof bundledPackageLicenseInventory>} records
 */
export function renderThirdPartyNotices(records) {
  const lines = [
    "THIRD-PARTY NOTICES",
    "",
    "This file is generated from package-lock.json, installed package legal files,",
    "and the exact third-party inputs included by esbuild in the compiled plugin.",
    "Release receipts under dist/ are not generation inputs.",
    "",
    `Bundled third-party package records: ${records.length}`,
    "",
  ];

  for (const record of records) {
    for (const legalFile of record.legalFiles) {
      lines.push(
        "================================================================================",
        `${record.name}@${record.version}`,
        `SPDX-License-Identifier: ${record.license}`,
        `Lockfile package path: ${record.path}`,
        `Legal file: ${legalFile.sourcePath}/${legalFile.file}`,
        ...(legalFile.provenance === undefined
          ? []
          : [`Legal text provenance: ${legalFile.provenance}`]),
        ...(legalFile.declarationAndAuthorSourceUrl === undefined
          ? []
          : [`License declaration and author source URL: ${legalFile.declarationAndAuthorSourceUrl}`]),
        ...(legalFile.termsReferenceUrl === undefined
          ? []
          : [`License terms reference URL: ${legalFile.termsReferenceUrl}`]),
        `Legal text SHA-256: ${legalFile.sha256}`,
        "--------------------------------------------------------------------------------",
        legalFile.text.replace(/\n$/u, ""),
        "",
      );
    }
  }
  return `${lines.join("\n").replace(/\n*$/u, "\n")}`;
}

/**
 * @param {{ repositoryRoot: string, outputRoot: string, metafiles: Array<{ outputs?: Record<string, { inputs?: Record<string, { bytesInOutput?: number }> }> }>, additionalPackages?: Array<{ packagePath: string, licensePackagePath: string }> }} options
 */
export function writePluginLegalArtifacts(options) {
  const licensePath = resolve(options.repositoryRoot, "LICENSE");
  const licenseMetadata = lstatSync(licensePath);
  if (!licenseMetadata.isFile() || licenseMetadata.isSymbolicLink()) {
    throw new Error("Repository LICENSE must be a regular file");
  }
  const license = readFileSync(licensePath);
  const records = bundledPackageLicenseInventory(
    options.repositoryRoot,
    options.metafiles,
    options.additionalPackages ?? [],
  );
  const outputs = [
    { path: resolve(options.outputRoot, "LICENSE"), content: license },
    {
      path: resolve(options.outputRoot, "THIRD_PARTY_NOTICES.txt"),
      content: renderThirdPartyNotices(records),
    },
  ];
  for (const output of outputs) {
    if (existsSync(output.path)) {
      const metadata = lstatSync(output.path);
      if (!metadata.isFile() || metadata.isSymbolicLink()) {
        throw new Error(`Plugin legal artifact output is not a regular file: ${output.path}`);
      }
    }
    writeFileSync(output.path, output.content);
  }
  return records;
}
