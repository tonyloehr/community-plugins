import { existsSync, readdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const repositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const requestedRoots = process.argv.slice(2).map((value) => resolve(repositoryRoot, value));
const roots = requestedRoots.length === 0 ? [resolve(repositoryRoot, "tests")] : requestedRoots;
/** @type {string[]} */
const files = [];

/** @param {string} path */
function visit(path) {
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    const child = resolve(path, entry.name);
    if (entry.isDirectory()) visit(child);
    else if (entry.isFile() && entry.name.endsWith(".test.ts")) files.push(child);
  }
}

for (const root of roots) {
  if (!existsSync(root)) {
    console.error(`Test root does not exist: ${root}`);
    process.exit(2);
  }
  visit(root);
}
files.sort();
if (files.length === 0) {
  console.error("No test files were discovered.");
  process.exit(2);
}

const tsxCli = resolve(repositoryRoot, "node_modules/tsx/dist/cli.mjs");
// Keep release qualification deterministic across supported Node versions and
// differently sized CI hosts. Individual suites exercise product concurrency;
// running every real-child/process suite at once only creates host contention.
const result = spawnSync(process.execPath, [tsxCli, "--test", "--test-concurrency=1", ...files], {
  cwd: repositoryRoot,
  stdio: "inherit",
});
process.exit(result.status ?? 1);
