import { existsSync, rmSync } from "node:fs";
import { resolve } from "node:path";
import { spawnSync } from "node:child_process";

export const PUBLIC_PACKAGE_BUILD_ORDER = Object.freeze([
  "contracts",
  "adapter-sdk",
  "adapter-host",
  "adapter-conformance",
]);

const packageDefinitions = Object.freeze([
  Object.freeze({ key: "contracts", directory: "packages/contracts", assets: ["schemas", "examples"] }),
  Object.freeze({ key: "adapter-sdk", directory: "packages/adapter-sdk", assets: ["examples"] }),
  Object.freeze({ key: "adapter-host", directory: "packages/adapter-host", assets: [] }),
  Object.freeze({ key: "adapter-conformance", directory: "conformance", assets: ["schemas", "examples"] }),
]);

/** @param {string} repositoryRoot */
export function publicPackageSpecs(repositoryRoot) {
  return packageDefinitions.map((definition) => {
    const root = resolve(repositoryRoot, definition.directory);
    return {
      key: definition.key,
      root,
      buildConfig: resolve(root, "tsconfig.build.json"),
      dist: resolve(root, "dist"),
      assets: [...definition.assets],
    };
  });
}

/**
 * Clean and compile the public workspaces once in dependency order. Removing
 * every ignored output before the first compile proves that no package is
 * resolved from a warmed workspace tree.
 * @param {string} repositoryRoot
 */
export function compilePublicPackageDependencies(repositoryRoot) {
  const compiler = resolve(repositoryRoot, "node_modules/typescript/bin/tsc");
  if (!existsSync(compiler)) {
    throw new Error("Public package compilation requires TypeScript; run npm ci --ignore-scripts");
  }
  const packageSpecs = publicPackageSpecs(repositoryRoot);
  for (const packageSpec of packageSpecs) {
    rmSync(packageSpec.dist, { force: true, recursive: true });
  }
  for (const packageSpec of packageSpecs) {
    const result = spawnSync(
      process.execPath,
      [compiler, "-p", packageSpec.buildConfig, "--noEmitOnError"],
      {
        cwd: repositoryRoot,
        stdio: "inherit",
      },
    );
    if (result.status !== 0) {
      throw new Error(
        `Public package compilation failed for ${packageSpec.key} with status ${String(result.status)}`,
      );
    }
  }
  return packageSpecs;
}
