import {
  cpSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { createHash } from "node:crypto";
import { basename, dirname, resolve } from "node:path";

import { build } from "esbuild";

import { writePluginLegalArtifacts } from "./license-inventory.mjs";
import {
  pluginNativeAssetForTarget,
  pluginDescriptorById,
  productionMonitoringPluginDescriptor,
} from "./plugin-descriptors.mjs";

export const GENERATED_SOURCE_PART_MAX_BYTES = 140_000;
export const GENERATED_PLUGIN_FILE_MAX_BYTES = 150_000;

const SOURCE_PART_MARKER = "__PM_SOURCE_PARTS__=";
const LOADER_URL_IDENTIFIER = "__PM_LOADER_URL__";

/** @param {Buffer} value */
function digest(value) {
  return createHash("sha256").update(value).digest("hex");
}

/**
 * Produce Git-portable document text. The workspace template contains no
 * whitespace-sensitive preformatted element, so removing line-end indentation
 * does not change its rendered UI. Executable source is never passed here.
 * @param {Buffer | Uint8Array | string} source
 */
function canonicalGeneratedText(source) {
  const bytes = Buffer.isBuffer(source) ? source : Buffer.from(source);
  const text = bytes.toString("utf8");
  if (!Buffer.from(text, "utf8").equals(bytes)) {
    throw new Error("Generated plugin source must be valid UTF-8");
  }
  return Buffer.from(text.replace(/[\t ]+(?=\r?\n|$)/gu, ""), "utf8");
}

/**
 * Split UTF-8 source without changing a byte or cutting through a multibyte
 * character. The raw source remains readable in the generated part files.
 * @param {Buffer} source
 */
function sourceParts(source) {
  if (!Buffer.from(source.toString("utf8"), "utf8").equals(source)) {
    throw new Error("Generated plugin source must be valid UTF-8");
  }
  if (/[\t ]+(?=\r?\n|$)/u.test(source.toString("utf8"))) {
    throw new Error("Generated plugin source must not contain line-ending whitespace");
  }
  /** @type {Buffer[]} */
  const parts = [];
  for (let offset = 0; offset < source.byteLength;) {
    let end = Math.min(offset + GENERATED_SOURCE_PART_MAX_BYTES, source.byteLength);
    while (end < source.byteLength && (source[end] & 0xc0) === 0x80) end -= 1;
    while (
      end < source.byteLength
      && end > offset
      && [0x09, 0x0a, 0x0d, 0x20].includes(source[end - 1])
    ) {
      end -= 1;
    }
    if (end <= offset) throw new Error("Unable to split generated UTF-8 source safely");
    parts.push(source.subarray(offset, end));
    offset = end;
  }
  return parts;
}

/**
 * @param {string} filename
 * @param {Buffer} source
 */
function sourcePartManifest(filename, source) {
  const parts = sourceParts(source);
  const prefix = `${filename}.source.part-`;
  return {
    schemaVersion: 1,
    sourceBytes: source.byteLength,
    sourceSha256: digest(source),
    parts: parts.map((bytes, index) => ({
      name: `${prefix}${String(index).padStart(3, "0")}`,
      bytes: bytes.byteLength,
      sha256: digest(bytes),
    })),
    contents: parts,
  };
}

/** @param {Omit<ReturnType<typeof sourcePartManifest>, "contents">} manifest */
function nodeSourceLoader(manifest) {
  return `import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname } from "node:path";
import { URL, fileURLToPath } from "node:url";

const ${SOURCE_PART_MARKER}${JSON.stringify(manifest)};
const sourceParts = __PM_SOURCE_PARTS__.parts.map((part) => {
  const bytes = readFileSync(new URL(part.name, import.meta.url));
  if (bytes.byteLength !== part.bytes || createHash("sha256").update(bytes).digest("hex") !== part.sha256) {
    throw new Error("Generated Production Monitoring source part failed integrity verification");
  }
  return bytes;
});
const source = Buffer.concat(sourceParts);
if (source.byteLength !== __PM_SOURCE_PARTS__.sourceBytes || createHash("sha256").update(source).digest("hex") !== __PM_SOURCE_PARTS__.sourceSha256) {
  throw new Error("Generated Production Monitoring source failed integrity verification");
}
const loaderPath = fileURLToPath(import.meta.url);
const require = createRequire(import.meta.url);
const Module = require("node:module");
const runtimeModule = new Module(loaderPath);
runtimeModule.filename = loaderPath;
runtimeModule.paths = Module._nodeModulePaths(dirname(loaderPath));
runtimeModule._compile(source.toString("utf8"), loaderPath);
`;
}

/**
 * @param {string} outputPath
 * @param {Uint8Array} source
 * @param {{ shebang?: boolean }} [options]
 */
function writeShardedNodeSource(outputPath, source, options = {}) {
  const bytes = Buffer.from(Buffer.from(source).toString("utf8").replaceAll(
    LOADER_URL_IDENTIFIER,
    'require("node:url").pathToFileURL(__filename).href',
  ), "utf8");
  const filename = basename(outputPath);
  const { contents, ...manifest } = sourcePartManifest(filename, bytes);
  const loader = `${options.shebang === true ? "#!/usr/bin/env node\n" : ""}${nodeSourceLoader(manifest)}`;
  if (Buffer.byteLength(loader) > GENERATED_SOURCE_PART_MAX_BYTES) {
    throw new Error(`Generated loader exceeds ${GENERATED_SOURCE_PART_MAX_BYTES} bytes: ${outputPath}`);
  }
  writeFileSync(outputPath, loader, "utf8");
  for (const [index, part] of contents.entries()) {
    writeFileSync(resolve(dirname(outputPath), manifest.parts[index].name), part);
  }
  return manifest;
}

/**
 * Public for release tests and test-only signed worker fixtures. Production
 * assembly and tests therefore exercise exactly one sharding implementation.
 * @param {string} outputPath
 * @param {Uint8Array} source
 * @param {{ shebang?: boolean }} [options]
 */
export function writeGeneratedNodeSource(outputPath, source, options = {}) {
  return writeShardedNodeSource(outputPath, source, options);
}

/**
 * Copy one descriptor-owned native asset after verifying package metadata and
 * the literal size/digest. No package entrypoint, PATH lookup, or shell runs.
 * @param {{ repositoryRoot: string, outputRoot: string, asset: any }} options
 */
export function copyPinnedNativeAsset(options) {
  const { asset } = options;
  const sourcePath = resolve(options.repositoryRoot, asset.sourcePath);
  const metadata = lstatSync(sourcePath);
  if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size !== asset.bytes) {
    throw new Error(`Pinned native asset has unsafe metadata: ${asset.sourcePath}`);
  }
  const packageManifest = JSON.parse(readFileSync(
    resolve(options.repositoryRoot, asset.packagePath, "package.json"),
    "utf8",
  ));
  if (
    packageManifest.name !== asset.packageName
    || packageManifest.version !== asset.packageVersion
    || packageManifest.license !== asset.license
    || !Array.isArray(packageManifest.os)
    || !packageManifest.os.includes(asset.platform)
    || !Array.isArray(packageManifest.cpu)
    || !packageManifest.cpu.includes(asset.architecture)
  ) {
    throw new Error(`Pinned native package metadata differs from its descriptor: ${asset.packageName}`);
  }
  const bytes = readFileSync(sourcePath);
  if (bytes.byteLength !== asset.bytes || digest(bytes) !== asset.sha256) {
    throw new Error(`Pinned native asset digest differs from its descriptor: ${asset.sourcePath}`);
  }
  const outputPath = resolve(options.outputRoot, asset.output);
  writeFileSync(outputPath, bytes, { mode: 0o444 });
  const output = readFileSync(outputPath);
  if (output.byteLength !== asset.bytes || digest(output) !== asset.sha256) {
    throw new Error(`Copied native asset failed release verification: ${asset.output}`);
  }
}

/**
 * @param {string} outputPath
 * @param {Buffer} source
 */
function writeShardedWorkspace(outputPath, source) {
  const filename = basename(outputPath);
  const { contents, ...manifest } = sourcePartManifest(filename, canonicalGeneratedText(source));
  writeFileSync(outputPath, `${SOURCE_PART_MARKER}${JSON.stringify(manifest)};\n`, "utf8");
  for (const [index, part] of contents.entries()) {
    writeFileSync(resolve(dirname(outputPath), manifest.parts[index].name), part);
  }
  return manifest;
}

/**
 * Compile every generated plugin artifact into an explicitly owned output root.
 * Keeping this in one module makes release freshness checks use the exact same
 * esbuild contract as the checked-in plugin bundle.
 * @param {{
 *   repositoryRoot: string,
 *   outputRoot: string,
 *   logLevel?: "silent" | "info",
 *   pluginId?: string,
 *   descriptor?: typeof productionMonitoringPluginDescriptor,
 *   targetPlatform?: NodeJS.Platform,
 *   targetArchitecture?: NodeJS.Architecture,
 * }} options
 */
export async function buildPluginArtifacts(options) {
  const descriptor = options.descriptor
    ?? (options.pluginId === undefined
      ? productionMonitoringPluginDescriptor
      : pluginDescriptorById(options.pluginId));
  const schemaSourceRoot = resolve(options.repositoryRoot, descriptor.build.schemaSourcePath);
  for (const directory of descriptor.build.generatedDirectories) {
    rmSync(resolve(options.outputRoot, directory), { force: true, recursive: true });
    mkdirSync(resolve(options.outputRoot, directory), { recursive: true });
  }
  cpSync(schemaSourceRoot, resolve(options.outputRoot, "schemas"), { recursive: true });

  const nativeAsset = pluginNativeAssetForTarget(
    descriptor,
    options.targetPlatform ?? process.platform,
    options.targetArchitecture ?? process.arch,
  );
  if (nativeAsset !== undefined) {
    copyPinnedNativeAsset({
      repositoryRoot: options.repositoryRoot,
      outputRoot: options.outputRoot,
      asset: nativeAsset,
    });
  }

  /** @type {import("esbuild").BuildOptions} */
  const common = {
    absWorkingDir: options.repositoryRoot,
    bundle: true,
    charset: "utf8",
    define: { "import.meta.url": LOADER_URL_IDENTIFIER },
    format: "cjs",
    legalComments: "none",
    logLevel: options.logLevel ?? "info",
    metafile: true,
    minify: false,
    platform: "node",
    sourcemap: false,
    supported: { "template-literal": false },
    target: "node22",
    write: false,
  };

  /** @type {import("esbuild").BuildResult[]} */
  const results = [];
  for (const step of descriptor.build.steps) {
    if (!("template" in step)) {
      const result = await build({
        ...common,
        entryPoints: [resolve(options.repositoryRoot, step.entryPoint)],
      });
      const bytes = result.outputFiles?.[0]?.contents;
      if (bytes === undefined) throw new Error(`esbuild omitted the ${step.name} source`);
      writeShardedNodeSource(resolve(options.outputRoot, step.output), bytes, {
        shebang: step.shebang,
      });
      results.push(result);
      continue;
    }

    if (
      typeof step.template !== "string"
      || typeof step.styles !== "string"
      || typeof step.styleMarker !== "string"
      || typeof step.scriptMarker !== "string"
    ) {
      throw new Error(`${descriptor.id} contains an invalid workspace build step`);
    }

    const result = await build({
      absWorkingDir: options.repositoryRoot,
      bundle: true,
      charset: "utf8",
      entryPoints: [resolve(options.repositoryRoot, step.entryPoint)],
      format: "iife",
      legalComments: "none",
      logLevel: options.logLevel ?? "info",
      metafile: true,
      minify: true,
      platform: "browser",
      sourcemap: false,
      supported: { "template-literal": false },
      target: "es2022",
      write: false,
    });
    const appJavaScript = result.outputFiles?.[0]?.text;
    if (appJavaScript === undefined) {
      throw new Error(`esbuild omitted the ${step.name} JavaScript`);
    }
    const appTemplate = readFileSync(resolve(options.repositoryRoot, step.template), "utf8");
    const appStyles = readFileSync(resolve(options.repositoryRoot, step.styles), "utf8");
    if (!appTemplate.includes(step.styleMarker) || !appTemplate.includes(step.scriptMarker)) {
      throw new Error(`${step.name} template is missing a build marker`);
    }
    const appHtml = appTemplate
      .replace(step.styleMarker, () => appStyles.replaceAll("</style", "<\\/style"))
      .replace(step.scriptMarker, () => appJavaScript.replaceAll("</script", "<\\/script"));
    writeShardedWorkspace(resolve(options.outputRoot, step.output), Buffer.from(appHtml, "utf8"));
    results.push(result);
  }
  const metafiles = results.map((result) => {
    if (result.metafile === undefined) {
      throw new Error("esbuild omitted the required legal-inventory metafile");
    }
    return result.metafile;
  });
  writePluginLegalArtifacts({
    repositoryRoot: options.repositoryRoot,
    outputRoot: options.outputRoot,
    metafiles,
    additionalPackages: nativeAsset === undefined ? [] : [{
      packagePath: nativeAsset.packagePath,
      licensePackagePath: nativeAsset.licensePackagePath,
    }],
  });
}
