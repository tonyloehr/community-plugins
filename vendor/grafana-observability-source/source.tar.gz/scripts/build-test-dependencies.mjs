import { resolve } from "node:path";

import {
  compilePublicPackageDependencies,
  PUBLIC_PACKAGE_BUILD_ORDER,
} from "./public-package-compile.mjs";

const repositoryRoot = resolve(import.meta.dirname, "..");
compilePublicPackageDependencies(repositoryRoot);
console.log(
  `Built clean test dependencies in order: ${PUBLIC_PACKAGE_BUILD_ORDER.join(" -> ")}.`,
);
