import { createHash } from "node:crypto";
import {
  cpSync,
  lstatSync,
  readFileSync,
  readdirSync,
  realpathSync,
} from "node:fs";
import { basename, relative, resolve, sep } from "node:path";
import { gunzipSync } from "node:zlib";

import { assertPublishedManifest } from "./public-package-manifest.mjs";
import {
  pluginNativeAssetForTarget,
  pluginDescriptors,
  productionMonitoringPluginDescriptor,
} from "./plugin-descriptors.mjs";
import { resolveReleaseTarget } from "./release-target.mjs";

// Backward-compatible aliases for tests and callers that exercise the primary
// Production Monitoring layout directly. New matrix callers pass a descriptor.
export const pluginReleaseEntries = productionMonitoringPluginDescriptor.release.entries;
export const generatedPluginFiles = productionMonitoringPluginDescriptor.release.generatedFiles;
export const generatedPluginRootFiles = productionMonitoringPluginDescriptor.release.generatedRootFiles;
const GENERATED_SOURCE_PART_MAX_BYTES = 140_000;
const GENERATED_PLUGIN_FILE_MAX_BYTES = 150_000;
const MAX_GENERATED_SOURCE_PARTS = 128;
const SHA256_PATTERN = /^[a-f0-9]{64}$/u;
const STRICT_SEMVER_PATTERN = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/u;

export const releaseNetworkPolicy = Object.freeze({
  networkRequired: true,
  dependencyInstallationNetwork: "REGISTRY_OR_PREPOPULATED_CACHE_REQUIRED",
  vulnerabilityAuditNetworkRequired: true,
  vulnerabilityAuditNetwork: "CONNECTED_NPM_REGISTRY_REQUIRED",
  releaseAssemblyNetworkRequired: false,
  providerNetworkRequired: false,
});

/**
 * @typedef {{
 *   name: string,
 *   version: string,
 *   license?: string,
 *   private?: boolean,
 *   workspaces?: string[],
 *   publishConfig?: { access?: string, provenance?: boolean },
 * }} PackageManifest
 */

/**
 * @typedef {{ name: string, version: string, file: string, sha256: string }} PublicPackageEntry
 */

/**
 * @typedef {{ name: string, bytes: number, sha256: string }} GeneratedSourcePart
 * @typedef {{ schemaVersion: 1, sourceBytes: number, sourceSha256: string, parts: GeneratedSourcePart[] }} GeneratedSourceManifest
 */

/**
 * @typedef {{
 *   name: string,
 *   version: string,
 *   sourcePath: string,
 *   path: string,
 *   root: string,
 *   treeSha256: string,
 *   files: Array<{ path: string, bytes: number, sha256: string }>,
 *   nativeAssets?: Array<{ name: string, version: string, license: string, platform: string, architecture: string, path: string, bytes: number, sha256: string }>,
 * }} PluginReleaseArtifact
 */

/**
 * @typedef {{
 *   name: string,
 *   version: string,
 *   license: string,
 *   path: string,
 *   absolutePath: string,
 *   bytes: number,
 *   sha256: string,
 * }} PublicReleaseArtifact
 */

/**
 * @typedef {{
 *   name: string,
 *   version: string,
 *   license: string,
 *   plugins: PluginReleaseArtifact[],
 *   plugin: PluginReleaseArtifact,
 *   releaseTarget?: ReturnType<typeof resolveReleaseTarget>,
 *   publicPackages: PublicReleaseArtifact[],
 *   versionChecks: Array<{ name: string, version: string }>,
 * }} ReleaseInventory
 */

/** @param {string | NodeJS.ArrayBufferView} value */
export function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

/** @param {string} root */
export function filesUnder(root) {
  /** @type {string[]} */
  const files = [];
  /** @param {string} directory */
  function visit(directory) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      if (entry.name === ".DS_Store") continue;
      const path = resolve(directory, entry.name);
      if (entry.isDirectory()) visit(path);
      else if (entry.isFile()) files.push(path);
      else throw new Error(`Release tree contains a non-file entry: ${path}`);
    }
  }
  visit(root);
  return files.sort((left, right) => relative(root, left).localeCompare(relative(root, right)));
}

/** @param {string} root */
export function treeReceipts(root) {
  return filesUnder(root).map((path) => {
    const content = readFileSync(path);
    return {
      path: relative(root, path).split("\\").join("/"),
      bytes: content.byteLength,
      sha256: sha256(content),
    };
  });
}

/** @param {string} root */
export function treeHash(root) {
  return sha256(`${JSON.stringify(treeReceipts(root))}\n`);
}

/** @param {string} root @param {readonly string[]} expected */
export function assertExactFiles(root, expected) {
  const actual = treeReceipts(root).map((receipt) => receipt.path);
  const patterns = [...expected].map((path) => path.split("\\").join("/")).sort();
  if (new Set(patterns).size !== patterns.length) {
    throw new Error(`Release allowlist for ${root} contains duplicate entries`);
  }
  const wanted = patterns.flatMap((pattern) => {
    if (!pattern.endsWith("*")) return [pattern];
    const prefix = pattern.slice(0, -1);
    const matches = actual.filter((path) => path.startsWith(prefix)).sort();
    if (matches.length === 0) {
      throw new Error(`Release directory ${root} is missing required generated files matching ${pattern}`);
    }
    const expectedMatches = matches.map((_, index) => `${prefix}${String(index).padStart(3, "0")}`);
    if (JSON.stringify(matches) !== JSON.stringify(expectedMatches)) {
      throw new Error(`Release directory ${root} has a non-contiguous generated source part sequence for ${pattern}`);
    }
    return matches;
  }).sort();
  if (new Set(wanted).size !== wanted.length) {
    throw new Error(`Release allowlist for ${root} overlaps generated entries`);
  }
  if (JSON.stringify(actual) !== JSON.stringify(wanted)) {
    throw new Error(
      `Release directory ${root} differs from its allowlist (expected ${wanted.join(", ")}; found ${actual.join(", ")})`,
    );
  }
}

/** @param {unknown} value @param {readonly string[]} expected */
function hasExactKeys(value, expected) {
  return value !== null
    && typeof value === "object"
    && !Array.isArray(value)
    && JSON.stringify(Object.keys(value).sort()) === JSON.stringify([...expected].sort());
}

/**
 * @param {string} loaderPath
 * @param {string} filename
 */
function readGeneratedSourceManifest(loaderPath, filename) {
  const loader = readFileSync(loaderPath);
  if (!Buffer.from(loader.toString("utf8"), "utf8").equals(loader) || loader.includes(0)) {
    throw new Error(`Generated payload loader is not plain UTF-8 text: ${loaderPath}`);
  }
  const matches = [...loader.toString("utf8").matchAll(
    /(?:^|\n)(?:const )?__PM_SOURCE_PARTS__=(\{[^\r\n]+\});(?:\r?\n|$)/gu,
  )];
  if (matches.length !== 1) {
    throw new Error(`Generated payload loader must contain exactly one source-part manifest: ${loaderPath}`);
  }
  /** @type {unknown} */
  let value;
  try {
    value = JSON.parse(matches[0][1]);
  } catch {
    throw new Error(`Generated payload loader contains invalid source-part manifest JSON: ${loaderPath}`);
  }
  if (!hasExactKeys(value, ["schemaVersion", "sourceBytes", "sourceSha256", "parts"])) {
    throw new Error(`Generated payload loader contains an invalid source-part manifest: ${loaderPath}`);
  }
  const candidate = /** @type {Record<string, unknown>} */ (value);
  if (
    candidate.schemaVersion !== 1
    || typeof candidate.sourceBytes !== "number"
    || !Number.isSafeInteger(candidate.sourceBytes)
    || candidate.sourceBytes <= 0
    || typeof candidate.sourceSha256 !== "string"
    || !SHA256_PATTERN.test(candidate.sourceSha256)
    || !Array.isArray(candidate.parts)
    || candidate.parts.length === 0
    || candidate.parts.length > MAX_GENERATED_SOURCE_PARTS
  ) {
    throw new Error(`Generated payload loader contains an invalid source-part manifest: ${loaderPath}`);
  }
  let declaredBytes = 0;
  /** @type {GeneratedSourcePart[]} */
  const parts = [];
  for (const [index, part] of candidate.parts.entries()) {
    const expectedName = `${filename}.source.part-${String(index).padStart(3, "0")}`;
    if (!hasExactKeys(part, ["name", "bytes", "sha256"])) {
      throw new Error(`Generated payload loader contains an invalid source-part record: ${loaderPath}`);
    }
    const record = /** @type {Record<string, unknown>} */ (part);
    if (
      record.name !== expectedName
      || typeof record.bytes !== "number"
      || !Number.isSafeInteger(record.bytes)
      || record.bytes <= 0
      || record.bytes > GENERATED_SOURCE_PART_MAX_BYTES
      || typeof record.sha256 !== "string"
      || !SHA256_PATTERN.test(record.sha256)
    ) {
      throw new Error(`Generated payload loader contains an invalid source-part record: ${loaderPath}`);
    }
    const validated = /** @type {GeneratedSourcePart} */ (record);
    declaredBytes += validated.bytes;
    parts.push(validated);
  }
  if (declaredBytes !== candidate.sourceBytes) {
    throw new Error(`Generated payload source-part byte total differs from its manifest: ${loaderPath}`);
  }
  return /** @type {GeneratedSourceManifest} */ ({
    schemaVersion: 1,
    sourceBytes: candidate.sourceBytes,
    sourceSha256: candidate.sourceSha256,
    parts,
  });
}

/** @param {string} directoryRoot @param {string} filename */
function assertGeneratedSourceArtifact(directoryRoot, filename) {
  const loaderPath = resolve(directoryRoot, filename);
  const manifest = readGeneratedSourceManifest(loaderPath, filename);
  const prefix = `${filename}.source.part-`;
  const actualNames = treeReceipts(directoryRoot)
    .map((receipt) => receipt.path)
    .filter((path) => path.startsWith(prefix));
  const expectedNames = manifest.parts.map((part) => part.name);
  if (JSON.stringify(actualNames) !== JSON.stringify(expectedNames)) {
    throw new Error(`Generated payload source-part membership differs from its manifest: ${loaderPath}`);
  }
  const sourceParts = manifest.parts.map((part) => {
    const path = resolve(directoryRoot, part.name);
    const bytes = readFileSync(path);
    if (bytes.byteLength !== part.bytes || sha256(bytes) !== part.sha256) {
      throw new Error(`Generated payload source-part digest differs from its manifest: ${path}`);
    }
    if (!Buffer.from(bytes.toString("utf8"), "utf8").equals(bytes) || bytes.includes(0)) {
      throw new Error(`Generated payload source part is not plain UTF-8 text: ${path}`);
    }
    return bytes;
  });
  const source = Buffer.concat(sourceParts);
  if (source.byteLength !== manifest.sourceBytes || sha256(source) !== manifest.sourceSha256) {
    throw new Error(`Generated payload reconstructed source differs from its manifest: ${loaderPath}`);
  }
}

/**
 * @param {string} pluginRoot
 * @param {typeof productionMonitoringPluginDescriptor} descriptor
 */
function assertGeneratedPayloadFileLimits(pluginRoot, descriptor) {
  const binaryDirectories = new Set(descriptor.build.generatedBinaryDirectories ?? []);
  for (const directory of descriptor.build.generatedDirectories) {
    if (binaryDirectories.has(directory)) continue;
    for (const receipt of treeReceipts(resolve(pluginRoot, directory))) {
      if (receipt.bytes > GENERATED_PLUGIN_FILE_MAX_BYTES) {
        throw new Error(`Generated plugin file exceeds ${GENERATED_PLUGIN_FILE_MAX_BYTES} bytes: ${directory}/${receipt.path}`);
      }
    }
  }
  for (const file of descriptor.release.generatedRootFiles) {
    const bytes = readFileSync(resolve(pluginRoot, file));
    if (bytes.byteLength > GENERATED_PLUGIN_FILE_MAX_BYTES) {
      throw new Error(`Generated plugin file exceeds ${GENERATED_PLUGIN_FILE_MAX_BYTES} bytes: ${file}`);
    }
  }
}

/**
 * Verify the platform-specific native directory against the literal descriptor.
 * Unsupported targets must have an empty native directory.
 * @param {string} pluginRoot
 * @param {typeof productionMonitoringPluginDescriptor} descriptor
 * @param {NodeJS.Platform} [platform]
 * @param {NodeJS.Architecture} [architecture]
 */
export function assertPluginNativeAssets(
  pluginRoot,
  descriptor,
  platform = process.platform,
  architecture = process.arch,
) {
  const nativeAssets = descriptor.build.nativeAssets ?? [];
  if (nativeAssets.length === 0) return [];
  const selected = pluginNativeAssetForTarget(descriptor, platform, architecture);
  const directories = new Set(nativeAssets.map((asset) => asset.output.split("/")[0]));
  if (directories.size !== 1) {
    throw new Error(`${descriptor.id} native assets must share one generated directory`);
  }
  const directory = [...directories][0];
  const receipts = treeReceipts(resolve(pluginRoot, directory));
  if (selected === undefined) {
    if (receipts.length !== 0) {
      throw new Error(`${descriptor.id} must not contain a native asset for unsupported ${platform}/${architecture}`);
    }
    return [];
  }
  const expectedPath = selected.output.slice(directory.length + 1);
  if (
    receipts.length !== 1
    || receipts[0].path !== expectedPath
    || receipts[0].bytes !== selected.bytes
    || receipts[0].sha256 !== selected.sha256
  ) {
    throw new Error(`${descriptor.id} native asset differs from the pinned ${platform}/${architecture} allowlist`);
  }
  return [{
    name: selected.packageName,
    version: selected.packageVersion,
    license: selected.license,
    platform: selected.platform,
    architecture: selected.architecture,
    path: selected.output,
    bytes: selected.bytes,
    sha256: selected.sha256,
  }];
}

/**
 * The generated directories have an exact file set. Static, reviewed plugin
 * directories remain recursively copied, but no unreviewed top-level entry can
 * enter a release bundle.
 * @param {string} pluginRoot
 * @param {string} schemaSourceRoot
 * @param {typeof productionMonitoringPluginDescriptor} [descriptor]
 * @param {NodeJS.Platform} [platform]
 * @param {NodeJS.Architecture} [architecture]
 */
export function assertPluginReleaseLayout(
  pluginRoot,
  schemaSourceRoot,
  descriptor = productionMonitoringPluginDescriptor,
  platform = process.platform,
  architecture = process.arch,
) {
  const actualEntries = readdirSync(pluginRoot, { withFileTypes: true })
    .filter((entry) => entry.name !== ".DS_Store")
    .map((entry) => entry.name)
    .sort();
  const expectedEntries = [...descriptor.release.entries].sort();
  if (JSON.stringify(actualEntries) !== JSON.stringify(expectedEntries)) {
    throw new Error(
      `Plugin release root differs from its allowlist (expected ${expectedEntries.join(", ")}; found ${actualEntries.join(", ")})`,
    );
  }
  for (const file of descriptor.release.generatedRootFiles) {
    const metadata = lstatSync(resolve(pluginRoot, file));
    if (!metadata.isFile() || metadata.isSymbolicLink()) {
      throw new Error(`Plugin legal artifact is not a regular file: ${file}`);
    }
  }
  for (const [directory, expected] of Object.entries(descriptor.release.generatedFiles)) {
    assertExactFiles(resolve(pluginRoot, directory), expected);
  }
  assertPluginNativeAssets(pluginRoot, descriptor, platform, architecture);
  const schemaFiles = treeReceipts(schemaSourceRoot).map((receipt) => receipt.path);
  assertExactFiles(resolve(pluginRoot, "schemas"), schemaFiles);
  assertGeneratedPayloadFileLimits(pluginRoot, descriptor);
  for (const artifact of descriptor.release.generatedSourceArtifacts) {
    assertGeneratedSourceArtifact(resolve(pluginRoot, artifact.directory), artifact.filename);
  }
}

/**
 * Prove that checked-in/generated plugin bytes came from the current source.
 * File allowlists alone cannot detect a semantically stale compiled bundle.
 * @param {string} pluginRoot
 * @param {string} rebuiltRoot
 * @param {typeof productionMonitoringPluginDescriptor} [descriptor]
 */
export function assertGeneratedPluginFresh(
  pluginRoot,
  rebuiltRoot,
  descriptor = productionMonitoringPluginDescriptor,
) {
  for (const directory of descriptor.build.generatedDirectories) {
    const current = treeReceipts(resolve(pluginRoot, directory));
    const rebuilt = treeReceipts(resolve(rebuiltRoot, directory));
    if (JSON.stringify(current) !== JSON.stringify(rebuilt)) {
      throw new Error(
        `Generated plugin directory ${directory} is stale; run npm run build before release validation`,
      );
    }
  }
  for (const file of descriptor.release.generatedRootFiles) {
    const current = readFileSync(resolve(pluginRoot, file));
    const rebuilt = readFileSync(resolve(rebuiltRoot, file));
    if (!current.equals(rebuilt)) {
      throw new Error(
        `Generated plugin legal artifact ${file} is stale; run npm run build before release validation`,
      );
    }
  }
}

/**
 * Assemble static reviewed inputs from the plugin tree while taking every
 * generated byte from the exact private rebuild that passed freshness checks.
 * @param {string} pluginRoot
 * @param {string} rebuiltRoot
 * @param {string} outputRoot
 * @param {typeof productionMonitoringPluginDescriptor} [descriptor]
 */
export function assemblePluginRelease(
  pluginRoot,
  rebuiltRoot,
  outputRoot,
  descriptor = productionMonitoringPluginDescriptor,
) {
  const generatedPluginEntries = new Set([
    ...descriptor.build.generatedDirectories,
    ...descriptor.release.generatedRootFiles,
  ]);
  for (const entry of descriptor.release.entries) {
    const sourceRoot = generatedPluginEntries.has(entry) ? rebuiltRoot : pluginRoot;
    cpSync(resolve(sourceRoot, entry), resolve(outputRoot, entry), {
      filter: (source) => basename(source) !== ".DS_Store",
      recursive: true,
    });
  }
  assertGeneratedPluginFresh(outputRoot, rebuiltRoot, descriptor);
}

/**
 * @param {string} expectedVersion
 * @param {Array<{ name: string, version: string }>} components
 */
export function assertVersionConsistency(expectedVersion, components) {
  if (typeof expectedVersion !== "string" || expectedVersion.length === 0) {
    throw new Error("Release version must be a non-empty string");
  }
  const mismatches = components.filter((component) => component.version !== expectedVersion);
  if (mismatches.length > 0) {
    throw new Error(
      `Release version mismatch: expected ${expectedVersion}; ${mismatches.map((item) => `${item.name}=${item.version}`).join(", ")}`,
    );
  }
}

/**
 * @typedef {{ path: string, kind: "FILE" | "METADATA", bytes: Buffer }} TarEntry
 */

/** @param {Buffer} header @param {number} start @param {number} length */
function tarString(header, start, length) {
  const end = header.indexOf(0, start);
  const boundedEnd = end === -1 || end > start + length ? start + length : end;
  return header.subarray(start, boundedEnd).toString("utf8");
}

/**
 * Read a bounded gzip tarball without extracting it. Paths, links, duplicate
 * files, header checksums, truncation, and unsupported entry types fail closed.
 * @param {string} path
 * @param {{ maxCompressedBytes?: number, maxExpandedBytes?: number, maxEntries?: number }} [options]
 * @returns {TarEntry[]}
 */
export function readGzipTarEntries(path, options = {}) {
  const maxCompressedBytes = options.maxCompressedBytes ?? 32 * 1024 * 1024;
  const maxExpandedBytes = options.maxExpandedBytes ?? 128 * 1024 * 1024;
  const maxEntries = options.maxEntries ?? 10_000;
  const compressed = readFileSync(path);
  if (compressed.byteLength > maxCompressedBytes) {
    throw new Error(`Release tarball exceeds the compressed read budget: ${path}`);
  }
  const archive = gunzipSync(compressed, { maxOutputLength: maxExpandedBytes });
  /** @type {TarEntry[]} */
  const entries = [];
  const filePaths = new Set();
  let offset = 0;
  let terminated = false;
  while (offset + 512 <= archive.length) {
    const header = archive.subarray(offset, offset + 512);
    if (header.every((byte) => byte === 0)) {
      terminated = true;
      break;
    }
    const expectedChecksum = Number.parseInt(tarString(header, 148, 8).trim(), 8);
    let actualChecksum = 0;
    for (let index = 0; index < header.length; index += 1) {
      actualChecksum += index >= 148 && index < 156 ? 32 : header[index];
    }
    if (!Number.isSafeInteger(expectedChecksum) || expectedChecksum !== actualChecksum) {
      throw new Error(`Release tarball has an invalid header checksum: ${path}`);
    }
    const name = tarString(header, 0, 100);
    const prefix = tarString(header, 345, 155);
    const archivePath = prefix.length > 0 ? `${prefix}/${name}` : name;
    if (
      archivePath.length === 0
      || archivePath.startsWith("/")
      || archivePath.includes("\\")
      || archivePath.split("/").some((part) => part === "" || part === "." || part === "..")
    ) {
      throw new Error(`Release tarball contains an unsafe path: ${path}:${archivePath}`);
    }
    const sizeText = tarString(header, 124, 12).trim();
    const size = sizeText.length === 0 ? 0 : Number.parseInt(sizeText, 8);
    if (!Number.isSafeInteger(size) || size < 0) {
      throw new Error(`Release tarball contains an invalid entry size: ${path}:${archivePath}`);
    }
    const type = tarString(header, 156, 1);
    const contentStart = offset + 512;
    const contentEnd = contentStart + size;
    if (contentEnd > archive.length) {
      throw new Error(`Release tarball is truncated: ${path}:${archivePath}`);
    }
    if (type === "" || type === "0") {
      if (filePaths.has(archivePath)) {
        throw new Error(`Release tarball contains a duplicate file: ${path}:${archivePath}`);
      }
      filePaths.add(archivePath);
      entries.push({
        path: archivePath,
        kind: "FILE",
        bytes: archive.subarray(contentStart, contentEnd),
      });
    } else if (type === "x" || type === "g") {
      entries.push({
        path: archivePath,
        kind: "METADATA",
        bytes: archive.subarray(contentStart, contentEnd),
      });
    } else if (type !== "5") {
      throw new Error(`Release tarball contains a link or unsupported entry type: ${path}:${archivePath}`);
    }
    if (entries.length > maxEntries) {
      throw new Error(`Release tarball exceeds the entry-count budget: ${path}`);
    }
    offset = contentStart + Math.ceil(size / 512) * 512;
  }
  if (!terminated || entries.length === 0) {
    throw new Error(`Release tarball is empty or lacks a complete terminator: ${path}`);
  }
  return entries;
}

/** @param {string} path @returns {PackageManifest} */
function readPackageManifest(path) {
  const value = JSON.parse(readFileSync(path, "utf8"));
  if (
    value === null
    || typeof value !== "object"
    || typeof value.name !== "string"
    || typeof value.version !== "string"
  ) {
    throw new Error(`Invalid package manifest: ${path}`);
  }
  return value;
}

/** @param {string} repositoryRoot @param {readonly string[]} patterns */
function workspaceManifestPaths(repositoryRoot, patterns) {
  /** @type {string[]} */
  const manifests = [];
  for (const pattern of patterns) {
    if (pattern.endsWith("/*")) {
      const workspaceRoot = resolve(repositoryRoot, pattern.slice(0, -2));
      for (const entry of readdirSync(workspaceRoot, { withFileTypes: true })) {
        if (entry.isDirectory()) manifests.push(resolve(workspaceRoot, entry.name, "package.json"));
      }
      continue;
    }
    if (pattern.includes("*")) {
      throw new Error(`Unsupported workspace pattern in release validation: ${pattern}`);
    }
    manifests.push(resolve(repositoryRoot, pattern, "package.json"));
  }
  return manifests.sort();
}

/** @param {string} root @param {string} candidate */
function assertContainedRegularFile(root, candidate) {
  const lexical = relative(root, candidate);
  if (lexical === ".." || lexical.startsWith(`..${sep}`) || lexical === "") {
    throw new Error(`Release artifact is outside its owned directory: ${candidate}`);
  }
  const metadata = lstatSync(candidate);
  if (!metadata.isFile() || metadata.isSymbolicLink()) {
    throw new Error(`Release artifact is not a regular file: ${candidate}`);
  }
  const realRoot = realpathSync(root);
  const realCandidate = realpathSync(candidate);
  const resolved = relative(realRoot, realCandidate);
  if (resolved === ".." || resolved.startsWith(`..${sep}`) || resolved === "") {
    throw new Error(`Release artifact escapes its owned directory: ${candidate}`);
  }
  return metadata;
}

/**
 * Load and verify the complete candidate inventory. Public package names,
 * versions, licenses, paths, and bytes are checked against workspace manifests
 * and the generated tarball manifest before evidence is emitted.
 * @param {string} repositoryRoot
 * @param {{
 *   targetPlatform?: NodeJS.Platform,
 *   targetArchitecture?: NodeJS.Architecture,
 *   releaseKind?: "NATIVE_CANDIDATE" | "SOURCE_ONLY",
 * }} [options]
 * @returns {ReleaseInventory}
 */
export function loadReleaseInventory(repositoryRoot, options = {}) {
  const releaseTarget = resolveReleaseTarget({
    environment: {
      ...(options.targetPlatform === undefined
        ? {} : { PM_RELEASE_TARGET_PLATFORM: options.targetPlatform }),
      ...(options.targetArchitecture === undefined
        ? {} : { PM_RELEASE_TARGET_ARCHITECTURE: options.targetArchitecture }),
      ...(options.releaseKind === undefined ? {} : { PM_RELEASE_KIND: options.releaseKind }),
      ...(options.targetPlatform === undefined
        && options.targetArchitecture === undefined
        && options.releaseKind === undefined
        ? process.env
        : {}),
    },
  });
  const rootManifest = readPackageManifest(resolve(repositoryRoot, "package.json"));
  if (!Array.isArray(rootManifest.workspaces)) {
    throw new Error("Root package.json must declare a workspace array");
  }
  const license = rootManifest.license;
  if (typeof license !== "string" || license.length === 0) {
    throw new Error("Root package.json must declare a release license");
  }

  const plugins = pluginDescriptors.map((descriptor) => {
    const pluginRoot = resolve(repositoryRoot, descriptor.distPath);
    const pluginManifest = readPackageManifest(
      resolve(pluginRoot, ".codex-plugin/plugin.json"),
    );
    if (pluginManifest.name !== descriptor.id) {
      throw new Error(
        `${descriptor.distPath} manifest name ${pluginManifest.name} differs from descriptor ${descriptor.id}`,
      );
    }
    if (!STRICT_SEMVER_PATTERN.test(pluginManifest.version)) {
      throw new Error(`${descriptor.id} manifest version is not strict semantic versioning`);
    }
    if (pluginManifest.license !== license) {
      throw new Error(
        `${descriptor.id} license ${String(pluginManifest.license)} differs from release license ${license}`,
      );
    }
    const pluginFiles = treeReceipts(pluginRoot);
    const nativeAssets = assertPluginNativeAssets(
      pluginRoot,
      descriptor,
      releaseTarget.platform,
      releaseTarget.architecture,
    );
    return {
      name: pluginManifest.name,
      version: pluginManifest.version,
      sourcePath: descriptor.sourcePath,
      path: relative(repositoryRoot, pluginRoot).split("\\").join("/"),
      root: pluginRoot,
      treeSha256: sha256(`${JSON.stringify(pluginFiles)}\n`),
      files: pluginFiles,
      nativeAssets,
    };
  });

  const workspaceManifests = workspaceManifestPaths(repositoryRoot, rootManifest.workspaces)
    .map((path) => ({ path, manifest: readPackageManifest(path) }));
  const publicWorkspaces = workspaceManifests
    .filter(({ manifest }) => manifest.private !== true && manifest.publishConfig?.access === "public")
    .sort((left, right) => left.manifest.name.localeCompare(right.manifest.name));
  const publicByName = new Map(publicWorkspaces.map((item) => [item.manifest.name, item.manifest]));

  const publicManifestPath = resolve(repositoryRoot, "dist/public-packages/manifest.json");
  /** @type {{ schemaVersion?: string, packages?: PublicPackageEntry[] }} */
  const publicManifest = JSON.parse(readFileSync(publicManifestPath, "utf8"));
  if (publicManifest.schemaVersion !== "1.0.0" || !Array.isArray(publicManifest.packages)) {
    throw new Error("Public package manifest is missing or has an unsupported schema");
  }
  const names = publicManifest.packages.map((entry) => entry.name);
  if (new Set(names).size !== names.length) {
    throw new Error("Public package manifest contains duplicate package names");
  }
  const artifactPaths = publicManifest.packages.map((entry) => entry.file);
  if (new Set(artifactPaths).size !== artifactPaths.length) {
    throw new Error("Public package manifest contains duplicate artifact paths");
  }
  const expectedNames = [...publicByName.keys()].sort();
  const actualNames = [...names].sort();
  if (JSON.stringify(expectedNames) !== JSON.stringify(actualNames)) {
    throw new Error(
      `Public package manifest does not match publishable workspaces (expected ${expectedNames.join(", ")}; found ${actualNames.join(", ")})`,
    );
  }

  const tarballRoot = resolve(repositoryRoot, "dist/public-packages/tarballs");
  /** @type {PublicReleaseArtifact[]} */
  const publicPackages = [];
  for (const entry of publicManifest.packages) {
    if (
      typeof entry.name !== "string"
      || typeof entry.version !== "string"
      || typeof entry.file !== "string"
      || !/^[a-f0-9]{64}$/u.test(entry.sha256)
    ) {
      throw new Error("Public package manifest contains an invalid artifact record");
    }
    const workspace = publicByName.get(entry.name);
    if (workspace === undefined) throw new Error(`Unknown public package: ${entry.name}`);
    if (workspace.version !== entry.version) {
      throw new Error(`${entry.name} manifest version ${entry.version} differs from its workspace ${workspace.version}`);
    }
    if (workspace.license !== license) {
      throw new Error(`${entry.name} license ${String(workspace.license)} differs from release license ${license}`);
    }
    const absolutePath = resolve(repositoryRoot, entry.file);
    const metadata = assertContainedRegularFile(tarballRoot, absolutePath);
    const actualDigest = sha256(readFileSync(absolutePath));
    if (actualDigest !== entry.sha256) {
      throw new Error(`${entry.name} tarball digest differs from the public package manifest`);
    }
    const tarEntries = readGzipTarEntries(absolutePath);
    if (tarEntries.some((item) => item.kind === "FILE" && !item.path.startsWith("package/"))) {
      throw new Error(`${entry.name} tarball contains a file outside the npm package root`);
    }
    const packedManifestEntries = tarEntries.filter(
      (item) => item.kind === "FILE" && item.path === "package/package.json",
    );
    if (packedManifestEntries.length !== 1) {
      throw new Error(`${entry.name} tarball must contain exactly one package/package.json`);
    }
    const packedManifest = JSON.parse(packedManifestEntries[0].bytes.toString("utf8"));
    assertPublishedManifest(packedManifest, entry.name);
    if (
      packedManifest === null
      || typeof packedManifest !== "object"
      || packedManifest.name !== entry.name
      || packedManifest.version !== entry.version
      || packedManifest.license !== license
    ) {
      throw new Error(`${entry.name} tarball manifest identity, version, or license differs from release metadata`);
    }
    publicPackages.push({
      name: entry.name,
      version: entry.version,
      license,
      path: relative(repositoryRoot, absolutePath).split("\\").join("/"),
      absolutePath,
      bytes: metadata.size,
      sha256: actualDigest,
    });
  }
  publicPackages.sort((left, right) => left.name.localeCompare(right.name));

  const versionChecks = [
    { name: rootManifest.name, version: rootManifest.version },
    ...pluginDescriptors.flatMap((descriptor, index) => (
      descriptor.governance.versionBinding === "ROOT"
        ? [{ name: plugins[index].name, version: plugins[index].version }]
        : []
    )),
    ...publicPackages.map((item) => ({ name: item.name, version: item.version })),
  ];
  assertVersionConsistency(rootManifest.version, versionChecks);

  const primaryPlugin = plugins.find(
    (plugin) => plugin.name === productionMonitoringPluginDescriptor.id,
  );
  if (primaryPlugin === undefined) {
    throw new Error("The primary Production Monitoring plugin is absent from the release matrix");
  }

  return {
    name: rootManifest.name,
    version: rootManifest.version,
    license,
    plugins,
    plugin: primaryPlugin,
    releaseTarget,
    publicPackages,
    versionChecks,
  };
}

/** @param {ReleaseInventory} inventory */
export function releaseManifest(inventory) {
  return {
    schemaVersion: "1.0.0",
    release: {
      name: inventory.name,
      version: inventory.version,
      license: inventory.license,
      ...(inventory.releaseTarget === undefined ? {} : { target: inventory.releaseTarget }),
    },
    versionConsistency: {
      status: "VERIFIED",
      expectedVersion: inventory.version,
      components: inventory.versionChecks,
    },
    artifacts: [
      ...inventory.plugins.flatMap((plugin) => [{
          kind: "CODEX_PLUGIN_TREE",
          name: plugin.name,
          version: plugin.version,
          path: plugin.path,
          digestType: "TREE_RECEIPTS_SHA256",
          sha256: plugin.treeSha256,
          fileCount: plugin.files.length,
        },
        ...(plugin.nativeAssets ?? []).map((asset) => ({
          kind: "NATIVE_BINARY",
          name: asset.name,
          version: asset.version,
          plugin: plugin.name,
          platform: asset.platform,
          architecture: asset.architecture,
          path: `${plugin.path}/${asset.path}`,
          digestType: "FILE_SHA256",
          sha256: asset.sha256,
          bytes: asset.bytes,
        })),
      ]),
      ...inventory.publicPackages.map((item) => ({
        kind: "NPM_TARBALL",
        name: item.name,
        version: item.version,
        path: item.path,
        digestType: "FILE_SHA256",
        sha256: item.sha256,
        bytes: item.bytes,
      })),
    ],
  };
}
