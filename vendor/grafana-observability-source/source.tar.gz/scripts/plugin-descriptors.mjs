/**
 * The ordered, code-owned plugin matrix. Every path is repository-relative and
 * every generated artifact is declared here so build and release callers do
 * not infer a plugin surface from mutable filesystem contents.
 */

const productionMonitoringReleaseEntries = [
  ".codex-plugin",
  ".mcp.json",
  "LICENSE",
  "THIRD_PARTY_NOTICES.txt",
  "assets",
  "examples",
  "mcp",
  "native",
  "references",
  "schemas",
  "scripts",
  "skills",
  "workers",
];

const grafanaObservabilityReleaseEntries = [
  ".codex-plugin",
  ".mcp.json",
  "LICENSE",
  "README.md",
  "THIRD_PARTY_NOTICES.txt",
  "assets",
  "mcp",
  "native",
  "schemas",
  "scripts",
  "skills",
  "workers",
];

const grafanaMacOsKeychainAssets = [
  {
    platform: "darwin",
    architecture: "arm64",
    packageName: "@napi-rs/keyring-darwin-arm64",
    packageVersion: "1.3.0",
    packagePath: "node_modules/@napi-rs/keyring-darwin-arm64",
    licensePackagePath: "node_modules/@napi-rs/keyring",
    sourcePath: "node_modules/@napi-rs/keyring-darwin-arm64/keyring.darwin-arm64.node",
    output: "native/keyring.darwin-arm64.node",
    bytes: 491_232,
    sha256: "9627560bd2490b8495504df6b48dafe0153883aab09fd8eee976f826c74a6fff",
    license: "MIT",
  },
  {
    platform: "darwin",
    architecture: "x64",
    packageName: "@napi-rs/keyring-darwin-x64",
    packageVersion: "1.3.0",
    packagePath: "node_modules/@napi-rs/keyring-darwin-x64",
    licensePackagePath: "node_modules/@napi-rs/keyring",
    sourcePath: "node_modules/@napi-rs/keyring-darwin-x64/keyring.darwin-x64.node",
    output: "native/keyring.darwin-x64.node",
    bytes: 516_004,
    sha256: "3ad3b083cab321be04223e7fa1a22a8258c32c4da0883886683e25dcba9d03cc",
    license: "MIT",
  },
];

const productionMonitoringCachedToolNames = [
  "monitoring_open_workbench",
  "monitoring_open_workspace",
  "monitoring_workbench_snapshot",
  "monitoring_workbench_evidence",
  "monitoring_workbench_resolve_link",
  "monitoring_workbench_patch_context",
  "monitoring_doctor",
  "monitoring_list_capabilities",
  "monitoring_list_operations",
  "monitoring_resolve_scope",
  "monitoring_begin_run",
  "monitoring_resume_run",
  "monitoring_collect",
  "monitoring_compare",
  "monitoring_get_evidence",
  "monitoring_audit_status",
  "monitoring_finalize_run",
  "monitoring_cancel_run",
];

const grafanaObservabilityCachedToolNames = [
  "grafana_profile_status",
  "grafana_list_packs",
  "grafana_run_pack",
  "grafana_get_evidence",
  "grafana_resolve_link",
];

const grafanaObservabilityCachedToolAnnotations = {
  grafana_profile_status: {
    readOnlyHint: true,
    openWorldHint: true,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_list_packs: {
    readOnlyHint: true,
    openWorldHint: false,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_run_pack: {
    readOnlyHint: false,
    openWorldHint: true,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_get_evidence: {
    readOnlyHint: true,
    openWorldHint: false,
    destructiveHint: false,
    idempotentHint: true,
  },
  grafana_resolve_link: {
    readOnlyHint: true,
    openWorldHint: false,
    destructiveHint: false,
    idempotentHint: true,
  },
};

/** @param {unknown} value */
function deepFreeze(value) {
  if (value !== null && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}

const descriptors = [
  {
    order: 10,
    id: "production-monitoring",
    displayName: "Production Monitoring",
    sourcePath: "plugins/production-monitoring",
    distPath: "dist/production-monitoring",
    marketplace: {
      name: "production-monitoring-local",
      sourcePath: "./plugins/production-monitoring",
    },
    manifest: {
      setupSkill: "setup-production-monitoring",
      requiredCapabilities: ["Interactive", "Read", "Write"],
      forbiddenCapabilities: [],
      requirePromptArray: true,
      requireLogo: true,
      requireComposerIcon: true,
    },
    mcp: {
      serverName: "production-monitoring",
      command: "node",
      args: ["./mcp/server.mjs", "--stdio"],
      cwd: ".",
    },
    cachedInstallProbe: {
      kind: "PRODUCTION_MONITORING_FIXTURE_WORKFLOW",
      cliEntrypoint: "scripts/pmctl.mjs",
      expectedMcpToolNames: productionMonitoringCachedToolNames,
    },
    build: {
      schemaSourcePath: "packages/contracts/schemas",
      generatedDirectories: ["mcp", "native", "schemas", "scripts", "workers"],
      generatedBinaryDirectories: ["native"],
      nativeAssets: grafanaMacOsKeychainAssets,
      steps: [
        {
          kind: "NODE",
          name: "MCP server",
          entryPoint: "packages/mcp-server/src/entrypoint.ts",
          output: "mcp/server.mjs",
          shebang: false,
        },
        {
          kind: "WORKSPACE",
          name: "Production Monitoring workspace",
          entryPoint: "packages/mcp-server/src/app/client.ts",
          template: "packages/mcp-server/src/app/template.html",
          styles: "packages/mcp-server/src/app/styles.css",
          styleMarker: "/*__PRODUCTION_MONITORING_APP_STYLES__*/",
          scriptMarker: "/*__PRODUCTION_MONITORING_APP_SCRIPT__*/",
          output: "mcp/workspace.html",
        },
        {
          kind: "NODE",
          name: "pmctl",
          entryPoint: "packages/cli/src/entrypoint.ts",
          output: "scripts/pmctl.mjs",
          shebang: true,
        },
        {
          kind: "NODE",
          name: "provider worker",
          entryPoint: "packages/provider-runtime/src/worker-entrypoint.ts",
          output: "workers/provider-worker.mjs",
          shebang: false,
        },
      ],
    },
    release: {
      entries: productionMonitoringReleaseEntries,
      generatedFiles: {
        mcp: [
          "server.mjs",
          "server.mjs.source.part-*",
          "workspace.html",
          "workspace.html.source.part-*",
        ],
        scripts: ["pmctl.mjs", "pmctl.mjs.source.part-*"],
        workers: ["provider-worker.mjs", "provider-worker.mjs.source.part-*"],
      },
      generatedRootFiles: ["LICENSE", "THIRD_PARTY_NOTICES.txt"],
      generatedSourceArtifacts: [
        { directory: "mcp", filename: "server.mjs" },
        { directory: "mcp", filename: "workspace.html" },
        { directory: "scripts", filename: "pmctl.mjs" },
        { directory: "workers", filename: "provider-worker.mjs" },
      ],
    },
    governance: {
      versionBinding: "ROOT",
      cachedInstall: true,
      firstReleaseBootstrap: true,
      officialValidator: true,
      offlineWorkflowEval: true,
    },
  },
  {
    order: 20,
    id: "grafana-observability",
    displayName: "Grafana Observability",
    sourcePath: "plugins/grafana-observability",
    distPath: "dist/grafana-observability",
    marketplace: {
      name: "production-monitoring-local",
      sourcePath: "./plugins/grafana-observability",
    },
    manifest: {
      setupSkill: "setup-grafana-observability",
      requiredCapabilities: ["Read", "Write"],
      forbiddenCapabilities: [],
      requirePromptArray: true,
      requireLogo: true,
      requireComposerIcon: true,
    },
    mcp: {
      serverName: "grafana-observability",
      command: "node",
      args: ["./mcp/server.mjs", "--stdio"],
      cwd: ".",
    },
    cachedInstallProbe: {
      kind: "GRAFANA_STANDALONE_NO_PROVIDER",
      cliEntrypoint: "scripts/observabilityctl.mjs",
      expectedMcpToolNames: grafanaObservabilityCachedToolNames,
      expectedMcpToolAnnotations: grafanaObservabilityCachedToolAnnotations,
    },
    build: {
      schemaSourcePath: "packages/contracts/schemas",
      generatedDirectories: ["mcp", "native", "schemas", "scripts", "workers"],
      generatedBinaryDirectories: ["native"],
      nativeAssets: grafanaMacOsKeychainAssets,
      steps: [
        {
          kind: "NODE",
          name: "Grafana Observability MCP server",
          entryPoint: "packages/grafana-mcp-server/src/entrypoint.ts",
          output: "mcp/server.mjs",
          shebang: false,
        },
        {
          kind: "NODE",
          name: "observabilityctl",
          entryPoint: "packages/observability-cli/src/entrypoint.ts",
          output: "scripts/observabilityctl.mjs",
          shebang: true,
        },
        {
          kind: "NODE",
          name: "grafana-authorityctl",
          entryPoint: "packages/grafana-authority-cli/src/entrypoint.ts",
          output: "scripts/grafana-authorityctl.mjs",
          shebang: true,
        },
        {
          kind: "NODE",
          name: "provider worker",
          entryPoint: "packages/provider-runtime/src/worker-entrypoint.ts",
          output: "workers/provider-worker.mjs",
          shebang: false,
        },
      ],
    },
    release: {
      entries: grafanaObservabilityReleaseEntries,
      generatedFiles: {
        mcp: ["server.mjs", "server.mjs.source.part-*"],
        scripts: [
          "observabilityctl.mjs",
          "observabilityctl.mjs.source.part-*",
          "grafana-authorityctl.mjs",
          "grafana-authorityctl.mjs.source.part-*",
        ],
        workers: ["provider-worker.mjs", "provider-worker.mjs.source.part-*"],
      },
      generatedRootFiles: ["LICENSE", "THIRD_PARTY_NOTICES.txt"],
      generatedSourceArtifacts: [
        { directory: "mcp", filename: "server.mjs" },
        { directory: "scripts", filename: "observabilityctl.mjs" },
        { directory: "scripts", filename: "grafana-authorityctl.mjs" },
        { directory: "workers", filename: "provider-worker.mjs" },
      ],
    },
    governance: {
      versionBinding: "INDEPENDENT",
      cachedInstall: true,
      firstReleaseBootstrap: false,
      officialValidator: true,
      offlineWorkflowEval: false,
    },
  },
];

/** @param {string} value @param {string} label */
function assertRepositoryRelativePath(value, label) {
  if (
    typeof value !== "string"
    || value.length === 0
    || value.startsWith("/")
    || value.includes("\\")
    || value.split("/").some((part) => part === "" || part === "." || part === "..")
  ) {
    throw new Error(`${label} must be a normalized repository-relative path`);
  }
}

function assertDescriptorMatrix() {
  const identities = new Set();
  const sourcePaths = new Set();
  const distPaths = new Set();
  const mcpNames = new Set();
  let priorOrder = -1;
  for (const descriptor of descriptors) {
    if (!Number.isSafeInteger(descriptor.order) || descriptor.order <= priorOrder) {
      throw new Error("Plugin descriptor order must be strictly increasing");
    }
    priorOrder = descriptor.order;
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(descriptor.id) || identities.has(descriptor.id)) {
      throw new Error(`Plugin descriptor identity is invalid or duplicated: ${descriptor.id}`);
    }
    identities.add(descriptor.id);
    assertRepositoryRelativePath(descriptor.sourcePath, `${descriptor.id} sourcePath`);
    assertRepositoryRelativePath(descriptor.distPath, `${descriptor.id} distPath`);
    if (sourcePaths.has(descriptor.sourcePath) || distPaths.has(descriptor.distPath)) {
      throw new Error(`Plugin descriptor paths must be unique: ${descriptor.id}`);
    }
    sourcePaths.add(descriptor.sourcePath);
    distPaths.add(descriptor.distPath);
    if (mcpNames.has(descriptor.mcp.serverName)) {
      throw new Error(`Plugin MCP server names must be unique: ${descriptor.mcp.serverName}`);
    }
    mcpNames.add(descriptor.mcp.serverName);
    if (descriptor.governance.versionBinding !== "ROOT" && descriptor.governance.versionBinding !== "INDEPENDENT") {
      throw new Error(`${descriptor.id} version binding is invalid`);
    }
    const cachedInstallProbe = descriptor.cachedInstallProbe;
    if (descriptor.governance.cachedInstall !== true || cachedInstallProbe === undefined) {
      throw new Error(`${descriptor.id} must declare an admitted cached-install probe`);
    }
    if (!new Set([
      "PRODUCTION_MONITORING_FIXTURE_WORKFLOW",
      "GRAFANA_STANDALONE_NO_PROVIDER",
    ]).has(cachedInstallProbe.kind)) {
      throw new Error(`${descriptor.id} cached-install probe kind is invalid`);
    }
    assertRepositoryRelativePath(
      cachedInstallProbe.cliEntrypoint,
      `${descriptor.id} cached-install CLI entrypoint`,
    );
    if (
      !Array.isArray(cachedInstallProbe.expectedMcpToolNames)
      || cachedInstallProbe.expectedMcpToolNames.length === 0
      || new Set(cachedInstallProbe.expectedMcpToolNames).size
        !== cachedInstallProbe.expectedMcpToolNames.length
      || cachedInstallProbe.expectedMcpToolNames.some(
        (name) => typeof name !== "string" || !/^[a-z][a-z0-9_]{0,127}$/u.test(name),
      )
    ) {
      throw new Error(`${descriptor.id} cached-install MCP tool contract is invalid`);
    }
    const expectedMcpToolAnnotations = "expectedMcpToolAnnotations" in cachedInstallProbe
      ? cachedInstallProbe.expectedMcpToolAnnotations
      : undefined;
    if (cachedInstallProbe.kind === "GRAFANA_STANDALONE_NO_PROVIDER") {
      const expectedNames = [...cachedInstallProbe.expectedMcpToolNames].sort();
      const annotationNames = expectedMcpToolAnnotations !== null
        && typeof expectedMcpToolAnnotations === "object"
        && !Array.isArray(expectedMcpToolAnnotations)
        ? Object.keys(expectedMcpToolAnnotations).sort()
        : [];
      const annotationKeys = [
        "destructiveHint",
        "idempotentHint",
        "openWorldHint",
        "readOnlyHint",
      ];
      const annotationContract = /** @type {Record<string, Record<string, unknown>>} */ (
        expectedMcpToolAnnotations
      );
      if (
        JSON.stringify(annotationNames) !== JSON.stringify(expectedNames)
        || annotationNames.some((name) => {
          const annotations = annotationContract[name];
          return annotations === null
            || annotations === undefined
            || typeof annotations !== "object"
            || Array.isArray(annotations)
            || JSON.stringify(Object.keys(annotations).sort()) !== JSON.stringify(annotationKeys)
            || annotationKeys.some((key) => typeof annotations[key] !== "boolean");
        })
      ) {
        throw new Error(`${descriptor.id} cached-install MCP annotation contract is invalid`);
      }
    }
    for (const path of [
      descriptor.build.schemaSourcePath,
      ...descriptor.build.steps.flatMap((step) => [
        step.entryPoint,
        step.output,
        ...("template" in step ? [step.template ?? "", step.styles ?? ""] : []),
      ]),
    ]) {
      assertRepositoryRelativePath(path, `${descriptor.id} build path`);
    }
    const nativeAssets = descriptor.build.nativeAssets ?? [];
    const nativeOutputs = new Set();
    for (const asset of nativeAssets) {
      assertRepositoryRelativePath(asset.packagePath, `${descriptor.id} native packagePath`);
      assertRepositoryRelativePath(asset.licensePackagePath, `${descriptor.id} native licensePackagePath`);
      assertRepositoryRelativePath(asset.sourcePath, `${descriptor.id} native sourcePath`);
      assertRepositoryRelativePath(asset.output, `${descriptor.id} native output`);
      if (
        asset.platform !== "darwin"
        || (asset.architecture !== "arm64" && asset.architecture !== "x64")
        || asset.packageVersion !== "1.3.0"
        || asset.license !== "MIT"
        || !Number.isSafeInteger(asset.bytes)
        || asset.bytes < 1
        || !/^[a-f0-9]{64}$/u.test(asset.sha256)
        || nativeOutputs.has(asset.output)
      ) {
        throw new Error(`${descriptor.id} contains an invalid or duplicate native asset`);
      }
      const [outputDirectory] = asset.output.split("/");
      if (
        outputDirectory === undefined
        || !descriptor.build.generatedDirectories.includes(outputDirectory)
        || !descriptor.release.entries.includes(outputDirectory)
      ) {
        throw new Error(`${descriptor.id} native asset is outside the generated release contract`);
      }
      nativeOutputs.add(asset.output);
    }
    const nativeTargets = nativeAssets.map((asset) => `${asset.platform}/${asset.architecture}`);
    if (new Set(nativeTargets).size !== nativeTargets.length) {
      throw new Error(`${descriptor.id} contains duplicate native platform targets`);
    }
    const releaseEntrySet = new Set(descriptor.release.entries);
    if (releaseEntrySet.size !== descriptor.release.entries.length) {
      throw new Error(`Plugin release entries contain duplicates: ${descriptor.id}`);
    }
    for (const directory of descriptor.build.generatedDirectories) {
      if (!releaseEntrySet.has(directory)) {
        throw new Error(`${descriptor.id} generated directory is absent from its release entries: ${directory}`);
      }
    }
    for (const step of descriptor.build.steps) {
      const [directory, filename] = step.output.split("/");
      const generatedFiles = /** @type {Record<string, readonly string[]>} */ (
        descriptor.release.generatedFiles
      );
      const allowlist = generatedFiles[directory];
      if (
        filename === undefined
        || !Array.isArray(allowlist)
        || !allowlist.includes(filename)
        || !descriptor.release.generatedSourceArtifacts.some(
          (artifact) => artifact.directory === directory && artifact.filename === filename,
        )
      ) {
        throw new Error(`${descriptor.id} build output is absent from its generated release contract: ${step.output}`);
      }
    }
    if (
      !descriptor.build.steps.some((step) => step.output === cachedInstallProbe.cliEntrypoint)
      || descriptor.mcp.args[0] !== "./mcp/server.mjs"
      || descriptor.mcp.args[1] !== "--stdio"
    ) {
      throw new Error(`${descriptor.id} cached-install probe is not bound to its built CLI and MCP entrypoints`);
    }
  }
}

assertDescriptorMatrix();
deepFreeze(descriptors);

export const pluginDescriptors = descriptors;
export const productionMonitoringPluginDescriptor = pluginDescriptors[0];
export const grafanaObservabilityPluginDescriptor = pluginDescriptors[1];

/** @param {string} id */
export function pluginDescriptorById(id) {
  const descriptor = pluginDescriptors.find((candidate) => candidate.id === id);
  if (descriptor === undefined) throw new Error(`Unknown plugin descriptor: ${id}`);
  return descriptor;
}

/** @param {keyof typeof productionMonitoringPluginDescriptor.governance} capability */
export function pluginDescriptorsWithGovernance(capability) {
  return pluginDescriptors.filter((descriptor) => descriptor.governance[capability] === true);
}

/**
 * Select at most one code-owned native asset for a concrete release target.
 * Unsupported platforms intentionally select no credential backend.
 * @param {typeof productionMonitoringPluginDescriptor} descriptor
 * @param {NodeJS.Platform} [platform]
 * @param {NodeJS.Architecture} [architecture]
 */
export function pluginNativeAssetForTarget(
  descriptor,
  platform = process.platform,
  architecture = process.arch,
) {
  return (descriptor.build.nativeAssets ?? []).find(
    (asset) => asset.platform === platform && asset.architecture === architecture,
  );
}
