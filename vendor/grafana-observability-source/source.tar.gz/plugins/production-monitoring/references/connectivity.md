# Connectivity by deployment surface

Connectivity belongs to the active deployment and administrator policy. It is not implied by installing this plugin.

| Surface | Status in this release | Reachability | Explicit non-claim |
| --- | --- | --- | --- |
| Fixture | Implemented | No provider network; deterministic local data | Not live production evidence |
| Local stdio | Implemented | The exact release-code-owned first-party child worker uses a trusted HTTP client that validates administrator-approved endpoints before direct sockets over ordinary host routing or an owner-established host VPN | The child is not an OS egress/filesystem/resource sandbox and third-party workers are not admitted; does not create a VPN, use an application proxy, or grant another surface private reachability |
| Customer VPC | Reference implementation | TLS 1.3 mutual-TLS Streamable HTTP inside a customer-controlled deployment | A local integration test is not a deployed or approved customer route; no publisher-hosted route is implied |
| Customer relay | Not implemented | Future fixed-operation outbound relay | Not a general URL/query proxy |
| Publisher hosted | Not implemented | Future explicitly supported public routes | Cannot reach a user's loopback, laptop VPN, or private VPC by default |

The model supplies only profile, scope, operation, and run aliases. The trusted host supplies endpoint, route, tenant, and credential bindings. Redirects are off by default. Missing reachability is `UNSUPPORTED`, `UNAVAILABLE`, or `BLOCKED`; it never falls back to another tenant or relabels fixture data as live.

Endpoint and connected-peer checks are application controls inside trusted bundled code, not an OS egress firewall. A deployment that requires defense-in-depth network containment must supply and test an external deny-default policy.

Endpoint authentication is exactly `NONE`, `BEARER`, `BASIC`, or `MTLS`, using only environment, workload-identity, or broker references. TLS pins a minimum of `TLSv1.2` or `TLSv1.3`; optional custom-CA and SNI settings are also references or reviewed names, never secret values. The runtime enforces the declared `loopback`, `private`, or `public` class against DNS selection and the connected peer.

`direct` and `host_vpn` both mean a direct socket; `host_vpn` relies on an administrator-established private route. `application_proxy` is explicitly `NOT_IMPLEMENTED` and fails with `APPLICATION_PROXY_NOT_IMPLEMENTED`; ambient proxy variables do not provide an implicit fallback.

Before claiming a surface, test its authentication, authorization, TLS, DNS and connected peer, proxy, redirects, tenant pinning, timeout/cancellation, audit, residency, retention, restart, support, and rollback behavior.

The customer-VPC reference is source and test evidence only. It becomes a supported surface only after the customer deployment and its certificate, identity, network, residency, audit, support, and rollback controls are approved.
